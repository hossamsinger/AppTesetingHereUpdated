using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using LearningProject.Data;
using LearningProject.Models;

namespace LearningProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResultController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ResultController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("{userExamId}")]
        public async Task<ActionResult<Result>> GetResult(int userExamId)
        {
            var result = await _context.Results
                                        .Where(r => r.Id == userExamId)
                                        .Include(r => r.ExamVariant)
                                        .FirstOrDefaultAsync();

            if (result == null)
            {
                return NotFound();
            }

            return result;
        }

        [HttpPost("{userExamId}")]
        public async Task<ActionResult<Result>> PostResult(int userExamId)
        {
            var resultExist = await _context.Results.FirstOrDefaultAsync(e => e.UserExamId == userExamId);
            if (resultExist != null){
                return BadRequest(new {
                    message = "user already started the exam !"
                });
            }

            var userExam = await _context.UserExams.Where(e=>e.Id == userExamId).Include(e=>e.Exam).Select(e=> new UserExam {
                Id = e.Id,
                Exam = new Exam {
                    Id = e.Exam.Id,
                    Name = e.Exam.Name,
                    StartDate = e.Exam.StartDate,
                    EndDate = e.Exam.EndDate,
                    ExamDefinitionId = e.Exam.ExamDefinitionId
                }
            }).FirstOrDefaultAsync();

            if (userExam == null)
            {
                return NotFound();
            }

            if (!(userExam.Exam.StartDate >= DateTime.Now && DateTime.Now >= userExam.Exam.StartDate))
            {
                return BadRequest(new {
                    message = "This exam is expired"
                });
            }
            
            var result = new Result{
                UserExamId = userExamId,
                StartDate = DateTime.Now
            };
 
            return result;
        }

    }
}
