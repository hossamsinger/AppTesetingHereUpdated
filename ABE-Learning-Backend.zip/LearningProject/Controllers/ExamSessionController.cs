using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using LearningProject.Data;
using LearningProject.Models;
using LearningProject.Services;

namespace LearningProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExamSessionController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IExamSessionService _examSessionService;


        public ExamSessionController(ApplicationDbContext context, IExamSessionService examSessionService)
        {
            _context = context;
            _examSessionService = examSessionService;
        }

        // Start a new exam session
        [HttpPost("start")]
        public async Task<IActionResult> StartExamSession(int userExamId)
        {
            var sessionId = await _examSessionService.StartExamSession(userExamId);
            return Ok(new { SessionId = sessionId });
        }

        // Get progress for an exam session
        [HttpGet("{resultId}/progress")]
        public async Task<IActionResult> GetExamProgress(int resultId)
        {
            var progress = await _examSessionService.GetExamProgress(resultId);
            if (progress == null) return NotFound("Session not found.");

            return Ok(progress);
        }

        // Get randomized questions for the session
        [HttpGet("{resultId}/questions")]
        public async Task<IActionResult> GetQuestionsInOrder(int resultId)
        {
            var questions = await _examSessionService.GetQuestionsInOrder(resultId);
            if (questions == null) return NotFound("No questions found.");

            return Ok(questions);
        }

        // Submit an answer
        [HttpPost("{resultId}/submit-answer")]
        public async Task<IActionResult> SubmitAnswer(int resultId, int answerId)
        {
            var success = await _examSessionService.SubmitAnswer(resultId, answerId);
            if (!success) return BadRequest("Failed to submit the answer.");

            return Ok("Answer submitted successfully.");
        }

        // Submit final exam
        [HttpPost("{resultId}/submit-final")]
        public async Task<IActionResult> SubmitFinalExam(int resultId)
        {
            var score = await _examSessionService.SubmitFinalExam(resultId);
            return Ok(new { TotalScore = score });
        }



    }
}
