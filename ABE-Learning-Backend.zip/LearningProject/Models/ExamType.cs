namespace LearningProject.Models
{
public class ExamType
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}