using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using LearningProject.Data;
using LearningProject.Dtos;
using LearningProject.Models;
using LearningProject.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http.HttpResults;

namespace ExamApi.Services
{
    public class ExamSessionService : IExamSessionService
    {
        private readonly ApplicationDbContext _context;

        public ExamSessionService(ApplicationDbContext context)
        {
            _context = context;
        }

        // Get Exam Progress
        public async Task<ExamProgressDto> GetExamProgress(int resultId)
        {
            var result = await _context.Results.FindAsync(resultId)?? throw new KeyNotFoundException("Exam Session Not Found.");

            var totalQuestions = result.QuestionOrder!.Split(',').Length;

            var answeredQuestions = await _context.AnswerResults
                .Where(ar => ar.ResultId == resultId && ar.AnswerId != null)
                .Select(ar => ar.Answer!.QuestionId)
                .Distinct()
                .ToListAsync();

            var pendingQuestions = result.QuestionOrder
                .Split(',')
                .Select(int.Parse)
                .Except(answeredQuestions)
                .ToList();

            var score = await _context.AnswerResults
                .Where(ar => ar.ResultId == resultId && ar.Answer!.IsCorrect)
                .SumAsync(ar => ar.Answer!.Question!.Marks);

            return new ExamProgressDto
            {
                TotalQuestions = totalQuestions,
                QuestionsAnswered = answeredQuestions.Count,
                Score = score,
                CompletedQuestions = answeredQuestions,
                PendingQuestions = pendingQuestions
            };
        }

        // Submit Final Exam
        public async Task<int> SubmitFinalExam(int resultId)
        {
            // Calculate total score for the exam
            var finalScore = await _context.AnswerResults
                .Where(ar => ar.ResultId == resultId && ar.Answer!.IsCorrect)
                .SumAsync(ar => ar.Answer!.Question!.Marks);

            return finalScore;
        }

        public async Task<bool> SubmitAnswer(int resultId, int answerId)
        {
            var result = await _context.Results.Include(e => e.ExamVariant).FirstOrDefaultAsync(e => e.Id == resultId) ?? throw new KeyNotFoundException("Exam not found.");
            var examDuration = result.ExamVariant!.ExamDefinition!.Duration;

            if (DateTime.Now > result.StartDate.AddMinutes(examDuration))
            {
                throw new InvalidOperationException("Exam session has expired.");
            }

            var answer = await _context.Answers
                .FirstOrDefaultAsync(a => a.Id == answerId) ?? throw new ArgumentException("Invalid answer ID.");

            // 4. Prevent Duplicate Submissions
            var existingAnswer = await _context.AnswerResults
                .Include(ar => ar.Answer)
                .FirstOrDefaultAsync(ar => ar.ResultId == resultId && ar.Answer!.QuestionId == answer.QuestionId);

            if (existingAnswer != null)
            {
                if (existingAnswer.AnswerId != answerId) // Only replace if different
                {
                    _context.AnswerResults.Remove(existingAnswer); // Remove old answer
                }
                else
                {
                    // The submitted answer is the same as the existing one; no changes needed
                    return true;
                }
            }

            var answerResult = new AnswerResult
            {
                ResultId = resultId,
                AnswerId = answerId
            };

            _context.AnswerResults.Add(answerResult);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<int> StartExamSession(int userExamId)
        {

            var resultExist = await _context.Results.FirstOrDefaultAsync(e => e.UserExamId == userExamId);
            if (resultExist != null)
            {
                throw new InvalidOperationException("user already started the exam !");
            }

            var userExam = await _context.UserExams.Where(e => e.Id == userExamId).Include(e => e.Exam).Select(e => new UserExam
            {
                Id = e.Id,
                Exam = new Exam
                {
                    Id = e.Exam.Id,
                    Name = e.Exam.Name,
                    StartDate = e.Exam.StartDate,
                    EndDate = e.Exam.EndDate,
                    ExamDefinitionId = e.Exam.ExamDefinitionId
                }
            }).FirstOrDefaultAsync() ?? throw new KeyNotFoundException("exam not found !");

            // pick a random exam variant
            Random random = new Random();
            var examVariantList = await _context.ExamVariants.Where(e => e.ExamDefinitionId == userExam.Exam.ExamDefinitionId).Select(e => e.Id).ToListAsync();
            var examVariantId = examVariantList[random.Next(examVariantList.Count)];
            // Fetch questions and shuffle for randomized order
            var questionIds = await _context.ExamQuestions
                .Where(q => q.ExamVariantId == examVariantId) // Replace with exam-specific logic
                .Select(q => q.QuestionId)
                .ToListAsync();

            var randomOrder = questionIds.OrderBy(q => Guid.NewGuid()).ToList();
            var questionOrder = string.Join(",", randomOrder);

            // Calculate Start and End Time
            var startTime = DateTime.Now;
            // var endTime = startTime.AddMinutes(durationMinutes);

            if (!(userExam.Exam.StartDate >= DateTime.Now && DateTime.Now >= userExam.Exam.StartDate))
            {
                throw new InvalidOperationException("This exam is expired !");
            }

            var result = new Result
            {
                UserExamId = userExamId,
                StartDate = DateTime.Now,
                ExamVariantId = examVariantId,
                QuestionOrder = questionOrder,
            };


            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return result.Id; // Return session ID
        }

        public async Task<bool> IsExamActive(int resultId)
        {
            var result = await _context.Results.FindAsync(resultId);
            if (result == null) return false;

            var currentTime = DateTime.Now;
            return currentTime >= result.StartDate && currentTime <= result.EndDate;
        }

        public async Task<ActionResult<IEnumerable<Question>>> GetQuestionsInOrder(int resultId)
        {
            var result = await _context.Results.FindAsync(resultId)?? throw new KeyNotFoundException("Exam Session Not Found.");
            // Retrieve IDs in the saved order
            var questionIds = result.QuestionOrder!
                .Split(',')
                .Select(int.Parse)
                .ToList();

            // Fetch questions in the specific order
            var questions = await _context.Questions
                .Where(q => questionIds.Contains(q.Id))
                .OrderBy(q => questionIds.IndexOf(q.Id)) // Maintain order
                .ToListAsync();

            return questions;
        }

        public async Task<ActionResult<Question>> GetQuestion(int resultId, int questionId)
        {
            var result = await _context.Results.FindAsync(resultId)?? throw new KeyNotFoundException("Exam Session Not Found.");

            // Retrieve IDs in the saved order
            var questionIds = result.QuestionOrder!
                .Split(',')
                .Select(int.Parse)
                .ToList();

            // Fetch questions in the specific order
            var question = await _context.Questions
            .Where(e=>e.Id == questionId && questionIds.Contains(questionId))
            .Include(e=>e.Answers)
            .Select(e=> new Question {
                Id = e.Id,
                Name = e.Name,
                Answers = (ICollection<Answer>)e.Answers!.Select(a=> new Answer{
                    Id = a.Id,
                    Name = a.Name
                })
            }).FirstOrDefaultAsync()?? throw new KeyNotFoundException("Question Not Found.");

            return question;
        }

    }
}
