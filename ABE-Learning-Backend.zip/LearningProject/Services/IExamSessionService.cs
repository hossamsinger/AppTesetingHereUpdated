using System.Collections.Generic;
using System.Threading.Tasks;
using LearningProject.Dtos;
using LearningProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace LearningProject.Services
{
    public interface IExamSessionService
    {
        Task<ExamProgressDto> GetExamProgress(int resultId);
        Task<int> SubmitFinalExam(int resultId);
        Task<bool> SubmitAnswer(int resultId, int answerId);
        Task<bool> IsExamActive(int resultId);
        Task<ActionResult<IEnumerable<Question>>> GetQuestionsInOrder(int resultId);
        Task<ActionResult<Question>> GetQuestion(int resultId, int questionId);
        Task<int> StartExamSession(int userExamId);

    }
}
