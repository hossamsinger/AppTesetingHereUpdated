using System.Collections.Generic;

namespace LearningProject.Dtos
{
    public class ExamProgressDto
    {
        public int TotalQuestions { get; set; }
        public int QuestionsAnswered { get; set; }
        public int QuestionsRemaining => TotalQuestions - QuestionsAnswered;

        public int Score { get; set; } // Current score
        public List<int> CompletedQuestions { get; set; } // List of completed question IDs
        public List<int> PendingQuestions { get; set; } // List of pending question IDs
    }
}
