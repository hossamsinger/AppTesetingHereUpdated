public class ErrorDetails
{
    public int StatusCode { get; set; }
    public string? Message { get; set; }
    public string? Details { get; set; } // Optional for debugging

    public override string ToString()
    {
        return System.Text.Json.JsonSerializer.Serialize(this);
    }
}
