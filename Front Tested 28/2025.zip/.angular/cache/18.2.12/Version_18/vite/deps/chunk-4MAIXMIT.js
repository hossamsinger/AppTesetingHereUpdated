import {
  config_default,
  errors_default,
  extend,
  extendFromObject,
  init_config,
  init_console,
  init_errors,
  init_extend,
  init_type,
  isDeferred,
  isDefined,
  isFunction,
  isNumeric,
  isObject,
  isPlainObject,
  isPromise,
  isString,
  isWindow,
  logger,
  type
} from "./chunk-ND5ICVCX.js";
import {
  __esm,
  __export
} from "./chunk-WOR4A3D2.js";

// node_modules/devextreme/esm/core/utils/callbacks.js
var Callback, Callbacks, callbacks_default;
var init_callbacks = __esm({
  "node_modules/devextreme/esm/core/utils/callbacks.js"() {
    Callback = function(options) {
      this._options = options || {};
      this._list = [];
      this._queue = [];
      this._firing = false;
      this._fired = false;
      this._firingIndexes = [];
    };
    Callback.prototype._fireCore = function(context, args) {
      const firingIndexes = this._firingIndexes;
      const list = this._list;
      const stopOnFalse = this._options.stopOnFalse;
      const step = firingIndexes.length;
      for (firingIndexes[step] = 0; firingIndexes[step] < list.length; firingIndexes[step]++) {
        const result = list[firingIndexes[step]].apply(context, args);
        if (false === result && stopOnFalse) {
          break;
        }
      }
      firingIndexes.pop();
    };
    Callback.prototype.add = function(fn) {
      if ("function" === typeof fn && (!this._options.unique || !this.has(fn))) {
        this._list.push(fn);
      }
      return this;
    };
    Callback.prototype.remove = function(fn) {
      const list = this._list;
      const firingIndexes = this._firingIndexes;
      const index = list.indexOf(fn);
      if (index > -1) {
        list.splice(index, 1);
        if (this._firing && firingIndexes.length) {
          for (let step = 0; step < firingIndexes.length; step++) {
            if (index <= firingIndexes[step]) {
              firingIndexes[step]--;
            }
          }
        }
      }
      return this;
    };
    Callback.prototype.has = function(fn) {
      const list = this._list;
      return fn ? list.indexOf(fn) > -1 : !!list.length;
    };
    Callback.prototype.empty = function(fn) {
      this._list = [];
      return this;
    };
    Callback.prototype.fireWith = function(context, args) {
      const queue = this._queue;
      args = args || [];
      args = args.slice ? args.slice() : args;
      if (this._options.syncStrategy) {
        this._firing = true;
        this._fireCore(context, args);
      } else {
        queue.push([context, args]);
        if (this._firing) {
          return;
        }
        this._firing = true;
        while (queue.length) {
          const memory = queue.shift();
          this._fireCore(memory[0], memory[1]);
        }
      }
      this._firing = false;
      this._fired = true;
      return this;
    };
    Callback.prototype.fire = function() {
      this.fireWith(this, arguments);
    };
    Callback.prototype.fired = function() {
      return this._fired;
    };
    Callbacks = function(options) {
      return new Callback(options);
    };
    callbacks_default = Callbacks;
  }
});

// node_modules/devextreme/esm/core/utils/deferred.js
var deferred_exports = {};
__export(deferred_exports, {
  Deferred: () => Deferred,
  fromPromise: () => fromPromise,
  setStrategy: () => setStrategy,
  when: () => when
});
function fromPromise(promise, context) {
  if (isDeferred(promise)) {
    return promise;
  } else if (isPromise(promise)) {
    const d = new DeferredObj();
    promise.then(function() {
      d.resolveWith.apply(d, [context].concat([[].slice.call(arguments)]));
    }, function() {
      d.rejectWith.apply(d, [context].concat([[].slice.call(arguments)]));
    });
    return d;
  }
  return new DeferredObj().resolveWith(context, [promise]);
}
function setStrategy(value) {
  DeferredObj = value.Deferred;
  whenFunc = value.when;
}
function Deferred() {
  return new DeferredObj();
}
function when() {
  return whenFunc.apply(this, arguments);
}
var deferredConfig, DeferredObj, whenFunc;
var init_deferred = __esm({
  "node_modules/devextreme/esm/core/utils/deferred.js"() {
    init_type();
    init_extend();
    init_callbacks();
    deferredConfig = [{
      method: "resolve",
      handler: "done",
      state: "resolved"
    }, {
      method: "reject",
      handler: "fail",
      state: "rejected"
    }, {
      method: "notify",
      handler: "progress"
    }];
    DeferredObj = function() {
      const that = this;
      this._state = "pending";
      this._promise = {};
      deferredConfig.forEach(function(config) {
        const methodName = config.method;
        this[methodName + "Callbacks"] = callbacks_default();
        this[methodName] = function() {
          return this[methodName + "With"](this._promise, arguments);
        }.bind(this);
        this._promise[config.handler] = function(handler) {
          if (!handler) {
            return this;
          }
          const callbacks2 = that[methodName + "Callbacks"];
          if (callbacks2.fired()) {
            handler.apply(that[methodName + "Context"], that[methodName + "Args"]);
          } else {
            callbacks2.add(function(context, args) {
              handler.apply(context, args);
            }.bind(this));
          }
          return this;
        };
      }.bind(this));
      this._promise.always = function(handler) {
        return this.done(handler).fail(handler);
      };
      this._promise.catch = function(handler) {
        return this.then(null, handler);
      };
      this._promise.then = function(resolve, reject) {
        const result = new DeferredObj();
        ["done", "fail"].forEach(function(method) {
          const callback = "done" === method ? resolve : reject;
          this[method](function() {
            if (!callback) {
              result["done" === method ? "resolve" : "reject"].apply(this, arguments);
              return;
            }
            const callbackResult = callback && callback.apply(this, arguments);
            if (isDeferred(callbackResult)) {
              callbackResult.done(result.resolve).fail(result.reject);
            } else if (isPromise(callbackResult)) {
              callbackResult.then(result.resolve, result.reject);
            } else {
              result.resolve.apply(this, isDefined(callbackResult) ? [callbackResult] : arguments);
            }
          });
        }.bind(this));
        return result.promise();
      };
      this._promise.state = function() {
        return that._state;
      };
      this._promise.promise = function(args) {
        return args ? extend(args, that._promise) : that._promise;
      };
      this._promise.promise(this);
    };
    deferredConfig.forEach(function(config) {
      const methodName = config.method;
      const state = config.state;
      DeferredObj.prototype[methodName + "With"] = function(context, args) {
        const callbacks2 = this[methodName + "Callbacks"];
        if ("pending" === this.state()) {
          this[methodName + "Args"] = args;
          this[methodName + "Context"] = context;
          if (state) {
            this._state = state;
          }
          callbacks2.fire(context, args);
          if ("pending" !== state) {
            this.resolveCallbacks.empty();
            this.rejectCallbacks.empty();
          }
        }
        return this;
      };
    });
    whenFunc = function() {
      if (1 === arguments.length) {
        return fromPromise(arguments[0]);
      }
      const values = [].slice.call(arguments);
      const contexts = [];
      let resolvedCount = 0;
      const deferred = new DeferredObj();
      const updateState = function(i) {
        return function(value) {
          contexts[i] = this;
          values[i] = arguments.length > 1 ? [].slice.call(arguments) : value;
          resolvedCount++;
          if (resolvedCount === values.length) {
            deferred.resolveWith(contexts, values);
          }
        };
      };
      for (let i = 0; i < values.length; i++) {
        if (isDeferred(values[i])) {
          values[i].promise().done(updateState(i)).fail(deferred.reject);
        } else {
          resolvedCount++;
        }
      }
      if (resolvedCount === values.length) {
        deferred.resolveWith(contexts, values);
      }
      return deferred.promise();
    };
  }
});

// node_modules/@babel/runtime/helpers/esm/extends.js
function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
var init_extends = __esm({
  "node_modules/@babel/runtime/helpers/esm/extends.js"() {
  }
});

// node_modules/devextreme/esm/core/class.js
var wrapOverridden, clonePrototype, redefine, include, subclassOf, abstract, copyStatic, classImpl, class_default;
var init_class = __esm({
  "node_modules/devextreme/esm/core/class.js"() {
    init_errors();
    init_type();
    wrapOverridden = function(baseProto, methodName, method) {
      return function() {
        const prevCallBase = this.callBase;
        this.callBase = baseProto[methodName];
        try {
          return method.apply(this, arguments);
        } finally {
          this.callBase = prevCallBase;
        }
      };
    };
    clonePrototype = function(obj) {
      const func = function() {
      };
      func.prototype = obj.prototype;
      return new func();
    };
    redefine = function(members) {
      const that = this;
      let overridden;
      let memberName;
      let member;
      if (!members) {
        return that;
      }
      for (memberName in members) {
        member = members[memberName];
        overridden = "function" === typeof that.prototype[memberName] && "function" === typeof member;
        that.prototype[memberName] = overridden ? wrapOverridden(that.parent.prototype, memberName, member) : member;
      }
      return that;
    };
    include = function() {
      const classObj = this;
      let argument;
      let name;
      let i;
      const hasClassObjOwnProperty = Object.prototype.hasOwnProperty.bind(classObj);
      const isES6Class = !hasClassObjOwnProperty("_includedCtors") && !hasClassObjOwnProperty("_includedPostCtors");
      if (isES6Class) {
        classObj._includedCtors = classObj._includedCtors.slice(0);
        classObj._includedPostCtors = classObj._includedPostCtors.slice(0);
      }
      for (i = 0; i < arguments.length; i++) {
        argument = arguments[i];
        if (argument.ctor) {
          classObj._includedCtors.push(argument.ctor);
        }
        if (argument.postCtor) {
          classObj._includedPostCtors.push(argument.postCtor);
        }
        for (name in argument) {
          if ("ctor" === name || "postCtor" === name || "default" === name) {
            continue;
          }
          classObj.prototype[name] = argument[name];
        }
      }
      return classObj;
    };
    subclassOf = function(parentClass) {
      const hasParentProperty = Object.prototype.hasOwnProperty.bind(this)("parent");
      const isES6Class = !hasParentProperty && this.parent;
      if (isES6Class) {
        const baseClass = Object.getPrototypeOf(this);
        return baseClass === parentClass || baseClass.subclassOf(parentClass);
      } else {
        if (this.parent === parentClass) {
          return true;
        }
        if (!this.parent || !this.parent.subclassOf) {
          return false;
        }
        return this.parent.subclassOf(parentClass);
      }
    };
    abstract = function() {
      throw errors_default.Error("E0001");
    };
    copyStatic = /* @__PURE__ */ function() {
      const hasOwn = Object.prototype.hasOwnProperty;
      return function(source, destination) {
        for (const key in source) {
          if (!hasOwn.call(source, key)) {
            return;
          }
          destination[key] = source[key];
        }
      };
    }();
    classImpl = function() {
    };
    classImpl.inherit = function(members) {
      const inheritor = function() {
        if (!this || isWindow(this) || "function" !== typeof this.constructor) {
          throw errors_default.Error("E0003");
        }
        const instance = this;
        const ctor = instance.ctor;
        const includedCtors = instance.constructor._includedCtors;
        const includedPostCtors = instance.constructor._includedPostCtors;
        let i;
        for (i = 0; i < includedCtors.length; i++) {
          includedCtors[i].call(instance);
        }
        if (ctor) {
          ctor.apply(instance, arguments);
        }
        for (i = 0; i < includedPostCtors.length; i++) {
          includedPostCtors[i].call(instance);
        }
      };
      inheritor.prototype = clonePrototype(this);
      copyStatic(this, inheritor);
      inheritor.inherit = this.inherit;
      inheritor.abstract = abstract;
      inheritor.redefine = redefine;
      inheritor.include = include;
      inheritor.subclassOf = subclassOf;
      inheritor.parent = this;
      inheritor._includedCtors = this._includedCtors ? this._includedCtors.slice(0) : [];
      inheritor._includedPostCtors = this._includedPostCtors ? this._includedPostCtors.slice(0) : [];
      inheritor.prototype.constructor = inheritor;
      inheritor.redefine(members);
      return inheritor;
    };
    classImpl.abstract = abstract;
    class_default = classImpl;
  }
});

// node_modules/devextreme/esm/core/guid.js
var Guid, guid_default;
var init_guid = __esm({
  "node_modules/devextreme/esm/core/guid.js"() {
    init_class();
    Guid = class_default.inherit({
      ctor: function(value) {
        if (value) {
          value = String(value);
        }
        this._value = this._normalize(value || this._generate());
      },
      _normalize: function(value) {
        value = value.replace(/[^a-f0-9]/gi, "").toLowerCase();
        while (value.length < 32) {
          value += "0";
        }
        return [value.substr(0, 8), value.substr(8, 4), value.substr(12, 4), value.substr(16, 4), value.substr(20, 12)].join("-");
      },
      _generate: function() {
        let value = "";
        for (let i = 0; i < 32; i++) {
          value += Math.round(15 * Math.random()).toString(16);
        }
        return value;
      },
      toString: function() {
        return this._value;
      },
      valueOf: function() {
        return this._value;
      },
      toJSON: function() {
        return this._value;
      }
    });
    guid_default = Guid;
  }
});

// node_modules/devextreme/esm/core/utils/iterator.js
var map, each, reverseEach;
var init_iterator = __esm({
  "node_modules/devextreme/esm/core/utils/iterator.js"() {
    map = (values, callback) => {
      if (Array.isArray(values)) {
        return values.map(callback);
      }
      const result = [];
      for (const key in values) {
        result.push(callback(values[key], key));
      }
      return result;
    };
    each = (values, callback) => {
      if (!values) {
        return;
      }
      if ("length" in values) {
        for (let i = 0; i < values.length; i++) {
          if (false === callback.call(values[i], i, values[i])) {
            break;
          }
        }
      } else {
        for (const key in values) {
          if (false === callback.call(values[key], key, values[key])) {
            break;
          }
        }
      }
      return values;
    };
    reverseEach = (array, callback) => {
      if (!array || !("length" in array) || 0 === array.length) {
        return;
      }
      for (let i = array.length - 1; i >= 0; i--) {
        if (false === callback.call(array[i], i, array[i])) {
          break;
        }
      }
    };
  }
});

// node_modules/devextreme/esm/core/utils/dependency_injector.js
function dependency_injector_default(object) {
  const BaseClass = class_default.inherit(object);
  let InjectedClass = BaseClass;
  let instance = new InjectedClass(object);
  const initialFields = {};
  const injectFields = function(injectionObject, initial) {
    each(injectionObject, function(key) {
      if (isFunction(instance[key])) {
        if (initial || !object[key]) {
          object[key] = function() {
            return instance[key].apply(object, arguments);
          };
        }
      } else {
        if (initial) {
          initialFields[key] = object[key];
        }
        object[key] = instance[key];
      }
    });
  };
  injectFields(object, true);
  object.inject = function(injectionObject) {
    InjectedClass = InjectedClass.inherit(injectionObject);
    instance = new InjectedClass();
    injectFields(injectionObject);
  };
  object.resetInjection = function() {
    extend(object, initialFields);
    InjectedClass = BaseClass;
    instance = new BaseClass();
  };
  return object;
}
var init_dependency_injector = __esm({
  "node_modules/devextreme/esm/core/utils/dependency_injector.js"() {
    init_extend();
    init_type();
    init_iterator();
    init_class();
  }
});

// node_modules/devextreme/esm/core/utils/variable_wrapper.js
var variable_wrapper_default;
var init_variable_wrapper = __esm({
  "node_modules/devextreme/esm/core/utils/variable_wrapper.js"() {
    init_console();
    init_dependency_injector();
    variable_wrapper_default = dependency_injector_default({
      isWrapped: function() {
        return false;
      },
      isWritableWrapped: function() {
        return false;
      },
      wrap: function(value) {
        return value;
      },
      unwrap: function(value) {
        return value;
      },
      assign: function() {
        logger.error("Method 'assign' should not be used for not wrapped variables. Use 'isWrapped' method for ensuring.");
      }
    });
  }
});

// node_modules/devextreme/esm/core/utils/object.js
var clone, orderEach, assignValueToProperty, deepExtendArraySafe;
var init_object = __esm({
  "node_modules/devextreme/esm/core/utils/object.js"() {
    init_type();
    init_variable_wrapper();
    clone = /* @__PURE__ */ function() {
      function Clone() {
      }
      return function(obj) {
        Clone.prototype = obj;
        return new Clone();
      };
    }();
    orderEach = function(map2, func) {
      const keys = [];
      let key;
      let i;
      for (key in map2) {
        if (Object.prototype.hasOwnProperty.call(map2, key)) {
          keys.push(key);
        }
      }
      keys.sort(function(x, y) {
        const isNumberX = isNumeric(x);
        const isNumberY = isNumeric(y);
        if (isNumberX && isNumberY) {
          return x - y;
        }
        if (isNumberX && !isNumberY) {
          return -1;
        }
        if (!isNumberX && isNumberY) {
          return 1;
        }
        if (x < y) {
          return -1;
        }
        if (x > y) {
          return 1;
        }
        return 0;
      });
      for (i = 0; i < keys.length; i++) {
        key = keys[i];
        func(key, map2[key]);
      }
    };
    assignValueToProperty = function(target, property, value, assignByReference) {
      if (!assignByReference && variable_wrapper_default.isWrapped(target[property])) {
        variable_wrapper_default.assign(target[property], value);
      } else {
        target[property] = value;
      }
    };
    deepExtendArraySafe = function(target, changes, extendComplexObject, assignByReference) {
      let prevValue;
      let newValue;
      for (const name in changes) {
        prevValue = target[name];
        newValue = changes[name];
        if ("__proto__" === name || "constructor" === name || target === newValue) {
          continue;
        }
        if (isPlainObject(newValue)) {
          const goDeeper = extendComplexObject ? isObject(prevValue) : isPlainObject(prevValue);
          newValue = deepExtendArraySafe(goDeeper ? prevValue : {}, newValue, extendComplexObject, assignByReference);
        }
        if (void 0 !== newValue && prevValue !== newValue) {
          assignValueToProperty(target, name, newValue, assignByReference);
        }
      }
      return target;
    };
  }
});

// node_modules/devextreme/esm/core/utils/data.js
function unwrap(value, options) {
  return options.unwrapObservables ? unwrapVariable(value) : value;
}
function combineGetters(getters) {
  const compiledGetters = {};
  for (let i = 0, l = getters.length; i < l; i++) {
    const getter = getters[i];
    compiledGetters[getter] = compileGetter(getter);
  }
  return function(obj, options) {
    let result;
    each(compiledGetters, function(name) {
      const value = this(obj, options);
      if (void 0 === value) {
        return;
      }
      let current = result || (result = {});
      const path = name.split(".");
      const last = path.length - 1;
      for (let i = 0; i < last; i++) {
        const pathItem = path[i];
        if (!(pathItem in current)) {
          current[pathItem] = {};
        }
        current = current[pathItem];
      }
      current[path[last]] = value;
    });
    return result;
  };
}
function toLowerCase(value, options) {
  return null !== options && void 0 !== options && options.locale ? value.toLocaleLowerCase(options.locale) : value.toLowerCase();
}
function toUpperCase(value, options) {
  return null !== options && void 0 !== options && options.locale ? value.toLocaleUpperCase(options.locale) : value.toUpperCase();
}
var unwrapVariable, isWrapped, assign, bracketsToDots, getPathParts, readPropValue, assignPropValue, prepareOptions, compileGetter, ensurePropValueDefined, compileSetter, toComparable;
var init_data = __esm({
  "node_modules/devextreme/esm/core/utils/data.js"() {
    init_errors();
    init_class();
    init_object();
    init_type();
    init_iterator();
    init_variable_wrapper();
    unwrapVariable = variable_wrapper_default.unwrap;
    isWrapped = variable_wrapper_default.isWrapped;
    assign = variable_wrapper_default.assign;
    bracketsToDots = function(expr) {
      return expr.replace(/\[/g, ".").replace(/\]/g, "");
    };
    getPathParts = function(name) {
      return bracketsToDots(name).split(".");
    };
    readPropValue = function(obj, propName, options) {
      options = options || {};
      if ("this" === propName) {
        return unwrap(obj, options);
      }
      return unwrap(obj[propName], options);
    };
    assignPropValue = function(obj, propName, value, options) {
      if ("this" === propName) {
        throw new errors_default.Error("E4016");
      }
      const propValue = obj[propName];
      if (options.unwrapObservables && isWrapped(propValue)) {
        assign(propValue, value);
      } else {
        obj[propName] = value;
      }
    };
    prepareOptions = function(options) {
      options = options || {};
      options.unwrapObservables = void 0 !== options.unwrapObservables ? options.unwrapObservables : true;
      return options;
    };
    compileGetter = function(expr) {
      if (arguments.length > 1) {
        expr = [].slice.call(arguments);
      }
      if (!expr || "this" === expr) {
        return function(obj) {
          return obj;
        };
      }
      if ("string" === typeof expr) {
        const path = getPathParts(expr);
        return function(obj, options) {
          options = prepareOptions(options);
          const functionAsIs = options.functionsAsIs;
          const hasDefaultValue = "defaultValue" in options;
          let current = unwrap(obj, options);
          for (let i = 0; i < path.length; i++) {
            if (!current) {
              if (null == current && hasDefaultValue) {
                return options.defaultValue;
              }
              break;
            }
            const pathPart = path[i];
            if (hasDefaultValue && isObject(current) && !(pathPart in current)) {
              return options.defaultValue;
            }
            let next = unwrap(current[pathPart], options);
            if (!functionAsIs && isFunction(next)) {
              next = next.call(current);
            }
            current = next;
          }
          return current;
        };
      }
      if (Array.isArray(expr)) {
        return combineGetters(expr);
      }
      if (isFunction(expr)) {
        return expr;
      }
    };
    ensurePropValueDefined = function(obj, propName, value, options) {
      if (isDefined(value)) {
        return value;
      }
      const newValue = {};
      assignPropValue(obj, propName, newValue, options);
      return newValue;
    };
    compileSetter = function(expr) {
      expr = getPathParts(expr || "this");
      const lastLevelIndex = expr.length - 1;
      return function(obj, value, options) {
        options = prepareOptions(options);
        let currentValue = unwrap(obj, options);
        expr.forEach(function(propertyName, levelIndex) {
          let propertyValue = readPropValue(currentValue, propertyName, options);
          const isPropertyFunc = !options.functionsAsIs && isFunction(propertyValue) && !isWrapped(propertyValue);
          if (levelIndex === lastLevelIndex) {
            if (options.merge && isPlainObject(value) && (!isDefined(propertyValue) || isPlainObject(propertyValue))) {
              propertyValue = ensurePropValueDefined(currentValue, propertyName, propertyValue, options);
              deepExtendArraySafe(propertyValue, value, false, true);
            } else if (isPropertyFunc) {
              currentValue[propertyName](value);
            } else {
              assignPropValue(currentValue, propertyName, value, options);
            }
          } else {
            propertyValue = ensurePropValueDefined(currentValue, propertyName, propertyValue, options);
            if (isPropertyFunc) {
              propertyValue = propertyValue.call(currentValue);
            }
            currentValue = propertyValue;
          }
        });
      };
    };
    toComparable = function(value, caseSensitive) {
      var _options$collatorOpti;
      let options = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      if (value instanceof Date) {
        return value.getTime();
      }
      if (value && value instanceof class_default && value.valueOf) {
        return value.valueOf();
      }
      const isCaseSensitive = "case" === (null === options || void 0 === options || null === (_options$collatorOpti = options.collatorOptions) || void 0 === _options$collatorOpti ? void 0 : _options$collatorOpti.sensitivity) || caseSensitive;
      if (!isCaseSensitive && "string" === typeof value) {
        var _options$collatorOpti2, _options$locale;
        if ("base" === (null === options || void 0 === options || null === (_options$collatorOpti2 = options.collatorOptions) || void 0 === _options$collatorOpti2 ? void 0 : _options$collatorOpti2.sensitivity)) {
          const REMOVE_DIACRITICAL_MARKS_REGEXP = /[\u0300-\u036f]/g;
          value = value.normalize("NFD").replace(REMOVE_DIACRITICAL_MARKS_REGEXP, "");
        }
        const locale = null === options || void 0 === options || null === (_options$locale = options.locale) || void 0 === _options$locale ? void 0 : _options$locale.toLowerCase();
        const useUpperCase = locale && !!["hy", "el"].find((code) => locale === code || locale.startsWith(`${code}-`));
        return (useUpperCase ? toUpperCase : toLowerCase)(value, options);
      }
      return value;
    };
  }
});

// node_modules/devextreme/esm/core/utils/common.js
var ensureDefined, executeAsync, delayedFuncs, delayedNames, delayedDeferreds, executingName, deferExecute, deferRender, deferUpdate, deferRenderer, deferUpdater, findBestMatches, match, splitPair, normalizeKey, pairToObject, getKeyHash, escapeRegExp, applyServerDecimalSeparator, noop, asyncNoop, grep, compareArrays, compareObjects, DEFAULT_EQUAL_BY_VALUE_OPTS, compareByValue, equalByValue;
var init_common = __esm({
  "node_modules/devextreme/esm/core/utils/common.js"() {
    init_extends();
    init_config();
    init_guid();
    init_deferred();
    init_data();
    init_iterator();
    init_type();
    ensureDefined = function(value, defaultValue) {
      return isDefined(value) ? value : defaultValue;
    };
    executeAsync = function(action, context) {
      const deferred = new Deferred();
      const normalizedContext = context || this;
      const task = {
        promise: deferred.promise(),
        abort: function() {
          clearTimeout(timerId);
          deferred.rejectWith(normalizedContext);
        }
      };
      const timerId = (arguments[2] || setTimeout)(function() {
        const result = action.call(normalizedContext);
        if (result && result.done && isFunction(result.done)) {
          result.done(function() {
            deferred.resolveWith(normalizedContext);
          });
        } else {
          deferred.resolveWith(normalizedContext);
        }
      }, "number" === typeof context ? context : 0);
      return task;
    };
    delayedFuncs = [];
    delayedNames = [];
    delayedDeferreds = [];
    deferExecute = function(name, func, deferred) {
      if (executingName && executingName !== name) {
        delayedFuncs.push(func);
        delayedNames.push(name);
        deferred = deferred || new Deferred();
        delayedDeferreds.push(deferred);
        return deferred;
      } else {
        const oldExecutingName = executingName;
        const currentDelayedCount = delayedDeferreds.length;
        executingName = name;
        let result = func();
        if (!result) {
          if (delayedDeferreds.length > currentDelayedCount) {
            result = when.apply(this, delayedDeferreds.slice(currentDelayedCount));
          } else if (deferred) {
            deferred.resolve();
          }
        }
        executingName = oldExecutingName;
        if (deferred && result && result.done) {
          result.done(deferred.resolve).fail(deferred.reject);
        }
        if (!executingName && delayedFuncs.length) {
          ("render" === delayedNames.shift() ? deferRender : deferUpdate)(delayedFuncs.shift(), delayedDeferreds.shift());
        }
        return result || when();
      }
    };
    deferRender = function(func, deferred) {
      return deferExecute("render", func, deferred);
    };
    deferUpdate = function(func, deferred) {
      return deferExecute("update", func, deferred);
    };
    deferRenderer = function(func) {
      return function() {
        const that = this;
        return deferExecute("render", function() {
          return func.call(that);
        });
      };
    };
    deferUpdater = function(func) {
      return function() {
        const that = this;
        return deferExecute("update", function() {
          return func.call(that);
        });
      };
    };
    findBestMatches = function(targetFilter, items, mapFn) {
      const bestMatches = [];
      let maxMatchCount = 0;
      each(items, (index, itemSrc) => {
        let matchCount = 0;
        const item = mapFn ? mapFn(itemSrc) : itemSrc;
        each(targetFilter, (paramName, targetValue) => {
          const value = item[paramName];
          if (void 0 === value) {
            return;
          }
          if (match(value, targetValue)) {
            matchCount++;
            return;
          }
          matchCount = -1;
          return false;
        });
        if (matchCount < maxMatchCount) {
          return;
        }
        if (matchCount > maxMatchCount) {
          bestMatches.length = 0;
          maxMatchCount = matchCount;
        }
        bestMatches.push(itemSrc);
      });
      return bestMatches;
    };
    match = function(value, targetValue) {
      if (Array.isArray(value) && Array.isArray(targetValue)) {
        let mismatch = false;
        each(value, (index, valueItem) => {
          if (valueItem !== targetValue[index]) {
            mismatch = true;
            return false;
          }
        });
        if (mismatch) {
          return false;
        }
        return true;
      }
      if (value === targetValue) {
        return true;
      }
      return false;
    };
    splitPair = function(raw) {
      switch (type(raw)) {
        case "string":
          return raw.split(/\s+/, 2);
        case "object":
          return [raw.x ?? raw.h, raw.y ?? raw.v];
        case "number":
          return [raw];
        case "array":
          return raw;
        default:
          return null;
      }
    };
    normalizeKey = function(id) {
      let key = isString(id) ? id : id.toString();
      const arr = key.match(/[^a-zA-Z0-9_]/g);
      arr && each(arr, (_, sign) => {
        key = key.replace(sign, "__" + sign.charCodeAt() + "__");
      });
      return key;
    };
    pairToObject = function(raw, preventRound) {
      const pair = splitPair(raw);
      let h = preventRound ? parseFloat(pair && pair[0]) : parseInt(pair && pair[0], 10);
      let v = preventRound ? parseFloat(pair && pair[1]) : parseInt(pair && pair[1], 10);
      if (!isFinite(h)) {
        h = 0;
      }
      if (!isFinite(v)) {
        v = h;
      }
      return {
        h,
        v
      };
    };
    getKeyHash = function(key) {
      if (key instanceof guid_default) {
        return key.toString();
      } else if (isObject(key) || Array.isArray(key)) {
        try {
          const keyHash = JSON.stringify(key);
          return "{}" === keyHash ? key : keyHash;
        } catch (e) {
          return key;
        }
      }
      return key;
    };
    escapeRegExp = function(string) {
      return string.replace(/[[\]{}\-()*+?.\\^$|\s]/g, "\\$&");
    };
    applyServerDecimalSeparator = function(value) {
      const separator = config_default().serverDecimalSeparator;
      if (isDefined(value)) {
        value = value.toString().replace(".", separator);
      }
      return value;
    };
    noop = function() {
    };
    asyncNoop = function() {
      return new Deferred().resolve().promise();
    };
    grep = function(elements, checkFunction, invert) {
      const result = [];
      let check;
      const expectedCheck = !invert;
      for (let i = 0; i < elements.length; i++) {
        check = !!checkFunction(elements[i], i);
        if (check === expectedCheck) {
          result.push(elements[i]);
        }
      }
      return result;
    };
    compareArrays = (array1, array2, depth, options) => {
      if (array1.length !== array2.length) {
        return false;
      }
      return !array1.some((item, idx) => !compareByValue(item, array2[idx], depth + 1, _extends({}, options, {
        strict: true
      })));
    };
    compareObjects = (object1, object2, depth, options) => {
      const keys1 = Object.keys(object1);
      const keys2 = Object.keys(object2);
      if (keys1.length !== keys2.length) {
        return false;
      }
      const keys2Set = new Set(keys2);
      return !keys1.some((key) => !keys2Set.has(key) || !compareByValue(object1[key], object2[key], depth + 1, options));
    };
    DEFAULT_EQUAL_BY_VALUE_OPTS = {
      maxDepth: 3,
      strict: true
    };
    compareByValue = (value1, value2, depth, options) => {
      const {
        strict,
        maxDepth
      } = options;
      const comparable1 = toComparable(value1, true);
      const comparable2 = toComparable(value2, true);
      const comparisonResult = strict ? comparable1 === comparable2 : comparable1 == comparable2;
      switch (true) {
        case comparisonResult:
        case depth >= maxDepth:
          return true;
        case (isObject(comparable1) && isObject(comparable2)):
          return compareObjects(comparable1, comparable2, depth, options);
        case (Array.isArray(comparable1) && Array.isArray(comparable2)):
          return compareArrays(comparable1, comparable2, depth, options);
        default:
          return false;
      }
    };
    equalByValue = function(value1, value2) {
      let options = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : DEFAULT_EQUAL_BY_VALUE_OPTS;
      const compareOptions = _extends({}, DEFAULT_EQUAL_BY_VALUE_OPTS, options);
      return compareByValue(value1, value2, 0, compareOptions);
    };
  }
});

// node_modules/devextreme/esm/core/utils/shadow_dom.js
function createConstructedStyleSheet(rootNode) {
  try {
    return new CSSStyleSheet();
  } catch (err) {
    const styleElement = rootNode.ownerDocument.createElement("style");
    rootNode.appendChild(styleElement);
    return styleElement.sheet;
  }
}
function processRules(targetStyleSheet, styleSheets, needApplyAllStyles) {
  for (let i = 0; i < styleSheets.length; i++) {
    const sheet = styleSheets[i];
    try {
      for (let j = 0; j < sheet.cssRules.length; j++) {
        insertRule(targetStyleSheet, sheet.cssRules[j], needApplyAllStyles);
      }
    } catch (err) {
    }
  }
}
function insertRule(targetStyleSheet, rule, needApplyAllStyles) {
  var _rule$selectorText, _rule$cssRules, _rule$name, _rule$style;
  const isDxRule = needApplyAllStyles || (null === (_rule$selectorText = rule.selectorText) || void 0 === _rule$selectorText ? void 0 : _rule$selectorText.includes(DX_RULE_PREFIX)) || (null === (_rule$cssRules = rule.cssRules) || void 0 === _rule$cssRules || null === (_rule$cssRules = _rule$cssRules[0]) || void 0 === _rule$cssRules || null === (_rule$cssRules = _rule$cssRules.selectorText) || void 0 === _rule$cssRules ? void 0 : _rule$cssRules.includes(DX_RULE_PREFIX)) || (null === (_rule$name = rule.name) || void 0 === _rule$name ? void 0 : _rule$name.startsWith(DX_RULE_PREFIX)) || "DXIcons" === (null === (_rule$style = rule.style) || void 0 === _rule$style ? void 0 : _rule$style.fontFamily);
  if (isDxRule) {
    targetStyleSheet.insertRule(rule.cssText, targetStyleSheet.cssRules.length);
  }
}
function addShadowDomStyles($element) {
  var _el$getRootNode;
  const el = $element.get(0);
  const root = null === (_el$getRootNode = el.getRootNode) || void 0 === _el$getRootNode ? void 0 : _el$getRootNode.call(el);
  if (!(null !== root && void 0 !== root && root.host)) {
    return;
  }
  if (!ownerDocumentStyleSheet) {
    ownerDocumentStyleSheet = createConstructedStyleSheet(root);
    processRules(ownerDocumentStyleSheet, el.ownerDocument.styleSheets, false);
  }
  const currentShadowDomStyleSheet = createConstructedStyleSheet(root);
  processRules(currentShadowDomStyleSheet, root.styleSheets, true);
  root.adoptedStyleSheets = [ownerDocumentStyleSheet, currentShadowDomStyleSheet];
}
function isPositionInElementRectangle(element, x, y) {
  var _element$getBoundingC;
  const rect = null === (_element$getBoundingC = element.getBoundingClientRect) || void 0 === _element$getBoundingC ? void 0 : _element$getBoundingC.call(element);
  return rect && x >= rect.left && x < rect.right && y >= rect.top && y < rect.bottom;
}
function createQueue() {
  let shiftIndex = 0;
  const items = [];
  return {
    push(item) {
      items.push(item);
      return this;
    },
    shift() {
      shiftIndex++;
      return items[shiftIndex - 1];
    },
    get length() {
      return items.length - shiftIndex;
    },
    get items() {
      return items;
    }
  };
}
function getShadowElementsFromPoint(x, y, root) {
  const elementQueue = createQueue().push(root);
  while (elementQueue.length) {
    const el = elementQueue.shift();
    for (let i = 0; i < el.childNodes.length; i++) {
      const childNode = el.childNodes[i];
      if (childNode.nodeType === Node.ELEMENT_NODE && isPositionInElementRectangle(childNode, x, y) && "none" !== getComputedStyle(childNode).pointerEvents) {
        elementQueue.push(childNode);
      }
    }
  }
  const result = elementQueue.items.reverse();
  result.pop();
  return result;
}
var DX_RULE_PREFIX, ownerDocumentStyleSheet;
var init_shadow_dom = __esm({
  "node_modules/devextreme/esm/core/utils/shadow_dom.js"() {
    DX_RULE_PREFIX = "dx-";
    ownerDocumentStyleSheet = null;
  }
});

// node_modules/devextreme/esm/core/dom_adapter.js
var nativeDOMAdapterStrategy, dom_adapter_default;
var init_dom_adapter = __esm({
  "node_modules/devextreme/esm/core/dom_adapter.js"() {
    init_dependency_injector();
    init_common();
    init_shadow_dom();
    nativeDOMAdapterStrategy = {
      querySelectorAll: (element, selector) => element.querySelectorAll(selector),
      elementMatches(element, selector) {
        const matches = element.matches || element.matchesSelector || element.mozMatchesSelector || element.msMatchesSelector || element.oMatchesSelector || element.webkitMatchesSelector || ((selector2) => {
          const doc = element.document || element.ownerDocument;
          if (!doc) {
            return false;
          }
          const items = this.querySelectorAll(doc, selector2);
          for (let i = 0; i < items.length; i++) {
            if (items[i] === element) {
              return true;
            }
          }
        });
        return matches.call(element, selector);
      },
      createElement(tagName, context) {
        context = context || this._document;
        return context.createElement(tagName);
      },
      createElementNS(ns, tagName, context) {
        context = context || this._document;
        return context.createElementNS(ns, tagName);
      },
      createTextNode(text, context) {
        context = context || this._document;
        return context.createTextNode(text);
      },
      createAttribute(text, context) {
        context = context || this._document;
        return context.createAttribute(text);
      },
      isNode: (element) => element && "object" === typeof element && "nodeType" in element && "nodeName" in element,
      isElementNode: (element) => element && 1 === element.nodeType,
      isTextNode: (element) => element && 3 === element.nodeType,
      isDocument: (element) => element && 9 === element.nodeType,
      isDocumentFragment: (element) => element && 11 === element.nodeType,
      removeElement(element) {
        const parentNode = element && element.parentNode;
        if (parentNode) {
          parentNode.removeChild(element);
        }
      },
      insertElement(parentElement, newElement, nextSiblingElement) {
        if (parentElement && newElement && parentElement !== newElement) {
          if (nextSiblingElement) {
            parentElement.insertBefore(newElement, nextSiblingElement);
          } else {
            parentElement.appendChild(newElement);
          }
        }
      },
      getAttribute: (element, name) => element.getAttribute(name),
      setAttribute(element, name, value) {
        if ("style" === name) {
          element.style.cssText = value;
        } else {
          element.setAttribute(name, value);
        }
      },
      removeAttribute(element, name) {
        element.removeAttribute(name);
      },
      setProperty(element, name, value) {
        element[name] = value;
      },
      setText(element, text) {
        if (element) {
          element.textContent = text;
        }
      },
      setClass(element, className, isAdd) {
        if (1 === element.nodeType && className) {
          isAdd ? element.classList.add(className) : element.classList.remove(className);
        }
      },
      setStyle(element, name, value) {
        element.style[name] = value || "";
      },
      _document: "undefined" === typeof document ? void 0 : document,
      getDocument() {
        return this._document;
      },
      getActiveElement(element) {
        const activeElementHolder = this.getRootNode(element);
        return activeElementHolder.activeElement;
      },
      getRootNode(element) {
        var _element$getRootNode;
        return (null === element || void 0 === element || null === (_element$getRootNode = element.getRootNode) || void 0 === _element$getRootNode ? void 0 : _element$getRootNode.call(element)) ?? this._document;
      },
      getBody() {
        return this._document.body;
      },
      createDocumentFragment() {
        return this._document.createDocumentFragment();
      },
      getDocumentElement() {
        return this._document.documentElement;
      },
      getLocation() {
        return this._document.location;
      },
      getSelection() {
        return this._document.selection;
      },
      getReadyState() {
        return this._document.readyState;
      },
      getHead() {
        return this._document.head;
      },
      hasDocumentProperty(property) {
        return property in this._document;
      },
      listen(element, event, callback, options) {
        if (!element || !("addEventListener" in element)) {
          return noop;
        }
        element.addEventListener(event, callback, options);
        return () => {
          element.removeEventListener(event, callback);
        };
      },
      elementsFromPoint(x, y, element) {
        const activeElementHolder = this.getRootNode(element);
        if (activeElementHolder.host) {
          return getShadowElementsFromPoint(x, y, activeElementHolder);
        }
        return activeElementHolder.elementsFromPoint(x, y);
      }
    };
    dom_adapter_default = dependency_injector_default(nativeDOMAdapterStrategy);
  }
});

// node_modules/devextreme/esm/core/utils/window.js
var hasWindowValue, hasWindow, windowObject, getWindow, hasProperty, defaultScreenFactorFunc, getCurrentScreenFactor, getNavigator;
var init_window = __esm({
  "node_modules/devextreme/esm/core/utils/window.js"() {
    init_dom_adapter();
    hasWindowValue = "undefined" !== typeof window;
    hasWindow = () => hasWindowValue;
    windowObject = hasWindow() ? window : void 0;
    if (!windowObject) {
      windowObject = {};
      windowObject.window = windowObject;
    }
    getWindow = () => windowObject;
    hasProperty = (prop) => hasWindow() && prop in windowObject;
    defaultScreenFactorFunc = (width) => {
      if (width < 768) {
        return "xs";
      } else if (width < 992) {
        return "sm";
      } else if (width < 1200) {
        return "md";
      } else {
        return "lg";
      }
    };
    getCurrentScreenFactor = (screenFactorCallback) => {
      const screenFactorFunc = screenFactorCallback || defaultScreenFactorFunc;
      const windowWidth = dom_adapter_default.getDocumentElement().clientWidth;
      return screenFactorFunc(windowWidth);
    };
    getNavigator = () => hasWindow() ? windowObject.navigator : {
      userAgent: ""
    };
  }
});

// node_modules/devextreme/esm/core/http_request.js
var window2, nativeXMLHttpRequest, http_request_default;
var init_http_request = __esm({
  "node_modules/devextreme/esm/core/http_request.js"() {
    init_window();
    init_dependency_injector();
    window2 = getWindow();
    nativeXMLHttpRequest = {
      getXhr: function() {
        return new window2.XMLHttpRequest();
      }
    };
    http_request_default = dependency_injector_default(nativeXMLHttpRequest);
  }
});

// node_modules/devextreme/esm/core/utils/call_once.js
var callOnce, call_once_default;
var init_call_once = __esm({
  "node_modules/devextreme/esm/core/utils/call_once.js"() {
    callOnce = function(handler) {
      let result;
      let wrappedHandler = function() {
        result = handler.apply(this, arguments);
        wrappedHandler = function() {
          return result;
        };
        return result;
      };
      return function() {
        return wrappedHandler.apply(this, arguments);
      };
    };
    call_once_default = callOnce;
  }
});

// node_modules/devextreme/esm/core/utils/ready_callbacks.js
var callbacks, subscribeReady, readyCallbacks, ready_callbacks_default;
var init_ready_callbacks = __esm({
  "node_modules/devextreme/esm/core/utils/ready_callbacks.js"() {
    init_dom_adapter();
    init_dependency_injector();
    init_window();
    init_call_once();
    callbacks = [];
    subscribeReady = call_once_default(() => {
      const removeListener = dom_adapter_default.listen(dom_adapter_default.getDocument(), "DOMContentLoaded", () => {
        readyCallbacks.fire();
        removeListener();
      });
    });
    readyCallbacks = {
      add: (callback) => {
        const windowExists = hasWindow();
        if (windowExists && "loading" !== dom_adapter_default.getReadyState()) {
          callback();
        } else {
          callbacks.push(callback);
          windowExists && subscribeReady();
        }
      },
      fire: () => {
        callbacks.forEach((callback) => callback());
        callbacks = [];
      }
    };
    ready_callbacks_default = dependency_injector_default(readyCallbacks);
  }
});

// node_modules/devextreme/esm/core/utils/ajax_utils.js
function getMethod(options) {
  return (options.method || "GET").toUpperCase();
}
var window3, createScript, appendToHead, removeScript, evalScript, evalCrossDomainScript, paramsConvert, getContentTypeHeader, getAcceptHeader, getRequestHeaders, getJsonpOptions, getRequestOptions, isCrossDomain;
var init_ajax_utils = __esm({
  "node_modules/devextreme/esm/core/utils/ajax_utils.js"() {
    init_extend();
    init_window();
    init_dom_adapter();
    window3 = getWindow();
    createScript = function(options) {
      const script = dom_adapter_default.createElement("script");
      for (const name in options) {
        script[name] = options[name];
      }
      return script;
    };
    appendToHead = function(element) {
      return dom_adapter_default.getHead().appendChild(element);
    };
    removeScript = function(scriptNode) {
      scriptNode.parentNode.removeChild(scriptNode);
    };
    evalScript = function(code) {
      const script = createScript({
        text: code
      });
      appendToHead(script);
      removeScript(script);
    };
    evalCrossDomainScript = function(url) {
      const script = createScript({
        src: url
      });
      return new Promise(function(resolve, reject) {
        const events = {
          load: resolve,
          error: reject
        };
        const loadHandler = function(e) {
          events[e.type]();
          removeScript(script);
        };
        for (const event in events) {
          dom_adapter_default.listen(script, event, loadHandler);
        }
        appendToHead(script);
      });
    };
    paramsConvert = function(params) {
      const result = [];
      for (const name in params) {
        let value = params[name];
        if (void 0 === value) {
          continue;
        }
        if (null === value) {
          value = "";
        }
        if ("function" === typeof value) {
          value = value();
        }
        result.push(encodeURIComponent(name) + "=" + encodeURIComponent(value));
      }
      return result.join("&");
    };
    getContentTypeHeader = function(options) {
      let defaultContentType;
      if (options.data && !options.upload && "GET" !== getMethod(options)) {
        defaultContentType = "application/x-www-form-urlencoded;charset=utf-8";
      }
      return options.contentType || defaultContentType;
    };
    getAcceptHeader = function(options) {
      const dataType = options.dataType || "*";
      const scriptAccept = "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript";
      const accepts = {
        "*": "*/*",
        text: "text/plain",
        html: "text/html",
        xml: "application/xml, text/xml",
        json: "application/json, text/javascript",
        jsonp: scriptAccept,
        script: scriptAccept
      };
      extendFromObject(accepts, options.accepts, true);
      return accepts[dataType] ? accepts[dataType] + ("*" !== dataType ? ", */*; q=0.01" : "") : accepts["*"];
    };
    getRequestHeaders = function(options) {
      const headers = options.headers || {};
      headers["Content-Type"] = headers["Content-Type"] || getContentTypeHeader(options);
      headers.Accept = headers.Accept || getAcceptHeader(options);
      if (!options.crossDomain && !headers["X-Requested-With"]) {
        headers["X-Requested-With"] = "XMLHttpRequest";
      }
      return headers;
    };
    getJsonpOptions = function(options) {
      if ("jsonp" === options.dataType) {
        const random = Math.random().toString().replace(/\D/g, "");
        const callbackName = options.jsonpCallback || "dxCallback" + Date.now() + "_" + random;
        const callbackParameter = options.jsonp || "callback";
        options.data = options.data || {};
        options.data[callbackParameter] = callbackName;
        return callbackName;
      }
    };
    getRequestOptions = function(options, headers) {
      let params = options.data;
      const paramsAlreadyString = "string" === typeof params;
      let url = options.url || window3.location.href;
      if (!paramsAlreadyString && !options.cache) {
        params = params || {};
        params._ = Date.now();
      }
      if (params && !options.upload) {
        if (!paramsAlreadyString) {
          params = paramsConvert(params);
        }
        if ("GET" === getMethod(options)) {
          if ("" !== params) {
            url += (url.indexOf("?") > -1 ? "&" : "?") + params;
          }
          params = null;
        } else if (headers["Content-Type"] && headers["Content-Type"].indexOf("application/x-www-form-urlencoded") > -1) {
          params = params.replace(/%20/g, "+");
        }
      }
      return {
        url,
        parameters: params
      };
    };
    isCrossDomain = function(url) {
      if (!hasWindow()) {
        return true;
      }
      let crossDomain = false;
      const originAnchor = dom_adapter_default.createElement("a");
      const urlAnchor = dom_adapter_default.createElement("a");
      originAnchor.href = window3.location.href;
      try {
        urlAnchor.href = url;
        urlAnchor.href = urlAnchor.href;
        crossDomain = originAnchor.protocol + "//" + originAnchor.host !== urlAnchor.protocol + "//" + urlAnchor.host;
      } catch (e) {
        crossDomain = true;
      }
      return crossDomain;
    };
  }
});

// node_modules/devextreme/esm/core/utils/ajax.js
var ajax_exports = {};
__export(ajax_exports, {
  default: () => ajax_default
});
var window4, SUCCESS, ERROR, TIMEOUT, NO_CONTENT, PARSER_ERROR, isStatusSuccess, hasContent, getDataFromResponse, postProcess, setHttpTimeout, sendRequest, ajax_default;
var init_ajax = __esm({
  "node_modules/devextreme/esm/core/utils/ajax.js"() {
    init_deferred();
    init_http_request();
    init_window();
    init_type();
    init_dependency_injector();
    init_ajax_utils();
    window4 = getWindow();
    SUCCESS = "success";
    ERROR = "error";
    TIMEOUT = "timeout";
    NO_CONTENT = "nocontent";
    PARSER_ERROR = "parsererror";
    isStatusSuccess = function(status) {
      return 200 <= status && status < 300;
    };
    hasContent = function(status) {
      return 204 !== status;
    };
    getDataFromResponse = function(xhr) {
      return xhr.responseType && "text" !== xhr.responseType || "string" !== typeof xhr.responseText ? xhr.response : xhr.responseText;
    };
    postProcess = function(deferred, xhr, dataType) {
      const data = getDataFromResponse(xhr);
      switch (dataType) {
        case "jsonp":
          evalScript(data);
          break;
        case "script":
          evalScript(data);
          deferred.resolve(data, SUCCESS, xhr);
          break;
        case "json":
          try {
            deferred.resolve(JSON.parse(data), SUCCESS, xhr);
          } catch (e) {
            deferred.reject(xhr, PARSER_ERROR, e);
          }
          break;
        default:
          deferred.resolve(data, SUCCESS, xhr);
      }
    };
    setHttpTimeout = function(timeout, xhr) {
      return timeout && setTimeout(function() {
        xhr.customStatus = TIMEOUT;
        xhr.abort();
      }, timeout);
    };
    sendRequest = function(options) {
      const xhr = http_request_default.getXhr();
      const d = new Deferred();
      const result = d.promise();
      const async = isDefined(options.async) ? options.async : true;
      const dataType = options.dataType;
      const timeout = options.timeout || 0;
      let timeoutId;
      options.crossDomain = isCrossDomain(options.url);
      const needScriptEvaluation = "jsonp" === dataType || "script" === dataType;
      if (void 0 === options.cache) {
        options.cache = !needScriptEvaluation;
      }
      const callbackName = getJsonpOptions(options);
      const headers = getRequestHeaders(options);
      const requestOptions = getRequestOptions(options, headers);
      const url = requestOptions.url;
      const parameters = requestOptions.parameters;
      if (callbackName) {
        window4[callbackName] = function(data) {
          d.resolve(data, SUCCESS, xhr);
        };
      }
      if (options.crossDomain && needScriptEvaluation) {
        const reject = function() {
          d.reject(xhr, ERROR);
        };
        const resolve = function() {
          if ("jsonp" === dataType) {
            return;
          }
          d.resolve(null, SUCCESS, xhr);
        };
        evalCrossDomainScript(url).then(resolve, reject);
        return result;
      }
      if (options.crossDomain && !("withCredentials" in xhr)) {
        d.reject(xhr, ERROR);
        return result;
      }
      xhr.open(getMethod(options), url, async, options.username, options.password);
      if (async) {
        xhr.timeout = timeout;
        timeoutId = setHttpTimeout(timeout, xhr);
      }
      xhr.onreadystatechange = function(e) {
        if (4 === xhr.readyState) {
          clearTimeout(timeoutId);
          if (isStatusSuccess(xhr.status)) {
            if (hasContent(xhr.status)) {
              postProcess(d, xhr, dataType);
            } else {
              d.resolve(null, NO_CONTENT, xhr);
            }
          } else {
            d.reject(xhr, xhr.customStatus || ERROR);
          }
        }
      };
      if (options.upload) {
        xhr.upload.onprogress = options.upload.onprogress;
        xhr.upload.onloadstart = options.upload.onloadstart;
        xhr.upload.onabort = options.upload.onabort;
      }
      if (options.xhrFields) {
        for (const field in options.xhrFields) {
          xhr[field] = options.xhrFields[field];
        }
      }
      if ("arraybuffer" === options.responseType) {
        xhr.responseType = options.responseType;
      }
      for (const name in headers) {
        if (Object.prototype.hasOwnProperty.call(headers, name) && isDefined(headers[name])) {
          xhr.setRequestHeader(name, headers[name]);
        }
      }
      if (options.beforeSend) {
        options.beforeSend(xhr);
      }
      xhr.send(parameters);
      result.abort = function() {
        xhr.abort();
      };
      return result;
    };
    ajax_default = dependency_injector_default({
      sendRequest
    });
  }
});

export {
  map,
  each,
  reverseEach,
  init_iterator,
  class_default,
  init_class,
  dependency_injector_default,
  init_dependency_injector,
  _extends,
  init_extends,
  guid_default,
  init_guid,
  callbacks_default,
  init_callbacks,
  fromPromise,
  Deferred,
  when,
  deferred_exports,
  init_deferred,
  variable_wrapper_default,
  init_variable_wrapper,
  clone,
  orderEach,
  deepExtendArraySafe,
  init_object,
  getPathParts,
  compileGetter,
  compileSetter,
  toComparable,
  init_data,
  ensureDefined,
  executeAsync,
  deferRender,
  deferUpdate,
  deferRenderer,
  deferUpdater,
  findBestMatches,
  splitPair,
  normalizeKey,
  pairToObject,
  getKeyHash,
  escapeRegExp,
  applyServerDecimalSeparator,
  noop,
  asyncNoop,
  grep,
  equalByValue,
  init_common,
  addShadowDomStyles,
  init_shadow_dom,
  dom_adapter_default,
  init_dom_adapter,
  hasWindow,
  getWindow,
  hasProperty,
  defaultScreenFactorFunc,
  getCurrentScreenFactor,
  getNavigator,
  init_window,
  call_once_default,
  init_call_once,
  http_request_default,
  init_http_request,
  ready_callbacks_default,
  init_ready_callbacks,
  ajax_default,
  ajax_exports,
  init_ajax
};
//# sourceMappingURL=chunk-4MAIXMIT.js.map
