import {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
} from "./chunk-M4PC57RV.js";
import "./chunk-WOX6XKRX.js";
import "./chunk-4MAIXMIT.js";
import "./chunk-ND5ICVCX.js";
import "./chunk-WBCLGCHV.js";
import "./chunk-EBLT4CH3.js";
import "./chunk-74ZAWBSC.js";
import "./chunk-WOR4A3D2.js";
export {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
};
//# sourceMappingURL=devextreme-angular_core.js.map
