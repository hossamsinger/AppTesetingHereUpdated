import {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-HZWM4F7U.js";
import "./chunk-OCXZH3GA.js";
import "./chunk-3T4EK4BM.js";
import "./chunk-DKXCLVAT.js";
import "./chunk-IWHA4UWF.js";
import "./chunk-WBCLGCHV.js";
import "./chunk-EBLT4CH3.js";
import "./chunk-74ZAWBSC.js";
import "./chunk-WOR4A3D2.js";
export {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
