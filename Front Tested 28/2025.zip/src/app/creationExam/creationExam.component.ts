import { Component } from '@angular/core';
import {  Router } from '@angular/router'; // Correct import for routing functionality
import { FormsModule } from '@angular/forms';  // Import FormsModule
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-creationExam',
  standalone: true,
  imports:[FormsModule , CommonModule],
  templateUrl: './creationExam.component.html',
  styleUrls: ['./creationExam.component.scss']
})
export class CreationExamComponent {
  constructor(
    private router: Router,
  ) {}  
  currentStep: number = 1;

  examDetails = {
    title: '',
    name: '',
    startDate: '',
    endDate: ''
  };

  examDefinition = {
    categoryId: '',
    duration: ''
  };

  examQuestion = {
    title: '',
    name: '',
    duration: ''
  };

  // Go to next step
  goToNextStep() {
    if (this.currentStep < 3) {
      this.currentStep++;
    }
  }

  // Handle form submission
  submitForm() {
    // Here you can handle your form submission logic, like making an API call
    console.log('Exam Details:', this.examDetails);
    console.log('Exam Definition:', this.examDefinition);
    console.log('Exam Question:', this.examQuestion);
  }
}
