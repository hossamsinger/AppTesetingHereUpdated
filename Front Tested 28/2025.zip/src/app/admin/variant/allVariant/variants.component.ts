import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DevExtremeModule, DxButtonModule, DxTemplateModule } from 'devextreme-angular';
import { DxDataGridModule } from 'devextreme-angular';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import 'devextreme/data/odata/store';
import { ToastType } from 'devextreme/ui/toast';
import { MatDialog } from '@angular/material/dialog';
import { VariantDialogComponent } from '../variantDialog/variantDialog.component';
import { forkJoin } from 'rxjs';


export interface Question {
  id: number;
  name: string;
  examDefinition: string;
}

@Component({
  selector: 'app-allvariant',
  standalone: true,
  imports: [
    CommonModule,
    DevExtremeModule,
    DxDataGridModule,
    DxTemplateModule,
    HttpClientModule,
    DxButtonModule,
    VariantDialogComponent, // Ensure this is added

  ],

  templateUrl: './variants.component.html',
  styleUrls: ['./variants.component.scss'],
})
export class AllVariantComponent {
  remoteDataSource: any;
  variantsWithDefinitions: any;
  definationDataSource : any;
  definationDataSourceById : any;
  fetchedData: any[] = [];
  isDialogVisible: boolean = false;
  selectedVariant: any; // Holds data for the selected variant

  constructor(private http: HttpClient , private dialog: MatDialog) {}

  ngOnInit(): void {
    this.fetchVariants();
    this.fetchDefinations();
    this.fetchDefinationById();
    // this.fetchVariantsWithDefination();
  }
  // =============================================================================================
  // Calling Api For Get All Variants To Add In This Variants__Lists
  fetchVariants(): void {
    this.remoteDataSource = createStore({
      key: 'id',
      loadUrl: 'http://localhost:5221/api/ExamVariant',
    });
    this.http.get('http://localhost:5221/api/ExamVariant').subscribe({
      next: (data: any) => {
        this.fetchedData = data;
        console.log('Fetched Variants:', this.fetchedData);        
      },
      error: (err) => {
        console.error('Error fetching Variants:', err);
      },
    });
  }
  // =============================================================================================
  // Calling Api For Get All Variants To Add In This Variants__Lists
  fetchVariantsWithDefination(): void {
    this.remoteDataSource = createStore({
      key: 'id',
      loadUrl: 'http://localhost:5221/api/ExamVariant',
    });
  
    this.http.get<any[]>('http://localhost:5221/api/ExamVariant').subscribe({
      next: (data: any[]) => {
        this.fetchedData = data;
        console.log('Fetched Variants:', this.fetchedData);
  
        // Create an array of observables for fetching definition names
        const definitionRequests = this.fetchedData.map((variant) =>
          this.http.get<{ name: string }>(`http://localhost:5221/api/ExamDefinition/${variant.id}`)
        );
        console.log('definitionRequests = :', definitionRequests);

        // Use forkJoin to wait for all requests to complete
        forkJoin(definitionRequests).subscribe({
          next: (definitions) => {
            // Combine variants with their corresponding definitions
            this.variantsWithDefinitions = this.fetchedData.map((variant, index) => ({
              ...variant,
              definition: definitions[index].name, // Assuming the API returns the name as 'name'
            }));
  
            console.log('Variants with Definitions:', this.variantsWithDefinitions);
          },
          error: (err) => {
            console.error('Error fetching Definitions:', err);
          },
        });
      },
      error: (err) => {
        console.error('Error fetching Variants:', err);
      },
    });
  }  
  // =============================================================================================
    // Toast Data For Identifiy What Happen Provided By Show Notification......
    toastMessage: string = '';
    toastType: ToastType = 'error';
    isToastVisible: boolean = false;
    private showToast(message: string, type: ToastType) {
    console.log('Toast invoked:', message, type); 
    this.toastMessage = message;
    this.toastType = type;
    this.isToastVisible = true;
    console.log('Toast visibility:', this.isToastVisible); 
  }
  // =============================================================================================
  // Calling Api For Get All Definations To Add In This Definations__List SelectBox 
  fetchDefinations(): void {
    this.http.get('http://localhost:5221/api/ExamDefinition').subscribe({
      next: (data: any) => {
        this.definationDataSource = data;
        console.log('Fetched Defination:', this.definationDataSource);
      },
      error: (err) => {
        console.error('Error fetching Defination:', err);
      },
    });
  }
    // =============================================================================================
  // Calling Get Api Here For Get_By_ID  Defination &  Add Defination Id For get  It 
  fetchDefinationById(): void {
    this.http.get(`http://localhost:5221/api/ExamDefinition/${1}`).subscribe({
      next: (data: any) => {
        this.  definationDataSourceById = data;
        console.log('Fetched Defination By ID:', this.definationDataSourceById);
      },
      error: (err) => {
        console.error('Error fetching Defination  By ID:', err);
      },
    });
  }
  // =============================================================================================
  // Calling Api For Deleting Selected Variant from Variants__List  
  deleteVariantById(variantId: number): void {
    console.log({variantId});
    
    this.http.delete(`http://localhost:5221/api/ExamVariant/${variantId}`).subscribe({
      next: () => {
        this.toastMessage = 'Defination deleted successfully!';
        this.toastType = 'success';
        this.isToastVisible = true;
        this.fetchVariants();
      },
      error: (err) => {
        this.toastMessage = 'Failed To Delete Defination';
        this.toastType = 'error';
        this.isToastVisible = true;
      },
    });
  }
  // =============================================================================================
  // Calling Api For Deleting Selected Variant from Variants__List 
  openDialog(rowData: any = []): void {
    console.log({rowData});
    this.selectedVariant = rowData; // Pass the selected row data
    this.isDialogVisible = false; 
    setTimeout(() => {
      this.isDialogVisible = true;
    }, 0);
  }
  closeDialog() {
    this.isDialogVisible = false;
  }
}
