import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DevExtremeModule, DxButtonModule, DxDataGridModule } from 'devextreme-angular';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-variant-Dialog',
  standalone: true,
  imports: [ CommonModule , DevExtremeModule , HttpClientModule  ,  DxDataGridModule,
    DxButtonModule,],
  templateUrl: './variantDialog.component.html',
  styleUrls: ['./variantDialog.component.scss'],
})
export class VariantDialogComponent {
  definationDataSource : any;
  questionDataSource : any;
  questionDataByCategory :any[] = [];
  VariantquestionsData :any[] = [];
  selectedDefination :any;
  variantName: string = '';

  @Input() variantData: any; // Data to be edited
  @Input() isVisible: boolean = false; // Ensure this is defined
  @Output() closePopup = new EventEmitter<void>(); // handel oppining and closing Dynamically

  constructor(private http: HttpClient ) {}

  ngOnInit(): void {
    this.fetchDefinations();
    this.fetchQuestions();
    if (this.variantData) {
      this.initializeDialogData();
    }
  }
  ngOnChanges(): void {
    if (this.variantData) {
      this.initializeDialogData();
    }
  }
  initializeDialogData() {
    debugger;
    this.variantName = this.variantData.data.variantName;
    this.selectedDefination = this.variantData.data.examDefinition;
    this.VariantquestionsData = this.variantData.data.questions || [];
  }

  // =============================================================================================
  // Calling Api For Get All Definations To Add In This Definations__List SelectBox 
  fetchDefinations(): void {
    this.http.get('http://localhost:5221/api/ExamDefinition').subscribe({
      next: (data: any) => {
        this.definationDataSource = data;
        console.log('Fetched Defination:', this.definationDataSource);
      },
      error: (err) => {
        console.error('Error fetching Defination:', err);
      },
    });
  }
  // =============================================================================================
  // Calling Api For Get All Question To Choise The Variant Question from Question__List SelectBox 
  fetchQuestions(): void {
    this.http.get('http://localhost:5221/api/Question').subscribe({
      next: (data: any) => {
        this.questionDataSource = data;
        console.log('Fetched Question:', this.questionDataSource);
      },
      error: (err) => {
        console.error('Error fetching Question:', err);
      },
    });
  }
  // =============================================================================================
  // Calling Api For Get  Question By Category 
  fetchQuestionsByCategory(examDefinitionId: number): void {
    this.http.get(`http://localhost:5221/api/Question/ByCategory?examDefinitionId=${examDefinitionId}`).subscribe({
      next: (data: any) => {
        this.questionDataByCategory = data;
        console.log('Fetched question Data By Category:', this.questionDataByCategory);
      },
      error: (err) => {
        console.error('Error fetching question Data By Category:', err);
      },
    });
  }
  // =============================================================================================
  // Handle Selection Changed Event
  CallQuestionApi(event: any): void {
    const selectedData = event.selectedItem; // Contains the selected item's data
    console.log('Selected Item:', selectedData);
    this.selectedDefination=selectedData;
    console.log("selectedDefination = " , this.selectedDefination);
    
    // Ensure that the selected data has the expected structure, for example:
    if (selectedData && selectedData.category && selectedData.category.id) {
      const categoryId = selectedData.category.id;
      console.log('Selected Category ID:', categoryId);

      // Call the fetchQuestionsByCategory method with the selected category ID
      this.fetchQuestionsByCategory(categoryId);
    } else {
      console.error('Invalid selected data structure');
    }
  }

  // =============================================================================================
  // Add question to selected grid
   addQuestionToSelectedGrid(question: any) {
    this.VariantquestionsData.push(question);
    this.questionDataByCategory = this.questionDataByCategory.filter(
      (q) => q.id !== question.id
    );
  }

  // =============================================================================================
  // Remove question from selected grid
  removeQuestionFromSelectedGrid(question: any) {
    this.questionDataByCategory.push(question);
    this.VariantquestionsData = this.VariantquestionsData.filter(
      (q) => q.id !== question.id
    );
  }

 // =============================================================================================
  // Handle Saving Variant Popup When Click On Cancel 
  clearAllDialogData(){
    this.questionDataByCategory=[];
    this.VariantquestionsData=[];
    this.variantName=""
    this.selectedDefination=''
  }

 // =============================================================================================
   // Handle Saving  OR Update Variant Popup When Click On Corrosponding Buttons 
  // if (this.editMode) {
  //   this.update();
  // } else {
  //   this.save();
  // }
  
  // =============================================================================================
  // Handle updating Variant Popup When Click On Update 
  update(){
    
  };

  // =============================================================================================
  // Handle Saving Variant Popup When Click On Save 
  save() {

    console.log("On Saving Data For Variant Here........");
    console.log("Variant Question = " , this.VariantquestionsData);
    console.log("selected Defination= " , this.selectedDefination);
    
    this.clearAllDialogData();
    const requestData = 
      {
        examDefinitionId:this.selectedDefination.id,
        name: this.variantName,
        category: {
          name: this.selectedDefination.category.name,
        }
        
    }
    this.http.post('http://localhost:5221/api/ExamVariant', requestData ).subscribe({
      next: (data: any) => {
        
        console.log('posting Variants  Data Done.......');        
      },
      error: (err) => {
        console.error('Error when posting Variants Data :', err);
      },
    });
  }
  
  // =============================================================================================
  // Handle Close Popup When Click On Cancel 
  
  close() {
    this.clearAllDialogData();
    this.closePopup.emit();  // Notify parent to update visibility
  }
}
