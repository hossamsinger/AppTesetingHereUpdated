import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DefinationDialogComponent } from '../definationDialog/definationDialog.component';
import { DevExtremeModule, DxTemplateModule } from 'devextreme-angular';
import { DxDataGridModule } from 'devextreme-angular';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import 'devextreme/data/odata/store';
import { ConfirmDialogComponent } from '../../../../shared/components/confirmation_Dialog/confirm-dialog.component';
import { ToastType } from 'devextreme/ui/toast';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-alldefination',
  standalone: true,
  imports: [
    CommonModule,
    DevExtremeModule,
    DxDataGridModule,
    DxTemplateModule,
    DefinationDialogComponent,
    HttpClientModule
  ],
  templateUrl: './definations.component.html',
  styleUrls: ['./definations.component.scss'],
})

export class AllDefinationComponent  implements OnInit {
  remoteDataSource: any;
  fetchedData: any[] = [];
  constructor(private http: HttpClient , private dialog: MatDialog) {}
  isDialogVisible: boolean = false;
  title: string = '';
  data: any = [];

  // =============================================================================================
  ngOnInit(): void {
    this.fetchDefinations();
  }
  //Hook Function to Call Data After Intialization Component Here ............
  fetchDefinations(): void {
    this.remoteDataSource = createStore({
      key: 'id',
      loadUrl: 'http://localhost:5221/api/ExamDefinition',
    });
    this.http.get('http://localhost:5221/api/ExamDefinition').subscribe({
      next: (data: any) => {
        this.fetchedData = data;
        console.log('Fetched Defination:', this.fetchedData);
      },
      error: (err) => {
        console.error('Error fetching Defination:', err);
      },
    });
  }
 // =============================================================================================
     // Toast Data For Identifiy What Happen Provided By Show Notification......
     toastMessage: string = '';
     toastType: ToastType = 'error';
     isToastVisible: boolean = false;
     private showToast(message: string, type: ToastType) {
      console.log('Toast invoked:', message, type); 
      this.toastMessage = message;
      this.toastType = type;
      this.isToastVisible = true;
      console.log('Toast visibility:', this.isToastVisible); 
    }
  // =============================================================================================
  showDialog({ title, data }: { title: string; data: any }) {
    this.isDialogVisible = false; 
    setTimeout(() => {
      this.title = title;  
      this.data = { ...data }; 
      this.isDialogVisible = true;
    }, 0);
  }
 // =============================================================================================
   openDeleteDialog(definationId: number): void {
     const dialogRef = this.dialog.open(ConfirmDialogComponent, {
       width: '410px',
       data: { message: 'Are you sure you want to delete this Defination ?' },
     });
     dialogRef.afterClosed().subscribe((result) => {
       if (result) {
         this.deleteDefinationById(definationId);
       } else {
         console.log('Deletion canceled');
       }
     });
   }
    // =============================================================================================
   // Calling Delete Api Here For Deleting Defination By Add Defination Id For It 
   deleteDefinationById(definationId: number): void {
     this.http.delete(`http://localhost:5221/api/ExamDefinition/${definationId}`).subscribe({
       next: () => {
         this.toastMessage = 'Defination deleted successfully!';
         this.toastType = 'success';
         this.isToastVisible = true;
         // Refresh the categories list
         this.fetchDefinations();
       },
       error: (err) => {
         this.toastMessage = 'Failed To Delete Defination';
         this.toastType = 'error';
         this.isToastVisible = true;
       },
     });
   }
   // =============================================================================================
}
