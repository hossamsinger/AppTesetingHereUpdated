import {Component, Input , SimpleChanges} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DevExtremeModule } from 'devextreme-angular';
import { ToastType } from 'devextreme/ui/toast';
import { Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { createStore } from 'devextreme-aspnet-data-nojquery';
// Define the interface for the request body
interface DefinitionRequestBody {
  name: string;
  categoryId: string;
  duration: number | null;
  examTypeId: number;
  id?: string; // Optional property
}
@Component({
  selector: 'app-defination-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule , DevExtremeModule ],
  templateUrl: './definationDialog.component.html',
  styleUrls: ['./definationDialog.component.scss'],
})
export class DefinationDialogComponent {
  @Input() isVisible: boolean = false;
  @Input() title: string = 'Add';  // Accept title dynamically
  @Input() definitionData: any;  // Accept data passed from parent
  @Input() refreshDefinitions!: () => void; // Callback for fetching definitions
  @Output() closePopup = new EventEmitter<void>(); // handel oppining and closing Dynamically
 
  remoteDataSource: any;
  fetchedDataForAllCategories: any[] = [];
  fetchedDataForAddDefination: any[] = [];
  constructor(private http: HttpClient , private dialog: MatDialog) {}
  // =============================================================================================
   ngOnInit(): void {
     this.fetchCategories();
   }
   //Hook Function to Call Data After Intialization Component Here ............
   fetchCategories(): void {
     this.remoteDataSource = createStore({
       key: 'id',
       loadUrl: 'http://localhost:5221/api/Category',
     });
     this.http.get('http://localhost:5221/api/Category').subscribe({
       next: (data: any) => {
         this.fetchedDataForAllCategories = data;
         console.log('Fetched Categories:', this.fetchedDataForAllCategories);
       },
       error: (err) => {
         console.error('Error fetching categories:', err);
       },
     });
   }
  // =============================================================================================
  //  Data For Defination  And CategoryOptions 
  definition = {
    id:'null',
    name: '',
    category: '',
    duration: null,
    questionNumber: null
  };
  // =============================================================================================
  // Dynamically Populating Data In Corrosponding Fields.....
  ngOnChanges(changes: SimpleChanges) {
    if (changes['definitionData'] && this.definitionData) {
      this.definition = { ...this.definitionData.data };
      console.log(" this.definition = " , this.definitionData);
      
    } else {
      debugger;
      // Reset form when adding new definition
      this.definition = {
        id: 'null',
        name: '',
        category: '',
        duration: null,
        questionNumber: null,
      };
    }
  }
  // =============================================================================================
    // Dynamically Populating Title For Popup Title.....
    get popupTitle(): string { 
      return this.title.toLowerCase() === 'edit' ? 'Edit Actual Defination' : 'Add New Defination';
    }
  // =============================================================================================
     // Toast Data For Identifiy What Happen Provided By Show Notification......
     toastMessage: string = '';
     toastType: ToastType = 'error';
     isToastVisible: boolean = false;
     private showToast(message: string, type: ToastType) {
      console.log('Toast invoked:', message, type); 
      this.toastMessage = message;
      this.toastType = type;
      this.isToastVisible = true;
      console.log('Toast visibility:', this.isToastVisible); 
    }
  // =============================================================================================
  save() {
    const { name, category, duration, questionNumber } = this.definition;
    // Validate the form fields
    if (name && category && duration && questionNumber) {
      let requestBody: DefinitionRequestBody = {
        name,
        categoryId: category,
        duration,
        examTypeId: 1,
      };
  
      if (this.title.toLowerCase() === 'edit' && this.definitionData?.data?.id) {
        // Retrieve the ID for the edit case
        const id = this.definitionData.data.id;        
        requestBody.id = this.definitionData.data.id;
        // =============================================================================================
        // Calling API for updating definition
        this.http.put(`http://localhost:5221/api/ExamDefinition/${id}`, requestBody).subscribe({
          next: (data: any) => {
            this.isVisible = false;
            this.showToast('Definition updated successfully!', 'success');
            console.log('API Response:', data);
            
          },
          error: (err) => {
            console.error('Error updating definition:', err);
            this.showToast('Failed to update the definition. Please try again.', 'error');
          }
        });
      } else {
        // =============================================================================================
        // Calling API for adding a new definition
        this.http.post('http://localhost:5221/api/ExamDefinition', requestBody).subscribe({
          next: (data: any) => {
            this.isVisible = false;
            this.showToast('Definition added successfully!', 'success');
            console.log('API Response:', data);
          },
          error: (err) => {
            console.error('Error adding definition:', err);
            this.showToast('Failed to add the definition. Please try again.', 'error');
          }
        });
      }
    } else {
      this.showToast('Please fill all fields correctly.', 'error');
    }
  }
  
  close() {
    this.closePopup.emit();  // Notify parent to update visibility
  }
}
