import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  FormArray,
  FormBuilder,
  FormControl,
  Validators,
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {
  DxTextBoxModule,
  DxSelectBoxModule,
  DxNumberBoxModule,
  DxButtonModule,
  DxRadioGroupModule,
  DxPopupModule,
} from 'devextreme-angular';

export enum ToastMessageType {
  Success = 'success',
  Error = 'error',
  Warning = 'warning',
}

@Component({
  selector: 'app-question-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DxTextBoxModule,
    DxSelectBoxModule,
    DxNumberBoxModule,
    DxButtonModule,
    DxRadioGroupModule,
    DxPopupModule,
  ],
  templateUrl: './questionDialog.component.html',
  styleUrls: ['./questionDialog.component.scss'],
})
export class QuestionDialogComponent implements OnInit {
  @Input() isVisible: boolean = false;
  @Input() title: string = 'Add';
  @Input() questionData: any;
  @Output() closePopup = new EventEmitter<void>();

  questionTypes = [
    { id: 0, name: 'True or False' },
    { id: 1, name: 'Multiple Choices' },
  ];
  toastMessage: string = '';
  toastType: ToastMessageType = ToastMessageType.Error;
  isToastVisible: boolean = false;
  chosenType: boolean = false;

  questionForm!: FormGroup;

  readonly QUESTION_LEVELS = [1, 2, 3, 4, 5];

  constructor(private http: HttpClient, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initializeForm();
  }

  // Initialize Form
  private initializeForm(): void {
    this.questionForm = this.fb.group({
      questionTypeId: [this.questionTypes[0]?.id],
      name: ['', Validators.required],
      marks: [0, Validators.min(0)],
      questionLevel: [1],
      answer: [''], // For True/False
      answers: this.fb.array([]), // For Multiple Choice
    });
  }

  get answers(): FormArray {
    return this.questionForm.get('answers') as FormArray;
  }

  // Handle Question Type Change
  onSelectChange(selectedValue: number): void {
    this.chosenType = selectedValue === 1; // 1 = Multiple Choices
    if (!this.chosenType) {
      this.answers.clear(); // Clear Multiple Choice answers when switching to True/False
    }
  }
    // Getter for type-safe access to FormControl
    getAnswerControl(index: number): FormControl {
      return this.answers.at(index) as FormControl;
    }

  addAnswer(): void {
    if (this.answers.length >= 5) {
      this.showToast('You can only add up to 5 answers.', ToastMessageType.Warning);
      return;
    }
    this.answers.push(new FormControl('', Validators.required));
  }

  // Close Popup
  close(): void {
    this.questionForm.reset();
    this.closePopup.emit();
  }

  // Show Toast Notification
  private showToast(message: string, type: ToastMessageType): void {
    this.toastMessage = message;
    this.toastType = type;
    this.isToastVisible = true;
  }

  // Save Question
  save(): void {
    if (this.questionForm.invalid) {
      this.showToast('Please fill all required fields.', ToastMessageType.Error);
      return;
    }

    const requestBody = this.questionForm.value;
    console.log("questionData = " , requestBody);
    
    // Convert True/False Answer to Boolean
    if (!this.chosenType) {
      requestBody.answer = requestBody.answer === 'True';
    }
    // =============================================================================================
    // Calling API for adding a new Question
    this.http.post('http://localhost:5221/api/Question', requestBody).subscribe({
      next: (data: any) => {
        this.isVisible = false;
        console.log('API Response:', data);
        this.showToast(
          this.title === 'Add'
            ? 'Question added successfully!'
            : 'Question updated successfully!',
          ToastMessageType.Success
        );
        this.closePopup.emit();
      },
      error: (err) => {
        this.showToast(
          this.title === 'Add'
            ? 'Failed to add question!'
            : 'Failed to update question!',
          ToastMessageType.Error
        );
        console.error('Save Question Error:', err);    
      }
    });
    // =============================================================================================
    // Calling API for Updating a Selected Question
    this.http.put(`http://localhost:5221/api/Question/${1}`, requestBody).subscribe({
      next: (data: any) => {
        this.isVisible = false;
        console.log('API Response:', data);
        this.showToast(
          this.title === 'Add'
            ? 'Question added successfully!'
            : 'Question updated successfully!',
          ToastMessageType.Success
        );
        this.closePopup.emit();
      },
      error: (err) => {
        this.showToast(
          this.title === 'Add'
            ? 'Failed to add question!'
            : 'Failed to update question!',
          ToastMessageType.Error
        );
        console.error('Save Question Error:', err);    
      }
    });
  }
}

