import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-examDialog',
  standalone: true,
  imports: [ CommonModule],
  templateUrl: './examDialog.component.html',
  styleUrls: ['./examDialog.component.scss'],
})
export class ExamDialogComponent {

}
