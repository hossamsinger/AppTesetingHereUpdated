import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

// =============================
// devextreme imports here .... 
// =============================
import { DevExtremeModule } from 'devextreme-angular';;
import { createStore } from 'devextreme-aspnet-data-nojquery';
import 'devextreme/data/odata/store';

@Component({
  selector: 'app-allexam',
  standalone: true,
  imports: [ CommonModule , DevExtremeModule],
  templateUrl: './exams.component.html',
  styleUrls: ['./exams.component.scss'],
})
export class AllExamComponent {
  remoteDataSource: any;

  constructor() {
    this.remoteDataSource = createStore({
      key: 'Id',
      loadUrl: 'https://localhost:5221/dxdatagrid'
    });
  }
}
