import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterModule} from '@angular/router';
import { CommonModule } from '@angular/common';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatMenuModule } from '@angular/material/menu';
interface NavItem {
  label: string;
  path: string;
  badge?: number;
  role ?:string;
  submenu?: boolean;  
}
interface SubMenuItem {
  label: string;
  path: string; 
  badge?: number;
}

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive ,RouterModule  ,  MatMenuModule,MatFormFieldModule , MatSelectModule ]
})
export class NavbarComponent {
  navItems: NavItem[] = [
    { label: 'النتائج',        path: '/results',        badge: 12,      role:"admin"     , submenu: false },
    { label: 'تسطيب الامتحان ', path: '/creationExam',   badge: 7,       role:"admin"     , submenu: false },
    { label: 'ابدء الامتحان',  path: '/exam' ,          badge: 50,      role:"*"         , submenu: false },
    { label: 'الرئيسيه',      path: '/dashboard',      badge: 5,       role:"*"         , submenu: false },
    { label: 'الإعدادات',          path: '',                badge: 2,       role: 'admin'    , submenu: true },
  ];  
  // Admin menu item with submenu
  adminMenuItems: SubMenuItem[] = [
    { label: 'التصنيفات', path: '/admin/AllCategory'  },
    { label: 'التعريفات', path: '/admin/AllDefination' },
    { label: 'النماذج', path: '/admin/AllVariant' },
    { label: 'الاسئله', path: '/admin/Questions' },
    { label: 'الاماكن', path: '/admin/AllLocation' },
    { label: 'الامتحانات', path: 'exam/exam-list' },
    { label: 'الموظفين', path: '/admin/Employee' },
  ];
item: any;
}