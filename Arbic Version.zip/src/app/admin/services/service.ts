import { Injectable } from '@angular/core';

export interface Tab {
  id: string; // Make id a required string
  text: string; // Ensure text is always a string
  content: string; // content should always be a string
}

@Injectable()
export class Service {
    getTabsWithText(): Tab[] {  // Return an array of Tab objects
        return [
          { text: 'Edit Exam Details', content: 'examForm', id: 'exam-details' },
          { text: 'Assigned Employees ', content: 'employeeForm', id: 'assigned-employee' },
        ];
    }
}
