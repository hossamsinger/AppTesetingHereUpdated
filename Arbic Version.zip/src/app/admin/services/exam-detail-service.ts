import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IExam } from '../models/Iexam';

const baseUrl = "https://localhost:5221/api/Exam/";
const headers: HttpHeaders = new HttpHeaders()
  .append('Content-Type', 'application/json');

const httpOptions = {
  headers: headers
};

@Injectable({
  providedIn: 'root'
})

export class ExamServices {
  constructor(private http: HttpClient) { }

  post(data: any): Observable<IExam> {
    const url = `${baseUrl}`;
    return this.http.post<IExam>(url, data, httpOptions);
  }
  
  getAll(): Observable<IExam> {
    const url = `${baseUrl}`;
    return this.http.get<IExam>(url, httpOptions);
  }

  getLocations(): Observable<any> {
    const url = `http://localhost:5221/api/Location`;
    return this.http.get<any>(url, httpOptions);
  }

  getExamDefinitions(): Observable<any> {
    const url = `http://localhost:5221/api/ExamDefinition`;
    return this.http.get<any>(url, httpOptions);
  }

  put(id: any, data: any): Observable<IExam> {
    const url = `${baseUrl}` + id;
    return this.http.put<IExam>(url, data, httpOptions);
  }
  
  delete(id: any): Observable<IExam> {
    
    const url =  `${baseUrl}` + id;
    return this.http.delete<IExam>(url, httpOptions); 
}

  getById(id: number): Observable<IExam> {
    const url = `${baseUrl}`+ id;
    return this.http.get<IExam>(url, httpOptions);
  }
  
}