import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { DevExtremeModule } from 'devextreme-angular';
import { ToastType } from 'devextreme/ui/toast';


@Component({
  selector: 'app-category-dialog',
  standalone: true,
  imports: [
    FormsModule,
    DevExtremeModule
  ],
  templateUrl: './category-dialog.component.html',
  styleUrls: ['./category-dialog.component.scss'],
})
export class CategoryDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: {categoryName: string },
    private dialogRef: MatDialogRef<CategoryDialogComponent>
  ) {}




   // Toast Data For  properties with correct type
   toastMessage: string = '';
   toastType: ToastType = 'error';
   isToastVisible: boolean = false;
   private showToast(message: string, type: ToastType) {
    console.log('Toast invoked:', message, type); 
    this.toastMessage = message;
    this.toastType = type;
    this.isToastVisible = true;
    console.log('Toast visibility:', this.isToastVisible); 
  }

  save(updateForm: any): void {
    ;
    if (!updateForm.valid) {
      this.showToast('Please fill all fields correctly.', 'error');
      return;
    }
    this.showToast('Category  Add  successfully!', 'success');
    this.dialogRef.close(this.data);
  }

  close(): void {
    this.dialogRef.close();
  }
}
