import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CategoryDialogComponent } from '../categoryDialog/category-dialog.component';
import { ConfirmDialogComponent } from '../../../../shared/components/confirmation_Dialog/confirm-dialog.component';
import { DevExtremeModule, DxTemplateModule } from 'devextreme-angular';
import { DxDataGridModule } from 'devextreme-angular';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import 'devextreme/data/odata/store';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ToastType } from 'devextreme/ui/toast';

@Component({
  selector: 'app-allCategory',
  standalone: true,
  imports: [
    CategoryDialogComponent,HttpClientModule,
    DevExtremeModule,DxTemplateModule , DxDataGridModule

  ],
  templateUrl: './allCategory.component.html',
  styleUrls: ['./allCategory.component.scss'],
})

 
export class AllCategoryComponent implements OnInit {
  remoteDataSource: any;
  fetchedData: any[] = [];
  
  constructor(private http: HttpClient, private dialog: MatDialog) {}
  // =============================================================================================
  ngOnInit(): void {
    this.fetchCategories();
  }
  //Hook Function to Call Data After Intialization Component Here ............
  fetchCategories(): void {
    this.remoteDataSource = createStore({
      key: 'id',
      loadUrl: 'http://localhost:5221/api/Category',
    });
    this.http.get('http://localhost:5221/api/Category').subscribe({
      next: (data: any) => {
        this.fetchedData = data;
        console.log('Fetched Categories:', this.fetchedData);
      },
      error: (err) => {
        console.error('Error fetching categories:', err);
      },
    });
  }
  // =============================================================================================
     // Toast Data For Identifiy What Happen Provided By Show Notification......
     toastMessage: string = '';
     toastType: ToastType = 'error';
     isToastVisible: boolean = false;
     private showToast(message: string, type: ToastType) {
      console.log('Toast invoked:', message, type); 
      this.toastMessage = message;
      this.toastType = type;
      this.isToastVisible = true;
      console.log('Toast visibility:', this.isToastVisible); 
    }
  // =============================================================================================

  openDialog(categoryId?: number, categoryName?: string): void {
    const isUpdate = !!categoryId; // If categoryId exists, it's an update
    const dialogRef = this.dialog.open(CategoryDialogComponent, {
      width: '400px',
      data: { categoryId: categoryId, categoryName: categoryName || '' },
    });
  
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (isUpdate) {
           this.updateCategory(categoryId!, result);
        } else {
          this.addCategory(result); 
        }
      }
    });
  }
  

  // =============================================================================================
  openDeleteDialog(categoryId: number): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '410px',
      data: { message: 'Are you sure you want to delete this category ?' },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.deleteCategory(categoryId);
      } else {
        console.log('Deletion canceled');
      }
    });
  }
  // =============================================================================================
  // Calling Delete Api Here For Deleting Category By Add Category Id..
  deleteCategory(categoryId: number): void {
    this.http.delete(`http://localhost:5221/api/Category/${categoryId}`).subscribe({
      next: () => {
        this.toastMessage = 'Category deleted successfully!';
        this.toastType = 'success';
        this.isToastVisible = true;
        // Refresh the categories list
        this.fetchCategories();
      },
      error: (err) => {
        this.toastMessage = 'Failed to delete category.';
        this.toastType = 'error';
        this.isToastVisible = true;
      },
    });
  }
  // =============================================================================================
    // Calling Add Api Here For Adding Category By Add Category Name.. 
  addCategory(categoryData: any): void {
    const requestData = {
      id: categoryData.categoryId || 0, 
      name: categoryData.categoryName || '', 
    };
    console.log({requestData}); 
    this.http.post('http://localhost:5221/api/Category', requestData).subscribe({
      next: () => {
        this.toastMessage = 'Category added successfully!';
        this.toastType = 'success';
        this.isToastVisible = true;
        // Refresh the categories list
        this.fetchCategories();
      },
      error: (err) => {
        this.toastMessage = 'Failed to add category.';
        this.toastType = 'error';
        this.isToastVisible = true;
      },
    });
  }
  // =============================================================================================
    // Calling Put Api Here For Updating Category By Updating Category Name..
  updateCategory(categoryId: number, categoryData: any): void {
    const requestData = {
      id: categoryData.categoryId || 0, 
      name: categoryData.categoryName || '', 
    };
    console.log();
    
    this.http.put(`http://localhost:5221/api/Category/${categoryId}`, requestData).subscribe({
      next: () => {
        this.toastMessage = 'Category updated successfully!';
        this.toastType = 'success';
        this.isToastVisible = true;
        // Refresh the categories list
        this.fetchCategories();
      },
      error: (err) => {
        this.toastMessage = 'Failed to update category.';
        this.toastType = 'error';
        this.isToastVisible = true;
      },
    });
  }
  
}
