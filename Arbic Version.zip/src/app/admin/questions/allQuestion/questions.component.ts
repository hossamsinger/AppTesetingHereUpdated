import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DevExtremeModule, DxTemplateModule } from 'devextreme-angular';
import { DxDataGridModule } from 'devextreme-angular';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import 'devextreme/data/odata/store';
import { ConfirmDialogComponent } from '../../../../shared/components/confirmation_Dialog/confirm-dialog.component';
import { ToastType } from 'devextreme/ui/toast';
import { MatDialog } from '@angular/material/dialog';
import { QuestionDialogComponent } from '../questionDialog/questionDialog.component';


@Component({
  selector: 'app-allquestion',
  standalone: true,
  imports: [
    CommonModule,
    DevExtremeModule,
    DxDataGridModule,
    DxTemplateModule,
    HttpClientModule , QuestionDialogComponent
  ],
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.scss'],
})

export class AllQuestionComponent  implements OnInit {
  remoteDataSource: any;
  fetchedData: any[] = [];
  constructor(private http: HttpClient , private dialog: MatDialog) {}
  isDialogVisible: boolean = false;
  title: string = '';
  data: any = [];

  // =============================================================================================
  ngOnInit(): void {
    this.fetchQuestions();
  }
  //Hook Function to Call Data After Intialization Component Here ............
  fetchQuestions(): void {
    this.remoteDataSource = createStore({
      key: 'id',
      loadUrl: 'http://localhost:5221/api/Question',
    });
    this.http.get('http://localhost:5221/api/Question').subscribe({
      next: (data: any) => {
        this.fetchedData = data;
        console.log('Fetched Question:', this.fetchedData);
      },
      error: (err) => {
        console.error('Error fetching Question:', err);
      },
    });
  }
 // =============================================================================================
     // Toast Data For Identifiy What Happen Provided By Show Notification......
     toastMessage: string = '';
     toastType: ToastType = 'error';
     isToastVisible: boolean = false;

     private showToast(message: string, type: ToastType) {
      this.toastMessage = message;
      this.toastType = type;
      this.isToastVisible = true;
    }
  // ============================================================================================
  showDialog({ title, data }: { title: string; data: any }) {
    this.isDialogVisible = false;
    setTimeout(() => {
      this.title = title;  
      this.isDialogVisible = true; 
      this.data = { ...data }; 
    }, 0);
    console.log(' this.isDialogVisible = ' ,  this.isDialogVisible);
    
  }
 // =============================================================================================
   openDeleteDialog(questionId: number): void {
     const dialogRef = this.dialog.open(ConfirmDialogComponent, {
       width: '410px',
       data: { message: 'Are you sure you want to delete this Question ?' },
     });
     dialogRef.afterClosed().subscribe((result) => {
       if (result) {
         this.deleteDefinationById(questionId);
       } else {
         console.log('Deletion canceled');
       }
     });
   }
    // =============================================================================================
   // Calling Delete Api Here For Deleting Defination By Add Defination Id For It 
   deleteDefinationById(questionId: number): void {
     this.http.delete(`http://localhost:5221/api/Question/${questionId}`).subscribe({
       next: () => {
         this.toastMessage = 'Defination deleted successfully!';
         this.toastType = 'success';
         this.isToastVisible = true;
         this.fetchQuestions();
       },
       error: (err) => {
         this.toastMessage = 'Failed To Delete Defination';
         this.toastType = 'error';
         this.isToastVisible = true;
       },
     });
   }
   // =============================================================================================
}
