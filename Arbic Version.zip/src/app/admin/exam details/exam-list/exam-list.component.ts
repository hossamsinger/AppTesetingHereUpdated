import { Component, OnInit } from '@angular/core';
import { ExamServices } from '../../services/exam-detail-service';
import { IExam } from '../../models/Iexam';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { DevExtremeModule } from 'devextreme-angular';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import { RouterModule } from '@angular/router'; // Import RouterModule
import { DxDataGridModule } from 'devextreme-angular';
import { DxButtonModule } from 'devextreme-angular';

@Component({
  selector: 'app-exam-list',
  templateUrl: './exam-list.component.html',
  standalone:true,
  styleUrl: './exam-list.component.scss',
  imports:[
    CommonModule,
    DevExtremeModule,
    RouterModule,
    DxDataGridModule,
    DxButtonModule
  ],
})
export class ExamListComponent implements OnInit {
  dialog: any;

  examObj: any = {};
  examDetailsList: IExam[] = [];
  remoteDataSource: any;

  constructor(private router : Router,private http: HttpClient,
    private examDetailsService: ExamServices) { 
      this.remoteDataSource = createStore({
        key: 'Id',
        loadUrl: 'http://localhost:5221/api/Exam'
      });
     
    }

 ngOnInit(): void {
   this.getAllExams();
 }


 public getAllExams() {
   this.examDetailsService.getAll().subscribe((result: any) => {
     this.examDetailsList = result;
     console.log(this.examDetailsList);
   });
 }

 onEdit(updatedData: any)
 {
   this.examObj = updatedData;
 }

 onDetailsClick(){

 }

}
