import { Component, OnInit, ViewChild, viewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ExamServices } from '../../services/exam-detail-service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { Service, Tab } from '../../services/service';
import { createStore } from 'devextreme-aspnet-data-nojquery';
import { DevExtremeModule } from 'devextreme-angular';
import { RouterModule } from '@angular/router'; // Import RouterModule
import { DxTabsComponent } from 'devextreme-angular/ui/tabs';
import { DxDataGridModule } from 'devextreme-angular';
import { DxButtonModule } from 'devextreme-angular';

@Component({
  selector: 'app-exam-detail',
  templateUrl: './exam-detail.component.html',
  styleUrls: ['./exam-detail.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    CommonModule,
    DevExtremeModule,
    RouterModule,
    DxDataGridModule,
    DxButtonModule,
],
  providers: [Service],
})
export class ExamDetailComponent implements OnInit {
  examForm: FormGroup;

  ValidationMessages = {
    'name': {
      'required': 'Name is required',
      'minlength': 'Name must be greater than 3 characters',
      'maxlength': 'Name must be less than 10 characters'
    },
    'startDate': {
      'required': 'Start Date is required'
    },
    'endDate': {
      'required': 'End Date is required'
    },
    'location': {
      'required': 'Location Name is required'
    },
    'locationId': {
      'required': 'Location Id is required'
    },
    'examDefinitionId': {
      'required': 'Exam Definition Id is required'
    }
  };
formErrors = {
    'name': '',
    'startDate': '',
    'endDate': '',
    'location': '',
    'locationId': '',
    'examDefinitionId': ''
  };
  examObj: any = {};

   /* */
    // readonly withText = viewChild<DxTabsComponent>('withText');
    tabsWithText: { text: string; content: string; id: string }[] = [
      { text: 'Edit Exam Details', content: 'examForm', id: 'exam-details' },
      { text: 'Exam Questions', content: 'examQuestions', id: 'exam-questions' },
    ];
  
    @ViewChild(DxTabsComponent) withText!: DxTabsComponent;

  
    showNavButtons = false;
  
    scrollByContent = false;
  
    rtlEnabled = false;
  
    width = 'auto';

    locations : any;
    
    examDefinitions : any;
  
    widgetWrapperClasses = {
      'widget-wrapper': true,
      'widget-wrapper-horizontal': true,
      'widget-wrapper-vertical': false,
      'strict-width': false,
    };
  remoteDataSource: any;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private _route: ActivatedRoute,
    private http: HttpClient,
    private examDetailsService: ExamServices,
    private Service: Service
  ) {
    this.remoteDataSource = createStore({
            key: 'Id',
            loadUrl: 'https://localhost:7135/api/Exam/dxdatagrid'
          });
          
    this.examForm = this.fb.group({
      Name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(10)]],
      StartDate: ['', [Validators.required]],
      EndDate: ['', [Validators.required]],
      LocationId: ['', [Validators.required]],
      ExamDefinitionId: ['', [Validators.required]]
    });
     /**Assigned employees */
     this.tabsWithText = this.Service.getTabsWithText() as { text: string; content: string; id: string }[];

  }

  ngOnInit(): void {

    this.examDetailsService.getLocations().subscribe((result: any) => {
      this.locations = result;
    });

    this.examDetailsService.getExamDefinitions().subscribe((result: any) => {
      this.examDefinitions = result;
    });

    this._route.paramMap.subscribe(params => {
      if (params.get('id') && params.get('id') !== 'new') {
        this.examObj.Id = params.get('id');
        this.getExamById(this.examObj.Id);
      }
      else{
        this.examObj.Id = 0;
      }
    });

    this.examForm.valueChanges.subscribe((data: string) => {
      this.logValidationErrors(this.examForm);
    });



//  const examId = this._route.snapshot.paramMap.get('id');
//  if (examId) {
//    this.examDetailsService.getById(+examId).subscribe((examData) => {
//      this.examObj = examData;
//      this.examForm.patchValue(this.examObj);
//      if (this.examObj.id && this.examObj.id !== 'new') {
//       this.getExamById(this.examObj.id);
//     }
//    });
//    this.examForm.valueChanges.subscribe(() => {
//     this.logValidationErrors(this.examForm);
//   });
//  }

  }

  logValidationErrors(group: FormGroup = this.examForm): void {
    Object.keys(group.controls).forEach((key: string) => {
      const control = group.get(key);
  
      if (control) {
        this.formErrors[key as keyof typeof this.formErrors] = '';
  
        if (control.invalid && (control.touched || control.dirty)) {
          const controlErrors = control.errors;
  
          if (controlErrors) {
            Object.keys(controlErrors).forEach((errorKey: string) => {
              const validationMessagesForKey = this.ValidationMessages[key as keyof typeof this.ValidationMessages];
  
              if (validationMessagesForKey && validationMessagesForKey[errorKey as keyof typeof validationMessagesForKey]) {
                this.formErrors[key as keyof typeof this.formErrors] += validationMessagesForKey[errorKey as keyof typeof validationMessagesForKey] + ' ';
              }
            });
          }
        }
      }
    });
  }

  onSave() {
    console.log(this.examObj);
    
    this.examDetailsService.post(this.examObj).subscribe({
      next: () => {
        this.router.navigate(['exam/exam-list'])
      },
    });
  }

  onUpdate(): void {
    //console.log(this.examObj);
    this.examDetailsService.put(this.examObj.Id, this.examObj).subscribe({
      next: () => {
        this.router.navigate(['exam/exam-list'])
      },
    });
  }

  onDelete(id: any): void {
    const isDelete = confirm("Are you sure you want to delete?");
    if (isDelete) {
      this.examDetailsService.delete(id).subscribe(() => {
        this.router.navigate(['exam/exam-list']);
      });
    }
  }

  getExamById(id: any): void {
    this.examDetailsService.getById(id).subscribe((result: any) => {
      this.examObj = result;
      this.examForm.patchValue(result); // Populate the form with data
    });
  }
}
