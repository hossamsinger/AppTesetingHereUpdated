import { DateType } from "devextreme/ui/date_box";

export interface IExam {
    id: number;
    name: string;
    startDate: Date;
    endDate: Date;
    location: any;
    locationId?: number;
    examDefinitionId: number;
    examDefinition: string;
}