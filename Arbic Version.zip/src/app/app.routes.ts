import { AllQuestionComponent } from './admin/questions/allQuestion/questions.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Routes } from '@angular/router';
import { ResultsComponent } from './results/results.component';
import { CreationExamComponent } from './creationExam/creationExam.component';
// import { QuestionComponent } from './admin/question/question.component';
import { AllCategoryComponent } from './admin/category/allCategory/allCategory.component';
import { ExamDetailComponent } from './admin/exam details/exam-detail/exam-detail.component';
import { AllDefinationComponent } from './admin/defination/allDefination/definations.component';
import { AllVariantComponent } from './admin/variant/allVariant/variants.component';
import { ExamListComponent } from './admin/exam details/exam-list/exam-list.component';
export const routes: Routes = [  
  
  // =================================================
  //  Defult Routes For App.
  // =================================================
  { path: '', redirectTo: 'login', pathMatch: 'full' }, // Redirect to login


  // =================================================
  //  Routes For All Feature Of Admin And Component.
  // =================================================

  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'creationExam', component:CreationExamComponent  },
  { path: 'results', component: ResultsComponent },

  // =================================================
  //  Routes For All Feature Of Admin And Component.
  // =================================================

  { path: 'admin/AllCategory', component: AllCategoryComponent },
  { path: 'admin/AllDefination', component:AllDefinationComponent  },
  { path: 'admin/AllVariant', component:AllVariantComponent  },
  { path: 'admin/Questions', component: AllQuestionComponent },

  { path: 'exam/exam-details/:id', component: ExamDetailComponent },

  { path: 'exam/exam-list' , component: ExamListComponent },

  // =================================================
  //  Routes For All UnLinked Routes.
  // =================================================

  { path: '**', redirectTo: 'login' }, // Wildcard route for undefined paths

  
];
