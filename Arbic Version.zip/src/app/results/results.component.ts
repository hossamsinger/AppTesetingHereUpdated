import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { results } from '../../data/results';
import { FormsModule } from '@angular/forms';  // Import FormsModule

@Component({
  selector: 'app-results',
  standalone: true,
  imports: [ CommonModule , FormsModule],
  templateUrl: './results.component.html',
  styleUrl: './results.component.scss'
})
export class ResultsComponent {
  items = results;
    // ----------------------------------------
    // The filtered list of items (initially all items)
    filteredItems = this.items;
    searchQuery: string = '';
      // Filter items based on the search query
  filterItems(): void {
    const query = this.searchQuery.toLowerCase();
    this.filteredItems = this.items.filter(item =>
      item.employeeName.toLowerCase().includes(query)||
      item.examTitle.toLowerCase().includes(query)
    );
    console.log("this.filteredItems ====== ",this.filteredItems);
    
  }
}

