import {
  DxToastComponent,
  DxToastModule
} from "./chunk-DUPBN2OJ.js";
import "./chunk-GAYW56K5.js";
import "./chunk-O2ZOTGYJ.js";
import "./chunk-BC4UU3FA.js";
import "./chunk-ICKSQFPZ.js";
import "./chunk-M4PC57RV.js";
import "./chunk-WOX6XKRX.js";
import "./chunk-4MAIXMIT.js";
import "./chunk-ND5ICVCX.js";
import "./chunk-WBCLGCHV.js";
import "./chunk-EBLT4CH3.js";
import "./chunk-74ZAWBSC.js";
import "./chunk-WOR4A3D2.js";
export {
  DxToastComponent,
  DxToastModule
};
//# sourceMappingURL=devextreme-angular_ui_toast.js.map
