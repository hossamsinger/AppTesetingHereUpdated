import {
  query_default
} from "./chunk-4V47G62F.js";
import {
  applyBatch,
  custom_store_default,
  indexByKey,
  init_array_utils,
  init_custom_store,
  insert,
  remove,
  update
} from "./chunk-C5QLDEFD.js";
import {
  abstract_store_default,
  errors,
  init_abstract_store,
  init_errors as init_errors2,
  init_utils,
  keysEqual,
  normalizeSortingInfo,
  rejectedPromise,
  throttleChanges,
  trivialPromise
} from "./chunk-I3DYQMSR.js";
import {
  Action,
  CLICK_EVENT_NAME,
  TemplateBase,
  _objectWithoutPropertiesLoose,
  addNamespace,
  attachInstanceToElement,
  browser_default,
  cancelAnimationFrame,
  click,
  component_registrator_default,
  convertRulesToOptions,
  createDefaultOptionRules,
  current,
  devices_default,
  dom_component_default,
  dxClick,
  emitter_default,
  emitter_gesture_default,
  emitter_registrator_default,
  eventData,
  eventDelta,
  event_registrator_default,
  findTemplates,
  fireEvent,
  fitIntoRange,
  focus,
  focusable,
  getBoundingRect,
  getInstanceByElement,
  getPublicElement,
  getUniqueValues,
  isCommandKeyPressed,
  isDxMouseWheelEvent,
  isFluent,
  isMaterial,
  isMouseEvent,
  keyboard,
  keyboard_processor_default,
  locate,
  move,
  multiplyInExponentialForm,
  nativeScrolling,
  normalizeKeyName,
  pointer_default,
  removeDuplicates,
  removeEvent,
  replaceWith,
  requestAnimationFrame,
  resetPosition,
  resize,
  resize_callbacks_default,
  sign,
  touch,
  ui_errors_default,
  ui_widget_default,
  visibility
} from "./chunk-O2ZOTGYJ.js";
import {
  EventsStrategy,
  init_events_strategy
} from "./chunk-BC4UU3FA.js";
import {
  camelize,
  cleanDataRecursive,
  events_engine_default,
  getHeight,
  getOuterHeight,
  getOuterWidth,
  getWidth,
  humanize,
  init_element_data,
  init_events_engine,
  init_inflector,
  init_renderer,
  init_size,
  init_style,
  normalizeStyleProp,
  renderer_default,
  titleize
} from "./chunk-WOX6XKRX.js";
import {
  Deferred,
  _extends,
  ajax_default,
  class_default,
  compileGetter,
  deferRender,
  deferRenderer,
  deferUpdate,
  deferUpdater,
  dependency_injector_default,
  dom_adapter_default,
  each,
  ensureDefined,
  equalByValue,
  escapeRegExp,
  executeAsync,
  fromPromise,
  getKeyHash,
  getPathParts,
  getWindow,
  grep,
  guid_default,
  hasWindow,
  init_ajax,
  init_class,
  init_common,
  init_data,
  init_deferred,
  init_dependency_injector,
  init_dom_adapter,
  init_extends,
  init_guid,
  init_iterator,
  init_ready_callbacks,
  init_window,
  map,
  noop,
  ready_callbacks_default,
  when
} from "./chunk-4MAIXMIT.js";
import {
  config_default,
  errors_default,
  extend,
  format,
  init_config,
  init_errors,
  init_extend,
  init_string,
  init_type,
  isBoolean,
  isDate,
  isDefined,
  isEmptyObject,
  isFunction,
  isNumeric,
  isObject,
  isPlainObject,
  isPrimitive,
  isPromise,
  isRenderer,
  isString
} from "./chunk-ND5ICVCX.js";

// node_modules/devextreme/esm/__internal/ui/tabs/m_tabs.js
init_renderer();

// node_modules/devextreme/esm/core/templates/bindable_template.js
init_renderer();
init_events_engine();
init_type();
var watchChanges = function(rawData, watchMethod, fields, fieldsMap, callback) {
  let fieldsDispose;
  const globalDispose = ((data, watchMethod2, callback2) => watchMethod2(() => data, callback2))(rawData, watchMethod, function(dataWithRawFields) {
    fieldsDispose && fieldsDispose();
    if (isPrimitive(dataWithRawFields)) {
      callback(dataWithRawFields);
      return;
    }
    fieldsDispose = function(data, watchMethod2, fields2, fieldsMap2, callback2) {
      const resolvedData = {};
      const missedFields = fields2.slice();
      const watchHandlers = fields2.map(function(name2) {
        const fieldGetter = fieldsMap2[name2];
        return watchMethod2(fieldGetter ? () => fieldGetter(data) : () => data[name2], function(value) {
          resolvedData[name2] = value;
          if (missedFields.length) {
            const index = missedFields.indexOf(name2);
            if (index >= 0) {
              missedFields.splice(index, 1);
            }
          }
          if (!missedFields.length) {
            callback2(resolvedData);
          }
        });
      });
      return function() {
        watchHandlers.forEach((dispose) => dispose());
      };
    }(dataWithRawFields, watchMethod, fields, fieldsMap, callback);
  });
  return function() {
    fieldsDispose && fieldsDispose();
    globalDispose && globalDispose();
  };
};
var BindableTemplate = class extends TemplateBase {
  constructor(render4, fields, watchMethod, fieldsMap) {
    super();
    this._render = render4;
    this._fields = fields;
    this._fieldsMap = fieldsMap || {};
    this._watchMethod = watchMethod;
  }
  _renderCore(options2) {
    const $container = renderer_default(options2.container);
    const dispose = watchChanges(options2.model, this._watchMethod, this._fields, this._fieldsMap, (data) => {
      $container.empty();
      this._render($container, data, options2.model);
    });
    events_engine_default.on($container, removeEvent, dispose);
    return $container.contents();
  }
};

// node_modules/devextreme/esm/__internal/ui/tabs/m_tabs.js
init_deferred();
init_extend();

// node_modules/devextreme/esm/core/utils/icon.js
init_renderer();
var getImageSourceType = (source) => {
  if (!source || "string" !== typeof source) {
    return false;
  }
  if (/^\s*<svg[^>]*>(.|\r?\n)*?<\/svg>\s*$/i.test(source)) {
    return "svg";
  }
  if (/data:.*base64|\.|[^<\s]\/{1,1}/.test(source)) {
    return "image";
  }
  if (/^[\w-_]+$/.test(source)) {
    return "dxIcon";
  }
  if (/^\s?([\w-_:]\s?)+$/.test(source)) {
    return "fontIcon";
  }
  return false;
};
var getImageContainer = (source) => {
  switch (getImageSourceType(source)) {
    case "image":
      return renderer_default("<img>").attr("src", source).addClass("dx-icon");
    case "fontIcon":
      return renderer_default("<i>").addClass(`dx-icon ${source}`);
    case "dxIcon":
      return renderer_default("<i>").addClass(`dx-icon dx-icon-${source}`);
    case "svg":
      return renderer_default("<i>").addClass("dx-icon dx-svg-icon").append(source);
    default:
      return null;
  }
};

// node_modules/devextreme/esm/__internal/ui/tabs/m_tabs.js
init_iterator();
init_size();
init_type();
init_window();
init_events_engine();

// node_modules/devextreme/esm/events/hold.js
var abs = Math.abs;
var HoldEmitter = emitter_default.inherit({
  start: function(e) {
    this._startEventData = eventData(e);
    this._startTimer(e);
  },
  _startTimer: function(e) {
    const holdTimeout = "timeout" in this ? this.timeout : 750;
    this._holdTimer = setTimeout(function() {
      this._requestAccept(e);
      this._fireEvent("dxhold", e, {
        target: e.target
      });
      this._forgetAccept();
    }.bind(this), holdTimeout);
  },
  move: function(e) {
    if (this._touchWasMoved(e)) {
      this._cancel(e);
    }
  },
  _touchWasMoved: function(e) {
    const delta = eventDelta(this._startEventData, eventData(e));
    return abs(delta.x) > 5 || abs(delta.y) > 5;
  },
  end: function() {
    this._stopTimer();
  },
  _stopTimer: function() {
    clearTimeout(this._holdTimer);
  },
  cancel: function() {
    this._stopTimer();
  },
  dispose: function() {
    this._stopTimer();
  }
});
emitter_registrator_default({
  emitter: HoldEmitter,
  bubble: true,
  events: ["dxhold"]
});
var hold_default = {
  name: "dxhold"
};

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/get_scroll_left_max.js
function getScrollLeftMax(element) {
  return element.scrollWidth - element.clientWidth;
}

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/get_scroll_top_max.js
function getScrollTopMax(element) {
  return element.scrollHeight - element.clientHeight;
}

// node_modules/devextreme/esm/renovation/ui/scroll_view/common/consts.js
var DIRECTION_VERTICAL = "vertical";
var DIRECTION_HORIZONTAL = "horizontal";
var DIRECTION_BOTH = "both";
var SCROLLABLE_CONTENT_CLASS = "dx-scrollable-content";

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/scroll_direction.js
var ScrollDirection = class {
  constructor(direction) {
    this.DIRECTION_HORIZONTAL = "horizontal";
    this.DIRECTION_VERTICAL = "vertical";
    this.DIRECTION_BOTH = "both";
    this.direction = direction ?? DIRECTION_VERTICAL;
  }
  get isHorizontal() {
    return this.direction === DIRECTION_HORIZONTAL || this.direction === DIRECTION_BOTH;
  }
  get isVertical() {
    return this.direction === DIRECTION_VERTICAL || this.direction === DIRECTION_BOTH;
  }
  get isBoth() {
    return this.direction === DIRECTION_BOTH;
  }
};

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/get_boundary_props.js
function isReachedLeft(scrollOffsetLeft, epsilon) {
  return Math.round(scrollOffsetLeft) <= epsilon;
}
function isReachedRight(element, scrollOffsetLeft, epsilon) {
  return Math.round(getScrollLeftMax(element) - scrollOffsetLeft) <= epsilon;
}
function isReachedTop(scrollOffsetTop, epsilon) {
  return Math.round(scrollOffsetTop) <= epsilon;
}
function isReachedBottom(element, scrollOffsetTop, pocketHeight, epsilon) {
  return Math.round(getScrollTopMax(element) - scrollOffsetTop - pocketHeight) <= epsilon;
}

// node_modules/devextreme/esm/renovation/component_wrapper/button.js
init_extends();

// node_modules/devextreme/esm/__internal/ui/m_validation_engine.js
init_class();
init_errors();
init_events_strategy();
init_common();
init_deferred();
init_extend();
init_iterator();
init_type();

// node_modules/devextreme/esm/localization/message.js
init_dependency_injector();
init_extend();
init_string();
init_inflector();

// node_modules/devextreme/esm/localization/core.js
init_dependency_injector();

// node_modules/devextreme/esm/localization/cldr-data/parent_locales.js
var parent_locales_default = {
  "en-150": "en-001",
  "en-AG": "en-001",
  "en-AI": "en-001",
  "en-AU": "en-001",
  "en-BB": "en-001",
  "en-BM": "en-001",
  "en-BS": "en-001",
  "en-BW": "en-001",
  "en-BZ": "en-001",
  "en-CC": "en-001",
  "en-CK": "en-001",
  "en-CM": "en-001",
  "en-CX": "en-001",
  "en-CY": "en-001",
  "en-DG": "en-001",
  "en-DM": "en-001",
  "en-ER": "en-001",
  "en-FJ": "en-001",
  "en-FK": "en-001",
  "en-FM": "en-001",
  "en-GB": "en-001",
  "en-GD": "en-001",
  "en-GG": "en-001",
  "en-GH": "en-001",
  "en-GI": "en-001",
  "en-GM": "en-001",
  "en-GY": "en-001",
  "en-HK": "en-001",
  "en-IE": "en-001",
  "en-IL": "en-001",
  "en-IM": "en-001",
  "en-IN": "en-001",
  "en-IO": "en-001",
  "en-JE": "en-001",
  "en-JM": "en-001",
  "en-KE": "en-001",
  "en-KI": "en-001",
  "en-KN": "en-001",
  "en-KY": "en-001",
  "en-LC": "en-001",
  "en-LR": "en-001",
  "en-LS": "en-001",
  "en-MG": "en-001",
  "en-MO": "en-001",
  "en-MS": "en-001",
  "en-MT": "en-001",
  "en-MU": "en-001",
  "en-MV": "en-001",
  "en-MW": "en-001",
  "en-MY": "en-001",
  "en-NA": "en-001",
  "en-NF": "en-001",
  "en-NG": "en-001",
  "en-NR": "en-001",
  "en-NU": "en-001",
  "en-NZ": "en-001",
  "en-PG": "en-001",
  "en-PK": "en-001",
  "en-PN": "en-001",
  "en-PW": "en-001",
  "en-RW": "en-001",
  "en-SB": "en-001",
  "en-SC": "en-001",
  "en-SD": "en-001",
  "en-SG": "en-001",
  "en-SH": "en-001",
  "en-SL": "en-001",
  "en-SS": "en-001",
  "en-SX": "en-001",
  "en-SZ": "en-001",
  "en-TC": "en-001",
  "en-TK": "en-001",
  "en-TO": "en-001",
  "en-TT": "en-001",
  "en-TV": "en-001",
  "en-TZ": "en-001",
  "en-UG": "en-001",
  "en-VC": "en-001",
  "en-VG": "en-001",
  "en-VU": "en-001",
  "en-WS": "en-001",
  "en-ZA": "en-001",
  "en-ZM": "en-001",
  "en-ZW": "en-001",
  "en-AT": "en-150",
  "en-BE": "en-150",
  "en-CH": "en-150",
  "en-DE": "en-150",
  "en-DK": "en-150",
  "en-FI": "en-150",
  "en-NL": "en-150",
  "en-SE": "en-150",
  "en-SI": "en-150",
  "hi-Latn": "en-IN",
  "es-AR": "es-419",
  "es-BO": "es-419",
  "es-BR": "es-419",
  "es-BZ": "es-419",
  "es-CL": "es-419",
  "es-CO": "es-419",
  "es-CR": "es-419",
  "es-CU": "es-419",
  "es-DO": "es-419",
  "es-EC": "es-419",
  "es-GT": "es-419",
  "es-HN": "es-419",
  "es-MX": "es-419",
  "es-NI": "es-419",
  "es-PA": "es-419",
  "es-PE": "es-419",
  "es-PR": "es-419",
  "es-PY": "es-419",
  "es-SV": "es-419",
  "es-US": "es-419",
  "es-UY": "es-419",
  "es-VE": "es-419",
  nb: "no",
  nn: "no",
  "pt-AO": "pt-PT",
  "pt-CH": "pt-PT",
  "pt-CV": "pt-PT",
  "pt-FR": "pt-PT",
  "pt-GQ": "pt-PT",
  "pt-GW": "pt-PT",
  "pt-LU": "pt-PT",
  "pt-MO": "pt-PT",
  "pt-MZ": "pt-PT",
  "pt-ST": "pt-PT",
  "pt-TL": "pt-PT",
  "az-Arab": "und",
  "az-Cyrl": "und",
  "bal-Latn": "und",
  "blt-Latn": "und",
  "bm-Nkoo": "und",
  "bs-Cyrl": "und",
  "byn-Latn": "und",
  "cu-Glag": "und",
  "dje-Arab": "und",
  "dyo-Arab": "und",
  "en-Dsrt": "und",
  "en-Shaw": "und",
  "ff-Adlm": "und",
  "ff-Arab": "und",
  "ha-Arab": "und",
  "iu-Latn": "und",
  "kk-Arab": "und",
  "ks-Deva": "und",
  "ku-Arab": "und",
  "ky-Arab": "und",
  "ky-Latn": "und",
  "ml-Arab": "und",
  "mn-Mong": "und",
  "mni-Mtei": "und",
  "ms-Arab": "und",
  "pa-Arab": "und",
  "sat-Deva": "und",
  "sd-Deva": "und",
  "sd-Khoj": "und",
  "sd-Sind": "und",
  "shi-Latn": "und",
  "so-Arab": "und",
  "sr-Latn": "und",
  "sw-Arab": "und",
  "tg-Arab": "und",
  "ug-Cyrl": "und",
  "uz-Arab": "und",
  "uz-Cyrl": "und",
  "vai-Latn": "und",
  "wo-Arab": "und",
  "yo-Arab": "und",
  "yue-Hans": "und",
  "zh-Hant": "und",
  "zh-Hant-MO": "zh-Hant-HK"
};

// node_modules/devextreme/esm/localization/parentLocale.js
var parentLocale_default = (parentLocales, locale) => {
  const parentLocale = parentLocales[locale];
  if (parentLocale) {
    return "root" !== parentLocale && parentLocale;
  }
  return locale.substr(0, locale.lastIndexOf("-"));
};

// node_modules/devextreme/esm/localization/core.js
var core_default = dependency_injector_default({
  locale: /* @__PURE__ */ (() => {
    let currentLocale = "en";
    return (locale) => {
      if (!locale) {
        return currentLocale;
      }
      currentLocale = locale;
    };
  })(),
  getValueByClosestLocale: function(getter) {
    let locale = this.locale();
    let value = getter(locale);
    let isRootLocale;
    while (!value && !isRootLocale) {
      locale = parentLocale_default(parent_locales_default, locale);
      if (locale) {
        value = getter(locale);
      } else {
        isRootLocale = true;
      }
    }
    if (void 0 === value && "en" !== locale) {
      return getter("en");
    }
    return value;
  }
});

// node_modules/devextreme/esm/localization/default_messages.js
var defaultMessages = {
  en: {
    Yes: "Yes",
    No: "No",
    Cancel: "Cancel",
    CheckState: "Check state",
    Close: "Close",
    Clear: "Clear",
    Done: "Done",
    Loading: "Loading...",
    Select: "Select...",
    Search: "Search",
    Back: "Back",
    OK: "OK",
    "dxCollectionWidget-noDataText": "No data to display",
    "dxDropDownEditor-selectLabel": "Select",
    "validation-required": "Required",
    "validation-required-formatted": "{0} is required",
    "validation-numeric": "Value must be a number",
    "validation-numeric-formatted": "{0} must be a number",
    "validation-range": "Value is out of range",
    "validation-range-formatted": "{0} is out of range",
    "validation-stringLength": "The length of the value is not correct",
    "validation-stringLength-formatted": "The length of {0} is not correct",
    "validation-custom": "Value is invalid",
    "validation-custom-formatted": "{0} is invalid",
    "validation-async": "Value is invalid",
    "validation-async-formatted": "{0} is invalid",
    "validation-compare": "Values do not match",
    "validation-compare-formatted": "{0} does not match",
    "validation-pattern": "Value does not match pattern",
    "validation-pattern-formatted": "{0} does not match pattern",
    "validation-email": "Email is invalid",
    "validation-email-formatted": "{0} is invalid",
    "validation-mask": "Value is invalid",
    "dxLookup-searchPlaceholder": "Minimum character number: {0}",
    "dxList-pullingDownText": "Pull down to refresh...",
    "dxList-pulledDownText": "Release to refresh...",
    "dxList-refreshingText": "Refreshing...",
    "dxList-pageLoadingText": "Loading...",
    "dxList-nextButtonText": "More",
    "dxList-selectAll": "Select All",
    "dxList-listAriaLabel": "Items",
    "dxList-listAriaLabel-deletable": "Deletable items",
    "dxListEditDecorator-delete": "Delete",
    "dxListEditDecorator-more": "More",
    "dxList-selectAll-indeterminate": "Half-checked",
    "dxList-selectAll-checked": "Checked",
    "dxList-selectAll-notChecked": "Not checked",
    "dxScrollView-pullingDownText": "Pull down to refresh...",
    "dxScrollView-pulledDownText": "Release to refresh...",
    "dxScrollView-refreshingText": "Refreshing...",
    "dxScrollView-reachBottomText": "Loading...",
    "dxDateBox-simulatedDataPickerTitleTime": "Select time",
    "dxDateBox-simulatedDataPickerTitleDate": "Select date",
    "dxDateBox-simulatedDataPickerTitleDateTime": "Select date and time",
    "dxDateBox-validation-datetime": "Value must be a date or time",
    "dxDateRangeBox-invalidStartDateMessage": "Start value must be a date",
    "dxDateRangeBox-invalidEndDateMessage": "End value must be a date",
    "dxDateRangeBox-startDateOutOfRangeMessage": "Start date is out of range",
    "dxDateRangeBox-endDateOutOfRangeMessage": "End date is out of range",
    "dxDateRangeBox-startDateLabel": "Start Date",
    "dxDateRangeBox-endDateLabel": "End Date",
    "dxFileUploader-selectFile": "Select a file",
    "dxFileUploader-dropFile": "or Drop a file here",
    "dxFileUploader-bytes": "bytes",
    "dxFileUploader-kb": "KB",
    "dxFileUploader-Mb": "MB",
    "dxFileUploader-Gb": "GB",
    "dxFileUploader-upload": "Upload",
    "dxFileUploader-uploaded": "Uploaded",
    "dxFileUploader-readyToUpload": "Ready to upload",
    "dxFileUploader-uploadAbortedMessage": "Upload cancelled",
    "dxFileUploader-uploadFailedMessage": "Upload failed",
    "dxFileUploader-invalidFileExtension": "File type is not allowed",
    "dxFileUploader-invalidMaxFileSize": "File is too large",
    "dxFileUploader-invalidMinFileSize": "File is too small",
    "dxRangeSlider-ariaFrom": "From",
    "dxRangeSlider-ariaTill": "Till",
    "dxSwitch-switchedOnText": "ON",
    "dxSwitch-switchedOffText": "OFF",
    "dxForm-optionalMark": "optional",
    "dxForm-requiredMessage": "{0} is required",
    "dxNumberBox-invalidValueMessage": "Value must be a number",
    "dxNumberBox-noDataText": "No data",
    "dxDataGrid-emptyHeaderWithColumnChooserText": "Use {0} to display columns",
    "dxDataGrid-emptyHeaderWithGroupPanelText": "Drag a column from the group panel here",
    "dxDataGrid-emptyHeaderWithColumnChooserAndGroupPanelText": "Use {0} or drag a column from the group panel",
    "dxDataGrid-emptyHeaderColumnChooserText": "column chooser",
    "dxDataGrid-columnChooserTitle": "Column Chooser",
    "dxDataGrid-columnChooserEmptyText": "Drag a column here to hide it",
    "dxDataGrid-groupContinuesMessage": "Continues on the next page",
    "dxDataGrid-groupContinuedMessage": "Continued from the previous page",
    "dxDataGrid-groupHeaderText": "Group by This Column",
    "dxDataGrid-ungroupHeaderText": "Ungroup",
    "dxDataGrid-ungroupAllText": "Ungroup All",
    "dxDataGrid-editingEditRow": "Edit",
    "dxDataGrid-editingSaveRowChanges": "Save",
    "dxDataGrid-editingCancelRowChanges": "Cancel",
    "dxDataGrid-editingDeleteRow": "Delete",
    "dxDataGrid-editingUndeleteRow": "Undelete",
    "dxDataGrid-editingConfirmDeleteMessage": "Are you sure you want to delete this record?",
    "dxDataGrid-validationCancelChanges": "Cancel changes",
    "dxDataGrid-groupPanelEmptyText": "Drag a column header here to group by that column",
    "dxDataGrid-noDataText": "No data",
    "dxDataGrid-searchPanelPlaceholder": "Search...",
    "dxDataGrid-filterRowShowAllText": "(All)",
    "dxDataGrid-filterRowResetOperationText": "Reset",
    "dxDataGrid-filterRowOperationEquals": "Equals",
    "dxDataGrid-filterRowOperationNotEquals": "Does not equal",
    "dxDataGrid-filterRowOperationLess": "Less than",
    "dxDataGrid-filterRowOperationLessOrEquals": "Less than or equal to",
    "dxDataGrid-filterRowOperationGreater": "Greater than",
    "dxDataGrid-filterRowOperationGreaterOrEquals": "Greater than or equal to",
    "dxDataGrid-filterRowOperationStartsWith": "Starts with",
    "dxDataGrid-filterRowOperationContains": "Contains",
    "dxDataGrid-filterRowOperationNotContains": "Does not contain",
    "dxDataGrid-filterRowOperationEndsWith": "Ends with",
    "dxDataGrid-filterRowOperationBetween": "Between",
    "dxDataGrid-filterRowOperationBetweenStartText": "Start",
    "dxDataGrid-filterRowOperationBetweenEndText": "End",
    "dxDataGrid-ariaSearchBox": "Search box",
    "dxDataGrid-applyFilterText": "Apply filter",
    "dxDataGrid-trueText": "true",
    "dxDataGrid-falseText": "false",
    "dxDataGrid-sortingAscendingText": "Sort Ascending",
    "dxDataGrid-sortingDescendingText": "Sort Descending",
    "dxDataGrid-sortingClearText": "Clear Sorting",
    "dxDataGrid-ariaNotSortedColumn": "Not sorted column",
    "dxDataGrid-ariaSortedAscendingColumn": "Column sorted in ascending order",
    "dxDataGrid-ariaSortedDescendingColumn": "Column sorted in descending order",
    "dxDataGrid-ariaSortIndex": "Sort index {0}",
    "dxDataGrid-editingSaveAllChanges": "Save changes",
    "dxDataGrid-editingCancelAllChanges": "Discard changes",
    "dxDataGrid-editingAddRow": "Add a row",
    "dxDataGrid-summaryMin": "Min: {0}",
    "dxDataGrid-summaryMinOtherColumn": "Min of {1} is {0}",
    "dxDataGrid-summaryMax": "Max: {0}",
    "dxDataGrid-summaryMaxOtherColumn": "Max of {1} is {0}",
    "dxDataGrid-summaryAvg": "Avg: {0}",
    "dxDataGrid-summaryAvgOtherColumn": "Avg of {1} is {0}",
    "dxDataGrid-summarySum": "Sum: {0}",
    "dxDataGrid-summarySumOtherColumn": "Sum of {1} is {0}",
    "dxDataGrid-summaryCount": "Count: {0}",
    "dxDataGrid-columnFixingFix": "Fix",
    "dxDataGrid-columnFixingUnfix": "Unfix",
    "dxDataGrid-columnFixingLeftPosition": "To the left",
    "dxDataGrid-columnFixingRightPosition": "To the right",
    "dxDataGrid-exportTo": "Export",
    "dxDataGrid-exportToExcel": "Export to Excel file",
    "dxDataGrid-exporting": "Exporting...",
    "dxDataGrid-excelFormat": "Excel file",
    "dxDataGrid-selectedRows": "Selected rows",
    "dxDataGrid-exportSelectedRows": "Export selected rows to {0}",
    "dxDataGrid-exportAll": "Export all data to {0}",
    "dxDataGrid-headerFilterLabel": "Filter options",
    "dxDataGrid-headerFilterIndicatorLabel": "Show filter options for column '{0}'",
    "dxDataGrid-headerFilterEmptyValue": "(Blanks)",
    "dxDataGrid-headerFilterOK": "OK",
    "dxDataGrid-headerFilterCancel": "Cancel",
    "dxDataGrid-ariaAdaptiveCollapse": "Hide additional data",
    "dxDataGrid-ariaAdaptiveExpand": "Display additional data",
    "dxDataGrid-ariaColumn": "Column",
    "dxDataGrid-ariaColumnHeader": "Column header",
    "dxDataGrid-ariaValue": "Value",
    "dxDataGrid-ariaError": "Error",
    "dxDataGrid-ariaRevertButton": "Press Escape to discard the changes",
    "dxDataGrid-ariaFilterCell": "Filter cell",
    "dxDataGrid-ariaCollapse": "Collapse",
    "dxDataGrid-ariaModifiedCell": "Modified",
    "dxDataGrid-ariaDeletedCell": "Deleted",
    "dxDataGrid-ariaEditableCell": "Editable",
    "dxDataGrid-ariaExpand": "Expand",
    "dxDataGrid-ariaCollapsedRow": "Collapsed row",
    "dxDataGrid-ariaExpandedRow": "Expanded row",
    "dxDataGrid-ariaDataGrid": "Data grid with {0} rows and {1} columns",
    "dxDataGrid-ariaSearchInGrid": "Search in the data grid",
    "dxDataGrid-ariaSelectAll": "Select all",
    "dxDataGrid-ariaSelectRow": "Select row",
    "dxDataGrid-ariaToolbar": "Data grid toolbar",
    "dxDataGrid-ariaEditForm": "Edit form",
    "dxDataGrid-filterBuilderPopupTitle": "Filter Builder",
    "dxDataGrid-filterPanelCreateFilter": "Create Filter",
    "dxDataGrid-filterPanelClearFilter": "Clear",
    "dxDataGrid-filterPanelFilterEnabledHint": "Enable the filter",
    "dxDataGrid-masterDetail": "Cell with details",
    "dxTreeList-ariaTreeList": "Tree list with {0} rows and {1} columns",
    "dxTreeList-ariaSearchInGrid": "Search in the tree list",
    "dxTreeList-ariaToolbar": "Tree list toolbar",
    "dxTreeList-editingAddRowToNode": "Add",
    "dxPager-infoText": "Page {0} of {1} ({2} items)",
    "dxPager-pagesCountText": "of",
    "dxPager-pageSize": "Items per page: {0}",
    "dxPager-pageSizesAllText": "All",
    "dxPager-page": "Page {0}",
    "dxPager-prevPage": "Previous Page",
    "dxPager-nextPage": "Next Page",
    "dxPager-ariaLabel": "Page Navigation",
    "dxPager-ariaPageSize": "Page size",
    "dxPager-ariaPageNumber": "Page number",
    "dxPivotGrid-grandTotal": "Grand Total",
    "dxPivotGrid-total": "{0} Total",
    "dxPivotGrid-fieldChooserTitle": "Field Chooser",
    "dxPivotGrid-showFieldChooser": "Show Field Chooser",
    "dxPivotGrid-expandAll": "Expand All",
    "dxPivotGrid-collapseAll": "Collapse All",
    "dxPivotGrid-sortColumnBySummary": 'Sort "{0}" by This Column',
    "dxPivotGrid-sortRowBySummary": 'Sort "{0}" by This Row',
    "dxPivotGrid-removeAllSorting": "Remove All Sorting",
    "dxPivotGrid-dataNotAvailable": "N/A",
    "dxPivotGrid-rowFields": "Row Fields",
    "dxPivotGrid-columnFields": "Column Fields",
    "dxPivotGrid-dataFields": "Data Fields",
    "dxPivotGrid-filterFields": "Filter Fields",
    "dxPivotGrid-allFields": "All Fields",
    "dxPivotGrid-columnFieldArea": "Drop Column Fields Here",
    "dxPivotGrid-dataFieldArea": "Drop Data Fields Here",
    "dxPivotGrid-rowFieldArea": "Drop Row Fields Here",
    "dxPivotGrid-filterFieldArea": "Drop Filter Fields Here",
    "dxScheduler-editorLabelTitle": "Subject",
    "dxScheduler-editorLabelStartDate": "Start Date",
    "dxScheduler-editorLabelEndDate": "End Date",
    "dxScheduler-editorLabelDescription": "Description",
    "dxScheduler-editorLabelRecurrence": "Repeat",
    "dxScheduler-openAppointment": "Open appointment",
    "dxScheduler-recurrenceNever": "Never",
    "dxScheduler-recurrenceMinutely": "Every minute",
    "dxScheduler-recurrenceHourly": "Hourly",
    "dxScheduler-recurrenceDaily": "Daily",
    "dxScheduler-recurrenceWeekly": "Weekly",
    "dxScheduler-recurrenceMonthly": "Monthly",
    "dxScheduler-recurrenceYearly": "Yearly",
    "dxScheduler-recurrenceRepeatEvery": "Repeat Every",
    "dxScheduler-recurrenceRepeatOn": "Repeat On",
    "dxScheduler-recurrenceEnd": "End repeat",
    "dxScheduler-recurrenceAfter": "After",
    "dxScheduler-recurrenceOn": "On",
    "dxScheduler-recurrenceRepeatMinutely": "minute(s)",
    "dxScheduler-recurrenceRepeatHourly": "hour(s)",
    "dxScheduler-recurrenceRepeatDaily": "day(s)",
    "dxScheduler-recurrenceRepeatWeekly": "week(s)",
    "dxScheduler-recurrenceRepeatMonthly": "month(s)",
    "dxScheduler-recurrenceRepeatYearly": "year(s)",
    "dxScheduler-switcherDay": "Day",
    "dxScheduler-switcherWeek": "Week",
    "dxScheduler-switcherWorkWeek": "Work Week",
    "dxScheduler-switcherMonth": "Month",
    "dxScheduler-switcherAgenda": "Agenda",
    "dxScheduler-switcherTimelineDay": "Timeline Day",
    "dxScheduler-switcherTimelineWeek": "Timeline Week",
    "dxScheduler-switcherTimelineWorkWeek": "Timeline Work Week",
    "dxScheduler-switcherTimelineMonth": "Timeline Month",
    "dxScheduler-recurrenceRepeatOnDate": "on date",
    "dxScheduler-recurrenceRepeatCount": "occurrence(s)",
    "dxScheduler-allDay": "All day",
    "dxScheduler-confirmRecurrenceEditTitle": "Edit Recurring Appointment",
    "dxScheduler-confirmRecurrenceDeleteTitle": "Delete Recurring Appointment",
    "dxScheduler-confirmRecurrenceEditMessage": "Do you want to edit only this appointment or the whole series?",
    "dxScheduler-confirmRecurrenceDeleteMessage": "Do you want to delete only this appointment or the whole series?",
    "dxScheduler-confirmRecurrenceEditSeries": "Edit series",
    "dxScheduler-confirmRecurrenceDeleteSeries": "Delete series",
    "dxScheduler-confirmRecurrenceEditOccurrence": "Edit appointment",
    "dxScheduler-confirmRecurrenceDeleteOccurrence": "Delete appointment",
    "dxScheduler-noTimezoneTitle": "No timezone",
    "dxScheduler-moreAppointments": "{0} more",
    "dxCalendar-currentDay": "Today",
    "dxCalendar-currentMonth": "Current month",
    "dxCalendar-currentYear": "Current year",
    "dxCalendar-currentYearRange": "Current year range",
    "dxCalendar-todayButtonText": "Today",
    "dxCalendar-ariaWidgetName": "Calendar",
    "dxCalendar-previousMonthButtonLabel": "Previous month",
    "dxCalendar-previousYearButtonLabel": "Previous year",
    "dxCalendar-previousDecadeButtonLabel": "Previous decade",
    "dxCalendar-previousCenturyButtonLabel": "Previous century",
    "dxCalendar-nextMonthButtonLabel": "Next month",
    "dxCalendar-nextYearButtonLabel": "Next year",
    "dxCalendar-nextDecadeButtonLabel": "Next decade",
    "dxCalendar-nextCenturyButtonLabel": "Next century",
    "dxCalendar-captionMonthLabel": "Month selection",
    "dxCalendar-captionYearLabel": "Year selection",
    "dxCalendar-captionDecadeLabel": "Decade selection",
    "dxCalendar-captionCenturyLabel": "Century selection",
    "dxCalendar-selectedDate": "The selected date is {0}",
    "dxCalendar-selectedDateRange": "The selected date range is from {0} to {1}",
    "dxColorView-ariaRed": "Red",
    "dxColorView-ariaGreen": "Green",
    "dxColorView-ariaBlue": "Blue",
    "dxColorView-ariaAlpha": "Transparency",
    "dxColorView-ariaHex": "Color code",
    "dxTagBox-selected": "{0} selected",
    "dxTagBox-allSelected": "All selected ({0})",
    "dxTagBox-moreSelected": "{0} more",
    "dxTagBox-tagRoleDescription": "Tag. Press the delete button to remove this tag",
    "vizExport-printingButtonText": "Print",
    "vizExport-titleMenuText": "Exporting/Printing",
    "vizExport-exportButtonText": "{0} file",
    "dxFilterBuilder-and": "And",
    "dxFilterBuilder-or": "Or",
    "dxFilterBuilder-notAnd": "Not And",
    "dxFilterBuilder-notOr": "Not Or",
    "dxFilterBuilder-addCondition": "Add Condition",
    "dxFilterBuilder-addGroup": "Add Group",
    "dxFilterBuilder-enterValueText": "<enter a value>",
    "dxFilterBuilder-filterOperationEquals": "Equals",
    "dxFilterBuilder-filterOperationNotEquals": "Does not equal",
    "dxFilterBuilder-filterOperationLess": "Is less than",
    "dxFilterBuilder-filterOperationLessOrEquals": "Is less than or equal to",
    "dxFilterBuilder-filterOperationGreater": "Is greater than",
    "dxFilterBuilder-filterOperationGreaterOrEquals": "Is greater than or equal to",
    "dxFilterBuilder-filterOperationStartsWith": "Starts with",
    "dxFilterBuilder-filterOperationContains": "Contains",
    "dxFilterBuilder-filterOperationNotContains": "Does not contain",
    "dxFilterBuilder-filterOperationEndsWith": "Ends with",
    "dxFilterBuilder-filterOperationIsBlank": "Is blank",
    "dxFilterBuilder-filterOperationIsNotBlank": "Is not blank",
    "dxFilterBuilder-filterOperationBetween": "Is between",
    "dxFilterBuilder-filterOperationAnyOf": "Is any of",
    "dxFilterBuilder-filterOperationNoneOf": "Is none of",
    "dxHtmlEditor-dialogColorCaption": "Change Font Color",
    "dxHtmlEditor-dialogBackgroundCaption": "Change Background Color",
    "dxHtmlEditor-dialogLinkCaption": "Add Link",
    "dxHtmlEditor-dialogLinkUrlField": "URL",
    "dxHtmlEditor-dialogLinkTextField": "Text",
    "dxHtmlEditor-dialogLinkTargetField": "Open link in new window",
    "dxHtmlEditor-dialogImageCaption": "Add Image",
    "dxHtmlEditor-dialogImageUrlField": "URL",
    "dxHtmlEditor-dialogImageAltField": "Alternate text",
    "dxHtmlEditor-dialogImageWidthField": "Width (px)",
    "dxHtmlEditor-dialogImageHeightField": "Height (px)",
    "dxHtmlEditor-dialogInsertTableRowsField": "Rows",
    "dxHtmlEditor-dialogInsertTableColumnsField": "Columns",
    "dxHtmlEditor-dialogInsertTableCaption": "Insert Table",
    "dxHtmlEditor-dialogUpdateImageCaption": "Update Image",
    "dxHtmlEditor-dialogImageUpdateButton": "Update",
    "dxHtmlEditor-dialogImageAddButton": "Add",
    "dxHtmlEditor-dialogImageSpecifyUrl": "From the Web",
    "dxHtmlEditor-dialogImageSelectFile": "From This Device",
    "dxHtmlEditor-dialogImageKeepAspectRatio": "Keep Aspect Ratio",
    "dxHtmlEditor-dialogImageEncodeToBase64": "Encode to Base64",
    "dxHtmlEditor-heading": "Heading",
    "dxHtmlEditor-normalText": "Normal text",
    "dxHtmlEditor-background": "Background Color",
    "dxHtmlEditor-bold": "Bold",
    "dxHtmlEditor-color": "Font Color",
    "dxHtmlEditor-font": "Font",
    "dxHtmlEditor-italic": "Italic",
    "dxHtmlEditor-link": "Add Link",
    "dxHtmlEditor-image": "Add Image",
    "dxHtmlEditor-size": "Size",
    "dxHtmlEditor-strike": "Strikethrough",
    "dxHtmlEditor-subscript": "Subscript",
    "dxHtmlEditor-superscript": "Superscript",
    "dxHtmlEditor-underline": "Underline",
    "dxHtmlEditor-blockquote": "Blockquote",
    "dxHtmlEditor-header": "Header",
    "dxHtmlEditor-increaseIndent": "Increase Indent",
    "dxHtmlEditor-decreaseIndent": "Decrease Indent",
    "dxHtmlEditor-orderedList": "Ordered List",
    "dxHtmlEditor-bulletList": "Bullet List",
    "dxHtmlEditor-alignLeft": "Align Left",
    "dxHtmlEditor-alignCenter": "Align Center",
    "dxHtmlEditor-alignRight": "Align Right",
    "dxHtmlEditor-alignJustify": "Align Justify",
    "dxHtmlEditor-codeBlock": "Code Block",
    "dxHtmlEditor-variable": "Add Variable",
    "dxHtmlEditor-undo": "Undo",
    "dxHtmlEditor-redo": "Redo",
    "dxHtmlEditor-clear": "Clear Formatting",
    "dxHtmlEditor-insertTable": "Insert Table",
    "dxHtmlEditor-insertHeaderRow": "Insert Header Row",
    "dxHtmlEditor-insertRowAbove": "Insert Row Above",
    "dxHtmlEditor-insertRowBelow": "Insert Row Below",
    "dxHtmlEditor-insertColumnLeft": "Insert Column Left",
    "dxHtmlEditor-insertColumnRight": "Insert Column Right",
    "dxHtmlEditor-deleteColumn": "Delete Column",
    "dxHtmlEditor-deleteRow": "Delete Row",
    "dxHtmlEditor-deleteTable": "Delete Table",
    "dxHtmlEditor-cellProperties": "Cell Properties",
    "dxHtmlEditor-tableProperties": "Table Properties",
    "dxHtmlEditor-insert": "Insert",
    "dxHtmlEditor-delete": "Delete",
    "dxHtmlEditor-border": "Border",
    "dxHtmlEditor-style": "Style",
    "dxHtmlEditor-width": "Width",
    "dxHtmlEditor-height": "Height",
    "dxHtmlEditor-borderColor": "Color",
    "dxHtmlEditor-borderWidth": "Border Width",
    "dxHtmlEditor-tableBackground": "Background",
    "dxHtmlEditor-dimensions": "Dimensions",
    "dxHtmlEditor-alignment": "Alignment",
    "dxHtmlEditor-horizontal": "Horizontal",
    "dxHtmlEditor-vertical": "Vertical",
    "dxHtmlEditor-paddingVertical": "Vertical Padding",
    "dxHtmlEditor-paddingHorizontal": "Horizontal Padding",
    "dxHtmlEditor-pixels": "Pixels",
    "dxHtmlEditor-list": "List",
    "dxHtmlEditor-ordered": "Ordered",
    "dxHtmlEditor-bullet": "Bullet",
    "dxHtmlEditor-align": "Align",
    "dxHtmlEditor-center": "Center",
    "dxHtmlEditor-left": "Left",
    "dxHtmlEditor-right": "Right",
    "dxHtmlEditor-indent": "Indent",
    "dxHtmlEditor-justify": "Justify",
    "dxHtmlEditor-borderStyleNone": "none",
    "dxHtmlEditor-borderStyleHidden": "hidden",
    "dxHtmlEditor-borderStyleDotted": "dotted",
    "dxHtmlEditor-borderStyleDashed": "dashed",
    "dxHtmlEditor-borderStyleSolid": "solid",
    "dxHtmlEditor-borderStyleDouble": "double",
    "dxHtmlEditor-borderStyleGroove": "groove",
    "dxHtmlEditor-borderStyleRidge": "ridge",
    "dxHtmlEditor-borderStyleInset": "inset",
    "dxHtmlEditor-borderStyleOutset": "outset",
    "dxFileManager-newDirectoryName": "Untitled directory",
    "dxFileManager-rootDirectoryName": "Files",
    "dxFileManager-errorNoAccess": "Access Denied. Operation could not be completed.",
    "dxFileManager-errorDirectoryExistsFormat": "Directory '{0}' already exists.",
    "dxFileManager-errorFileExistsFormat": "File '{0}' already exists.",
    "dxFileManager-errorFileNotFoundFormat": "File '{0}' not found.",
    "dxFileManager-errorDirectoryNotFoundFormat": "Directory '{0}' not found.",
    "dxFileManager-errorWrongFileExtension": "File extension is not allowed.",
    "dxFileManager-errorMaxFileSizeExceeded": "File size exceeds the maximum allowed size.",
    "dxFileManager-errorInvalidSymbols": "This name contains invalid characters.",
    "dxFileManager-errorDefault": "Unspecified error.",
    "dxFileManager-errorDirectoryOpenFailed": "The directory cannot be opened",
    "dxFileManager-commandCreate": "New directory",
    "dxFileManager-commandRename": "Rename",
    "dxFileManager-commandMove": "Move to",
    "dxFileManager-commandCopy": "Copy to",
    "dxFileManager-commandDelete": "Delete",
    "dxFileManager-commandDownload": "Download",
    "dxFileManager-commandUpload": "Upload files",
    "dxFileManager-commandRefresh": "Refresh",
    "dxFileManager-commandThumbnails": "Thumbnails View",
    "dxFileManager-commandDetails": "Details View",
    "dxFileManager-commandClearSelection": "Clear selection",
    "dxFileManager-commandShowNavPane": "Toggle navigation pane",
    "dxFileManager-dialogDirectoryChooserMoveTitle": "Move to",
    "dxFileManager-dialogDirectoryChooserMoveButtonText": "Move",
    "dxFileManager-dialogDirectoryChooserCopyTitle": "Copy to",
    "dxFileManager-dialogDirectoryChooserCopyButtonText": "Copy",
    "dxFileManager-dialogRenameItemTitle": "Rename",
    "dxFileManager-dialogRenameItemButtonText": "Save",
    "dxFileManager-dialogCreateDirectoryTitle": "New directory",
    "dxFileManager-dialogCreateDirectoryButtonText": "Create",
    "dxFileManager-dialogDeleteItemTitle": "Delete",
    "dxFileManager-dialogDeleteItemButtonText": "Delete",
    "dxFileManager-dialogDeleteItemSingleItemConfirmation": "Are you sure you want to delete {0}?",
    "dxFileManager-dialogDeleteItemMultipleItemsConfirmation": "Are you sure you want to delete {0} items?",
    "dxFileManager-dialogButtonCancel": "Cancel",
    "dxFileManager-editingCreateSingleItemProcessingMessage": "Creating a directory inside {0}",
    "dxFileManager-editingCreateSingleItemSuccessMessage": "Created a directory inside {0}",
    "dxFileManager-editingCreateSingleItemErrorMessage": "Directory was not created",
    "dxFileManager-editingCreateCommonErrorMessage": "Directory was not created",
    "dxFileManager-editingRenameSingleItemProcessingMessage": "Renaming an item inside {0}",
    "dxFileManager-editingRenameSingleItemSuccessMessage": "Renamed an item inside {0}",
    "dxFileManager-editingRenameSingleItemErrorMessage": "Item was not renamed",
    "dxFileManager-editingRenameCommonErrorMessage": "Item was not renamed",
    "dxFileManager-editingDeleteSingleItemProcessingMessage": "Deleting an item from {0}",
    "dxFileManager-editingDeleteMultipleItemsProcessingMessage": "Deleting {0} items from {1}",
    "dxFileManager-editingDeleteSingleItemSuccessMessage": "Deleted an item from {0}",
    "dxFileManager-editingDeleteMultipleItemsSuccessMessage": "Deleted {0} items from {1}",
    "dxFileManager-editingDeleteSingleItemErrorMessage": "Item was not deleted",
    "dxFileManager-editingDeleteMultipleItemsErrorMessage": "{0} items were not deleted",
    "dxFileManager-editingDeleteCommonErrorMessage": "Some items were not deleted",
    "dxFileManager-editingMoveSingleItemProcessingMessage": "Moving an item to {0}",
    "dxFileManager-editingMoveMultipleItemsProcessingMessage": "Moving {0} items to {1}",
    "dxFileManager-editingMoveSingleItemSuccessMessage": "Moved an item to {0}",
    "dxFileManager-editingMoveMultipleItemsSuccessMessage": "Moved {0} items to {1}",
    "dxFileManager-editingMoveSingleItemErrorMessage": "Item was not moved",
    "dxFileManager-editingMoveMultipleItemsErrorMessage": "{0} items were not moved",
    "dxFileManager-editingMoveCommonErrorMessage": "Some items were not moved",
    "dxFileManager-editingCopySingleItemProcessingMessage": "Copying an item to {0}",
    "dxFileManager-editingCopyMultipleItemsProcessingMessage": "Copying {0} items to {1}",
    "dxFileManager-editingCopySingleItemSuccessMessage": "Copied an item to {0}",
    "dxFileManager-editingCopyMultipleItemsSuccessMessage": "Copied {0} items to {1}",
    "dxFileManager-editingCopySingleItemErrorMessage": "Item was not copied",
    "dxFileManager-editingCopyMultipleItemsErrorMessage": "{0} items were not copied",
    "dxFileManager-editingCopyCommonErrorMessage": "Some items were not copied",
    "dxFileManager-editingUploadSingleItemProcessingMessage": "Uploading an item to {0}",
    "dxFileManager-editingUploadMultipleItemsProcessingMessage": "Uploading {0} items to {1}",
    "dxFileManager-editingUploadSingleItemSuccessMessage": "Uploaded an item to {0}",
    "dxFileManager-editingUploadMultipleItemsSuccessMessage": "Uploaded {0} items to {1}",
    "dxFileManager-editingUploadSingleItemErrorMessage": "Item was not uploaded",
    "dxFileManager-editingUploadMultipleItemsErrorMessage": "{0} items were not uploaded",
    "dxFileManager-editingUploadCanceledMessage": "Canceled",
    "dxFileManager-editingDownloadSingleItemErrorMessage": "Item was not downloaded",
    "dxFileManager-editingDownloadMultipleItemsErrorMessage": "{0} items were not downloaded",
    "dxFileManager-listDetailsColumnCaptionName": "Name",
    "dxFileManager-listDetailsColumnCaptionDateModified": "Date Modified",
    "dxFileManager-listDetailsColumnCaptionFileSize": "File Size",
    "dxFileManager-listThumbnailsTooltipTextSize": "Size",
    "dxFileManager-listThumbnailsTooltipTextDateModified": "Date Modified",
    "dxFileManager-notificationProgressPanelTitle": "Progress",
    "dxFileManager-notificationProgressPanelEmptyListText": "No operations",
    "dxFileManager-notificationProgressPanelOperationCanceled": "Canceled",
    "dxDiagram-categoryGeneral": "General",
    "dxDiagram-categoryFlowchart": "Flowchart",
    "dxDiagram-categoryOrgChart": "Org Chart",
    "dxDiagram-categoryContainers": "Containers",
    "dxDiagram-categoryCustom": "Custom",
    "dxDiagram-commandExportToSvg": "Export to SVG",
    "dxDiagram-commandExportToPng": "Export to PNG",
    "dxDiagram-commandExportToJpg": "Export to JPEG",
    "dxDiagram-commandUndo": "Undo",
    "dxDiagram-commandRedo": "Redo",
    "dxDiagram-commandFontName": "Font Name",
    "dxDiagram-commandFontSize": "Font Size",
    "dxDiagram-commandBold": "Bold",
    "dxDiagram-commandItalic": "Italic",
    "dxDiagram-commandUnderline": "Underline",
    "dxDiagram-commandTextColor": "Font Color",
    "dxDiagram-commandLineColor": "Line Color",
    "dxDiagram-commandLineWidth": "Line Width",
    "dxDiagram-commandLineStyle": "Line Style",
    "dxDiagram-commandLineStyleSolid": "Solid",
    "dxDiagram-commandLineStyleDotted": "Dotted",
    "dxDiagram-commandLineStyleDashed": "Dashed",
    "dxDiagram-commandFillColor": "Fill Color",
    "dxDiagram-commandAlignLeft": "Align Left",
    "dxDiagram-commandAlignCenter": "Align Center",
    "dxDiagram-commandAlignRight": "Align Right",
    "dxDiagram-commandConnectorLineType": "Connector Line Type",
    "dxDiagram-commandConnectorLineStraight": "Straight",
    "dxDiagram-commandConnectorLineOrthogonal": "Orthogonal",
    "dxDiagram-commandConnectorLineStart": "Connector Line Start",
    "dxDiagram-commandConnectorLineEnd": "Connector Line End",
    "dxDiagram-commandConnectorLineNone": "None",
    "dxDiagram-commandConnectorLineArrow": "Arrow",
    "dxDiagram-commandFullscreen": "Full Screen",
    "dxDiagram-commandUnits": "Units",
    "dxDiagram-commandPageSize": "Page Size",
    "dxDiagram-commandPageOrientation": "Page Orientation",
    "dxDiagram-commandPageOrientationLandscape": "Landscape",
    "dxDiagram-commandPageOrientationPortrait": "Portrait",
    "dxDiagram-commandPageColor": "Page Color",
    "dxDiagram-commandShowGrid": "Show Grid",
    "dxDiagram-commandSnapToGrid": "Snap to Grid",
    "dxDiagram-commandGridSize": "Grid Size",
    "dxDiagram-commandZoomLevel": "Zoom Level",
    "dxDiagram-commandAutoZoom": "Auto Zoom",
    "dxDiagram-commandFitToContent": "Fit to Content",
    "dxDiagram-commandFitToWidth": "Fit to Width",
    "dxDiagram-commandAutoZoomByContent": "Auto Zoom by Content",
    "dxDiagram-commandAutoZoomByWidth": "Auto Zoom by Width",
    "dxDiagram-commandSimpleView": "Simple View",
    "dxDiagram-commandCut": "Cut",
    "dxDiagram-commandCopy": "Copy",
    "dxDiagram-commandPaste": "Paste",
    "dxDiagram-commandSelectAll": "Select All",
    "dxDiagram-commandDelete": "Delete",
    "dxDiagram-commandBringToFront": "Bring to Front",
    "dxDiagram-commandSendToBack": "Send to Back",
    "dxDiagram-commandLock": "Lock",
    "dxDiagram-commandUnlock": "Unlock",
    "dxDiagram-commandInsertShapeImage": "Insert Image...",
    "dxDiagram-commandEditShapeImage": "Change Image...",
    "dxDiagram-commandDeleteShapeImage": "Delete Image",
    "dxDiagram-commandLayoutLeftToRight": "Left-to-right",
    "dxDiagram-commandLayoutRightToLeft": "Right-to-left",
    "dxDiagram-commandLayoutTopToBottom": "Top-to-bottom",
    "dxDiagram-commandLayoutBottomToTop": "Bottom-to-top",
    "dxDiagram-unitIn": "in",
    "dxDiagram-unitCm": "cm",
    "dxDiagram-unitPx": "px",
    "dxDiagram-dialogButtonOK": "OK",
    "dxDiagram-dialogButtonCancel": "Cancel",
    "dxDiagram-dialogInsertShapeImageTitle": "Insert Image",
    "dxDiagram-dialogEditShapeImageTitle": "Change Image",
    "dxDiagram-dialogEditShapeImageSelectButton": "Select image",
    "dxDiagram-dialogEditShapeImageLabelText": "or drop a file here",
    "dxDiagram-uiExport": "Export",
    "dxDiagram-uiProperties": "Properties",
    "dxDiagram-uiSettings": "Settings",
    "dxDiagram-uiShowToolbox": "Show Toolbox",
    "dxDiagram-uiSearch": "Search",
    "dxDiagram-uiStyle": "Style",
    "dxDiagram-uiLayout": "Layout",
    "dxDiagram-uiLayoutTree": "Tree",
    "dxDiagram-uiLayoutLayered": "Layered",
    "dxDiagram-uiDiagram": "Diagram",
    "dxDiagram-uiText": "Text",
    "dxDiagram-uiObject": "Object",
    "dxDiagram-uiConnector": "Connector",
    "dxDiagram-uiPage": "Page",
    "dxDiagram-shapeText": "Text",
    "dxDiagram-shapeRectangle": "Rectangle",
    "dxDiagram-shapeEllipse": "Ellipse",
    "dxDiagram-shapeCross": "Cross",
    "dxDiagram-shapeTriangle": "Triangle",
    "dxDiagram-shapeDiamond": "Diamond",
    "dxDiagram-shapeHeart": "Heart",
    "dxDiagram-shapePentagon": "Pentagon",
    "dxDiagram-shapeHexagon": "Hexagon",
    "dxDiagram-shapeOctagon": "Octagon",
    "dxDiagram-shapeStar": "Star",
    "dxDiagram-shapeArrowLeft": "Left Arrow",
    "dxDiagram-shapeArrowUp": "Up Arrow",
    "dxDiagram-shapeArrowRight": "Right Arrow",
    "dxDiagram-shapeArrowDown": "Down Arrow",
    "dxDiagram-shapeArrowUpDown": "Up Down Arrow",
    "dxDiagram-shapeArrowLeftRight": "Left Right Arrow",
    "dxDiagram-shapeProcess": "Process",
    "dxDiagram-shapeDecision": "Decision",
    "dxDiagram-shapeTerminator": "Terminator",
    "dxDiagram-shapePredefinedProcess": "Predefined Process",
    "dxDiagram-shapeDocument": "Document",
    "dxDiagram-shapeMultipleDocuments": "Multiple Documents",
    "dxDiagram-shapeManualInput": "Manual Input",
    "dxDiagram-shapePreparation": "Preparation",
    "dxDiagram-shapeData": "Data",
    "dxDiagram-shapeDatabase": "Database",
    "dxDiagram-shapeHardDisk": "Hard Disk",
    "dxDiagram-shapeInternalStorage": "Internal Storage",
    "dxDiagram-shapePaperTape": "Paper Tape",
    "dxDiagram-shapeManualOperation": "Manual Operation",
    "dxDiagram-shapeDelay": "Delay",
    "dxDiagram-shapeStoredData": "Stored Data",
    "dxDiagram-shapeDisplay": "Display",
    "dxDiagram-shapeMerge": "Merge",
    "dxDiagram-shapeConnector": "Connector",
    "dxDiagram-shapeOr": "Or",
    "dxDiagram-shapeSummingJunction": "Summing Junction",
    "dxDiagram-shapeContainerDefaultText": "Container",
    "dxDiagram-shapeVerticalContainer": "Vertical Container",
    "dxDiagram-shapeHorizontalContainer": "Horizontal Container",
    "dxDiagram-shapeCardDefaultText": "Person's Name",
    "dxDiagram-shapeCardWithImageOnLeft": "Card with Image on the Left",
    "dxDiagram-shapeCardWithImageOnTop": "Card with Image on the Top",
    "dxDiagram-shapeCardWithImageOnRight": "Card with Image on the Right",
    "dxGantt-dialogTitle": "Title",
    "dxGantt-dialogStartTitle": "Start",
    "dxGantt-dialogEndTitle": "End",
    "dxGantt-dialogProgressTitle": "Progress",
    "dxGantt-dialogResourcesTitle": "Resources",
    "dxGantt-dialogResourceManagerTitle": "Resource Manager",
    "dxGantt-dialogTaskDetailsTitle": "Task Details",
    "dxGantt-dialogEditResourceListHint": "Edit Resource List",
    "dxGantt-dialogEditNoResources": "No resources",
    "dxGantt-dialogButtonAdd": "Add",
    "dxGantt-contextMenuNewTask": "New Task",
    "dxGantt-contextMenuNewSubtask": "New Subtask",
    "dxGantt-contextMenuDeleteTask": "Delete Task",
    "dxGantt-contextMenuDeleteDependency": "Delete Dependency",
    "dxGantt-dialogTaskDeleteConfirmation": "Deleting a task also deletes all its dependencies and subtasks. Are you sure you want to delete this task?",
    "dxGantt-dialogDependencyDeleteConfirmation": "Are you sure you want to delete the dependency from the task?",
    "dxGantt-dialogResourcesDeleteConfirmation": "Deleting a resource also deletes it from tasks to which this resource is assigned. Are you sure you want to delete these resources? Resources: {0}",
    "dxGantt-dialogConstraintCriticalViolationMessage": "The task you are attempting to move is linked to a second task by a dependency relation. This change would conflict with dependency rules. How would you like to proceed?",
    "dxGantt-dialogConstraintViolationMessage": "The task you are attempting to move is linked to a second task by a dependency relation. How would you like to proceed?",
    "dxGantt-dialogCancelOperationMessage": "Cancel the operation",
    "dxGantt-dialogDeleteDependencyMessage": "Delete the dependency",
    "dxGantt-dialogMoveTaskAndKeepDependencyMessage": "Move the task and keep the dependency",
    "dxGantt-dialogConstraintCriticalViolationSeveralTasksMessage": "The task you are attempting to move is linked to another tasks by dependency relations. This change would conflict with dependency rules. How would you like to proceed?",
    "dxGantt-dialogConstraintViolationSeveralTasksMessage": "The task you are attempting to move is linked to another tasks by dependency relations. How would you like to proceed?",
    "dxGantt-dialogDeleteDependenciesMessage": "Delete the dependency relations",
    "dxGantt-dialogMoveTaskAndKeepDependenciesMessage": "Move the task and keep the dependencies",
    "dxGantt-undo": "Undo",
    "dxGantt-redo": "Redo",
    "dxGantt-expandAll": "Expand All",
    "dxGantt-collapseAll": "Collapse All",
    "dxGantt-addNewTask": "Add New Task",
    "dxGantt-deleteSelectedTask": "Delete Selected Task",
    "dxGantt-zoomIn": "Zoom In",
    "dxGantt-zoomOut": "Zoom Out",
    "dxGantt-fullScreen": "Full Screen",
    "dxGantt-quarter": "Q{0}",
    "dxGantt-sortingAscendingText": "Sort Ascending",
    "dxGantt-sortingDescendingText": "Sort Descending",
    "dxGantt-sortingClearText": "Clear Sorting",
    "dxGantt-showResources": "Show Resources",
    "dxGantt-showDependencies": "Show Dependencies",
    "dxGantt-dialogStartDateValidation": "Start date must be after {0}",
    "dxGantt-dialogEndDateValidation": "End date must be after {0}",
    "dxGallery-itemName": "Gallery item",
    "dxMultiView-elementAriaRoleDescription": "MultiView",
    "dxMultiView-elementAriaLabel": "Use the arrow keys or swipe to navigate between views",
    "dxMultiView-itemAriaRoleDescription": "View",
    "dxMultiView-itemAriaLabel": "{0} of {1}",
    "dxSplitter-resizeHandleAriaLabel": "Split bar"
  }
};

// node_modules/devextreme/esm/localization/message.js
var baseDictionary = extend(true, {}, defaultMessages);
var getDataByLocale = (localeData, locale) => {
  var _Object$entries$find;
  return localeData[locale] || (null === locale || void 0 === locale ? void 0 : locale.toLowerCase) && (null === (_Object$entries$find = Object.entries(localeData).find((_ref) => {
    let [key] = _ref;
    return key.toLowerCase() === locale.toLowerCase();
  })) || void 0 === _Object$entries$find ? void 0 : _Object$entries$find[1]) || {};
};
var newMessages = {};
var messageLocalization = dependency_injector_default({
  engine: function() {
    return "base";
  },
  _dictionary: baseDictionary,
  load: function(messages) {
    extend(true, this._dictionary, messages);
  },
  _localizablePrefix: "@",
  setup: function(localizablePrefix) {
    this._localizablePrefix = localizablePrefix;
  },
  localizeString: function(text) {
    const that = this;
    const regex = new RegExp("(^|[^a-zA-Z_0-9" + that._localizablePrefix + "-]+)(" + that._localizablePrefix + "{1,2})([a-zA-Z_0-9-]+)", "g");
    const escapeString = that._localizablePrefix + that._localizablePrefix;
    return text.replace(regex, (str, prefix, escape, localizationKey) => {
      const defaultResult = that._localizablePrefix + localizationKey;
      let result2;
      if (escape !== escapeString) {
        result2 = that.format(localizationKey);
      }
      if (!result2) {
        newMessages[localizationKey] = humanize(localizationKey);
      }
      return prefix + (result2 || defaultResult);
    });
  },
  getMessagesByLocales: function() {
    return this._dictionary;
  },
  getDictionary: function(onlyNew) {
    if (onlyNew) {
      return newMessages;
    }
    return extend({}, newMessages, this.getMessagesByLocales()[core_default.locale()]);
  },
  getFormatter: function(key) {
    return this._getFormatterBase(key) || this._getFormatterBase(key, "en");
  },
  _getFormatterBase: function(key, locale) {
    const message = core_default.getValueByClosestLocale((locale2) => getDataByLocale(this._dictionary, locale2)[key]);
    if (message) {
      return function() {
        const args = 1 === arguments.length && Array.isArray(arguments[0]) ? arguments[0].slice(0) : Array.prototype.slice.call(arguments, 0);
        args.unshift(message);
        return format.apply(this, args);
      };
    }
  },
  format: function(key) {
    const formatter = this.getFormatter(key);
    const values = Array.prototype.slice.call(arguments, 1);
    return formatter && formatter.apply(this, values) || "";
  }
});
var message_default = messageLocalization;

// node_modules/devextreme/esm/localization/number.js
init_dependency_injector();
init_common();
init_iterator();
init_type();

// node_modules/devextreme/esm/localization/utils.js
var DECIMAL_BASE = 10;
function roundByAbs(value) {
  const valueSign = sign(value);
  return valueSign * Math.round(Math.abs(value));
}
function adjustValue(value, precision) {
  const precisionMultiplier = Math.pow(DECIMAL_BASE, precision);
  const intermediateValue = multiplyInExponentialForm(value, precision);
  return roundByAbs(intermediateValue) / precisionMultiplier;
}
function toFixed(value, precision) {
  const valuePrecision = precision || 0;
  const adjustedValue = valuePrecision > 0 ? adjustValue(...arguments) : value;
  return adjustedValue.toFixed(valuePrecision);
}

// node_modules/devextreme/esm/localization/ldml/number.js
var DEFAULT_CONFIG = {
  thousandsSeparator: ",",
  decimalSeparator: "."
};
var ESCAPING_CHAR = "'";
function getGroupSizes(formatString) {
  return formatString.split(",").slice(1).map(function(str) {
    let singleQuotesLeft = 0;
    return str.split("").filter(function(char, index) {
      singleQuotesLeft += "'" === char;
      const isDigit = "#" === char || "0" === char;
      const isInStub = singleQuotesLeft % 2;
      return isDigit && !isInStub;
    }).length;
  });
}
function getSignParts(format2) {
  const signParts = format2.split(";");
  if (1 === signParts.length) {
    signParts.push("-" + signParts[0]);
  }
  return signParts;
}
function reverseString(str) {
  return str.toString().split("").reverse().join("");
}
function isPercentFormat(format2) {
  return -1 !== format2.indexOf("%") && !format2.match(/'[^']*%[^']*'/g);
}
function removeStubs(str) {
  return str.replace(/'.+'/g, "");
}
function getNonRequiredDigitCount(floatFormat) {
  if (!floatFormat) {
    return 0;
  }
  const format2 = removeStubs(floatFormat);
  return format2.length - format2.replace(/[#]/g, "").length;
}
function getRequiredDigitCount(floatFormat) {
  if (!floatFormat) {
    return 0;
  }
  const format2 = removeStubs(floatFormat);
  return format2.length - format2.replace(/[0]/g, "").length;
}
function normalizeValueString(valuePart, minDigitCount, maxDigitCount) {
  if (!valuePart) {
    return "";
  }
  if (valuePart.length > maxDigitCount) {
    valuePart = valuePart.substr(0, maxDigitCount);
  }
  while (valuePart.length > minDigitCount && "0" === valuePart.slice(-1)) {
    valuePart = valuePart.substr(0, valuePart.length - 1);
  }
  while (valuePart.length < minDigitCount) {
    valuePart += "0";
  }
  return valuePart;
}
function applyGroups(valueString, groupSizes, thousandsSeparator) {
  if (!groupSizes.length) {
    return valueString;
  }
  const groups = [];
  let index = 0;
  while (valueString) {
    const groupSize = groupSizes[index];
    if (!groupSize) {
      break;
    }
    groups.push(valueString.slice(0, groupSize));
    valueString = valueString.slice(groupSize);
    if (index < groupSizes.length - 1) {
      index++;
    }
  }
  return groups.join(thousandsSeparator);
}
function formatNumberPart(format2, valueString) {
  return format2.split(ESCAPING_CHAR).map(function(formatPart, escapeIndex) {
    const isEscape = escapeIndex % 2;
    if (!formatPart && isEscape) {
      return ESCAPING_CHAR;
    }
    return isEscape ? formatPart : formatPart.replace(/[,#0]+/, valueString);
  }).join("");
}
function getFloatPointIndex(format2) {
  let isEscape = false;
  for (let index = 0; index < format2.length; index++) {
    if ("'" === format2[index]) {
      isEscape = !isEscape;
    }
    if ("." === format2[index] && !isEscape) {
      return index;
    }
  }
  return format2.length;
}
function getFormatter(format2, config) {
  config = config || DEFAULT_CONFIG;
  return function(value) {
    if ("number" !== typeof value || isNaN(value)) {
      return "";
    }
    const signFormatParts = getSignParts(format2);
    const isPositiveZero = 1 / value === 1 / 0;
    const isPositive = value > 0 || isPositiveZero;
    const numberFormat = signFormatParts[isPositive ? 0 : 1];
    const floatPointIndex = getFloatPointIndex(numberFormat);
    const floatFormatParts = [numberFormat.substr(0, floatPointIndex), numberFormat.substr(floatPointIndex + 1)];
    const minFloatPrecision = getRequiredDigitCount(floatFormatParts[1]);
    const maxFloatPrecision = minFloatPrecision + getNonRequiredDigitCount(floatFormatParts[1]);
    if (isPercentFormat(numberFormat)) {
      value = multiplyInExponentialForm(value, 2);
    }
    if (!isPositive) {
      value = -value;
    }
    const minIntegerPrecision = getRequiredDigitCount(floatFormatParts[0]);
    const maxIntegerPrecision = getNonRequiredDigitCount(floatFormatParts[0]) || config.unlimitedIntegerDigits ? void 0 : minIntegerPrecision;
    const integerLength = Math.floor(value).toString().length;
    const floatPrecision = fitIntoRange(maxFloatPrecision, 0, 15 - integerLength);
    const groupSizes = getGroupSizes(floatFormatParts[0]).reverse();
    const valueParts = toFixed(value, floatPrecision < 0 ? 0 : floatPrecision).split(".");
    let valueIntegerPart = normalizeValueString(reverseString(valueParts[0]), minIntegerPrecision, maxIntegerPrecision);
    const valueFloatPart = normalizeValueString(valueParts[1], minFloatPrecision, maxFloatPrecision);
    valueIntegerPart = applyGroups(valueIntegerPart, groupSizes, config.thousandsSeparator);
    const integerString = reverseString(formatNumberPart(reverseString(floatFormatParts[0]), valueIntegerPart));
    const floatString = maxFloatPrecision ? formatNumberPart(floatFormatParts[1], valueFloatPart) : "";
    const result2 = integerString + (floatString.match(/\d/) ? config.decimalSeparator : "") + floatString;
    return result2;
  };
}
function parseValue(text, isPercent, isNegative) {
  const value = (isPercent ? 0.01 : 1) * parseFloat(text) || 0;
  return isNegative ? -value : value;
}
function prepareValueText(valueText, formatter, isPercent, isIntegerPart) {
  let nextValueText = valueText;
  let char;
  let text;
  let nextText;
  do {
    if (nextText) {
      char = text.length === nextText.length ? "0" : "1";
      valueText = isIntegerPart ? char + valueText : valueText + char;
    }
    text = nextText || formatter(parseValue(nextValueText, isPercent));
    nextValueText = isIntegerPart ? "1" + nextValueText : nextValueText + "1";
    nextText = formatter(parseValue(nextValueText, isPercent));
  } while (text !== nextText && (isIntegerPart ? text.length === nextText.length : text.length <= nextText.length));
  if (isIntegerPart && nextText.length > text.length) {
    const hasGroups = -1 === formatter(12345).indexOf("12345");
    do {
      valueText = "1" + valueText;
    } while (hasGroups && parseValue(valueText, isPercent) < 1e5);
  }
  return valueText;
}
function getFormatByValueText(valueText, formatter, isPercent, isNegative) {
  let format2 = formatter(parseValue(valueText, isPercent, isNegative));
  const valueTextParts = valueText.split(".");
  const valueTextWithModifiedFloat = valueTextParts[0] + ".3" + valueTextParts[1].slice(1);
  const valueWithModifiedFloat = parseValue(valueTextWithModifiedFloat, isPercent, isNegative);
  const decimalSeparatorIndex = formatter(valueWithModifiedFloat).indexOf("3") - 1;
  format2 = format2.replace(/(\d)\D(\d)/g, "$1,$2");
  if (decimalSeparatorIndex >= 0) {
    format2 = format2.slice(0, decimalSeparatorIndex) + "." + format2.slice(decimalSeparatorIndex + 1);
  }
  format2 = format2.replace(/1+/, "1").replace(/1/g, "#");
  if (!isPercent) {
    format2 = format2.replace(/%/g, "'%'");
  }
  return format2;
}
function getFormat(formatter) {
  let valueText = ".";
  const isPercent = formatter(1).indexOf("100") >= 0;
  valueText = prepareValueText(valueText, formatter, isPercent, true);
  valueText = prepareValueText(valueText, formatter, isPercent, false);
  const positiveFormat = getFormatByValueText(valueText, formatter, isPercent, false);
  const negativeFormat = getFormatByValueText(valueText, formatter, isPercent, true);
  return negativeFormat === "-" + positiveFormat ? positiveFormat : positiveFormat + ";" + negativeFormat;
}

// node_modules/devextreme/esm/localization/number.js
init_config();
init_errors();

// node_modules/devextreme/esm/localization/currency.js
init_extend();
var currency_default = {
  _formatNumberCore: function(value, format2, formatConfig) {
    if ("currency" === format2) {
      formatConfig.precision = formatConfig.precision || 0;
      let result2 = this.format(value, extend({}, formatConfig, {
        type: "fixedpoint"
      }));
      const currencyPart = this.getCurrencySymbol().symbol.replace(/\$/g, "$$$$");
      result2 = result2.replace(/^(\D*)(\d.*)/, "$1" + currencyPart + "$2");
      return result2;
    }
    return this.callBase.apply(this, arguments);
  },
  getCurrencySymbol: function() {
    return {
      symbol: "$"
    };
  },
  getOpenXmlCurrencyFormat: function() {
    return "$#,##0{0}_);\\($#,##0{0}\\)";
  }
};

// node_modules/devextreme/esm/localization/intl/number.js
init_config();

// node_modules/devextreme/esm/localization/open_xml_currency_format.js
var open_xml_currency_format_default = (currencySymbol, accountingFormat) => {
  if (!accountingFormat) {
    return;
  }
  let encodedCurrencySymbol = currencySymbol;
  if ("string" === typeof currencySymbol) {
    encodedCurrencySymbol = "";
    for (let i = 0; i < currencySymbol.length; i++) {
      if ("$" !== currencySymbol[i]) {
        encodedCurrencySymbol += "\\";
      }
      encodedCurrencySymbol += currencySymbol[i];
    }
  }
  const encodeSymbols = {
    ".00": "{0}",
    "'": "\\'",
    "\\(": "\\(",
    "\\)": "\\)",
    " ": "\\ ",
    '"': "&quot;",
    "\\¤": encodedCurrencySymbol
  };
  const result2 = accountingFormat.split(";");
  for (let i = 0; i < result2.length; i++) {
    for (const symbol in encodeSymbols) {
      if (Object.prototype.hasOwnProperty.call(encodeSymbols, symbol)) {
        result2[i] = result2[i].replace(new RegExp(symbol, "g"), encodeSymbols[symbol]);
      }
    }
  }
  return 2 === result2.length ? result2[0] + "_);" + result2[1] : result2[0];
};

// node_modules/devextreme/esm/localization/cldr-data/accounting_formats.js
var accounting_formats_default = {
  af: "¤#,##0.00;(¤#,##0.00)",
  "af-NA": "¤#,##0.00;(¤#,##0.00)",
  agq: "#,##0.00¤",
  ak: "¤#,##0.00",
  am: "¤#,##0.00;(¤#,##0.00)",
  ar: "¤#,##0.00;(¤#,##0.00)",
  "ar-AE": "¤#,##0.00;(¤#,##0.00)",
  "ar-BH": "¤#,##0.00;(¤#,##0.00)",
  "ar-DJ": "¤#,##0.00;(¤#,##0.00)",
  "ar-DZ": "¤#,##0.00;(¤#,##0.00)",
  "ar-EG": "¤#,##0.00;(¤#,##0.00)",
  "ar-EH": "¤#,##0.00;(¤#,##0.00)",
  "ar-ER": "¤#,##0.00;(¤#,##0.00)",
  "ar-IL": "¤#,##0.00;(¤#,##0.00)",
  "ar-IQ": "¤#,##0.00;(¤#,##0.00)",
  "ar-JO": "¤#,##0.00;(¤#,##0.00)",
  "ar-KM": "¤#,##0.00;(¤#,##0.00)",
  "ar-KW": "¤#,##0.00;(¤#,##0.00)",
  "ar-LB": "¤#,##0.00;(¤#,##0.00)",
  "ar-LY": "¤#,##0.00;(¤#,##0.00)",
  "ar-MA": "¤#,##0.00;(¤#,##0.00)",
  "ar-MR": "¤#,##0.00;(¤#,##0.00)",
  "ar-OM": "¤#,##0.00;(¤#,##0.00)",
  "ar-PS": "¤#,##0.00;(¤#,##0.00)",
  "ar-QA": "¤#,##0.00;(¤#,##0.00)",
  "ar-SA": "¤#,##0.00;(¤#,##0.00)",
  "ar-SD": "¤#,##0.00;(¤#,##0.00)",
  "ar-SO": "¤#,##0.00;(¤#,##0.00)",
  "ar-SS": "¤#,##0.00;(¤#,##0.00)",
  "ar-SY": "¤#,##0.00;(¤#,##0.00)",
  "ar-TD": "¤#,##0.00;(¤#,##0.00)",
  "ar-TN": "¤#,##0.00;(¤#,##0.00)",
  "ar-YE": "¤#,##0.00;(¤#,##0.00)",
  as: "¤ #,##,##0.00",
  asa: "#,##0.00 ¤",
  ast: "#,##0.00 ¤",
  az: "#,##0.00 ¤",
  "az-Cyrl": "#,##0.00 ¤",
  "az-Latn": "#,##0.00 ¤",
  bas: "#,##0.00 ¤",
  be: "#,##0.00 ¤",
  "be-tarask": "#,##0.00 ¤",
  bem: "¤#,##0.00;(¤#,##0.00)",
  bez: "#,##0.00¤",
  bg: "0.00 ¤;(0.00 ¤)",
  bm: "¤#,##0.00;(¤#,##0.00)",
  bn: "#,##,##0.00¤;(#,##,##0.00¤)",
  "bn-IN": "#,##,##0.00¤;(#,##,##0.00¤)",
  bo: "¤ #,##0.00",
  "bo-IN": "¤ #,##0.00",
  br: "#,##0.00 ¤",
  brx: "¤ #,##,##0.00",
  bs: "#,##0.00 ¤",
  "bs-Cyrl": "#,##0.00 ¤",
  "bs-Latn": "#,##0.00 ¤",
  ca: "#,##0.00 ¤;(#,##0.00 ¤)",
  "ca-AD": "#,##0.00 ¤;(#,##0.00 ¤)",
  "ca-ES-valencia": "#,##0.00 ¤;(#,##0.00 ¤)",
  "ca-FR": "#,##0.00 ¤;(#,##0.00 ¤)",
  "ca-IT": "#,##0.00 ¤;(#,##0.00 ¤)",
  ccp: "#,##,##0.00¤;(#,##,##0.00¤)",
  "ccp-IN": "#,##,##0.00¤;(#,##,##0.00¤)",
  ce: "#,##0.00 ¤",
  ceb: "¤#,##0.00;(¤#,##0.00)",
  cgg: "¤#,##0.00",
  chr: "¤#,##0.00;(¤#,##0.00)",
  ckb: "¤ #,##0.00",
  "ckb-IR": "¤ #,##0.00",
  cs: "#,##0.00 ¤",
  cy: "¤#,##0.00;(¤#,##0.00)",
  da: "#,##0.00 ¤",
  "da-GL": "#,##0.00 ¤",
  dav: "¤#,##0.00;(¤#,##0.00)",
  de: "#,##0.00 ¤",
  "de-AT": "#,##0.00 ¤",
  "de-BE": "#,##0.00 ¤",
  "de-CH": "#,##0.00 ¤",
  "de-IT": "#,##0.00 ¤",
  "de-LI": "#,##0.00 ¤",
  "de-LU": "#,##0.00 ¤",
  dje: "#,##0.00¤",
  doi: "¤#,##0.00",
  dsb: "#,##0.00 ¤",
  dua: "#,##0.00 ¤",
  dyo: "#,##0.00 ¤",
  dz: "¤#,##,##0.00",
  ebu: "¤#,##0.00;(¤#,##0.00)",
  ee: "¤#,##0.00;(¤#,##0.00)",
  "ee-TG": "¤#,##0.00;(¤#,##0.00)",
  el: "#,##0.00 ¤",
  "el-CY": "#,##0.00 ¤",
  en: "¤#,##0.00;(¤#,##0.00)",
  "en-001": "¤#,##0.00;(¤#,##0.00)",
  "en-150": "#,##0.00 ¤",
  "en-AE": "¤#,##0.00;(¤#,##0.00)",
  "en-AG": "¤#,##0.00;(¤#,##0.00)",
  "en-AI": "¤#,##0.00;(¤#,##0.00)",
  "en-AS": "¤#,##0.00;(¤#,##0.00)",
  "en-AT": "¤ #,##0.00",
  "en-AU": "¤#,##0.00;(¤#,##0.00)",
  "en-BB": "¤#,##0.00;(¤#,##0.00)",
  "en-BE": "#,##0.00 ¤",
  "en-BI": "¤#,##0.00;(¤#,##0.00)",
  "en-BM": "¤#,##0.00;(¤#,##0.00)",
  "en-BS": "¤#,##0.00;(¤#,##0.00)",
  "en-BW": "¤#,##0.00;(¤#,##0.00)",
  "en-BZ": "¤#,##0.00;(¤#,##0.00)",
  "en-CA": "¤#,##0.00;(¤#,##0.00)",
  "en-CC": "¤#,##0.00;(¤#,##0.00)",
  "en-CH": "¤ #,##0.00;¤-#,##0.00",
  "en-CK": "¤#,##0.00;(¤#,##0.00)",
  "en-CM": "¤#,##0.00;(¤#,##0.00)",
  "en-CX": "¤#,##0.00;(¤#,##0.00)",
  "en-CY": "¤#,##0.00;(¤#,##0.00)",
  "en-DE": "#,##0.00 ¤",
  "en-DG": "¤#,##0.00;(¤#,##0.00)",
  "en-DK": "#,##0.00 ¤",
  "en-DM": "¤#,##0.00;(¤#,##0.00)",
  "en-ER": "¤#,##0.00;(¤#,##0.00)",
  "en-FI": "#,##0.00 ¤",
  "en-FJ": "¤#,##0.00;(¤#,##0.00)",
  "en-FK": "¤#,##0.00;(¤#,##0.00)",
  "en-FM": "¤#,##0.00;(¤#,##0.00)",
  "en-GB": "¤#,##0.00;(¤#,##0.00)",
  "en-GD": "¤#,##0.00;(¤#,##0.00)",
  "en-GG": "¤#,##0.00;(¤#,##0.00)",
  "en-GH": "¤#,##0.00;(¤#,##0.00)",
  "en-GI": "¤#,##0.00;(¤#,##0.00)",
  "en-GM": "¤#,##0.00;(¤#,##0.00)",
  "en-GU": "¤#,##0.00;(¤#,##0.00)",
  "en-GY": "¤#,##0.00;(¤#,##0.00)",
  "en-HK": "¤#,##0.00;(¤#,##0.00)",
  "en-IE": "¤#,##0.00;(¤#,##0.00)",
  "en-IL": "¤#,##0.00;(¤#,##0.00)",
  "en-IM": "¤#,##0.00;(¤#,##0.00)",
  "en-IN": "¤#,##0.00;(¤#,##0.00)",
  "en-IO": "¤#,##0.00;(¤#,##0.00)",
  "en-JE": "¤#,##0.00;(¤#,##0.00)",
  "en-JM": "¤#,##0.00;(¤#,##0.00)",
  "en-KE": "¤#,##0.00;(¤#,##0.00)",
  "en-KI": "¤#,##0.00;(¤#,##0.00)",
  "en-KN": "¤#,##0.00;(¤#,##0.00)",
  "en-KY": "¤#,##0.00;(¤#,##0.00)",
  "en-LC": "¤#,##0.00;(¤#,##0.00)",
  "en-LR": "¤#,##0.00;(¤#,##0.00)",
  "en-LS": "¤#,##0.00;(¤#,##0.00)",
  "en-MG": "¤#,##0.00;(¤#,##0.00)",
  "en-MH": "¤#,##0.00;(¤#,##0.00)",
  "en-MO": "¤#,##0.00;(¤#,##0.00)",
  "en-MP": "¤#,##0.00;(¤#,##0.00)",
  "en-MS": "¤#,##0.00;(¤#,##0.00)",
  "en-MT": "¤#,##0.00;(¤#,##0.00)",
  "en-MU": "¤#,##0.00;(¤#,##0.00)",
  "en-MV": "¤ #,##0.00",
  "en-MW": "¤#,##0.00;(¤#,##0.00)",
  "en-MY": "¤#,##0.00;(¤#,##0.00)",
  "en-NA": "¤#,##0.00;(¤#,##0.00)",
  "en-NF": "¤#,##0.00;(¤#,##0.00)",
  "en-NG": "¤#,##0.00;(¤#,##0.00)",
  "en-NL": "¤ #,##0.00;(¤ #,##0.00)",
  "en-NR": "¤#,##0.00;(¤#,##0.00)",
  "en-NU": "¤#,##0.00;(¤#,##0.00)",
  "en-NZ": "¤#,##0.00;(¤#,##0.00)",
  "en-PG": "¤#,##0.00;(¤#,##0.00)",
  "en-PH": "¤#,##0.00;(¤#,##0.00)",
  "en-PK": "¤#,##0.00;(¤#,##0.00)",
  "en-PN": "¤#,##0.00;(¤#,##0.00)",
  "en-PR": "¤#,##0.00;(¤#,##0.00)",
  "en-PW": "¤#,##0.00;(¤#,##0.00)",
  "en-RW": "¤#,##0.00;(¤#,##0.00)",
  "en-SB": "¤#,##0.00;(¤#,##0.00)",
  "en-SC": "¤#,##0.00;(¤#,##0.00)",
  "en-SD": "¤#,##0.00;(¤#,##0.00)",
  "en-SE": "#,##0.00 ¤",
  "en-SG": "¤#,##0.00;(¤#,##0.00)",
  "en-SH": "¤#,##0.00;(¤#,##0.00)",
  "en-SI": "#,##0.00 ¤;(#,##0.00 ¤)",
  "en-SL": "¤#,##0.00;(¤#,##0.00)",
  "en-SS": "¤#,##0.00;(¤#,##0.00)",
  "en-SX": "¤#,##0.00;(¤#,##0.00)",
  "en-SZ": "¤#,##0.00;(¤#,##0.00)",
  "en-TC": "¤#,##0.00;(¤#,##0.00)",
  "en-TK": "¤#,##0.00;(¤#,##0.00)",
  "en-TO": "¤#,##0.00;(¤#,##0.00)",
  "en-TT": "¤#,##0.00;(¤#,##0.00)",
  "en-TV": "¤#,##0.00;(¤#,##0.00)",
  "en-TZ": "¤#,##0.00;(¤#,##0.00)",
  "en-UG": "¤#,##0.00;(¤#,##0.00)",
  "en-UM": "¤#,##0.00;(¤#,##0.00)",
  "en-VC": "¤#,##0.00;(¤#,##0.00)",
  "en-VG": "¤#,##0.00;(¤#,##0.00)",
  "en-VI": "¤#,##0.00;(¤#,##0.00)",
  "en-VU": "¤#,##0.00;(¤#,##0.00)",
  "en-WS": "¤#,##0.00;(¤#,##0.00)",
  "en-ZA": "¤#,##0.00;(¤#,##0.00)",
  "en-ZM": "¤#,##0.00;(¤#,##0.00)",
  "en-ZW": "¤#,##0.00;(¤#,##0.00)",
  eo: "¤ #,##0.00",
  es: "#,##0.00 ¤",
  "es-419": "¤#,##0.00",
  "es-AR": "¤ #,##0.00;(¤ #,##0.00)",
  "es-BO": "¤#,##0.00",
  "es-BR": "¤#,##0.00",
  "es-BZ": "¤#,##0.00",
  "es-CL": "¤#,##0.00",
  "es-CO": "¤#,##0.00",
  "es-CR": "¤#,##0.00",
  "es-CU": "¤#,##0.00",
  "es-DO": "¤#,##0.00;(¤#,##0.00)",
  "es-EA": "#,##0.00 ¤",
  "es-EC": "¤#,##0.00",
  "es-GQ": "#,##0.00 ¤",
  "es-GT": "¤#,##0.00",
  "es-HN": "¤#,##0.00",
  "es-IC": "#,##0.00 ¤",
  "es-MX": "¤#,##0.00",
  "es-NI": "¤#,##0.00",
  "es-PA": "¤#,##0.00",
  "es-PE": "¤#,##0.00",
  "es-PH": "#,##0.00 ¤",
  "es-PR": "¤#,##0.00",
  "es-PY": "¤#,##0.00",
  "es-SV": "¤#,##0.00",
  "es-US": "¤#,##0.00",
  "es-UY": "¤ #,##0.00;(¤ #,##0.00)",
  "es-VE": "¤#,##0.00",
  et: "#,##0.00 ¤;(#,##0.00 ¤)",
  eu: "#,##0.00 ¤;(#,##0.00 ¤)",
  ewo: "#,##0.00 ¤",
  fa: "‎¤ #,##0.00;‎(¤ #,##0.00)",
  "fa-AF": "¤ #,##0.00;‎(¤ #,##0.00)",
  ff: "#,##0.00 ¤",
  "ff-Adlm": "¤ #,##0.00",
  "ff-Adlm-BF": "¤ #,##0.00",
  "ff-Adlm-CM": "¤ #,##0.00",
  "ff-Adlm-GH": "¤ #,##0.00",
  "ff-Adlm-GM": "¤ #,##0.00",
  "ff-Adlm-GW": "¤ #,##0.00",
  "ff-Adlm-LR": "¤ #,##0.00",
  "ff-Adlm-MR": "¤ #,##0.00",
  "ff-Adlm-NE": "¤ #,##0.00",
  "ff-Adlm-NG": "¤ #,##0.00",
  "ff-Adlm-SL": "¤ #,##0.00",
  "ff-Adlm-SN": "¤ #,##0.00",
  "ff-Latn": "#,##0.00 ¤",
  "ff-Latn-BF": "#,##0.00 ¤",
  "ff-Latn-CM": "#,##0.00 ¤",
  "ff-Latn-GH": "#,##0.00 ¤",
  "ff-Latn-GM": "#,##0.00 ¤",
  "ff-Latn-GN": "#,##0.00 ¤",
  "ff-Latn-GW": "#,##0.00 ¤",
  "ff-Latn-LR": "#,##0.00 ¤",
  "ff-Latn-MR": "#,##0.00 ¤",
  "ff-Latn-NE": "#,##0.00 ¤",
  "ff-Latn-NG": "#,##0.00 ¤",
  "ff-Latn-SL": "#,##0.00 ¤",
  fi: "#,##0.00 ¤",
  fil: "¤#,##0.00;(¤#,##0.00)",
  fo: "#,##0.00 ¤;(#,##0.00 ¤)",
  "fo-DK": "#,##0.00 ¤;(#,##0.00 ¤)",
  fr: "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-BE": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-BF": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-BI": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-BJ": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-BL": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-CA": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-CD": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-CF": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-CG": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-CH": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-CI": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-CM": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-DJ": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-DZ": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-GA": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-GF": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-GN": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-GP": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-GQ": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-HT": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-KM": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-LU": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-MA": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-MC": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-MF": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-MG": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-ML": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-MQ": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-MR": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-MU": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-NC": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-NE": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-PF": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-PM": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-RE": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-RW": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-SC": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-SN": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-SY": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-TD": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-TG": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-TN": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-VU": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-WF": "#,##0.00 ¤;(#,##0.00 ¤)",
  "fr-YT": "#,##0.00 ¤;(#,##0.00 ¤)",
  fur: "¤ #,##0.00",
  fy: "¤ #,##0.00;(¤ #,##0.00)",
  ga: "¤#,##0.00;(¤#,##0.00)",
  "ga-GB": "¤#,##0.00;(¤#,##0.00)",
  gd: "¤#,##0.00;(¤#,##0.00)",
  gl: "#,##0.00 ¤",
  gsw: "#,##0.00 ¤",
  "gsw-FR": "#,##0.00 ¤",
  "gsw-LI": "#,##0.00 ¤",
  gu: "¤#,##,##0.00;(¤#,##,##0.00)",
  guz: "¤#,##0.00;(¤#,##0.00)",
  gv: "¤#,##0.00",
  ha: "¤ #,##0.00",
  "ha-GH": "¤ #,##0.00",
  "ha-NE": "¤ #,##0.00",
  haw: "¤#,##0.00;(¤#,##0.00)",
  he: "#,##0.00 ¤",
  hi: "¤#,##,##0.00",
  "hi-Latn": "¤#,##,##0.00",
  hr: "#,##0.00 ¤",
  "hr-BA": "#,##0.00 ¤",
  hsb: "#,##0.00 ¤",
  hu: "#,##0.00 ¤",
  hy: "#,##0.00 ¤",
  ia: "¤ #,##0.00;(¤ #,##0.00)",
  id: "¤#,##0.00",
  ig: "¤#,##0.00;(¤#,##0.00)",
  ii: "¤ #,##0.00",
  is: "#,##0.00 ¤",
  it: "#,##0.00 ¤",
  "it-CH": "#,##0.00 ¤",
  "it-SM": "#,##0.00 ¤",
  "it-VA": "#,##0.00 ¤",
  ja: "¤#,##0.00;(¤#,##0.00)",
  jgo: "¤ #,##0.00",
  jmc: "¤#,##0.00",
  jv: "¤ #,##0.00",
  ka: "#,##0.00 ¤",
  kab: "#,##0.00¤",
  kam: "¤#,##0.00;(¤#,##0.00)",
  kde: "¤#,##0.00;(¤#,##0.00)",
  kea: "#,##0.00 ¤;(#,##0.00 ¤)",
  kgp: "¤ #,##0.00",
  khq: "#,##0.00¤",
  ki: "¤#,##0.00;(¤#,##0.00)",
  kk: "#,##0.00 ¤",
  kkj: "¤ #,##0.00",
  kl: "¤#,##0.00;¤-#,##0.00",
  kln: "¤#,##0.00;(¤#,##0.00)",
  km: "#,##0.00¤;(#,##0.00¤)",
  kn: "¤#,##0.00;(¤#,##0.00)",
  ko: "¤#,##0.00;(¤#,##0.00)",
  "ko-KP": "¤#,##0.00;(¤#,##0.00)",
  kok: "¤#,##0.00;(¤#,##0.00)",
  ks: "¤#,##0.00",
  "ks-Arab": "¤#,##0.00",
  "ks-Deva": "¤ #,##0.00",
  ksb: "#,##0.00¤",
  ksf: "#,##0.00 ¤",
  ksh: "#,##0.00 ¤",
  ku: "#,##0.00 ¤;(#,##0.00 ¤)",
  kw: "¤#,##0.00",
  ky: "#,##0.00 ¤",
  lag: "¤ #,##0.00",
  lb: "#,##0.00 ¤",
  lg: "#,##0.00¤",
  lkt: "¤ #,##0.00",
  ln: "#,##0.00 ¤",
  "ln-AO": "#,##0.00 ¤",
  "ln-CF": "#,##0.00 ¤",
  "ln-CG": "#,##0.00 ¤",
  lo: "¤#,##0.00;¤-#,##0.00",
  lrc: "¤ #,##0.00",
  "lrc-IQ": "¤ #,##0.00",
  lt: "#,##0.00 ¤",
  lu: "#,##0.00¤",
  luo: "#,##0.00¤",
  luy: "¤#,##0.00;¤- #,##0.00",
  lv: "#,##0.00 ¤",
  mai: "¤ #,##0.00",
  mas: "¤#,##0.00;(¤#,##0.00)",
  "mas-TZ": "¤#,##0.00;(¤#,##0.00)",
  mer: "¤#,##0.00;(¤#,##0.00)",
  mfe: "¤ #,##0.00",
  mg: "¤#,##0.00",
  mgh: "¤ #,##0.00",
  mgo: "¤ #,##0.00",
  mi: "¤ #,##0.00",
  mk: "#,##0.00 ¤",
  ml: "¤#,##0.00;(¤#,##0.00)",
  mn: "¤ #,##0.00",
  mni: "¤ #,##0.00",
  "mni-Beng": "¤ #,##0.00",
  mr: "¤#,##0.00;(¤#,##0.00)",
  ms: "¤#,##0.00;(¤#,##0.00)",
  "ms-BN": "¤#,##0.00;(¤#,##0.00)",
  "ms-ID": "¤#,##0.00",
  "ms-SG": "¤#,##0.00;(¤#,##0.00)",
  mt: "¤#,##0.00",
  mua: "¤#,##0.00;(¤#,##0.00)",
  my: "¤ #,##0.00",
  mzn: "¤ #,##0.00",
  naq: "¤#,##0.00",
  nb: "¤ #,##0.00;(¤ #,##0.00)",
  "nb-SJ": "¤ #,##0.00;(¤ #,##0.00)",
  nd: "¤#,##0.00;(¤#,##0.00)",
  nds: "¤ #,##0.00",
  "nds-NL": "¤ #,##0.00",
  ne: "¤ #,##,##0.00",
  "ne-IN": "¤ #,##,##0.00",
  nl: "¤ #,##0.00;(¤ #,##0.00)",
  "nl-AW": "¤ #,##0.00;(¤ #,##0.00)",
  "nl-BE": "¤ #,##0.00;(¤ #,##0.00)",
  "nl-BQ": "¤ #,##0.00;(¤ #,##0.00)",
  "nl-CW": "¤ #,##0.00;(¤ #,##0.00)",
  "nl-SR": "¤ #,##0.00;(¤ #,##0.00)",
  "nl-SX": "¤ #,##0.00;(¤ #,##0.00)",
  nmg: "#,##0.00 ¤",
  nn: "#,##0.00 ¤",
  nnh: "¤ #,##0.00",
  no: "¤ #,##0.00;(¤ #,##0.00)",
  nus: "¤#,##0.00;(¤#,##0.00)",
  nyn: "¤#,##0.00",
  om: "¤#,##0.00",
  "om-KE": "¤#,##0.00",
  or: "¤#,##0.00;(¤#,##0.00)",
  os: "¤ #,##0.00",
  "os-RU": "¤ #,##0.00",
  pa: "¤ #,##0.00",
  "pa-Arab": "¤ #,##0.00",
  "pa-Guru": "¤ #,##0.00",
  pcm: "¤#,##0.00",
  pl: "#,##0.00 ¤;(#,##0.00 ¤)",
  ps: "¤#,##0.00;(¤#,##0.00)",
  "ps-PK": "¤#,##0.00;(¤#,##0.00)",
  pt: "¤ #,##0.00",
  "pt-AO": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-CH": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-CV": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-GQ": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-GW": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-LU": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-MO": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-MZ": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-PT": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-ST": "#,##0.00 ¤;(#,##0.00 ¤)",
  "pt-TL": "#,##0.00 ¤;(#,##0.00 ¤)",
  qu: "¤ #,##0.00",
  "qu-BO": "¤ #,##0.00",
  "qu-EC": "¤ #,##0.00",
  rm: "#,##0.00 ¤",
  rn: "#,##0.00¤",
  ro: "#,##0.00 ¤;(#,##0.00 ¤)",
  "ro-MD": "#,##0.00 ¤;(#,##0.00 ¤)",
  rof: "¤#,##0.00",
  ru: "#,##0.00 ¤",
  "ru-BY": "#,##0.00 ¤",
  "ru-KG": "#,##0.00 ¤",
  "ru-KZ": "#,##0.00 ¤",
  "ru-MD": "#,##0.00 ¤",
  "ru-UA": "#,##0.00 ¤",
  rw: "¤ #,##0.00",
  rwk: "#,##0.00¤",
  sa: "¤ #,##0.00",
  sah: "#,##0.00 ¤",
  saq: "¤#,##0.00;(¤#,##0.00)",
  sat: "¤ #,##0.00",
  "sat-Olck": "¤ #,##0.00",
  sbp: "#,##0.00¤",
  sc: "#,##0.00 ¤",
  sd: "¤ #,##0.00",
  "sd-Arab": "¤ #,##0.00",
  "sd-Deva": "¤ #,##0.00",
  se: "#,##0.00 ¤",
  "se-FI": "#,##0.00 ¤",
  "se-SE": "#,##0.00 ¤",
  seh: "#,##0.00¤",
  ses: "#,##0.00¤",
  sg: "¤#,##0.00;¤-#,##0.00",
  shi: "#,##0.00¤",
  "shi-Latn": "#,##0.00¤",
  "shi-Tfng": "#,##0.00¤",
  si: "¤#,##0.00;(¤#,##0.00)",
  sk: "#,##0.00 ¤;(#,##0.00 ¤)",
  sl: "#,##0.00 ¤;(#,##0.00 ¤)",
  smn: "#,##0.00 ¤",
  sn: "¤#,##0.00;(¤#,##0.00)",
  so: "¤#,##0.00;(¤#,##0.00)",
  "so-DJ": "¤#,##0.00;(¤#,##0.00)",
  "so-ET": "¤#,##0.00;(¤#,##0.00)",
  "so-KE": "¤#,##0.00;(¤#,##0.00)",
  sq: "#,##0.00 ¤;(#,##0.00 ¤)",
  "sq-MK": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sq-XK": "#,##0.00 ¤;(#,##0.00 ¤)",
  sr: "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Cyrl": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Cyrl-BA": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Cyrl-ME": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Cyrl-XK": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Latn": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Latn-BA": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Latn-ME": "#,##0.00 ¤;(#,##0.00 ¤)",
  "sr-Latn-XK": "#,##0.00 ¤;(#,##0.00 ¤)",
  su: "¤#,##0.00",
  "su-Latn": "¤#,##0.00",
  sv: "#,##0.00 ¤",
  "sv-AX": "#,##0.00 ¤",
  "sv-FI": "#,##0.00 ¤",
  sw: "¤ #,##0.00",
  "sw-CD": "¤ #,##0.00",
  "sw-KE": "¤ #,##0.00",
  "sw-UG": "¤ #,##0.00",
  ta: "¤#,##0.00;(¤#,##0.00)",
  "ta-LK": "¤#,##0.00;(¤#,##0.00)",
  "ta-MY": "¤#,##0.00;(¤#,##0.00)",
  "ta-SG": "¤#,##0.00;(¤#,##0.00)",
  te: "¤#,##0.00;(¤#,##0.00)",
  teo: "¤#,##0.00;(¤#,##0.00)",
  "teo-KE": "¤#,##0.00;(¤#,##0.00)",
  tg: "#,##0.00 ¤",
  th: "¤#,##0.00;(¤#,##0.00)",
  ti: "¤#,##0.00",
  "ti-ER": "¤#,##0.00",
  tk: "#,##0.00 ¤",
  to: "¤ #,##0.00",
  tr: "¤#,##0.00;(¤#,##0.00)",
  "tr-CY": "¤#,##0.00;(¤#,##0.00)",
  tt: "#,##0.00 ¤",
  twq: "#,##0.00¤",
  tzm: "#,##0.00 ¤",
  ug: "¤#,##0.00;(¤#,##0.00)",
  uk: "#,##0.00 ¤",
  und: "¤ #,##0.00",
  ur: "¤#,##0.00;(¤#,##0.00)",
  "ur-IN": "¤#,##0.00;(¤#,##0.00)",
  uz: "#,##0.00 ¤",
  "uz-Arab": "¤ #,##0.00",
  "uz-Cyrl": "#,##0.00 ¤",
  "uz-Latn": "#,##0.00 ¤",
  vai: "¤#,##0.00;(¤#,##0.00)",
  "vai-Latn": "¤#,##0.00;(¤#,##0.00)",
  "vai-Vaii": "¤#,##0.00;(¤#,##0.00)",
  vi: "#,##0.00 ¤",
  vun: "¤#,##0.00",
  wae: "¤ #,##0.00",
  wo: "¤ #,##0.00",
  xh: "¤#,##0.00",
  xog: "#,##0.00 ¤",
  yav: "#,##0.00 ¤;(#,##0.00 ¤)",
  yi: "¤ #,##0.00",
  yo: "¤#,##0.00;(¤#,##0.00)",
  "yo-BJ": "¤#,##0.00;(¤#,##0.00)",
  yrl: "¤ #,##0.00",
  "yrl-CO": "¤ #,##0.00",
  "yrl-VE": "¤ #,##0.00",
  yue: "¤#,##0.00;(¤#,##0.00)",
  "yue-Hans": "¤#,##0.00;(¤#,##0.00)",
  "yue-Hant": "¤#,##0.00;(¤#,##0.00)",
  zgh: "#,##0.00¤",
  zh: "¤#,##0.00;(¤#,##0.00)",
  "zh-Hans": "¤#,##0.00;(¤#,##0.00)",
  "zh-Hans-HK": "¤#,##0.00;(¤#,##0.00)",
  "zh-Hans-MO": "¤#,##0.00;(¤#,##0.00)",
  "zh-Hans-SG": "¤#,##0.00;(¤#,##0.00)",
  "zh-Hant": "¤#,##0.00;(¤#,##0.00)",
  "zh-Hant-HK": "¤#,##0.00;(¤#,##0.00)",
  "zh-Hant-MO": "¤#,##0.00;(¤#,##0.00)",
  zu: "¤#,##0.00;(¤#,##0.00)"
};

// node_modules/devextreme/esm/localization/intl/number.js
var CURRENCY_STYLES = ["standard", "accounting"];
var detectCurrencySymbolRegex = /([^\s0]+)?(\s*)0*[.,]*0*(\s*)([^\s0]+)?/;
var formattersCache = {};
var getFormatter2 = (format2) => {
  const key = core_default.locale() + "/" + JSON.stringify(format2);
  if (!formattersCache[key]) {
    formattersCache[key] = new Intl.NumberFormat(core_default.locale(), format2).format;
  }
  return formattersCache[key];
};
var getCurrencyFormatter = (currency) => new Intl.NumberFormat(core_default.locale(), {
  style: "currency",
  currency
});
var number_default = {
  engine: function() {
    return "intl";
  },
  _formatNumberCore: function(value, format2, formatConfig) {
    if ("exponential" === format2) {
      return this.callBase.apply(this, arguments);
    }
    return getFormatter2(this._normalizeFormatConfig(format2, formatConfig, value))(value);
  },
  _normalizeFormatConfig: function(format2, formatConfig, value) {
    let config;
    if ("decimal" === format2) {
      const fractionDigits = String(value).split(".")[1];
      config = {
        minimumIntegerDigits: formatConfig.precision || void 0,
        useGrouping: false,
        maximumFractionDigits: fractionDigits && fractionDigits.length,
        round: value < 0 ? "ceil" : "floor"
      };
    } else {
      config = this._getPrecisionConfig(formatConfig.precision);
    }
    if ("percent" === format2) {
      config.style = "percent";
    } else if ("currency" === format2) {
      const useAccountingStyle = formatConfig.useCurrencyAccountingStyle ?? config_default().defaultUseCurrencyAccountingStyle;
      config.style = "currency";
      config.currency = formatConfig.currency || config_default().defaultCurrency;
      config.currencySign = CURRENCY_STYLES[+useAccountingStyle];
    }
    return config;
  },
  _getPrecisionConfig: function(precision) {
    let config;
    if (null === precision) {
      config = {
        minimumFractionDigits: 0,
        maximumFractionDigits: 20
      };
    } else {
      config = {
        minimumFractionDigits: precision || 0,
        maximumFractionDigits: precision || 0
      };
    }
    return config;
  },
  format: function(value, format2) {
    if ("number" !== typeof value) {
      return value;
    }
    format2 = this._normalizeFormat(format2);
    if ("default" === format2.currency) {
      format2.currency = config_default().defaultCurrency;
    }
    if (!format2 || "function" !== typeof format2 && !format2.type && !format2.formatter) {
      return getFormatter2(format2)(value);
    }
    return this.callBase.apply(this, arguments);
  },
  _getCurrencySymbolInfo: function(currency) {
    const formatter = getCurrencyFormatter(currency);
    return this._extractCurrencySymbolInfo(formatter.format(0));
  },
  _extractCurrencySymbolInfo: function(currencyValueString) {
    const match = detectCurrencySymbolRegex.exec(currencyValueString) || [];
    const position = match[1] ? "before" : "after";
    const symbol = match[1] || match[4] || "";
    const delimiter = match[2] || match[3] || "";
    return {
      position,
      symbol,
      delimiter
    };
  },
  getCurrencySymbol: function(currency) {
    if (!currency) {
      currency = config_default().defaultCurrency;
    }
    const symbolInfo = this._getCurrencySymbolInfo(currency);
    return {
      symbol: symbolInfo.symbol
    };
  },
  getOpenXmlCurrencyFormat: function(currency) {
    const targetCurrency = currency || config_default().defaultCurrency;
    const currencySymbol = this._getCurrencySymbolInfo(targetCurrency).symbol;
    const closestAccountingFormat = core_default.getValueByClosestLocale((locale) => accounting_formats_default[locale]);
    return open_xml_currency_format_default(currencySymbol, closestAccountingFormat);
  }
};

// node_modules/devextreme/esm/localization/number.js
var hasIntl = "undefined" !== typeof Intl;
var NUMERIC_FORMATS = ["currency", "fixedpoint", "exponential", "percent", "decimal"];
var LargeNumberFormatPostfixes = {
  1: "K",
  2: "M",
  3: "B",
  4: "T"
};
var LargeNumberFormatPowers = {
  largenumber: "auto",
  thousands: 1,
  millions: 2,
  billions: 3,
  trillions: 4
};
var numberLocalization = dependency_injector_default({
  engine: function() {
    return "base";
  },
  numericFormats: NUMERIC_FORMATS,
  defaultLargeNumberFormatPostfixes: LargeNumberFormatPostfixes,
  _parseNumberFormatString: function(formatType) {
    const formatObject = {};
    if (!formatType || "string" !== typeof formatType) {
      return;
    }
    const formatList = formatType.toLowerCase().split(" ");
    each(formatList, (index, value) => {
      if (NUMERIC_FORMATS.includes(value)) {
        formatObject.formatType = value;
      } else if (value in LargeNumberFormatPowers) {
        formatObject.power = LargeNumberFormatPowers[value];
      }
    });
    if (formatObject.power && !formatObject.formatType) {
      formatObject.formatType = "fixedpoint";
    }
    if (formatObject.formatType) {
      return formatObject;
    }
  },
  _calculateNumberPower: function(value, base, minPower, maxPower) {
    let number = Math.abs(value);
    let power = 0;
    if (number > 1) {
      while (number && number >= base && (void 0 === maxPower || power < maxPower)) {
        power++;
        number /= base;
      }
    } else if (number > 0 && number < 1) {
      while (number < 1 && (void 0 === minPower || power > minPower)) {
        power--;
        number *= base;
      }
    }
    return power;
  },
  _getNumberByPower: function(number, power, base) {
    let result2 = number;
    while (power > 0) {
      result2 /= base;
      power--;
    }
    while (power < 0) {
      result2 *= base;
      power++;
    }
    return result2;
  },
  _formatNumber: function(value, formatObject, formatConfig) {
    if ("auto" === formatObject.power) {
      formatObject.power = this._calculateNumberPower(value, 1e3, 0, 4);
    }
    if (formatObject.power) {
      value = this._getNumberByPower(value, formatObject.power, 1e3);
    }
    const powerPostfix = this.defaultLargeNumberFormatPostfixes[formatObject.power] || "";
    let result2 = this._formatNumberCore(value, formatObject.formatType, formatConfig);
    result2 = result2.replace(/(\d|.$)(\D*)$/, "$1" + powerPostfix + "$2");
    return result2;
  },
  _formatNumberExponential: function(value, formatConfig) {
    let power = this._calculateNumberPower(value, 10);
    let number = this._getNumberByPower(value, power, 10);
    if (void 0 === formatConfig.precision) {
      formatConfig.precision = 1;
    }
    if (number.toFixed(formatConfig.precision || 0) >= 10) {
      power++;
      number /= 10;
    }
    const powString = (power >= 0 ? "+" : "") + power.toString();
    return this._formatNumberCore(number, "fixedpoint", formatConfig) + "E" + powString;
  },
  _addZeroes: function(value, precision) {
    const multiplier = Math.pow(10, precision);
    const sign2 = value < 0 ? "-" : "";
    value = (Math.abs(value) * multiplier >>> 0) / multiplier;
    let result2 = value.toString();
    while (result2.length < precision) {
      result2 = "0" + result2;
    }
    return sign2 + result2;
  },
  _addGroupSeparators: function(value) {
    const parts = value.toString().split(".");
    return parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, config_default().thousandsSeparator) + (parts[1] ? config_default().decimalSeparator + parts[1] : "");
  },
  _formatNumberCore: function(value, format2, formatConfig) {
    if ("exponential" === format2) {
      return this._formatNumberExponential(value, formatConfig);
    }
    if ("decimal" !== format2 && null !== formatConfig.precision) {
      formatConfig.precision = formatConfig.precision || 0;
    }
    if ("percent" === format2) {
      value *= 100;
    }
    if (void 0 !== formatConfig.precision) {
      if ("decimal" === format2) {
        value = this._addZeroes(value, formatConfig.precision);
      } else {
        value = null === formatConfig.precision ? value.toPrecision() : toFixed(value, formatConfig.precision);
      }
    }
    if ("decimal" !== format2) {
      value = this._addGroupSeparators(value);
    } else {
      value = value.toString().replace(".", config_default().decimalSeparator);
    }
    if ("percent" === format2) {
      value += "%";
    }
    return value;
  },
  _normalizeFormat: function(format2) {
    if (!format2) {
      return {};
    }
    if ("function" === typeof format2) {
      return format2;
    }
    if (!isPlainObject(format2)) {
      format2 = {
        type: format2
      };
    }
    return format2;
  },
  _getSeparators: function() {
    return {
      decimalSeparator: this.getDecimalSeparator(),
      thousandsSeparator: this.getThousandsSeparator()
    };
  },
  getThousandsSeparator: function() {
    return this.format(1e4, "fixedPoint")[2];
  },
  getDecimalSeparator: function() {
    return this.format(1.2, {
      type: "fixedPoint",
      precision: 1
    })[1];
  },
  convertDigits: function(value, toStandard) {
    const digits = this.format(90, "decimal");
    if ("string" !== typeof value || "0" === digits[1]) {
      return value;
    }
    const fromFirstDigit = toStandard ? digits[1] : "0";
    const toFirstDigit = toStandard ? "0" : digits[1];
    const fromLastDigit = toStandard ? digits[0] : "9";
    const regExp = new RegExp("[" + fromFirstDigit + "-" + fromLastDigit + "]", "g");
    return value.replace(regExp, (char) => String.fromCharCode(char.charCodeAt(0) + (toFirstDigit.charCodeAt(0) - fromFirstDigit.charCodeAt(0))));
  },
  getNegativeEtalonRegExp: function(format2) {
    const separators = this._getSeparators();
    const digitalRegExp = new RegExp("[0-9" + escapeRegExp(separators.decimalSeparator + separators.thousandsSeparator) + "]+", "g");
    let negativeEtalon = this.format(-1, format2).replace(digitalRegExp, "1");
    ["\\", "(", ")", "[", "]", "*", "+", "$", "^", "?", "|", "{", "}"].forEach((char) => {
      negativeEtalon = negativeEtalon.replace(new RegExp(`\\${char}`, "g"), `\\${char}`);
    });
    negativeEtalon = negativeEtalon.replace(/ /g, "\\s");
    negativeEtalon = negativeEtalon.replace(/1/g, ".*");
    return new RegExp(negativeEtalon, "g");
  },
  getSign: function(text, format2) {
    if (!format2) {
      if ("-" === text.replace(/[^0-9-]/g, "").charAt(0)) {
        return -1;
      }
      return 1;
    }
    const negativeEtalon = this.getNegativeEtalonRegExp(format2);
    return text.match(negativeEtalon) ? -1 : 1;
  },
  format: function(value, format2) {
    if ("number" !== typeof value) {
      return value;
    }
    if ("number" === typeof format2) {
      return value;
    }
    format2 = format2 && format2.formatter || format2;
    if ("function" === typeof format2) {
      return format2(value);
    }
    format2 = this._normalizeFormat(format2);
    if (!format2.type) {
      format2.type = "decimal";
    }
    const numberConfig = this._parseNumberFormatString(format2.type);
    if (!numberConfig) {
      const formatterConfig = this._getSeparators();
      formatterConfig.unlimitedIntegerDigits = format2.unlimitedIntegerDigits;
      return this.convertDigits(getFormatter(format2.type, formatterConfig)(value));
    }
    return this._formatNumber(value, numberConfig, format2);
  },
  parse: function(text, format2) {
    if (!text) {
      return;
    }
    if (format2 && format2.parser) {
      return format2.parser(text);
    }
    text = this.convertDigits(text, true);
    if (format2 && "string" !== typeof format2) {
      errors_default.log("W0011");
    }
    const decimalSeparator = this.getDecimalSeparator();
    const regExp = new RegExp("[^0-9" + escapeRegExp(decimalSeparator) + "]", "g");
    const cleanedText = text.replace(regExp, "").replace(decimalSeparator, ".").replace(/\.$/g, "");
    if ("." === cleanedText || "" === cleanedText) {
      return null;
    }
    if (this._calcSignificantDigits(cleanedText) > 15) {
      return NaN;
    }
    let parsed = +cleanedText * this.getSign(text, format2);
    format2 = this._normalizeFormat(format2);
    const formatConfig = this._parseNumberFormatString(format2.type);
    let power = null === formatConfig || void 0 === formatConfig ? void 0 : formatConfig.power;
    if (power) {
      if ("auto" === power) {
        const match = text.match(/\d(K|M|B|T)/);
        if (match) {
          power = Object.keys(LargeNumberFormatPostfixes).find((power2) => LargeNumberFormatPostfixes[power2] === match[1]);
        }
      }
      parsed *= Math.pow(10, 3 * power);
    }
    if ("percent" === (null === formatConfig || void 0 === formatConfig ? void 0 : formatConfig.formatType)) {
      parsed /= 100;
    }
    return parsed;
  },
  _calcSignificantDigits: function(text) {
    const [integer, fractional] = text.split(".");
    const calcDigitsAfterLeadingZeros = (digits) => {
      let index = -1;
      for (let i = 0; i < digits.length; i++) {
        if ("0" !== digits[i]) {
          index = i;
          break;
        }
      }
      return index > -1 ? digits.length - index : 0;
    };
    let result2 = 0;
    if (integer) {
      result2 += calcDigitsAfterLeadingZeros(integer.split(""));
    }
    if (fractional) {
      result2 += calcDigitsAfterLeadingZeros(fractional.split("").reverse());
    }
    return result2;
  }
});
numberLocalization.inject(currency_default);
if (hasIntl) {
  numberLocalization.inject(number_default);
}
var number_default2 = numberLocalization;

// node_modules/devextreme/esm/__internal/ui/m_validation_engine.js
var EMAIL_VALIDATION_REGEX = /^[\d\w.+_-]+@[\d\w._-]+\.[\w]+$/i;
var STATUS = {
  valid: "valid",
  invalid: "invalid",
  pending: "pending"
};
var BaseRuleValidator = class {
  constructor() {
    this.NAME = "base";
  }
  defaultMessage(value) {
    return message_default.getFormatter(`validation-${this.NAME}`)(value);
  }
  defaultFormattedMessage(value) {
    return message_default.getFormatter(`validation-${this.NAME}-formatted`)(value);
  }
  _isValueEmpty(value) {
    return !rulesValidators.required.validate(value, {});
  }
  validate(value, rule) {
    const valueArray = Array.isArray(value) ? value : [value];
    let result2 = true;
    if (valueArray.length) {
      valueArray.every((itemValue) => {
        result2 = this._validate(itemValue, rule);
        return result2;
      });
    } else {
      result2 = this._validate(null, rule);
    }
    return result2;
  }
};
var RequiredRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "required";
  }
  _validate(value, rule) {
    if (!isDefined(value)) {
      return false;
    }
    if (false === value) {
      return false;
    }
    value = String(value);
    if (rule.trim || !isDefined(rule.trim)) {
      value = value.trim();
    }
    return "" !== value;
  }
};
var NumericRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "numeric";
  }
  _validate(value, rule) {
    if (false !== rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    if (rule.useCultureSettings && isString(value)) {
      return !isNaN(number_default2.parse(value));
    }
    return isNumeric(value);
  }
};
var RangeRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "range";
  }
  _validate(value, rule) {
    if (false !== rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    const validNumber = rulesValidators.numeric.validate(value, rule);
    const validValue = isDefined(value) && "" !== value;
    const number = validNumber ? parseFloat(value) : validValue && value.valueOf();
    const {
      min
    } = rule;
    const {
      max
    } = rule;
    if (!(validNumber || isDate(value)) && !validValue) {
      return false;
    }
    if (isDefined(min)) {
      if (isDefined(max)) {
        return number >= min && number <= max;
      }
      return number >= min;
    }
    if (isDefined(max)) {
      return number <= max;
    }
    throw errors_default.Error("E0101");
  }
};
var StringLengthRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "stringLength";
  }
  _validate(value, rule) {
    value = String(value ?? "");
    if (rule.trim || !isDefined(rule.trim)) {
      value = value.trim();
    }
    if (rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    return rulesValidators.range.validate(value.length, extend({}, rule));
  }
};
var CustomRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "custom";
  }
  validate(value, rule) {
    if (rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    const {
      validator
    } = rule;
    const dataGetter = validator && isFunction(validator.option) && validator.option("dataGetter");
    const extraParams = isFunction(dataGetter) && dataGetter();
    const params = {
      value,
      validator,
      rule
    };
    if (extraParams) {
      extend(params, extraParams);
    }
    return rule.validationCallback(params);
  }
};
var AsyncRuleValidator = class extends CustomRuleValidator {
  constructor() {
    super();
    this.NAME = "async";
  }
  validate(value, rule) {
    if (!isDefined(rule.reevaluate)) {
      extend(rule, {
        reevaluate: true
      });
    }
    if (rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    const {
      validator
    } = rule;
    const dataGetter = validator && isFunction(validator.option) && validator.option("dataGetter");
    const extraParams = isFunction(dataGetter) && dataGetter();
    const params = {
      value,
      validator,
      rule
    };
    if (extraParams) {
      extend(params, extraParams);
    }
    const callbackResult = rule.validationCallback(params);
    if (!isPromise(callbackResult)) {
      throw errors_default.Error("E0103");
    }
    return this._getWrappedPromise(fromPromise(callbackResult).promise());
  }
  _getWrappedPromise(promise) {
    const deferred = Deferred();
    promise.then((res) => {
      deferred.resolve(res);
    }, (err) => {
      const res = {
        isValid: false
      };
      if (isDefined(err)) {
        if (isString(err)) {
          res.message = err;
        } else if (isObject(err) && isDefined(err.message) && isString(err.message)) {
          res.message = err.message;
        }
      }
      deferred.resolve(res);
    });
    return deferred.promise();
  }
};
var CompareRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "compare";
  }
  _validate(value, rule) {
    if (!rule.comparisonTarget) {
      throw errors_default.Error("E0102");
    }
    if (rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    extend(rule, {
      reevaluate: true
    });
    const otherValue = rule.comparisonTarget();
    const type = rule.comparisonType || "==";
    switch (type) {
      case "==":
        return value == otherValue;
      case "!=":
        return value != otherValue;
      case "===":
        return value === otherValue;
      case "!==":
        return value !== otherValue;
      case ">":
        return value > otherValue;
      case ">=":
        return value >= otherValue;
      case "<":
        return value < otherValue;
      case "<=":
        return value <= otherValue;
    }
  }
};
var PatternRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "pattern";
  }
  _validate(value, rule) {
    if (false !== rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    let {
      pattern
    } = rule;
    if (isString(pattern)) {
      pattern = new RegExp(pattern);
    }
    return pattern.test(value);
  }
};
var EmailRuleValidator = class extends BaseRuleValidator {
  constructor() {
    super();
    this.NAME = "email";
  }
  _validate(value, rule) {
    if (false !== rule.ignoreEmptyValue && this._isValueEmpty(value)) {
      return true;
    }
    return rulesValidators.pattern.validate(value, extend({}, rule, {
      pattern: EMAIL_VALIDATION_REGEX
    }));
  }
};
var rulesValidators = {
  required: new RequiredRuleValidator(),
  numeric: new NumericRuleValidator(),
  range: new RangeRuleValidator(),
  stringLength: new StringLengthRuleValidator(),
  custom: new CustomRuleValidator(),
  async: new AsyncRuleValidator(),
  compare: new CompareRuleValidator(),
  pattern: new PatternRuleValidator(),
  email: new EmailRuleValidator()
};
var GroupConfig = class_default.inherit({
  ctor(group, isRemovable) {
    this.group = group;
    this.validators = [];
    this._isRemovable = isRemovable;
    this._pendingValidators = [];
    this._onValidatorStatusChanged = this._onValidatorStatusChanged.bind(this);
    this._resetValidationInfo();
    this._eventsStrategy = new EventsStrategy(this);
  },
  validate() {
    const result2 = {
      isValid: true,
      brokenRules: [],
      validators: [],
      status: STATUS.valid,
      complete: null
    };
    this._unsubscribeFromAllChangeEvents();
    this._pendingValidators = [];
    this._resetValidationInfo();
    each(this.validators, (_, validator) => {
      const validatorResult = validator.validate();
      result2.isValid = result2.isValid && validatorResult.isValid;
      if (validatorResult.brokenRules) {
        result2.brokenRules = result2.brokenRules.concat(validatorResult.brokenRules);
      }
      result2.validators.push(validator);
      if (validatorResult.status === STATUS.pending) {
        this._addPendingValidator(validator);
      }
      this._subscribeToChangeEvents(validator);
    });
    if (this._pendingValidators.length) {
      result2.status = STATUS.pending;
    } else {
      result2.status = result2.isValid ? STATUS.valid : STATUS.invalid;
      this._unsubscribeFromAllChangeEvents();
      this._raiseValidatedEvent(result2);
    }
    this._updateValidationInfo(result2);
    return extend({}, this._validationInfo.result);
  },
  _subscribeToChangeEvents(validator) {
    validator.on("validating", this._onValidatorStatusChanged);
    validator.on("validated", this._onValidatorStatusChanged);
  },
  _unsubscribeFromChangeEvents(validator) {
    validator.off("validating", this._onValidatorStatusChanged);
    validator.off("validated", this._onValidatorStatusChanged);
  },
  _unsubscribeFromAllChangeEvents() {
    each(this.validators, (_, validator) => {
      this._unsubscribeFromChangeEvents(validator);
    });
  },
  _updateValidationInfo(result2) {
    this._validationInfo.result = result2;
    if (result2.status !== STATUS.pending) {
      return;
    }
    if (!this._validationInfo.deferred) {
      this._validationInfo.deferred = Deferred();
      this._validationInfo.result.complete = this._validationInfo.deferred.promise();
    }
  },
  _addPendingValidator(validator) {
    const foundValidator = grep(this._pendingValidators, (val) => val === validator)[0];
    if (!foundValidator) {
      this._pendingValidators.push(validator);
    }
  },
  _removePendingValidator(validator) {
    const index = this._pendingValidators.indexOf(validator);
    if (index >= 0) {
      this._pendingValidators.splice(index, 1);
    }
  },
  _orderBrokenRules(brokenRules) {
    let orderedRules = [];
    each(this.validators, (_, validator) => {
      const foundRules = grep(brokenRules, (rule) => rule.validator === validator);
      if (foundRules.length) {
        orderedRules = orderedRules.concat(foundRules);
      }
    });
    return orderedRules;
  },
  _updateBrokenRules(result2) {
    if (!this._validationInfo.result) {
      return;
    }
    let {
      brokenRules
    } = this._validationInfo.result;
    const rules = grep(brokenRules, (rule) => rule.validator !== result2.validator);
    if (result2.brokenRules) {
      brokenRules = rules.concat(result2.brokenRules);
    }
    this._validationInfo.result.brokenRules = this._orderBrokenRules(brokenRules);
  },
  _onValidatorStatusChanged(result2) {
    if (result2.status === STATUS.pending) {
      this._addPendingValidator(result2.validator);
      return;
    }
    this._resolveIfComplete(result2);
  },
  _resolveIfComplete(result2) {
    this._removePendingValidator(result2.validator);
    this._updateBrokenRules(result2);
    if (!this._pendingValidators.length) {
      this._unsubscribeFromAllChangeEvents();
      if (!this._validationInfo.result) {
        return;
      }
      this._validationInfo.result.status = 0 === this._validationInfo.result.brokenRules.length ? STATUS.valid : STATUS.invalid;
      this._validationInfo.result.isValid = this._validationInfo.result.status === STATUS.valid;
      const res = extend({}, this._validationInfo.result, {
        complete: null
      });
      const {
        deferred
      } = this._validationInfo;
      this._validationInfo.deferred = null;
      this._raiseValidatedEvent(res);
      deferred && setTimeout(() => {
        deferred.resolve(res);
      });
    }
  },
  _raiseValidatedEvent(result2) {
    this._eventsStrategy.fireEvent("validated", [result2]);
  },
  _resetValidationInfo() {
    this._validationInfo = {
      result: null,
      deferred: null
    };
  },
  _synchronizeValidationInfo() {
    if (this._validationInfo.result) {
      this._validationInfo.result.validators = this.validators;
    }
  },
  removeRegisteredValidator(validator) {
    const index = this.validators.indexOf(validator);
    if (index > -1) {
      this.validators.splice(index, 1);
      this._synchronizeValidationInfo();
      this._resolveIfComplete({
        validator
      });
    }
  },
  registerValidator(validator) {
    if (!this.validators.includes(validator)) {
      this.validators.push(validator);
      this._synchronizeValidationInfo();
    }
  },
  reset() {
    each(this.validators, (_, validator) => {
      validator.reset();
    });
    this._pendingValidators = [];
    this._resetValidationInfo();
  },
  on(eventName, eventHandler) {
    this._eventsStrategy.on(eventName, eventHandler);
    return this;
  },
  off(eventName, eventHandler) {
    this._eventsStrategy.off(eventName, eventHandler);
    return this;
  }
});
var ValidationEngine = {
  groups: [],
  getGroupConfig(group) {
    const result2 = grep(this.groups, (config) => config.group === group);
    if (result2.length) {
      return result2[0];
    }
  },
  findGroup($element, model) {
    var _$element$data;
    const hasValidationGroup = null === (_$element$data = $element.data()) || void 0 === _$element$data || null === (_$element$data = _$element$data.dxComponents) || void 0 === _$element$data ? void 0 : _$element$data.includes("dxValidationGroup");
    const validationGroup = hasValidationGroup && $element.dxValidationGroup("instance");
    if (validationGroup) {
      return validationGroup;
    }
    const $dxGroup = $element.parents(".dx-validationgroup").first();
    if ($dxGroup.length) {
      return $dxGroup.dxValidationGroup("instance");
    }
    return model;
  },
  initGroups() {
    this.groups = [];
    this.addGroup(void 0, false);
  },
  addGroup(group) {
    let isRemovable = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : true;
    let config = this.getGroupConfig(group);
    if (!config) {
      config = new GroupConfig(group, isRemovable);
      this.groups.push(config);
    }
    return config;
  },
  removeGroup(group) {
    const config = this.getGroupConfig(group);
    const index = this.groups.indexOf(config);
    if (index > -1) {
      this.groups.splice(index, 1);
    }
    return config;
  },
  _setDefaultMessage(info) {
    const {
      rule,
      validator,
      name: name2
    } = info;
    if (!isDefined(rule.message)) {
      if (validator.defaultFormattedMessage && isDefined(name2)) {
        rule.message = validator.defaultFormattedMessage(name2);
      } else {
        rule.message = validator.defaultMessage();
      }
    }
  },
  _addBrokenRule(info) {
    const {
      result: result2,
      rule
    } = info;
    if (!result2.brokenRule) {
      result2.brokenRule = rule;
    }
    if (!result2.brokenRules) {
      result2.brokenRules = [];
    }
    result2.brokenRules.push(rule);
  },
  validate(value, rules, name2) {
    var _rules$;
    let result2 = {
      name: name2,
      value,
      brokenRule: null,
      brokenRules: null,
      isValid: true,
      validationRules: rules,
      pendingRules: null,
      status: STATUS.valid,
      complete: null
    };
    const validator = null === rules || void 0 === rules || null === (_rules$ = rules[0]) || void 0 === _rules$ ? void 0 : _rules$.validator;
    const asyncRuleItems = [];
    each(rules || [], (_, rule) => {
      const ruleValidator = rulesValidators[rule.type];
      let ruleValidationResult;
      if (ruleValidator) {
        if (isDefined(rule.isValid) && rule.value === value && !rule.reevaluate) {
          if (!rule.isValid) {
            result2.isValid = false;
            this._addBrokenRule({
              result: result2,
              rule
            });
            return false;
          }
          return true;
        }
        rule.value = value;
        if ("async" === rule.type) {
          asyncRuleItems.push({
            rule,
            ruleValidator
          });
          return true;
        }
        ruleValidationResult = ruleValidator.validate(value, rule);
        rule.isValid = ruleValidationResult;
        if (!ruleValidationResult) {
          result2.isValid = false;
          this._setDefaultMessage({
            rule,
            validator: ruleValidator,
            name: name2
          });
          this._addBrokenRule({
            result: result2,
            rule
          });
        }
        if (!rule.isValid) {
          return false;
        }
      } else {
        throw errors_default.Error("E0100");
      }
    });
    if (result2.isValid && !result2.brokenRules && asyncRuleItems.length) {
      result2 = this._validateAsyncRules({
        value,
        items: asyncRuleItems,
        result: result2,
        name: name2
      });
    }
    this._synchronizeGroupValidationInfo(validator, result2);
    result2.status = result2.pendingRules ? STATUS.pending : result2.isValid ? STATUS.valid : STATUS.invalid;
    return result2;
  },
  _synchronizeGroupValidationInfo(validator, result2) {
    if (!validator) {
      return;
    }
    const groupConfig = ValidationEngine.getGroupConfig(validator._validationGroup);
    groupConfig._updateBrokenRules.call(groupConfig, {
      validator,
      brokenRules: result2.brokenRules ?? []
    });
  },
  _validateAsyncRules(_ref) {
    let {
      result: result2,
      value,
      items,
      name: name2
    } = _ref;
    const asyncResults = [];
    each(items, (_, item) => {
      const validateResult = item.ruleValidator.validate(value, item.rule);
      if (!isPromise(validateResult)) {
        this._updateRuleConfig({
          rule: item.rule,
          ruleResult: this._getPatchedRuleResult(validateResult),
          validator: item.ruleValidator,
          name: name2
        });
      } else {
        if (!result2.pendingRules) {
          result2.pendingRules = [];
        }
        result2.pendingRules.push(item.rule);
        const asyncResult = validateResult.then((res) => {
          const ruleResult = this._getPatchedRuleResult(res);
          this._updateRuleConfig({
            rule: item.rule,
            ruleResult,
            validator: item.ruleValidator,
            name: name2
          });
          return ruleResult;
        });
        asyncResults.push(asyncResult);
      }
    });
    if (asyncResults.length) {
      result2.complete = Promise.all(asyncResults).then((values) => this._getAsyncRulesResult({
        result: result2,
        values
      }));
    }
    return result2;
  },
  _updateRuleConfig(_ref2) {
    let {
      rule,
      ruleResult,
      validator,
      name: name2
    } = _ref2;
    rule.isValid = ruleResult.isValid;
    if (!ruleResult.isValid) {
      if (isDefined(ruleResult.message) && isString(ruleResult.message) && ruleResult.message.length) {
        rule.message = ruleResult.message;
      } else {
        this._setDefaultMessage({
          rule,
          validator,
          name: name2
        });
      }
    }
  },
  _getPatchedRuleResult(ruleResult) {
    let result2;
    if (isObject(ruleResult)) {
      result2 = extend({}, ruleResult);
      if (!isDefined(result2.isValid)) {
        result2.isValid = true;
      }
    } else {
      result2 = {
        isValid: isBoolean(ruleResult) ? ruleResult : true
      };
    }
    return result2;
  },
  _getAsyncRulesResult(_ref3) {
    let {
      values,
      result: result2
    } = _ref3;
    each(values, (index, val) => {
      if (false === val.isValid) {
        result2.isValid = val.isValid;
        const rule = result2.pendingRules[index];
        this._addBrokenRule({
          result: result2,
          rule
        });
      }
    });
    result2.pendingRules = null;
    result2.complete = null;
    result2.status = result2.isValid ? STATUS.valid : STATUS.invalid;
    return result2;
  },
  registerValidatorInGroup(group, validator) {
    const groupConfig = ValidationEngine.addGroup(group);
    groupConfig.registerValidator.call(groupConfig, validator);
  },
  removeRegisteredValidator(group, validator) {
    const config = ValidationEngine.getGroupConfig(group);
    if (config) {
      config.removeRegisteredValidator.call(config, validator);
      const validatorsInGroup = config.validators;
      const isRemovable = config._isRemovable;
      const shouldRemoveGroup = 0 === validatorsInGroup.length && isRemovable;
      if (shouldRemoveGroup) {
        this.removeGroup(group);
      }
    }
  },
  initValidationOptions(options2) {
    const initedOptions = {};
    if (options2) {
      const syncOptions = ["isValid", "validationStatus", "validationError", "validationErrors"];
      syncOptions.forEach((prop) => {
        if (prop in options2) {
          extend(initedOptions, this.synchronizeValidationOptions({
            name: prop,
            value: options2[prop]
          }, options2));
        }
      });
    }
    return initedOptions;
  },
  synchronizeValidationOptions(_ref4, options2) {
    let {
      name: name2,
      value
    } = _ref4;
    switch (name2) {
      case "validationStatus": {
        const isValid = value === STATUS.valid || value === STATUS.pending;
        return options2.isValid !== isValid ? {
          isValid
        } : {};
      }
      case "isValid": {
        const {
          validationStatus
        } = options2;
        let newStatus = validationStatus;
        if (value && validationStatus === STATUS.invalid) {
          newStatus = STATUS.valid;
        } else if (!value && validationStatus !== STATUS.invalid) {
          newStatus = STATUS.invalid;
        }
        return newStatus !== validationStatus ? {
          validationStatus: newStatus
        } : {};
      }
      case "validationErrors": {
        const validationError = !value || !value.length ? null : value[0];
        return options2.validationError !== validationError ? {
          validationError
        } : {};
      }
      case "validationError": {
        const {
          validationErrors
        } = options2;
        if (!value && validationErrors) {
          return {
            validationErrors: null
          };
        }
        if (value && !validationErrors) {
          return {
            validationErrors: [value]
          };
        }
        if (value && validationErrors && value !== validationErrors[0]) {
          validationErrors[0] = value;
          return {
            validationErrors: validationErrors.slice()
          };
        }
      }
    }
    return {};
  },
  validateGroup(group) {
    const groupConfig = ValidationEngine.getGroupConfig(group);
    if (!groupConfig) {
      throw errors_default.Error("E0110");
    }
    return groupConfig.validate();
  },
  resetGroup(group) {
    const groupConfig = ValidationEngine.getGroupConfig(group);
    if (!groupConfig) {
      throw errors_default.Error("E0110");
    }
    return groupConfig.reset();
  }
};
ValidationEngine.initGroups();
var m_validation_engine_default = ValidationEngine;

// node_modules/devextreme/esm/ui/validation_engine.js
var validation_engine_default = m_validation_engine_default;

// node_modules/devextreme/esm/renovation/component_wrapper/common/component.js
init_extends();

// node_modules/inferno/dist/index.esm.js
var isArray = Array.isArray;
function isStringOrNumber(o) {
  var type = typeof o;
  return type === "string" || type === "number";
}
function isNullOrUndef(o) {
  return o === void 0 || o === null;
}
function isInvalid(o) {
  return o === null || o === false || o === true || o === void 0;
}
function isFunction2(o) {
  return typeof o === "function";
}
function isString2(o) {
  return typeof o === "string";
}
function isNumber(o) {
  return typeof o === "number";
}
function isNull(o) {
  return o === null;
}
function isUndefined(o) {
  return o === void 0;
}
function combineFrom(first, second) {
  var out = {};
  if (first) {
    for (var key in first) {
      out[key] = first[key];
    }
  }
  if (second) {
    for (var key$1 in second) {
      out[key$1] = second[key$1];
    }
  }
  return out;
}
function isLinkEventObject(o) {
  return !isNull(o) && typeof o === "object";
}
var EMPTY_OBJ = {};
var Fragment = "$F";
function normalizeEventName(name2) {
  return name2.substr(2).toLowerCase();
}
function appendChild(parentDOM, dom) {
  parentDOM.appendChild(dom);
}
function insertOrAppend(parentDOM, newNode, nextNode) {
  if (isNull(nextNode)) {
    appendChild(parentDOM, newNode);
  } else {
    parentDOM.insertBefore(newNode, nextNode);
  }
}
function documentCreateElement(tag, isSVG) {
  if (isSVG) {
    return document.createElementNS("http://www.w3.org/2000/svg", tag);
  }
  return document.createElement(tag);
}
function replaceChild(parentDOM, newDom, lastDom) {
  parentDOM.replaceChild(newDom, lastDom);
}
function removeChild(parentDOM, childNode) {
  parentDOM.removeChild(childNode);
}
function callAll(arrayFn) {
  for (var i = 0; i < arrayFn.length; i++) {
    arrayFn[i]();
  }
}
function findChildVNode(vNode, startEdge, flags) {
  var children = vNode.children;
  if (flags & 4) {
    return children.$LI;
  }
  if (flags & 8192) {
    return vNode.childFlags === 2 ? children : children[startEdge ? 0 : children.length - 1];
  }
  return children;
}
function findDOMfromVNode(vNode, startEdge) {
  var flags;
  while (vNode) {
    flags = vNode.flags;
    if (flags & 2033) {
      return vNode.dom;
    }
    vNode = findChildVNode(vNode, startEdge, flags);
  }
  return null;
}
function removeVNodeDOM(vNode, parentDOM) {
  do {
    var flags = vNode.flags;
    if (flags & 2033) {
      removeChild(parentDOM, vNode.dom);
      return;
    }
    var children = vNode.children;
    if (flags & 4) {
      vNode = children.$LI;
    }
    if (flags & 8) {
      vNode = children;
    }
    if (flags & 8192) {
      if (vNode.childFlags === 2) {
        vNode = children;
      } else {
        for (var i = 0, len = children.length; i < len; ++i) {
          removeVNodeDOM(children[i], parentDOM);
        }
        return;
      }
    }
  } while (vNode);
}
function moveVNodeDOM(vNode, parentDOM, nextNode) {
  do {
    var flags = vNode.flags;
    if (flags & 2033) {
      insertOrAppend(parentDOM, vNode.dom, nextNode);
      return;
    }
    var children = vNode.children;
    if (flags & 4) {
      vNode = children.$LI;
    }
    if (flags & 8) {
      vNode = children;
    }
    if (flags & 8192) {
      if (vNode.childFlags === 2) {
        vNode = children;
      } else {
        for (var i = 0, len = children.length; i < len; ++i) {
          moveVNodeDOM(children[i], parentDOM, nextNode);
        }
        return;
      }
    }
  } while (vNode);
}
function createDerivedState(instance, nextProps, state) {
  if (instance.constructor.getDerivedStateFromProps) {
    return combineFrom(state, instance.constructor.getDerivedStateFromProps(nextProps, state));
  }
  return state;
}
var renderCheck = {
  v: false
};
var options = {
  componentComparator: null,
  createVNode: null,
  renderComplete: null
};
function setTextContent(dom, children) {
  dom.textContent = children;
}
function isLastValueSameLinkEvent(lastValue, nextValue) {
  return isLinkEventObject(lastValue) && lastValue.event === nextValue.event && lastValue.data === nextValue.data;
}
function mergeUnsetProperties(to, from) {
  for (var propName in from) {
    if (isUndefined(to[propName])) {
      to[propName] = from[propName];
    }
  }
  return to;
}
function safeCall1(method, arg1) {
  return !!isFunction2(method) && (method(arg1), true);
}
var keyPrefix = "$";
function V(childFlags, children, className, flags, key, props, ref, type) {
  this.childFlags = childFlags;
  this.children = children;
  this.className = className;
  this.dom = null;
  this.flags = flags;
  this.key = key === void 0 ? null : key;
  this.props = props === void 0 ? null : props;
  this.ref = ref === void 0 ? null : ref;
  this.type = type;
}
function createVNode(flags, type, className, children, childFlags, props, key, ref) {
  var childFlag = childFlags === void 0 ? 1 : childFlags;
  var vNode = new V(childFlag, children, className, flags, key, props, ref, type);
  if (options.createVNode) {
    options.createVNode(vNode);
  }
  if (childFlag === 0) {
    normalizeChildren(vNode, vNode.children);
  }
  return vNode;
}
function mergeDefaultHooks(flags, type, ref) {
  if (flags & 4) {
    return ref;
  }
  var defaultHooks = (flags & 32768 ? type.render : type).defaultHooks;
  if (isNullOrUndef(defaultHooks)) {
    return ref;
  }
  if (isNullOrUndef(ref)) {
    return defaultHooks;
  }
  return mergeUnsetProperties(ref, defaultHooks);
}
function mergeDefaultProps(flags, type, props) {
  var defaultProps = (flags & 32768 ? type.render : type).defaultProps;
  if (isNullOrUndef(defaultProps)) {
    return props;
  }
  if (isNullOrUndef(props)) {
    return combineFrom(defaultProps, null);
  }
  return mergeUnsetProperties(props, defaultProps);
}
function resolveComponentFlags(flags, type) {
  if (flags & 12) {
    return flags;
  }
  if (type.prototype && type.prototype.render) {
    return 4;
  }
  if (type.render) {
    return 32776;
  }
  return 8;
}
function createComponentVNode(flags, type, props, key, ref) {
  flags = resolveComponentFlags(flags, type);
  var vNode = new V(1, null, null, flags, key, mergeDefaultProps(flags, type, props), mergeDefaultHooks(flags, type, ref), type);
  if (options.createVNode) {
    options.createVNode(vNode);
  }
  return vNode;
}
function createTextVNode(text, key) {
  return new V(1, isNullOrUndef(text) || text === true || text === false ? "" : text, null, 16, key, null, null, null);
}
function createFragment(children, childFlags, key) {
  var fragment = createVNode(8192, 8192, null, children, childFlags, null, key, null);
  switch (fragment.childFlags) {
    case 1:
      fragment.children = createVoidVNode();
      fragment.childFlags = 2;
      break;
    case 16:
      fragment.children = [createTextVNode(children)];
      fragment.childFlags = 4;
      break;
  }
  return fragment;
}
function normalizeProps(vNode) {
  var props = vNode.props;
  if (props) {
    var flags = vNode.flags;
    if (flags & 481) {
      if (props.children !== void 0 && isNullOrUndef(vNode.children)) {
        normalizeChildren(vNode, props.children);
      }
      if (props.className !== void 0) {
        if (isNullOrUndef(vNode.className)) {
          vNode.className = props.className || null;
        }
        props.className = void 0;
      }
    }
    if (props.key !== void 0) {
      vNode.key = props.key;
      props.key = void 0;
    }
    if (props.ref !== void 0) {
      if (flags & 8) {
        vNode.ref = combineFrom(vNode.ref, props.ref);
      } else {
        vNode.ref = props.ref;
      }
      props.ref = void 0;
    }
  }
  return vNode;
}
function cloneFragment(vNodeToClone) {
  var oldChildren = vNodeToClone.children;
  var childFlags = vNodeToClone.childFlags;
  return createFragment(childFlags === 2 ? directClone(oldChildren) : oldChildren.map(directClone), childFlags, vNodeToClone.key);
}
function directClone(vNodeToClone) {
  var flags = vNodeToClone.flags & -16385;
  var props = vNodeToClone.props;
  if (flags & 14) {
    if (!isNull(props)) {
      var propsToClone = props;
      props = {};
      for (var key in propsToClone) {
        props[key] = propsToClone[key];
      }
    }
  }
  if ((flags & 8192) === 0) {
    return new V(vNodeToClone.childFlags, vNodeToClone.children, vNodeToClone.className, flags, vNodeToClone.key, props, vNodeToClone.ref, vNodeToClone.type);
  }
  return cloneFragment(vNodeToClone);
}
function createVoidVNode() {
  return createTextVNode("", null);
}
function _normalizeVNodes(nodes, result2, index, currentKey) {
  for (var len = nodes.length; index < len; index++) {
    var n = nodes[index];
    if (!isInvalid(n)) {
      var newKey = currentKey + keyPrefix + index;
      if (isArray(n)) {
        _normalizeVNodes(n, result2, 0, newKey);
      } else {
        if (isStringOrNumber(n)) {
          n = createTextVNode(n, newKey);
        } else {
          var oldKey = n.key;
          var isPrefixedKey = isString2(oldKey) && oldKey[0] === keyPrefix;
          if (n.flags & 81920 || isPrefixedKey) {
            n = directClone(n);
          }
          n.flags |= 65536;
          if (!isPrefixedKey) {
            if (isNull(oldKey)) {
              n.key = newKey;
            } else {
              n.key = currentKey + oldKey;
            }
          } else if (oldKey.substring(0, currentKey.length) !== currentKey) {
            n.key = currentKey + oldKey;
          }
        }
        result2.push(n);
      }
    }
  }
}
function getFlagsForElementVnode(type) {
  switch (type) {
    case "svg":
      return 32;
    case "input":
      return 64;
    case "select":
      return 256;
    case "textarea":
      return 128;
    case Fragment:
      return 8192;
    default:
      return 1;
  }
}
function normalizeChildren(vNode, children) {
  var newChildren;
  var newChildFlags = 1;
  if (isInvalid(children)) {
    newChildren = children;
  } else if (isStringOrNumber(children)) {
    newChildFlags = 16;
    newChildren = children;
  } else if (isArray(children)) {
    var len = children.length;
    for (var i = 0; i < len; ++i) {
      var n = children[i];
      if (isInvalid(n) || isArray(n)) {
        newChildren = newChildren || children.slice(0, i);
        _normalizeVNodes(children, newChildren, i, "");
        break;
      } else if (isStringOrNumber(n)) {
        newChildren = newChildren || children.slice(0, i);
        newChildren.push(createTextVNode(n, keyPrefix + i));
      } else {
        var key = n.key;
        var needsCloning = (n.flags & 81920) > 0;
        var isNullKey = isNull(key);
        var isPrefixed = isString2(key) && key[0] === keyPrefix;
        if (needsCloning || isNullKey || isPrefixed) {
          newChildren = newChildren || children.slice(0, i);
          if (needsCloning || isPrefixed) {
            n = directClone(n);
          }
          if (isNullKey || isPrefixed) {
            n.key = keyPrefix + i;
          }
          newChildren.push(n);
        } else if (newChildren) {
          newChildren.push(n);
        }
        n.flags |= 65536;
      }
    }
    newChildren = newChildren || children;
    if (newChildren.length === 0) {
      newChildFlags = 1;
    } else {
      newChildFlags = 8;
    }
  } else {
    newChildren = children;
    newChildren.flags |= 65536;
    if (children.flags & 81920) {
      newChildren = directClone(children);
    }
    newChildFlags = 2;
  }
  vNode.children = newChildren;
  vNode.childFlags = newChildFlags;
  return vNode;
}
function normalizeRoot(input) {
  if (isInvalid(input) || isStringOrNumber(input)) {
    return createTextVNode(input, null);
  }
  if (isArray(input)) {
    return createFragment(input, 0, null);
  }
  return input.flags & 16384 ? directClone(input) : input;
}
var xlinkNS = "http://www.w3.org/1999/xlink";
var xmlNS = "http://www.w3.org/XML/1998/namespace";
var namespaces = {
  "xlink:actuate": xlinkNS,
  "xlink:arcrole": xlinkNS,
  "xlink:href": xlinkNS,
  "xlink:role": xlinkNS,
  "xlink:show": xlinkNS,
  "xlink:title": xlinkNS,
  "xlink:type": xlinkNS,
  "xml:base": xmlNS,
  "xml:lang": xmlNS,
  "xml:space": xmlNS
};
function getDelegatedEventObject(v) {
  return {
    onClick: v,
    onDblClick: v,
    onFocusIn: v,
    onFocusOut: v,
    onKeyDown: v,
    onKeyPress: v,
    onKeyUp: v,
    onMouseDown: v,
    onMouseMove: v,
    onMouseUp: v,
    onTouchEnd: v,
    onTouchMove: v,
    onTouchStart: v
  };
}
var attachedEventCounts = getDelegatedEventObject(0);
var attachedEvents = getDelegatedEventObject(null);
var syntheticEvents = getDelegatedEventObject(true);
function updateOrAddSyntheticEvent(name2, dom) {
  var eventsObject = dom.$EV;
  if (!eventsObject) {
    eventsObject = dom.$EV = getDelegatedEventObject(null);
  }
  if (!eventsObject[name2]) {
    if (++attachedEventCounts[name2] === 1) {
      attachedEvents[name2] = attachEventToDocument(name2);
    }
  }
  return eventsObject;
}
function unmountSyntheticEvent(name2, dom) {
  var eventsObject = dom.$EV;
  if (eventsObject && eventsObject[name2]) {
    if (--attachedEventCounts[name2] === 0) {
      document.removeEventListener(normalizeEventName(name2), attachedEvents[name2]);
      attachedEvents[name2] = null;
    }
    eventsObject[name2] = null;
  }
}
function handleSyntheticEvent(name2, lastEvent, nextEvent, dom) {
  if (isFunction2(nextEvent)) {
    updateOrAddSyntheticEvent(name2, dom)[name2] = nextEvent;
  } else if (isLinkEventObject(nextEvent)) {
    if (isLastValueSameLinkEvent(lastEvent, nextEvent)) {
      return;
    }
    updateOrAddSyntheticEvent(name2, dom)[name2] = nextEvent;
  } else {
    unmountSyntheticEvent(name2, dom);
  }
}
function getTargetNode(event) {
  return isFunction2(event.composedPath) ? event.composedPath()[0] : event.target;
}
function dispatchEvents(event, isClick, name2, eventData2) {
  var dom = getTargetNode(event);
  do {
    if (isClick && dom.disabled) {
      return;
    }
    var eventsObject = dom.$EV;
    if (eventsObject) {
      var currentEvent = eventsObject[name2];
      if (currentEvent) {
        eventData2.dom = dom;
        currentEvent.event ? currentEvent.event(currentEvent.data, event) : currentEvent(event);
        if (event.cancelBubble) {
          return;
        }
      }
    }
    dom = dom.parentNode;
  } while (!isNull(dom));
}
function stopPropagation() {
  this.cancelBubble = true;
  if (!this.immediatePropagationStopped) {
    this.stopImmediatePropagation();
  }
}
function isDefaultPrevented() {
  return this.defaultPrevented;
}
function isPropagationStopped() {
  return this.cancelBubble;
}
function extendEventProperties(event) {
  var eventData2 = {
    dom: document
  };
  event.isDefaultPrevented = isDefaultPrevented;
  event.isPropagationStopped = isPropagationStopped;
  event.stopPropagation = stopPropagation;
  Object.defineProperty(event, "currentTarget", {
    configurable: true,
    get: function get() {
      return eventData2.dom;
    }
  });
  return eventData2;
}
function rootClickEvent(name2) {
  return function(event) {
    if (event.button !== 0) {
      event.stopPropagation();
      return;
    }
    dispatchEvents(event, true, name2, extendEventProperties(event));
  };
}
function rootEvent(name2) {
  return function(event) {
    dispatchEvents(event, false, name2, extendEventProperties(event));
  };
}
function attachEventToDocument(name2) {
  var attachedEvent = name2 === "onClick" || name2 === "onDblClick" ? rootClickEvent(name2) : rootEvent(name2);
  document.addEventListener(normalizeEventName(name2), attachedEvent);
  return attachedEvent;
}
function isSameInnerHTML(dom, innerHTML) {
  var tempdom = document.createElement("i");
  tempdom.innerHTML = innerHTML;
  return tempdom.innerHTML === dom.innerHTML;
}
function triggerEventListener(props, methodName, e) {
  if (props[methodName]) {
    var listener = props[methodName];
    if (listener.event) {
      listener.event(listener.data, e);
    } else {
      listener(e);
    }
  } else {
    var nativeListenerName = methodName.toLowerCase();
    if (props[nativeListenerName]) {
      props[nativeListenerName](e);
    }
  }
}
function createWrappedFunction(methodName, applyValue) {
  var fnMethod = function(e) {
    var vNode = this.$V;
    if (!vNode) {
      return;
    }
    var props = vNode.props || EMPTY_OBJ;
    var dom = vNode.dom;
    if (isString2(methodName)) {
      triggerEventListener(props, methodName, e);
    } else {
      for (var i = 0; i < methodName.length; ++i) {
        triggerEventListener(props, methodName[i], e);
      }
    }
    if (isFunction2(applyValue)) {
      var newVNode = this.$V;
      var newProps = newVNode.props || EMPTY_OBJ;
      applyValue(newProps, dom, false, newVNode);
    }
  };
  Object.defineProperty(fnMethod, "wrapped", {
    configurable: false,
    enumerable: false,
    value: true,
    writable: false
  });
  return fnMethod;
}
function attachEvent(dom, eventName, handler) {
  var previousKey = "$" + eventName;
  var previousArgs = dom[previousKey];
  if (previousArgs) {
    if (previousArgs[1].wrapped) {
      return;
    }
    dom.removeEventListener(previousArgs[0], previousArgs[1]);
    dom[previousKey] = null;
  }
  if (isFunction2(handler)) {
    dom.addEventListener(eventName, handler);
    dom[previousKey] = [eventName, handler];
  }
}
function isCheckedType(type) {
  return type === "checkbox" || type === "radio";
}
var onTextInputChange = createWrappedFunction("onInput", applyValueInput);
var wrappedOnChange = createWrappedFunction(["onClick", "onChange"], applyValueInput);
function emptywrapper(event) {
  event.stopPropagation();
}
emptywrapper.wrapped = true;
function inputEvents(dom, nextPropsOrEmpty) {
  if (isCheckedType(nextPropsOrEmpty.type)) {
    attachEvent(dom, "change", wrappedOnChange);
    attachEvent(dom, "click", emptywrapper);
  } else {
    attachEvent(dom, "input", onTextInputChange);
  }
}
function applyValueInput(nextPropsOrEmpty, dom) {
  var type = nextPropsOrEmpty.type;
  var value = nextPropsOrEmpty.value;
  var checked = nextPropsOrEmpty.checked;
  var multiple = nextPropsOrEmpty.multiple;
  var defaultValue = nextPropsOrEmpty.defaultValue;
  var hasValue = !isNullOrUndef(value);
  if (type && type !== dom.type) {
    dom.setAttribute("type", type);
  }
  if (!isNullOrUndef(multiple) && multiple !== dom.multiple) {
    dom.multiple = multiple;
  }
  if (!isNullOrUndef(defaultValue) && !hasValue) {
    dom.defaultValue = defaultValue + "";
  }
  if (isCheckedType(type)) {
    if (hasValue) {
      dom.value = value;
    }
    if (!isNullOrUndef(checked)) {
      dom.checked = checked;
    }
  } else {
    if (hasValue && dom.value !== value) {
      dom.defaultValue = value;
      dom.value = value;
    } else if (!isNullOrUndef(checked)) {
      dom.checked = checked;
    }
  }
}
function updateChildOptions(vNode, value) {
  if (vNode.type === "option") {
    updateChildOption(vNode, value);
  } else {
    var children = vNode.children;
    var flags = vNode.flags;
    if (flags & 4) {
      updateChildOptions(children.$LI, value);
    } else if (flags & 8) {
      updateChildOptions(children, value);
    } else if (vNode.childFlags === 2) {
      updateChildOptions(children, value);
    } else if (vNode.childFlags & 12) {
      for (var i = 0, len = children.length; i < len; ++i) {
        updateChildOptions(children[i], value);
      }
    }
  }
}
function updateChildOption(vNode, value) {
  var props = vNode.props || EMPTY_OBJ;
  var dom = vNode.dom;
  dom.value = props.value;
  if (props.value === value || isArray(value) && value.indexOf(props.value) !== -1) {
    dom.selected = true;
  } else if (!isNullOrUndef(value) || !isNullOrUndef(props.selected)) {
    dom.selected = props.selected || false;
  }
}
var onSelectChange = createWrappedFunction("onChange", applyValueSelect);
function selectEvents(dom) {
  attachEvent(dom, "change", onSelectChange);
}
function applyValueSelect(nextPropsOrEmpty, dom, mounting, vNode) {
  var multiplePropInBoolean = Boolean(nextPropsOrEmpty.multiple);
  if (!isNullOrUndef(nextPropsOrEmpty.multiple) && multiplePropInBoolean !== dom.multiple) {
    dom.multiple = multiplePropInBoolean;
  }
  var index = nextPropsOrEmpty.selectedIndex;
  if (index === -1) {
    dom.selectedIndex = -1;
  }
  var childFlags = vNode.childFlags;
  if (childFlags !== 1) {
    var value = nextPropsOrEmpty.value;
    if (isNumber(index) && index > -1 && dom.options[index]) {
      value = dom.options[index].value;
    }
    if (mounting && isNullOrUndef(value)) {
      value = nextPropsOrEmpty.defaultValue;
    }
    updateChildOptions(vNode, value);
  }
}
var onTextareaInputChange = createWrappedFunction("onInput", applyValueTextArea);
var wrappedOnChange$1 = createWrappedFunction("onChange");
function textAreaEvents(dom, nextPropsOrEmpty) {
  attachEvent(dom, "input", onTextareaInputChange);
  if (nextPropsOrEmpty.onChange) {
    attachEvent(dom, "change", wrappedOnChange$1);
  }
}
function applyValueTextArea(nextPropsOrEmpty, dom, mounting) {
  var value = nextPropsOrEmpty.value;
  var domValue = dom.value;
  if (isNullOrUndef(value)) {
    if (mounting) {
      var defaultValue = nextPropsOrEmpty.defaultValue;
      if (!isNullOrUndef(defaultValue) && defaultValue !== domValue) {
        dom.defaultValue = defaultValue;
        dom.value = defaultValue;
      }
    }
  } else if (domValue !== value) {
    dom.defaultValue = value;
    dom.value = value;
  }
}
function processElement(flags, vNode, dom, nextPropsOrEmpty, mounting, isControlled) {
  if (flags & 64) {
    applyValueInput(nextPropsOrEmpty, dom);
  } else if (flags & 256) {
    applyValueSelect(nextPropsOrEmpty, dom, mounting, vNode);
  } else if (flags & 128) {
    applyValueTextArea(nextPropsOrEmpty, dom, mounting);
  }
  if (isControlled) {
    dom.$V = vNode;
  }
}
function addFormElementEventHandlers(flags, dom, nextPropsOrEmpty) {
  if (flags & 64) {
    inputEvents(dom, nextPropsOrEmpty);
  } else if (flags & 256) {
    selectEvents(dom);
  } else if (flags & 128) {
    textAreaEvents(dom, nextPropsOrEmpty);
  }
}
function isControlledFormElement(nextPropsOrEmpty) {
  return nextPropsOrEmpty.type && isCheckedType(nextPropsOrEmpty.type) ? !isNullOrUndef(nextPropsOrEmpty.checked) : !isNullOrUndef(nextPropsOrEmpty.value);
}
function createRef() {
  return {
    current: null
  };
}
function unmountRef(ref) {
  if (ref) {
    if (!safeCall1(ref, null) && ref.current) {
      ref.current = null;
    }
  }
}
function mountRef(ref, value, lifecycle) {
  if (ref && (isFunction2(ref) || ref.current !== void 0)) {
    lifecycle.push(function() {
      if (!safeCall1(ref, value) && ref.current !== void 0) {
        ref.current = value;
      }
    });
  }
}
function remove2(vNode, parentDOM) {
  unmount(vNode);
  removeVNodeDOM(vNode, parentDOM);
}
function unmount(vNode) {
  var flags = vNode.flags;
  var children = vNode.children;
  var ref;
  if (flags & 481) {
    ref = vNode.ref;
    var props = vNode.props;
    unmountRef(ref);
    var childFlags = vNode.childFlags;
    if (!isNull(props)) {
      var keys = Object.keys(props);
      for (var i = 0, len = keys.length; i < len; i++) {
        var key = keys[i];
        if (syntheticEvents[key]) {
          unmountSyntheticEvent(key, vNode.dom);
        }
      }
    }
    if (childFlags & 12) {
      unmountAllChildren(children);
    } else if (childFlags === 2) {
      unmount(children);
    }
  } else if (children) {
    if (flags & 4) {
      if (isFunction2(children.componentWillUnmount)) {
        children.componentWillUnmount();
      }
      unmountRef(vNode.ref);
      children.$UN = true;
      unmount(children.$LI);
    } else if (flags & 8) {
      ref = vNode.ref;
      if (!isNullOrUndef(ref) && isFunction2(ref.onComponentWillUnmount)) {
        ref.onComponentWillUnmount(findDOMfromVNode(vNode, true), vNode.props || EMPTY_OBJ);
      }
      unmount(children);
    } else if (flags & 1024) {
      remove2(children, vNode.ref);
    } else if (flags & 8192) {
      if (vNode.childFlags & 12) {
        unmountAllChildren(children);
      }
    }
  }
}
function unmountAllChildren(children) {
  for (var i = 0, len = children.length; i < len; ++i) {
    unmount(children[i]);
  }
}
function clearDOM(dom) {
  dom.textContent = "";
}
function removeAllChildren(dom, vNode, children) {
  unmountAllChildren(children);
  if (vNode.flags & 8192) {
    removeVNodeDOM(vNode, dom);
  } else {
    clearDOM(dom);
  }
}
function wrapLinkEvent(nextValue) {
  var ev = nextValue.event;
  return function(e) {
    ev(nextValue.data, e);
  };
}
function patchEvent(name2, lastValue, nextValue, dom) {
  if (isLinkEventObject(nextValue)) {
    if (isLastValueSameLinkEvent(lastValue, nextValue)) {
      return;
    }
    nextValue = wrapLinkEvent(nextValue);
  }
  attachEvent(dom, normalizeEventName(name2), nextValue);
}
function patchStyle(lastAttrValue, nextAttrValue, dom) {
  if (isNullOrUndef(nextAttrValue)) {
    dom.removeAttribute("style");
    return;
  }
  var domStyle = dom.style;
  var style;
  var value;
  if (isString2(nextAttrValue)) {
    domStyle.cssText = nextAttrValue;
    return;
  }
  if (!isNullOrUndef(lastAttrValue) && !isString2(lastAttrValue)) {
    for (style in nextAttrValue) {
      value = nextAttrValue[style];
      if (value !== lastAttrValue[style]) {
        domStyle.setProperty(style, value);
      }
    }
    for (style in lastAttrValue) {
      if (isNullOrUndef(nextAttrValue[style])) {
        domStyle.removeProperty(style);
      }
    }
  } else {
    for (style in nextAttrValue) {
      value = nextAttrValue[style];
      domStyle.setProperty(style, value);
    }
  }
}
function patchDangerInnerHTML(lastValue, nextValue, lastVNode, dom) {
  var lastHtml = lastValue && lastValue.__html || "";
  var nextHtml = nextValue && nextValue.__html || "";
  if (lastHtml !== nextHtml) {
    if (!isNullOrUndef(nextHtml) && !isSameInnerHTML(dom, nextHtml)) {
      if (!isNull(lastVNode)) {
        if (lastVNode.childFlags & 12) {
          unmountAllChildren(lastVNode.children);
        } else if (lastVNode.childFlags === 2) {
          unmount(lastVNode.children);
        }
        lastVNode.children = null;
        lastVNode.childFlags = 1;
      }
      dom.innerHTML = nextHtml;
    }
  }
}
function patchProp(prop, lastValue, nextValue, dom, isSVG, hasControlledValue, lastVNode) {
  switch (prop) {
    case "children":
    case "childrenType":
    case "className":
    case "defaultValue":
    case "key":
    case "multiple":
    case "ref":
    case "selectedIndex":
      break;
    case "autoFocus":
      dom.autofocus = !!nextValue;
      break;
    case "allowfullscreen":
    case "autoplay":
    case "capture":
    case "checked":
    case "controls":
    case "default":
    case "disabled":
    case "hidden":
    case "indeterminate":
    case "loop":
    case "muted":
    case "novalidate":
    case "open":
    case "readOnly":
    case "required":
    case "reversed":
    case "scoped":
    case "seamless":
    case "selected":
      dom[prop] = !!nextValue;
      break;
    case "defaultChecked":
    case "value":
    case "volume":
      if (hasControlledValue && prop === "value") {
        break;
      }
      var value = isNullOrUndef(nextValue) ? "" : nextValue;
      if (dom[prop] !== value) {
        dom[prop] = value;
      }
      break;
    case "style":
      patchStyle(lastValue, nextValue, dom);
      break;
    case "dangerouslySetInnerHTML":
      patchDangerInnerHTML(lastValue, nextValue, lastVNode, dom);
      break;
    default:
      if (syntheticEvents[prop]) {
        handleSyntheticEvent(prop, lastValue, nextValue, dom);
      } else if (prop.charCodeAt(0) === 111 && prop.charCodeAt(1) === 110) {
        patchEvent(prop, lastValue, nextValue, dom);
      } else if (isNullOrUndef(nextValue)) {
        dom.removeAttribute(prop);
      } else if (isSVG && namespaces[prop]) {
        dom.setAttributeNS(namespaces[prop], prop, nextValue);
      } else {
        dom.setAttribute(prop, nextValue);
      }
      break;
  }
}
function mountProps(vNode, flags, props, dom, isSVG) {
  var hasControlledValue = false;
  var isFormElement = (flags & 448) > 0;
  if (isFormElement) {
    hasControlledValue = isControlledFormElement(props);
    if (hasControlledValue) {
      addFormElementEventHandlers(flags, dom, props);
    }
  }
  for (var prop in props) {
    patchProp(prop, null, props[prop], dom, isSVG, hasControlledValue, null);
  }
  if (isFormElement) {
    processElement(flags, vNode, dom, props, true, hasControlledValue);
  }
}
function renderNewInput(instance, props, context) {
  var nextInput = normalizeRoot(instance.render(props, instance.state, context));
  var childContext = context;
  if (isFunction2(instance.getChildContext)) {
    childContext = combineFrom(context, instance.getChildContext());
  }
  instance.$CX = childContext;
  return nextInput;
}
function createClassComponentInstance(vNode, Component3, props, context, isSVG, lifecycle) {
  var instance = new Component3(props, context);
  var usesNewAPI = instance.$N = Boolean(Component3.getDerivedStateFromProps || instance.getSnapshotBeforeUpdate);
  instance.$SVG = isSVG;
  instance.$L = lifecycle;
  vNode.children = instance;
  instance.$BS = false;
  instance.context = context;
  if (instance.props === EMPTY_OBJ) {
    instance.props = props;
  }
  if (!usesNewAPI) {
    if (isFunction2(instance.componentWillMount)) {
      instance.$BR = true;
      instance.componentWillMount();
      var pending = instance.$PS;
      if (!isNull(pending)) {
        var state = instance.state;
        if (isNull(state)) {
          instance.state = pending;
        } else {
          for (var key in pending) {
            state[key] = pending[key];
          }
        }
        instance.$PS = null;
      }
      instance.$BR = false;
    }
  } else {
    instance.state = createDerivedState(instance, props, instance.state);
  }
  instance.$LI = renderNewInput(instance, props, context);
  return instance;
}
function renderFunctionalComponent(vNode, context) {
  var props = vNode.props || EMPTY_OBJ;
  return vNode.flags & 32768 ? vNode.type.render(props, vNode.ref, context) : vNode.type(props, context);
}
function mount(vNode, parentDOM, context, isSVG, nextNode, lifecycle) {
  var flags = vNode.flags |= 16384;
  if (flags & 481) {
    mountElement(vNode, parentDOM, context, isSVG, nextNode, lifecycle);
  } else if (flags & 4) {
    mountClassComponent(vNode, parentDOM, context, isSVG, nextNode, lifecycle);
  } else if (flags & 8) {
    mountFunctionalComponent(vNode, parentDOM, context, isSVG, nextNode, lifecycle);
    mountFunctionalComponentCallbacks(vNode, lifecycle);
  } else if (flags & 512 || flags & 16) {
    mountText(vNode, parentDOM, nextNode);
  } else if (flags & 8192) {
    mountFragment(vNode, context, parentDOM, isSVG, nextNode, lifecycle);
  } else if (flags & 1024) {
    mountPortal(vNode, context, parentDOM, nextNode, lifecycle);
  } else ;
}
function mountPortal(vNode, context, parentDOM, nextNode, lifecycle) {
  mount(vNode.children, vNode.ref, context, false, null, lifecycle);
  var placeHolderVNode = createVoidVNode();
  mountText(placeHolderVNode, parentDOM, nextNode);
  vNode.dom = placeHolderVNode.dom;
}
function mountFragment(vNode, context, parentDOM, isSVG, nextNode, lifecycle) {
  var children = vNode.children;
  var childFlags = vNode.childFlags;
  if (childFlags & 12 && children.length === 0) {
    childFlags = vNode.childFlags = 2;
    children = vNode.children = createVoidVNode();
  }
  if (childFlags === 2) {
    mount(children, parentDOM, context, isSVG, nextNode, lifecycle);
  } else {
    mountArrayChildren(children, parentDOM, context, isSVG, nextNode, lifecycle);
  }
}
function mountText(vNode, parentDOM, nextNode) {
  var dom = vNode.dom = document.createTextNode(vNode.children);
  if (!isNull(parentDOM)) {
    insertOrAppend(parentDOM, dom, nextNode);
  }
}
function mountElement(vNode, parentDOM, context, isSVG, nextNode, lifecycle) {
  var flags = vNode.flags;
  var props = vNode.props;
  var className = vNode.className;
  var childFlags = vNode.childFlags;
  var dom = vNode.dom = documentCreateElement(vNode.type, isSVG = isSVG || (flags & 32) > 0);
  var children = vNode.children;
  if (!isNullOrUndef(className) && className !== "") {
    if (isSVG) {
      dom.setAttribute("class", className);
    } else {
      dom.className = className;
    }
  }
  if (childFlags === 16) {
    setTextContent(dom, children);
  } else if (childFlags !== 1) {
    var childrenIsSVG = isSVG && vNode.type !== "foreignObject";
    if (childFlags === 2) {
      if (children.flags & 16384) {
        vNode.children = children = directClone(children);
      }
      mount(children, dom, context, childrenIsSVG, null, lifecycle);
    } else if (childFlags === 8 || childFlags === 4) {
      mountArrayChildren(children, dom, context, childrenIsSVG, null, lifecycle);
    }
  }
  if (!isNull(parentDOM)) {
    insertOrAppend(parentDOM, dom, nextNode);
  }
  if (!isNull(props)) {
    mountProps(vNode, flags, props, dom, isSVG);
  }
  mountRef(vNode.ref, dom, lifecycle);
}
function mountArrayChildren(children, dom, context, isSVG, nextNode, lifecycle) {
  for (var i = 0; i < children.length; ++i) {
    var child = children[i];
    if (child.flags & 16384) {
      children[i] = child = directClone(child);
    }
    mount(child, dom, context, isSVG, nextNode, lifecycle);
  }
}
function mountClassComponent(vNode, parentDOM, context, isSVG, nextNode, lifecycle) {
  var instance = createClassComponentInstance(vNode, vNode.type, vNode.props || EMPTY_OBJ, context, isSVG, lifecycle);
  mount(instance.$LI, parentDOM, instance.$CX, isSVG, nextNode, lifecycle);
  mountClassComponentCallbacks(vNode.ref, instance, lifecycle);
}
function mountFunctionalComponent(vNode, parentDOM, context, isSVG, nextNode, lifecycle) {
  mount(vNode.children = normalizeRoot(renderFunctionalComponent(vNode, context)), parentDOM, context, isSVG, nextNode, lifecycle);
}
function createClassMountCallback(instance) {
  return function() {
    instance.componentDidMount();
  };
}
function mountClassComponentCallbacks(ref, instance, lifecycle) {
  mountRef(ref, instance, lifecycle);
  if (isFunction2(instance.componentDidMount)) {
    lifecycle.push(createClassMountCallback(instance));
  }
}
function createOnMountCallback(ref, vNode) {
  return function() {
    ref.onComponentDidMount(findDOMfromVNode(vNode, true), vNode.props || EMPTY_OBJ);
  };
}
function mountFunctionalComponentCallbacks(vNode, lifecycle) {
  var ref = vNode.ref;
  if (!isNullOrUndef(ref)) {
    safeCall1(ref.onComponentWillMount, vNode.props || EMPTY_OBJ);
    if (isFunction2(ref.onComponentDidMount)) {
      lifecycle.push(createOnMountCallback(ref, vNode));
    }
  }
}
function replaceWithNewNode(lastVNode, nextVNode, parentDOM, context, isSVG, lifecycle) {
  unmount(lastVNode);
  if ((nextVNode.flags & lastVNode.flags & 2033) !== 0) {
    mount(nextVNode, null, context, isSVG, null, lifecycle);
    replaceChild(parentDOM, nextVNode.dom, lastVNode.dom);
  } else {
    mount(nextVNode, parentDOM, context, isSVG, findDOMfromVNode(lastVNode, true), lifecycle);
    removeVNodeDOM(lastVNode, parentDOM);
  }
}
function patch(lastVNode, nextVNode, parentDOM, context, isSVG, nextNode, lifecycle) {
  var nextFlags = nextVNode.flags |= 16384;
  if (lastVNode.flags !== nextFlags || lastVNode.type !== nextVNode.type || lastVNode.key !== nextVNode.key || nextFlags & 2048) {
    if (lastVNode.flags & 16384) {
      replaceWithNewNode(lastVNode, nextVNode, parentDOM, context, isSVG, lifecycle);
    } else {
      mount(nextVNode, parentDOM, context, isSVG, nextNode, lifecycle);
    }
  } else if (nextFlags & 481) {
    patchElement(lastVNode, nextVNode, context, isSVG, nextFlags, lifecycle);
  } else if (nextFlags & 4) {
    patchClassComponent(lastVNode, nextVNode, parentDOM, context, isSVG, nextNode, lifecycle);
  } else if (nextFlags & 8) {
    patchFunctionalComponent(lastVNode, nextVNode, parentDOM, context, isSVG, nextNode, lifecycle);
  } else if (nextFlags & 16) {
    patchText(lastVNode, nextVNode);
  } else if (nextFlags & 512) {
    nextVNode.dom = lastVNode.dom;
  } else if (nextFlags & 8192) {
    patchFragment(lastVNode, nextVNode, parentDOM, context, isSVG, lifecycle);
  } else {
    patchPortal(lastVNode, nextVNode, context, lifecycle);
  }
}
function patchSingleTextChild(lastChildren, nextChildren, parentDOM) {
  if (lastChildren !== nextChildren) {
    if (lastChildren !== "") {
      parentDOM.firstChild.nodeValue = nextChildren;
    } else {
      setTextContent(parentDOM, nextChildren);
    }
  }
}
function patchContentEditableChildren(dom, nextChildren) {
  if (dom.textContent !== nextChildren) {
    dom.textContent = nextChildren;
  }
}
function patchFragment(lastVNode, nextVNode, parentDOM, context, isSVG, lifecycle) {
  var lastChildren = lastVNode.children;
  var nextChildren = nextVNode.children;
  var lastChildFlags = lastVNode.childFlags;
  var nextChildFlags = nextVNode.childFlags;
  var nextNode = null;
  if (nextChildFlags & 12 && nextChildren.length === 0) {
    nextChildFlags = nextVNode.childFlags = 2;
    nextChildren = nextVNode.children = createVoidVNode();
  }
  var nextIsSingle = (nextChildFlags & 2) !== 0;
  if (lastChildFlags & 12) {
    var lastLen = lastChildren.length;
    if (
      // It uses keyed algorithm
      lastChildFlags & 8 && nextChildFlags & 8 || // It transforms from many to single
      nextIsSingle || // It will append more nodes
      !nextIsSingle && nextChildren.length > lastLen
    ) {
      nextNode = findDOMfromVNode(lastChildren[lastLen - 1], false).nextSibling;
    }
  }
  patchChildren(lastChildFlags, nextChildFlags, lastChildren, nextChildren, parentDOM, context, isSVG, nextNode, lastVNode, lifecycle);
}
function patchPortal(lastVNode, nextVNode, context, lifecycle) {
  var lastContainer = lastVNode.ref;
  var nextContainer = nextVNode.ref;
  var nextChildren = nextVNode.children;
  patchChildren(lastVNode.childFlags, nextVNode.childFlags, lastVNode.children, nextChildren, lastContainer, context, false, null, lastVNode, lifecycle);
  nextVNode.dom = lastVNode.dom;
  if (lastContainer !== nextContainer && !isInvalid(nextChildren)) {
    var node = nextChildren.dom;
    removeChild(lastContainer, node);
    appendChild(nextContainer, node);
  }
}
function patchElement(lastVNode, nextVNode, context, isSVG, nextFlags, lifecycle) {
  var dom = nextVNode.dom = lastVNode.dom;
  var lastProps = lastVNode.props;
  var nextProps = nextVNode.props;
  var isFormElement = false;
  var hasControlledValue = false;
  var nextPropsOrEmpty;
  isSVG = isSVG || (nextFlags & 32) > 0;
  if (lastProps !== nextProps) {
    var lastPropsOrEmpty = lastProps || EMPTY_OBJ;
    nextPropsOrEmpty = nextProps || EMPTY_OBJ;
    if (nextPropsOrEmpty !== EMPTY_OBJ) {
      isFormElement = (nextFlags & 448) > 0;
      if (isFormElement) {
        hasControlledValue = isControlledFormElement(nextPropsOrEmpty);
      }
      for (var prop in nextPropsOrEmpty) {
        var lastValue = lastPropsOrEmpty[prop];
        var nextValue = nextPropsOrEmpty[prop];
        if (lastValue !== nextValue) {
          patchProp(prop, lastValue, nextValue, dom, isSVG, hasControlledValue, lastVNode);
        }
      }
    }
    if (lastPropsOrEmpty !== EMPTY_OBJ) {
      for (var prop$1 in lastPropsOrEmpty) {
        if (isNullOrUndef(nextPropsOrEmpty[prop$1]) && !isNullOrUndef(lastPropsOrEmpty[prop$1])) {
          patchProp(prop$1, lastPropsOrEmpty[prop$1], null, dom, isSVG, hasControlledValue, lastVNode);
        }
      }
    }
  }
  var nextChildren = nextVNode.children;
  var nextClassName = nextVNode.className;
  if (lastVNode.className !== nextClassName) {
    if (isNullOrUndef(nextClassName)) {
      dom.removeAttribute("class");
    } else if (isSVG) {
      dom.setAttribute("class", nextClassName);
    } else {
      dom.className = nextClassName;
    }
  }
  if (nextFlags & 4096) {
    patchContentEditableChildren(dom, nextChildren);
  } else {
    patchChildren(lastVNode.childFlags, nextVNode.childFlags, lastVNode.children, nextChildren, dom, context, isSVG && nextVNode.type !== "foreignObject", null, lastVNode, lifecycle);
  }
  if (isFormElement) {
    processElement(nextFlags, nextVNode, dom, nextPropsOrEmpty, false, hasControlledValue);
  }
  var nextRef = nextVNode.ref;
  var lastRef = lastVNode.ref;
  if (lastRef !== nextRef) {
    unmountRef(lastRef);
    mountRef(nextRef, dom, lifecycle);
  }
}
function replaceOneVNodeWithMultipleVNodes(lastChildren, nextChildren, parentDOM, context, isSVG, lifecycle) {
  unmount(lastChildren);
  mountArrayChildren(nextChildren, parentDOM, context, isSVG, findDOMfromVNode(lastChildren, true), lifecycle);
  removeVNodeDOM(lastChildren, parentDOM);
}
function patchChildren(lastChildFlags, nextChildFlags, lastChildren, nextChildren, parentDOM, context, isSVG, nextNode, parentVNode, lifecycle) {
  switch (lastChildFlags) {
    case 2:
      switch (nextChildFlags) {
        case 2:
          patch(lastChildren, nextChildren, parentDOM, context, isSVG, nextNode, lifecycle);
          break;
        case 1:
          remove2(lastChildren, parentDOM);
          break;
        case 16:
          unmount(lastChildren);
          setTextContent(parentDOM, nextChildren);
          break;
        default:
          replaceOneVNodeWithMultipleVNodes(lastChildren, nextChildren, parentDOM, context, isSVG, lifecycle);
          break;
      }
      break;
    case 1:
      switch (nextChildFlags) {
        case 2:
          mount(nextChildren, parentDOM, context, isSVG, nextNode, lifecycle);
          break;
        case 1:
          break;
        case 16:
          setTextContent(parentDOM, nextChildren);
          break;
        default:
          mountArrayChildren(nextChildren, parentDOM, context, isSVG, nextNode, lifecycle);
          break;
      }
      break;
    case 16:
      switch (nextChildFlags) {
        case 16:
          patchSingleTextChild(lastChildren, nextChildren, parentDOM);
          break;
        case 2:
          clearDOM(parentDOM);
          mount(nextChildren, parentDOM, context, isSVG, nextNode, lifecycle);
          break;
        case 1:
          clearDOM(parentDOM);
          break;
        default:
          clearDOM(parentDOM);
          mountArrayChildren(nextChildren, parentDOM, context, isSVG, nextNode, lifecycle);
          break;
      }
      break;
    default:
      switch (nextChildFlags) {
        case 16:
          unmountAllChildren(lastChildren);
          setTextContent(parentDOM, nextChildren);
          break;
        case 2:
          removeAllChildren(parentDOM, parentVNode, lastChildren);
          mount(nextChildren, parentDOM, context, isSVG, nextNode, lifecycle);
          break;
        case 1:
          removeAllChildren(parentDOM, parentVNode, lastChildren);
          break;
        default:
          var lastLength = lastChildren.length | 0;
          var nextLength = nextChildren.length | 0;
          if (lastLength === 0) {
            if (nextLength > 0) {
              mountArrayChildren(nextChildren, parentDOM, context, isSVG, nextNode, lifecycle);
            }
          } else if (nextLength === 0) {
            removeAllChildren(parentDOM, parentVNode, lastChildren);
          } else if (nextChildFlags === 8 && lastChildFlags === 8) {
            patchKeyedChildren(lastChildren, nextChildren, parentDOM, context, isSVG, lastLength, nextLength, nextNode, parentVNode, lifecycle);
          } else {
            patchNonKeyedChildren(lastChildren, nextChildren, parentDOM, context, isSVG, lastLength, nextLength, nextNode, lifecycle);
          }
          break;
      }
      break;
  }
}
function createDidUpdate(instance, lastProps, lastState, snapshot, lifecycle) {
  lifecycle.push(function() {
    instance.componentDidUpdate(lastProps, lastState, snapshot);
  });
}
function updateClassComponent(instance, nextState, nextProps, parentDOM, context, isSVG, force, nextNode, lifecycle) {
  var lastState = instance.state;
  var lastProps = instance.props;
  var usesNewAPI = Boolean(instance.$N);
  var hasSCU = isFunction2(instance.shouldComponentUpdate);
  if (usesNewAPI) {
    nextState = createDerivedState(instance, nextProps, nextState !== lastState ? combineFrom(lastState, nextState) : nextState);
  }
  if (force || !hasSCU || hasSCU && instance.shouldComponentUpdate(nextProps, nextState, context)) {
    if (!usesNewAPI && isFunction2(instance.componentWillUpdate)) {
      instance.componentWillUpdate(nextProps, nextState, context);
    }
    instance.props = nextProps;
    instance.state = nextState;
    instance.context = context;
    var snapshot = null;
    var nextInput = renderNewInput(instance, nextProps, context);
    if (usesNewAPI && isFunction2(instance.getSnapshotBeforeUpdate)) {
      snapshot = instance.getSnapshotBeforeUpdate(lastProps, lastState);
    }
    patch(instance.$LI, nextInput, parentDOM, instance.$CX, isSVG, nextNode, lifecycle);
    instance.$LI = nextInput;
    if (isFunction2(instance.componentDidUpdate)) {
      createDidUpdate(instance, lastProps, lastState, snapshot, lifecycle);
    }
  } else {
    instance.props = nextProps;
    instance.state = nextState;
    instance.context = context;
  }
}
function patchClassComponent(lastVNode, nextVNode, parentDOM, context, isSVG, nextNode, lifecycle) {
  var instance = nextVNode.children = lastVNode.children;
  if (isNull(instance)) {
    return;
  }
  instance.$L = lifecycle;
  var nextProps = nextVNode.props || EMPTY_OBJ;
  var nextRef = nextVNode.ref;
  var lastRef = lastVNode.ref;
  var nextState = instance.state;
  if (!instance.$N) {
    if (isFunction2(instance.componentWillReceiveProps)) {
      instance.$BR = true;
      instance.componentWillReceiveProps(nextProps, context);
      if (instance.$UN) {
        return;
      }
      instance.$BR = false;
    }
    if (!isNull(instance.$PS)) {
      nextState = combineFrom(nextState, instance.$PS);
      instance.$PS = null;
    }
  }
  updateClassComponent(instance, nextState, nextProps, parentDOM, context, isSVG, false, nextNode, lifecycle);
  if (lastRef !== nextRef) {
    unmountRef(lastRef);
    mountRef(nextRef, instance, lifecycle);
  }
}
function patchFunctionalComponent(lastVNode, nextVNode, parentDOM, context, isSVG, nextNode, lifecycle) {
  var shouldUpdate = true;
  var nextProps = nextVNode.props || EMPTY_OBJ;
  var nextRef = nextVNode.ref;
  var lastProps = lastVNode.props;
  var nextHooksDefined = !isNullOrUndef(nextRef);
  var lastInput = lastVNode.children;
  if (nextHooksDefined && isFunction2(nextRef.onComponentShouldUpdate)) {
    shouldUpdate = nextRef.onComponentShouldUpdate(lastProps, nextProps);
  }
  if (shouldUpdate !== false) {
    if (nextHooksDefined && isFunction2(nextRef.onComponentWillUpdate)) {
      nextRef.onComponentWillUpdate(lastProps, nextProps);
    }
    var nextInput = normalizeRoot(renderFunctionalComponent(nextVNode, context));
    patch(lastInput, nextInput, parentDOM, context, isSVG, nextNode, lifecycle);
    nextVNode.children = nextInput;
    if (nextHooksDefined && isFunction2(nextRef.onComponentDidUpdate)) {
      nextRef.onComponentDidUpdate(lastProps, nextProps);
    }
  } else {
    nextVNode.children = lastInput;
  }
}
function patchText(lastVNode, nextVNode) {
  var nextText = nextVNode.children;
  var dom = nextVNode.dom = lastVNode.dom;
  if (nextText !== lastVNode.children) {
    dom.nodeValue = nextText;
  }
}
function patchNonKeyedChildren(lastChildren, nextChildren, dom, context, isSVG, lastChildrenLength, nextChildrenLength, nextNode, lifecycle) {
  var commonLength = lastChildrenLength > nextChildrenLength ? nextChildrenLength : lastChildrenLength;
  var i = 0;
  var nextChild;
  var lastChild;
  for (; i < commonLength; ++i) {
    nextChild = nextChildren[i];
    lastChild = lastChildren[i];
    if (nextChild.flags & 16384) {
      nextChild = nextChildren[i] = directClone(nextChild);
    }
    patch(lastChild, nextChild, dom, context, isSVG, nextNode, lifecycle);
    lastChildren[i] = nextChild;
  }
  if (lastChildrenLength < nextChildrenLength) {
    for (i = commonLength; i < nextChildrenLength; ++i) {
      nextChild = nextChildren[i];
      if (nextChild.flags & 16384) {
        nextChild = nextChildren[i] = directClone(nextChild);
      }
      mount(nextChild, dom, context, isSVG, nextNode, lifecycle);
    }
  } else if (lastChildrenLength > nextChildrenLength) {
    for (i = commonLength; i < lastChildrenLength; ++i) {
      remove2(lastChildren[i], dom);
    }
  }
}
function patchKeyedChildren(a, b, dom, context, isSVG, aLength, bLength, outerEdge, parentVNode, lifecycle) {
  var aEnd = aLength - 1;
  var bEnd = bLength - 1;
  var j = 0;
  var aNode = a[j];
  var bNode = b[j];
  var nextPos;
  var nextNode;
  outer: {
    while (aNode.key === bNode.key) {
      if (bNode.flags & 16384) {
        b[j] = bNode = directClone(bNode);
      }
      patch(aNode, bNode, dom, context, isSVG, outerEdge, lifecycle);
      a[j] = bNode;
      ++j;
      if (j > aEnd || j > bEnd) {
        break outer;
      }
      aNode = a[j];
      bNode = b[j];
    }
    aNode = a[aEnd];
    bNode = b[bEnd];
    while (aNode.key === bNode.key) {
      if (bNode.flags & 16384) {
        b[bEnd] = bNode = directClone(bNode);
      }
      patch(aNode, bNode, dom, context, isSVG, outerEdge, lifecycle);
      a[aEnd] = bNode;
      aEnd--;
      bEnd--;
      if (j > aEnd || j > bEnd) {
        break outer;
      }
      aNode = a[aEnd];
      bNode = b[bEnd];
    }
  }
  if (j > aEnd) {
    if (j <= bEnd) {
      nextPos = bEnd + 1;
      nextNode = nextPos < bLength ? findDOMfromVNode(b[nextPos], true) : outerEdge;
      while (j <= bEnd) {
        bNode = b[j];
        if (bNode.flags & 16384) {
          b[j] = bNode = directClone(bNode);
        }
        ++j;
        mount(bNode, dom, context, isSVG, nextNode, lifecycle);
      }
    }
  } else if (j > bEnd) {
    while (j <= aEnd) {
      remove2(a[j++], dom);
    }
  } else {
    patchKeyedChildrenComplex(a, b, context, aLength, bLength, aEnd, bEnd, j, dom, isSVG, outerEdge, parentVNode, lifecycle);
  }
}
function patchKeyedChildrenComplex(a, b, context, aLength, bLength, aEnd, bEnd, j, dom, isSVG, outerEdge, parentVNode, lifecycle) {
  var aNode;
  var bNode;
  var nextPos;
  var i = 0;
  var aStart = j;
  var bStart = j;
  var aLeft = aEnd - j + 1;
  var bLeft = bEnd - j + 1;
  var sources = new Int32Array(bLeft + 1);
  var canRemoveWholeContent = aLeft === aLength;
  var moved = false;
  var pos = 0;
  var patched = 0;
  if (bLength < 4 || (aLeft | bLeft) < 32) {
    for (i = aStart; i <= aEnd; ++i) {
      aNode = a[i];
      if (patched < bLeft) {
        for (j = bStart; j <= bEnd; j++) {
          bNode = b[j];
          if (aNode.key === bNode.key) {
            sources[j - bStart] = i + 1;
            if (canRemoveWholeContent) {
              canRemoveWholeContent = false;
              while (aStart < i) {
                remove2(a[aStart++], dom);
              }
            }
            if (pos > j) {
              moved = true;
            } else {
              pos = j;
            }
            if (bNode.flags & 16384) {
              b[j] = bNode = directClone(bNode);
            }
            patch(aNode, bNode, dom, context, isSVG, outerEdge, lifecycle);
            ++patched;
            break;
          }
        }
        if (!canRemoveWholeContent && j > bEnd) {
          remove2(aNode, dom);
        }
      } else if (!canRemoveWholeContent) {
        remove2(aNode, dom);
      }
    }
  } else {
    var keyIndex = {};
    for (i = bStart; i <= bEnd; ++i) {
      keyIndex[b[i].key] = i;
    }
    for (i = aStart; i <= aEnd; ++i) {
      aNode = a[i];
      if (patched < bLeft) {
        j = keyIndex[aNode.key];
        if (j !== void 0) {
          if (canRemoveWholeContent) {
            canRemoveWholeContent = false;
            while (i > aStart) {
              remove2(a[aStart++], dom);
            }
          }
          sources[j - bStart] = i + 1;
          if (pos > j) {
            moved = true;
          } else {
            pos = j;
          }
          bNode = b[j];
          if (bNode.flags & 16384) {
            b[j] = bNode = directClone(bNode);
          }
          patch(aNode, bNode, dom, context, isSVG, outerEdge, lifecycle);
          ++patched;
        } else if (!canRemoveWholeContent) {
          remove2(aNode, dom);
        }
      } else if (!canRemoveWholeContent) {
        remove2(aNode, dom);
      }
    }
  }
  if (canRemoveWholeContent) {
    removeAllChildren(dom, parentVNode, a);
    mountArrayChildren(b, dom, context, isSVG, outerEdge, lifecycle);
  } else if (moved) {
    var seq = lis_algorithm(sources);
    j = seq.length - 1;
    for (i = bLeft - 1; i >= 0; i--) {
      if (sources[i] === 0) {
        pos = i + bStart;
        bNode = b[pos];
        if (bNode.flags & 16384) {
          b[pos] = bNode = directClone(bNode);
        }
        nextPos = pos + 1;
        mount(bNode, dom, context, isSVG, nextPos < bLength ? findDOMfromVNode(b[nextPos], true) : outerEdge, lifecycle);
      } else if (j < 0 || i !== seq[j]) {
        pos = i + bStart;
        bNode = b[pos];
        nextPos = pos + 1;
        moveVNodeDOM(bNode, dom, nextPos < bLength ? findDOMfromVNode(b[nextPos], true) : outerEdge);
      } else {
        j--;
      }
    }
  } else if (patched !== bLeft) {
    for (i = bLeft - 1; i >= 0; i--) {
      if (sources[i] === 0) {
        pos = i + bStart;
        bNode = b[pos];
        if (bNode.flags & 16384) {
          b[pos] = bNode = directClone(bNode);
        }
        nextPos = pos + 1;
        mount(bNode, dom, context, isSVG, nextPos < bLength ? findDOMfromVNode(b[nextPos], true) : outerEdge, lifecycle);
      }
    }
  }
}
var result;
var p;
var maxLen = 0;
function lis_algorithm(arr) {
  var arrI = 0;
  var i = 0;
  var j = 0;
  var k = 0;
  var u = 0;
  var v = 0;
  var c = 0;
  var len = arr.length;
  if (len > maxLen) {
    maxLen = len;
    result = new Int32Array(len);
    p = new Int32Array(len);
  }
  for (; i < len; ++i) {
    arrI = arr[i];
    if (arrI !== 0) {
      j = result[k];
      if (arr[j] < arrI) {
        p[i] = j;
        result[++k] = i;
        continue;
      }
      u = 0;
      v = k;
      while (u < v) {
        c = u + v >> 1;
        if (arr[result[c]] < arrI) {
          u = c + 1;
        } else {
          v = c;
        }
      }
      if (arrI < arr[result[u]]) {
        if (u > 0) {
          p[i] = result[u - 1];
        }
        result[u] = i;
      }
    }
  }
  u = k + 1;
  var seq = new Int32Array(u);
  v = result[u - 1];
  while (u-- > 0) {
    seq[u] = v;
    v = p[v];
    result[u] = 0;
  }
  return seq;
}
var hasDocumentAvailable = typeof document !== "undefined";
if (hasDocumentAvailable) {
  if (window.Node) {
    Node.prototype.$EV = null;
    Node.prototype.$V = null;
  }
}
function __render(input, parentDOM, callback, context) {
  var lifecycle = [];
  var rootInput = parentDOM.$V;
  renderCheck.v = true;
  if (isNullOrUndef(rootInput)) {
    if (!isNullOrUndef(input)) {
      if (input.flags & 16384) {
        input = directClone(input);
      }
      mount(input, parentDOM, context, false, null, lifecycle);
      parentDOM.$V = input;
      rootInput = input;
    }
  } else {
    if (isNullOrUndef(input)) {
      remove2(rootInput, parentDOM);
      parentDOM.$V = null;
    } else {
      if (input.flags & 16384) {
        input = directClone(input);
      }
      patch(rootInput, input, parentDOM, context, false, null, lifecycle);
      rootInput = parentDOM.$V = input;
    }
  }
  callAll(lifecycle);
  renderCheck.v = false;
  if (isFunction2(callback)) {
    callback();
  }
  if (isFunction2(options.renderComplete)) {
    options.renderComplete(rootInput, parentDOM);
  }
}
function render(input, parentDOM, callback, context) {
  if (callback === void 0) callback = null;
  if (context === void 0) context = EMPTY_OBJ;
  __render(input, parentDOM, callback, context);
}
var QUEUE = [];
var nextTick = typeof Promise !== "undefined" ? Promise.resolve().then.bind(Promise.resolve()) : function(a) {
  window.setTimeout(a, 0);
};
var microTaskPending = false;
function queueStateChanges(component, newState, callback, force) {
  var pending = component.$PS;
  if (isFunction2(newState)) {
    newState = newState(pending ? combineFrom(component.state, pending) : component.state, component.props, component.context);
  }
  if (isNullOrUndef(pending)) {
    component.$PS = newState;
  } else {
    for (var stateKey in newState) {
      pending[stateKey] = newState[stateKey];
    }
  }
  if (!component.$BR) {
    if (!renderCheck.v) {
      if (QUEUE.length === 0) {
        applyState(component, force);
        if (isFunction2(callback)) {
          callback.call(component);
        }
        return;
      }
    }
    if (QUEUE.indexOf(component) === -1) {
      QUEUE.push(component);
    }
    if (force) {
      component.$F = true;
    }
    if (!microTaskPending) {
      microTaskPending = true;
      nextTick(rerender);
    }
    if (isFunction2(callback)) {
      var QU = component.$QU;
      if (!QU) {
        QU = component.$QU = [];
      }
      QU.push(callback);
    }
  } else if (isFunction2(callback)) {
    component.$L.push(callback.bind(component));
  }
}
function callSetStateCallbacks(component) {
  var queue = component.$QU;
  for (var i = 0; i < queue.length; ++i) {
    queue[i].call(component);
  }
  component.$QU = null;
}
function rerender() {
  var component;
  microTaskPending = false;
  while (component = QUEUE.shift()) {
    if (!component.$UN) {
      var force = component.$F;
      component.$F = false;
      applyState(component, force);
      if (component.$QU) {
        callSetStateCallbacks(component);
      }
    }
  }
}
function applyState(component, force) {
  if (force || !component.$BR) {
    var pendingState = component.$PS;
    component.$PS = null;
    var lifecycle = [];
    renderCheck.v = true;
    updateClassComponent(component, combineFrom(component.state, pendingState), component.props, findDOMfromVNode(component.$LI, true).parentNode, component.context, component.$SVG, force, null, lifecycle);
    callAll(lifecycle);
    renderCheck.v = false;
  } else {
    component.state = component.$PS;
    component.$PS = null;
  }
}
var Component = function Component2(props, context) {
  this.state = null;
  this.$BR = false;
  this.$BS = true;
  this.$PS = null;
  this.$LI = null;
  this.$UN = false;
  this.$CX = null;
  this.$QU = null;
  this.$N = false;
  this.$L = null;
  this.$SVG = false;
  this.$F = false;
  this.props = props || EMPTY_OBJ;
  this.context = context || EMPTY_OBJ;
};
Component.prototype.forceUpdate = function forceUpdate(callback) {
  if (this.$UN) {
    return;
  }
  queueStateChanges(this, {}, callback, true);
};
Component.prototype.setState = function setState(newState, callback) {
  if (this.$UN) {
    return;
  }
  if (!this.$BS) {
    queueStateChanges(this, newState, callback, false);
  }
};
Component.prototype.render = function render2(_nextProps, _nextState, _nextContext) {
  return null;
};

// node_modules/inferno/index.esm.js
if (true) {
  console.warn("You are running production build of Inferno in development mode. Use dev:module entry point.");
}

// node_modules/@devextreme/runtime/esm/inferno/effect_host.js
var InfernoEffectHost = {
  lockCount: 0,
  lock() {
    this.lockCount++;
  },
  callbacks: [],
  callEffects() {
    this.lockCount--;
    if (this.lockCount < 0) {
      throw new Error("Unexpected Effect Call");
    }
    if (this.lockCount === 0) {
      const effects = this.callbacks;
      this.callbacks = [];
      effects.forEach((callback) => callback());
    }
  }
};

// node_modules/@devextreme/runtime/esm/inferno/base_component.js
var areObjectsEqual = (firstObject, secondObject) => {
  const bothAreObjects = firstObject instanceof Object && secondObject instanceof Object;
  if (!bothAreObjects) {
    return firstObject === secondObject;
  }
  const firstObjectKeys = Object.keys(firstObject);
  const secondObjectKeys = Object.keys(secondObject);
  if (firstObjectKeys.length !== secondObjectKeys.length) {
    return false;
  }
  const hasDifferentElement = firstObjectKeys.some((key) => firstObject[key] !== secondObject[key]);
  return !hasDifferentElement;
};
var BaseInfernoComponent = class extends Component {
  constructor() {
    super(...arguments);
    this._pendingContext = this.context;
  }
  componentWillReceiveProps(_, context) {
    this._pendingContext = context !== null && context !== void 0 ? context : {};
  }
  shouldComponentUpdate(nextProps, nextState) {
    return !areObjectsEqual(this.props, nextProps) || !areObjectsEqual(this.state, nextState) || !areObjectsEqual(this.context, this._pendingContext);
  }
};
var InfernoComponent = class extends BaseInfernoComponent {
  constructor() {
    super(...arguments);
    this._effects = [];
  }
  createEffects() {
    return [];
  }
  updateEffects() {
  }
  componentWillMount() {
    InfernoEffectHost.lock();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  componentWillUpdate(_nextProps, _nextState, _context) {
    InfernoEffectHost.lock();
  }
  componentDidMount() {
    InfernoEffectHost.callbacks.push(() => {
      this._effects = this.createEffects();
    });
    InfernoEffectHost.callEffects();
  }
  componentDidUpdate() {
    InfernoEffectHost.callbacks.push(() => this.updateEffects());
    InfernoEffectHost.callEffects();
  }
  destroyEffects() {
    this._effects.forEach((e) => e.dispose());
  }
  componentWillUnmount() {
    this.destroyEffects();
  }
};
var InfernoWrapperComponent = class extends InfernoComponent {
  constructor() {
    super(...arguments);
    this.vDomElement = null;
  }
  vDomUpdateClasses() {
    const el = this.vDomElement;
    const currentClasses = el.className.length ? el.className.split(" ") : [];
    const addedClasses = currentClasses.filter((className) => el.dxClasses.previous.indexOf(className) < 0);
    const removedClasses = el.dxClasses.previous.filter((className) => currentClasses.indexOf(className) < 0);
    addedClasses.forEach((value) => {
      const indexInRemoved = el.dxClasses.removed.indexOf(value);
      if (indexInRemoved > -1) {
        el.dxClasses.removed.splice(indexInRemoved, 1);
      } else if (!el.dxClasses.added.includes(value)) {
        el.dxClasses.added.push(value);
      }
    });
    removedClasses.forEach((value) => {
      const indexInAdded = el.dxClasses.added.indexOf(value);
      if (indexInAdded > -1) {
        el.dxClasses.added.splice(indexInAdded, 1);
      } else if (!el.dxClasses.removed.includes(value)) {
        el.dxClasses.removed.push(value);
      }
    });
  }
  componentDidMount() {
    const el = findDOMfromVNode(this.$LI, true);
    this.vDomElement = el;
    super.componentDidMount();
    el.dxClasses = el.dxClasses || {
      removed: [],
      added: [],
      previous: []
    };
    el.dxClasses.previous = (el === null || el === void 0 ? void 0 : el.className.length) ? el.className.split(" ") : [];
  }
  componentDidUpdate() {
    super.componentDidUpdate();
    const el = this.vDomElement;
    if (el !== null) {
      el.dxClasses.added.forEach((className) => el.classList.add(className));
      el.dxClasses.removed.forEach((className) => el.classList.remove(className));
      el.dxClasses.previous = el.className.length ? el.className.split(" ") : [];
    }
  }
  shouldComponentUpdate(nextProps, nextState) {
    const shouldUpdate = super.shouldComponentUpdate(nextProps, nextState);
    if (shouldUpdate) {
      this.vDomUpdateClasses();
    }
    return shouldUpdate;
  }
};

// node_modules/@devextreme/runtime/esm/inferno/create_context.js
var contextId = 0;
var createContext = function(defaultValue) {
  const id = contextId++;
  return {
    id,
    defaultValue,
    Provider: class extends Component {
      getChildContext() {
        return Object.assign(Object.assign({}, this.context), {
          [id]: this.props.value || defaultValue
        });
      }
      render() {
        return this.props.children;
      }
    }
  };
};

// node_modules/@devextreme/runtime/esm/inferno/effect.js
var InfernoEffect = class {
  constructor(effect, dependency) {
    this.dependency = dependency;
    this.effect = effect;
    this.destroy = effect();
  }
  update(dependency) {
    const currentDependency = this.dependency;
    if (dependency) {
      this.dependency = dependency;
    }
    if (!dependency || dependency.some((d, i) => currentDependency[i] !== d)) {
      this.dispose();
      this.destroy = this.effect();
    }
  }
  dispose() {
    if (this.destroy) {
      this.destroy();
    }
  }
};

// node_modules/@devextreme/runtime/esm/inferno/re_render_effect.js
var createReRenderEffect = () => new InfernoEffect(() => {
  rerender();
}, []);

// node_modules/@devextreme/runtime/esm/inferno/mocked/shared.js
var ERROR_MSG = "a runtime error occured! Use Inferno in development environment to find the error.";
function isNullOrUndef2(o) {
  return o === void 0 || o === null;
}
function isInvalid2(o) {
  return o === null || o === false || o === true || o === void 0;
}
function isFunction3(o) {
  return typeof o === "function";
}
function isNull2(o) {
  return o === null;
}
function throwError(message) {
  if (!message) {
    message = ERROR_MSG;
  }
  throw new Error(`Inferno Error: ${message}`);
}

// node_modules/@devextreme/runtime/esm/inferno/mocked/hydrate.js
function isSameInnerHTML2(dom, innerHTML) {
  const tempdom = document.createElement("i");
  tempdom.innerHTML = innerHTML;
  return tempdom.innerHTML === dom.innerHTML;
}
function findLastDOMFromVNode(vNode) {
  let flags;
  let children;
  while (vNode) {
    flags = vNode.flags;
    if (flags & 2033) {
      return vNode.dom;
    }
    children = vNode.children;
    if (flags & 8192) {
      vNode = vNode.childFlags === 2 ? children : children[children.length - 1];
    } else if (flags & 4) {
      vNode = children.$LI;
    } else {
      vNode = children;
    }
  }
  return null;
}
function isSamePropsInnerHTML(dom, props) {
  return Boolean(props && props.dangerouslySetInnerHTML && props.dangerouslySetInnerHTML.__html && isSameInnerHTML2(dom, props.dangerouslySetInnerHTML.__html));
}
function hydrateComponent(vNode, parentDOM, dom, context, isSVG, isClass, lifecycle) {
  const type = vNode.type;
  const ref = vNode.ref;
  const props = vNode.props || EMPTY_OBJ;
  let currentNode;
  if (isClass) {
    const instance = createClassComponentInstance(vNode, type, props, context, isSVG, lifecycle);
    const input = instance.$LI;
    currentNode = hydrateVNode(input, parentDOM, dom, instance.$CX, isSVG, lifecycle);
    mountClassComponentCallbacks(ref, instance, lifecycle);
  } else {
    const input = normalizeRoot(renderFunctionalComponent(vNode, context));
    currentNode = hydrateVNode(input, parentDOM, dom, context, isSVG, lifecycle);
    vNode.children = input;
    mountFunctionalComponentCallbacks(vNode, lifecycle);
  }
  return currentNode;
}
function hydrateChildren(parentVNode, parentNode, currentNode, context, isSVG, lifecycle) {
  const childFlags = parentVNode.childFlags;
  const children = parentVNode.children;
  const props = parentVNode.props;
  const flags = parentVNode.flags;
  if (childFlags !== 1) {
    if (childFlags === 2) {
      if (isNull2(currentNode)) {
        mount(children, parentNode, context, isSVG, null, lifecycle);
      } else {
        currentNode = hydrateVNode(children, parentNode, currentNode, context, isSVG, lifecycle);
        currentNode = currentNode ? currentNode.nextSibling : null;
      }
    } else if (childFlags === 16) {
      if (isNull2(currentNode)) {
        parentNode.appendChild(document.createTextNode(children));
      } else if (parentNode.childNodes.length !== 1 || currentNode.nodeType !== 3) {
        parentNode.textContent = children;
      } else if (currentNode.nodeValue !== children) {
        currentNode.nodeValue = children;
      }
      currentNode = null;
    } else if (childFlags & 12) {
      let prevVNodeIsTextNode = false;
      for (let i = 0, len = children.length; i < len; ++i) {
        const child = children[i];
        if (isNull2(currentNode) || prevVNodeIsTextNode && (child.flags & 16) > 0) {
          mount(child, parentNode, context, isSVG, currentNode, lifecycle);
        } else {
          currentNode = hydrateVNode(child, parentNode, currentNode, context, isSVG, lifecycle);
          currentNode = currentNode ? currentNode.nextSibling : null;
        }
        prevVNodeIsTextNode = (child.flags & 16) > 0;
      }
    }
    if ((flags & 8192) === 0) {
      let nextSibling = null;
      while (currentNode) {
        nextSibling = currentNode.nextSibling;
        parentNode.removeChild(currentNode);
        currentNode = nextSibling;
      }
    }
  } else if (!isNull2(parentNode.firstChild) && !isSamePropsInnerHTML(parentNode, props)) {
    parentNode.textContent = "";
    if (flags & 448) {
      parentNode.defaultValue = "";
    }
  }
}
function hydrateElement(vNode, parentDOM, dom, context, isSVG, lifecycle) {
  const props = vNode.props;
  const className = vNode.className;
  const flags = vNode.flags;
  const ref = vNode.ref;
  isSVG = isSVG || (flags & 32) > 0;
  if (dom.nodeType !== 1) {
    mountElement(vNode, null, context, isSVG, null, lifecycle);
    parentDOM.replaceChild(vNode.dom, dom);
  } else {
    vNode.dom = dom;
    hydrateChildren(vNode, dom, dom.firstChild, context, isSVG, lifecycle);
    if (!isNull2(props)) {
      mountProps(vNode, flags, props, dom, isSVG);
    }
    if (isNullOrUndef2(className)) {
      if (dom.className !== "") {
        dom.removeAttribute("class");
      }
    } else if (isSVG) {
      dom.setAttribute("class", className);
    } else {
      dom.className = className;
    }
    mountRef(ref, dom, lifecycle);
  }
  return vNode.dom;
}
function hydrateText(vNode, parentDOM, dom) {
  if (dom.nodeType !== 3) {
    parentDOM.replaceChild(vNode.dom = document.createTextNode(vNode.children), dom);
  } else {
    const text = vNode.children;
    if (dom.nodeValue !== text) {
      dom.nodeValue = text;
    }
    vNode.dom = dom;
  }
  return vNode.dom;
}
function hydrateFragment(vNode, parentDOM, dom, context, isSVG, lifecycle) {
  const children = vNode.children;
  if (vNode.childFlags === 2) {
    hydrateText(children, parentDOM, dom);
    return children.dom;
  }
  hydrateChildren(vNode, parentDOM, dom, context, isSVG, lifecycle);
  return findLastDOMFromVNode(children[children.length - 1]);
}
function hydrateVNode(vNode, parentDOM, currentDom, context, isSVG, lifecycle) {
  const flags = vNode.flags |= 16384;
  if (flags & 14) {
    return hydrateComponent(vNode, parentDOM, currentDom, context, isSVG, (flags & 4) > 0, lifecycle);
  }
  if (flags & 481) {
    return hydrateElement(vNode, parentDOM, currentDom, context, isSVG, lifecycle);
  }
  if (flags & 16) {
    return hydrateText(vNode, parentDOM, currentDom);
  }
  if (flags & 512) {
    return vNode.dom = currentDom;
  }
  if (flags & 8192) {
    return hydrateFragment(vNode, parentDOM, currentDom, context, isSVG, lifecycle);
  }
  throwError();
  return null;
}
function hydrate(input, parentDOM, callback) {
  let dom = parentDOM.firstChild;
  if (isNull2(dom)) {
    render(input, parentDOM, callback);
  } else {
    const lifecycle = [];
    if (!isInvalid2(input)) {
      dom = hydrateVNode(input, parentDOM, dom, {}, false, lifecycle);
    }
    while (dom && (dom = dom.nextSibling)) {
      parentDOM.removeChild(dom);
    }
    if (lifecycle.length > 0) {
      let listener;
      while ((listener = lifecycle.shift()) !== void 0) {
        listener();
      }
    }
  }
  parentDOM.$V = input;
  if (isFunction3(callback)) {
    callback();
  }
}

// node_modules/inferno-create-element/dist/index.esm.js
function isNullOrUndef3(o) {
  return o === void 0 || o === null;
}
function isString3(o) {
  return typeof o === "string";
}
function isUndefined2(o) {
  return o === void 0;
}
var componentHooks = {
  onComponentDidMount: 1,
  onComponentDidUpdate: 1,
  onComponentShouldUpdate: 1,
  onComponentWillMount: 1,
  onComponentWillUnmount: 1,
  onComponentWillUpdate: 1
};
function createElement(type, props, _children) {
  var arguments$1 = arguments;
  var children;
  var ref = null;
  var key = null;
  var className = null;
  var flags = 0;
  var newProps;
  var childLen = arguments.length - 2;
  if (childLen === 1) {
    children = _children;
  } else if (childLen > 1) {
    children = [];
    while (childLen-- > 0) {
      children[childLen] = arguments$1[childLen + 2];
    }
  }
  if (isString3(type)) {
    flags = getFlagsForElementVnode(type);
    if (!isNullOrUndef3(props)) {
      newProps = {};
      for (var prop in props) {
        if (prop === "className" || prop === "class") {
          className = props[prop];
        } else if (prop === "key") {
          key = props.key;
        } else if (prop === "children" && isUndefined2(children)) {
          children = props.children;
        } else if (prop === "ref") {
          ref = props.ref;
        } else {
          if (prop === "contenteditable") {
            flags |= 4096;
          }
          newProps[prop] = props[prop];
        }
      }
    }
  } else {
    flags = 2;
    if (!isUndefined2(children)) {
      if (!props) {
        props = {};
      }
      props.children = children;
    }
    if (!isNullOrUndef3(props)) {
      newProps = {};
      for (var prop$1 in props) {
        if (prop$1 === "key") {
          key = props.key;
        } else if (prop$1 === "ref") {
          ref = props.ref;
        } else if (componentHooks[prop$1] === 1) {
          if (!ref) {
            ref = {};
          }
          ref[prop$1] = props[prop$1];
        } else {
          newProps[prop$1] = props[prop$1];
        }
      }
    }
    return createComponentVNode(flags, type, newProps, key, ref);
  }
  if (flags & 8192) {
    return createFragment(childLen === 1 ? [children] : children, 0, key);
  }
  return createVNode(flags, type, className, children, 0, newProps, key, ref);
}

// node_modules/@devextreme/runtime/esm/inferno/render_template.js
var getContainer = (props) => {
  var _a, _b;
  return ((_a = props.container) === null || _a === void 0 ? void 0 : _a.get(0)) || ((_b = props.item) === null || _b === void 0 ? void 0 : _b.get(0));
};
function renderTemplate(template, props, _component) {
  setTimeout(() => {
    render(createElement(template, props), getContainer(props));
  }, 0);
}
var hasTemplate = (name2, properties, _component) => {
  const value = properties[name2];
  return !!value && typeof value !== "string";
};

// node_modules/@devextreme/runtime/esm/inferno/normalize_styles.js
var NUMBER_STYLES = /* @__PURE__ */ new Set(["animationIterationCount", "borderImageOutset", "borderImageSlice", "border-imageWidth", "boxFlex", "boxFlexGroup", "boxOrdinalGroup", "columnCount", "fillOpacity", "flex", "flexGrow", "flexNegative", "flexOrder", "flexPositive", "flexShrink", "floodOpacity", "fontWeight", "gridColumn", "gridRow", "lineClamp", "lineHeight", "opacity", "order", "orphans", "stopOpacity", "strokeDasharray", "strokeDashoffset", "strokeMiterlimit", "strokeOpacity", "strokeWidth", "tabSize", "widows", "zIndex", "zoom"]);
var isNumeric2 = (value) => {
  if (typeof value === "number") return true;
  return !Number.isNaN(Number(value));
};
var getNumberStyleValue = (style, value) => NUMBER_STYLES.has(style) ? value : `${value}px`;
var uppercasePattern = /[A-Z]/g;
var kebabCase = (str) => str.replace(uppercasePattern, "-$&").toLowerCase();
function normalizeStyles(styles) {
  if (!(styles instanceof Object)) {
    return void 0;
  }
  return Object.entries(styles).reduce((acc, [key, value]) => {
    acc[kebabCase(key)] = isNumeric2(value) ? getNumberStyleValue(key, value) : value;
    return acc;
  }, {});
}

// node_modules/devextreme/esm/core/inferno_renderer.js
init_dom_adapter();
init_element_data();
init_dependency_injector();
var remove3 = (element) => {
  const {
    parentNode
  } = element;
  if (parentNode) {
    const nextSibling = element.nextSibling;
    cleanDataRecursive(element);
    parentNode.$V = element.$V;
    render(null, parentNode);
    parentNode.insertBefore(element, nextSibling);
    element.innerHTML = "";
    delete parentNode.$V;
  }
  delete element.$V;
};
var inferno_renderer_default = dependency_injector_default({
  createElement: (component, props) => createElement(component, props),
  remove: remove3,
  onAfterRender: () => {
    InfernoEffectHost.callEffects();
  },
  onPreRender: () => {
    InfernoEffectHost.lock();
  },
  render: (component, props, container, replace) => {
    if (!replace) {
      const {
        parentNode
      } = container;
      const nextNode = null === container || void 0 === container ? void 0 : container.nextSibling;
      const rootNode = dom_adapter_default.createElement("div");
      rootNode.appendChild(container);
      const mountNode = dom_adapter_default.createDocumentFragment().appendChild(rootNode);
      const vNodeAlreadyExists = !!container.$V;
      vNodeAlreadyExists && remove3(container);
      hydrate(createElement(component, props), mountNode);
      container.$V = mountNode.$V;
      if (parentNode) {
        parentNode.insertBefore(container, nextNode);
      }
    } else {
      render(createElement(component, props), container);
    }
  }
});

// node_modules/devextreme/esm/renovation/component_wrapper/common/component.js
init_renderer();
init_dom_adapter();
init_extend();
init_type();

// node_modules/devextreme/esm/renovation/component_wrapper/common/template_wrapper.js
init_extends();

// node_modules/devextreme/esm/renovation/utils/shallow_equals.js
var shallowEquals = (firstObject, secondObject) => {
  if (Object.keys(firstObject).length !== Object.keys(secondObject).length) {
    return false;
  }
  return Object.keys(firstObject).every((key) => firstObject[key] === secondObject[key]);
};

// node_modules/devextreme/esm/renovation/component_wrapper/common/template_wrapper.js
init_renderer();
init_dom_adapter();
init_type();
var _excluded = ["isEqual"];
function isDxElementWrapper(element) {
  return !!element.toArray;
}
function buildTemplateArgs(model, template) {
  const args = {
    template,
    model: _extends({}, model)
  };
  const _ref = model.data ?? {}, {
    isEqual
  } = _ref, data = _objectWithoutPropertiesLoose(_ref, _excluded);
  if (isEqual) {
    args.model.data = data;
    args.isEqual = isEqual;
  }
  return args;
}
function renderTemplateContent(props, container) {
  const {
    data,
    index
  } = props.model ?? {
    data: {}
  };
  if (data) {
    Object.keys(data).forEach((name2) => {
      if (data[name2] && dom_adapter_default.isNode(data[name2])) {
        data[name2] = getPublicElement(renderer_default(data[name2]));
      }
    });
  }
  const rendered = props.template.render(_extends({
    container,
    transclude: props.transclude
  }, {
    renovated: props.renovated
  }, !props.transclude ? {
    model: data
  } : {}, !props.transclude && Number.isFinite(index) ? {
    index
  } : {}));
  if (void 0 === rendered) {
    return [];
  }
  return isDxElementWrapper(rendered) ? rendered.toArray() : [renderer_default(rendered).get(0)];
}
function removeDifferentElements(oldChildren, newChildren) {
  newChildren.forEach((newElement) => {
    const hasOldChild = !!oldChildren.find((oldElement) => newElement === oldElement);
    if (!hasOldChild && newElement.parentNode) {
      renderer_default(newElement).remove();
    }
  });
}
var TemplateWrapper = class extends InfernoComponent {
  constructor(props) {
    super(props);
    this.renderTemplate = this.renderTemplate.bind(this);
  }
  renderTemplate() {
    const node = findDOMfromVNode(this.$LI, true);
    if (!(null !== node && void 0 !== node && node.parentNode)) {
      return () => {
      };
    }
    const container = node.parentNode;
    const $container = renderer_default(container);
    const $oldContainerContent = $container.contents().toArray();
    const content = renderTemplateContent(this.props, getPublicElement($container));
    replaceWith(renderer_default(node), renderer_default(content));
    return () => {
      const $actualContainerContent = renderer_default(container).contents().toArray();
      removeDifferentElements($oldContainerContent, $actualContainerContent);
      container.appendChild(node);
    };
  }
  shouldComponentUpdate(nextProps) {
    const {
      model,
      template
    } = this.props;
    const {
      isEqual,
      model: nextModel,
      template: nextTemplate
    } = nextProps;
    const equalityComparer = isEqual ?? shallowEquals;
    if (template !== nextTemplate) {
      return true;
    }
    if (!isDefined(model) || !isDefined(nextModel)) {
      return model !== nextModel;
    }
    const {
      data,
      index
    } = model;
    const {
      data: nextData,
      index: nextIndex
    } = nextModel;
    if (index !== nextIndex) {
      return true;
    }
    return !equalityComparer(data, nextData);
  }
  createEffects() {
    return [new InfernoEffect(this.renderTemplate, [this.props.template, this.props.model])];
  }
  updateEffects() {
    this._effects[0].update([this.props.template, this.props.model]);
  }
  componentWillUnmount() {
  }
  render() {
    return null;
  }
};

// node_modules/devextreme/esm/renovation/component_wrapper/utils/update_props_immutable.js
init_extends();
init_type();
init_data();
function cloneObjectValue(value) {
  return Array.isArray(value) ? [...value] : _extends({}, value);
}
function cloneObjectProp(value, prevValue, fullNameParts) {
  const result2 = fullNameParts.length > 0 && prevValue && value !== prevValue ? cloneObjectValue(prevValue) : cloneObjectValue(value);
  const name2 = fullNameParts[0];
  if (fullNameParts.length > 1) {
    result2[name2] = cloneObjectProp(value[name2], null === prevValue || void 0 === prevValue ? void 0 : prevValue[name2], fullNameParts.slice(1));
  } else if (name2) {
    if (isPlainObject(value[name2])) {
      result2[name2] = cloneObjectValue(value[name2]);
    } else {
      result2[name2] = value[name2];
    }
  }
  return result2;
}
function updatePropsImmutable(props, option, name2, fullName) {
  const currentPropsValue = option[name2];
  const prevPropsValue = props[name2];
  const result2 = props;
  if (isPlainObject(currentPropsValue) || name2 !== fullName && Array.isArray(currentPropsValue)) {
    result2[name2] = cloneObjectProp(currentPropsValue, prevPropsValue, getPathParts(fullName).slice(1));
  } else {
    result2[name2] = currentPropsValue;
  }
}

// node_modules/devextreme/esm/renovation/component_wrapper/common/component.js
var setDefaultOptionValue = (options2, defaultValueGetter) => (name2) => {
  if (Object.prototype.hasOwnProperty.call(options2, name2) && void 0 === options2[name2]) {
    options2[name2] = defaultValueGetter(name2);
  }
};
var ComponentWrapper = class extends dom_component_default {
  get _propsInfo() {
    return {
      allowNull: [],
      twoWay: [],
      elements: [],
      templates: [],
      props: []
    };
  }
  constructor(element, options2) {
    super(element, options2);
    this._shouldRaiseContentReady = false;
    this.validateKeyDownHandler();
  }
  validateKeyDownHandler() {
    const supportedKeyNames = this.getSupportedKeyNames();
    const hasComponentDefaultKeyHandlers = supportedKeyNames.length > 0;
    const hasComponentKeyDownMethod = "function" === typeof this._viewComponent.prototype.keyDown;
    if (hasComponentDefaultKeyHandlers && !hasComponentKeyDownMethod) {
      throw Error("Component's declaration must have 'keyDown' method.");
    }
  }
  get viewRef() {
    var _this$_viewRef;
    return null === (_this$_viewRef = this._viewRef) || void 0 === _this$_viewRef ? void 0 : _this$_viewRef.current;
  }
  _checkContentReadyOption(fullName) {
    const contentReadyOptions = this._getContentReadyOptions().reduce((options2, name2) => {
      options2[name2] = true;
      return options2;
    }, {});
    this._checkContentReadyOption = (optionName) => !!contentReadyOptions[optionName];
    return this._checkContentReadyOption(fullName);
  }
  _getContentReadyOptions() {
    return ["rtlEnabled"];
  }
  _fireContentReady() {
    this._actionsMap.onContentReady({});
  }
  _getDefaultOptions() {
    const viewDefaultProps = this._getViewComponentDefaultProps();
    return extend(true, super._getDefaultOptions(), viewDefaultProps, this._propsInfo.twoWay.reduce((options2, _ref) => {
      let [name2, defaultName, eventName] = _ref;
      return _extends({}, options2, {
        [name2]: viewDefaultProps[defaultName],
        [eventName]: (value) => this.option(name2, value)
      });
    }, {}), this._propsInfo.templates.reduce((options2, name2) => _extends({}, options2, {
      [name2]: null
    }), {}));
  }
  _getUnwrappedOption() {
    const unwrappedProps = {};
    Object.keys(this.option()).forEach((key) => {
      unwrappedProps[key] = this.option(key);
    });
    return unwrappedProps;
  }
  _initializeComponent() {
    var _this$_templateManage;
    super._initializeComponent();
    null === (_this$_templateManage = this._templateManager) || void 0 === _this$_templateManage || _this$_templateManage.addDefaultTemplates(this.getDefaultTemplates());
    const optionProxy = this._getUnwrappedOption();
    this._props = this._optionsWithDefaultTemplates(optionProxy);
    this._propsInfo.templates.forEach((template) => {
      this._componentTemplates[template] = this._createTemplateComponent(this._props[template]);
    });
    Object.keys(this._getActionConfigsFull()).forEach((name2) => this._addAction(name2));
    this._viewRef = createRef();
    this.defaultKeyHandlers = this._createDefaultKeyHandlers();
  }
  _initMarkup() {
    const props = this.getProps();
    this._renderWrapper(props);
  }
  _renderWrapper(props) {
    const containerNode = this.$element()[0];
    if (!this._isNodeReplaced) {
      inferno_renderer_default.onPreRender();
    }
    inferno_renderer_default.render(this._viewComponent, props, containerNode, this._isNodeReplaced);
    if (!this._isNodeReplaced) {
      this._isNodeReplaced = true;
      inferno_renderer_default.onAfterRender();
      this._shouldRaiseContentReady = true;
    }
    if (this._shouldRaiseContentReady) {
      this._fireContentReady();
      this._shouldRaiseContentReady = false;
    }
  }
  _silent(name2, value) {
    this._options.silent(name2, value);
  }
  _render() {
  }
  _removeWidget() {
    inferno_renderer_default.remove(this.$element()[0]);
  }
  _dispose() {
    this._removeWidget();
    super._dispose();
  }
  get elementAttr() {
    const element = this.$element()[0];
    if (!this._elementAttr) {
      const {
        attributes
      } = element;
      const attrs = Array.from(attributes).filter((attr) => {
        var _attributes$attr$name;
        return !this._propsInfo.templates.includes(attr.name) && (null === (_attributes$attr$name = attributes[attr.name]) || void 0 === _attributes$attr$name ? void 0 : _attributes$attr$name.specified);
      }).reduce((result2, _ref2) => {
        let {
          name: name2,
          value
        } = _ref2;
        const updatedAttributes = result2;
        const isDomAttr = name2 in element;
        updatedAttributes[name2] = "" === value && isDomAttr ? element[name2] : value;
        return updatedAttributes;
      }, {});
      this._elementAttr = attrs;
      this._storedClasses = element.getAttribute("class") || "";
    }
    const elemStyle = element.style;
    const style = {};
    for (let i = 0; i < elemStyle.length; i += 1) {
      style[elemStyle[i]] = elemStyle.getPropertyValue(elemStyle[i]);
    }
    this._elementAttr.style = style;
    this._elementAttr.class = this._storedClasses;
    return this._elementAttr;
  }
  _getAdditionalActionConfigs() {
    return {
      onContentReady: {
        excludeValidators: ["disabled", "readOnly"]
      }
    };
  }
  _getAdditionalProps() {
    return [];
  }
  _patchOptionValues(options2) {
    const {
      allowNull,
      elements,
      props,
      twoWay
    } = this._propsInfo;
    const viewDefaultProps = this._getViewComponentDefaultProps();
    const defaultWidgetPropsKeys = Object.keys(viewDefaultProps);
    const defaultOptions2 = this._getDefaultOptions();
    const {
      children,
      onKeyboardHandled,
      ref
    } = options2;
    const onKeyDown = onKeyboardHandled ? (_, event_options) => {
      onKeyboardHandled(event_options);
    } : void 0;
    const widgetProps = {
      ref,
      children,
      onKeyDown
    };
    [...props, ...this._getAdditionalProps()].forEach((propName) => {
      if (Object.prototype.hasOwnProperty.call(options2, propName)) {
        widgetProps[propName] = options2[propName];
      }
    });
    allowNull.forEach(setDefaultOptionValue(widgetProps, () => null));
    defaultWidgetPropsKeys.forEach(setDefaultOptionValue(widgetProps, (name2) => defaultOptions2[name2]));
    twoWay.forEach((_ref3) => {
      let [name2, defaultName] = _ref3;
      setDefaultOptionValue(widgetProps, () => defaultOptions2[defaultName])(name2);
    });
    elements.forEach((name2) => {
      if (name2 in widgetProps) {
        const value = widgetProps[name2];
        if (isRenderer(value)) {
          widgetProps[name2] = this._patchElementParam(value);
        }
      }
    });
    return widgetProps;
  }
  getSupportedKeyNames() {
    return [];
  }
  prepareStyleProp(props) {
    if ("string" === typeof props.style) {
      return _extends({}, props, {
        style: {},
        cssText: props.style
      });
    }
    return props;
  }
  getProps() {
    const {
      elementAttr
    } = this.option();
    const options2 = this._patchOptionValues(_extends({}, this._props, {
      ref: this._viewRef,
      children: this._extractDefaultSlot(),
      aria: this._aria
    }));
    this._propsInfo.templates.forEach((template) => {
      options2[template] = this._componentTemplates[template];
    });
    return this.prepareStyleProp(_extends({}, options2, this.elementAttr, elementAttr, {
      className: [...(this.elementAttr.class ?? "").split(" "), ...((null === elementAttr || void 0 === elementAttr ? void 0 : elementAttr.class) ?? "").split(" ")].filter((c, i, a) => c && a.indexOf(c) === i).join(" ").trim(),
      class: ""
    }, this._actionsMap));
  }
  _getActionConfigs() {
    return {};
  }
  _getActionConfigsFull() {
    return _extends({}, this._getActionConfigs(), this._getAdditionalActionConfigs());
  }
  getDefaultTemplates() {
    const defaultTemplates = Object.values(this._templatesInfo);
    const result2 = {};
    defaultTemplates.forEach((template) => {
      result2[template] = "dx-renovation-template-mock";
    });
    return result2;
  }
  get _templatesInfo() {
    return {};
  }
  _optionsWithDefaultTemplates(options2) {
    const templateOptions = Object.entries(this._templatesInfo).reduce((result2, _ref4) => {
      let [templateName, templateValue] = _ref4;
      return _extends({}, result2, {
        [templateName]: options2[templateName] ?? templateValue
      });
    }, {});
    return _extends({}, options2, templateOptions);
  }
  _init() {
    super._init();
    this.customKeyHandlers = {};
    this._actionsMap = {};
    this._aria = {};
    this._componentTemplates = {};
  }
  _createDefaultKeyHandlers() {
    const result2 = {};
    const keys = this.getSupportedKeyNames();
    keys.forEach((key) => {
      result2[key] = (e) => this.viewRef.keyDown(keyboard_processor_default.createKeyDownOptions(e));
    });
    return result2;
  }
  _addAction(event, actionToAdd) {
    let action = actionToAdd;
    if (!action) {
      const actionByOption = this._createActionByOption(event, this._getActionConfigsFull()[event]);
      action = (actArgs) => {
        Object.keys(actArgs).forEach((name2) => {
          if (isDefined(actArgs[name2]) && dom_adapter_default.isNode(actArgs[name2])) {
            actArgs[name2] = getPublicElement(renderer_default(actArgs[name2]));
          }
        });
        return actionByOption(actArgs);
      };
    }
    this._actionsMap[event] = action;
  }
  _optionChanged(option) {
    const {
      fullName,
      name: name2,
      previousValue,
      value
    } = option;
    updatePropsImmutable(this._props, this.option(), name2, fullName);
    if (this._propsInfo.templates.includes(name2) && value !== previousValue) {
      this._componentTemplates[name2] = this._createTemplateComponent(value);
    }
    if (name2 && this._getActionConfigsFull()[name2]) {
      this._addAction(name2);
    }
    this._shouldRaiseContentReady = this._shouldRaiseContentReady || this._checkContentReadyOption(fullName);
    super._optionChanged(option);
    this._invalidate();
  }
  _extractDefaultSlot() {
    if (this.option("_hasAnonymousTemplateContent")) {
      return inferno_renderer_default.createElement(TemplateWrapper, {
        template: this._getTemplate(this._templateManager.anonymousTemplateName),
        transclude: true,
        renovated: true
      });
    }
    return null;
  }
  _createTemplateComponent(templateOption) {
    if (!templateOption) {
      return;
    }
    const template = this._getTemplate(templateOption);
    if (isString(template) && "dx-renovation-template-mock" === template) {
      return;
    }
    return (model) => inferno_renderer_default.createElement(TemplateWrapper, buildTemplateArgs(model, template));
  }
  _wrapKeyDownHandler(initialHandler) {
    return (options2) => {
      const {
        keyName,
        originalEvent,
        which
      } = options2;
      const keys = this.customKeyHandlers;
      const func = keys[keyName] || keys[which];
      if (void 0 !== func) {
        const handler = func.bind(this);
        const result2 = handler(originalEvent, options2);
        if (!result2) {
          originalEvent.cancel = true;
          return originalEvent;
        }
      }
      return null === initialHandler || void 0 === initialHandler ? void 0 : initialHandler(originalEvent, options2);
    };
  }
  _toPublicElement(element) {
    return getPublicElement(renderer_default(element));
  }
  _patchElementParam(value) {
    try {
      const result2 = renderer_default(value);
      const element = null === result2 || void 0 === result2 ? void 0 : result2.get(0);
      return null !== element && void 0 !== element && element.nodeType ? element : value;
    } catch (error) {
      return value;
    }
  }
  repaint() {
    this._isNodeReplaced = false;
    this._shouldRaiseContentReady = true;
    this._removeWidget();
    this._refresh();
  }
  _supportedKeys() {
    return _extends({}, this.defaultKeyHandlers, this.customKeyHandlers);
  }
  registerKeyHandler(key, handler) {
    this.customKeyHandlers[key] = handler;
  }
  setAria(name2, value) {
    this._aria[name2] = value;
    this._initMarkup();
  }
  _getViewComponentDefaultProps() {
    return this._viewComponent.defaultProps || {};
  }
};
ComponentWrapper.IS_RENOVATED_WIDGET = false;
var component_default = ComponentWrapper;
ComponentWrapper.IS_RENOVATED_WIDGET = true;

// node_modules/devextreme/esm/renovation/component_wrapper/button.js
var ButtonWrapper = class extends component_default {
  get _validationGroupConfig() {
    return validation_engine_default.getGroupConfig(this._findGroup());
  }
  getDefaultTemplateNames() {
    return ["content"];
  }
  getSupportedKeyNames() {
    return ["space", "enter"];
  }
  getProps() {
    const props = super.getProps();
    props.onClick = (_ref) => {
      let {
        event
      } = _ref;
      this._clickAction({
        event,
        validationGroup: this._validationGroupConfig
      });
    };
    const iconType = getImageSourceType(props.icon);
    if ("svg" === iconType) {
      props.iconTemplate = this._createTemplateComponent(() => props.icon);
    }
    return props;
  }
  get _templatesInfo() {
    return {
      template: "content"
    };
  }
  _toggleActiveState(_, value) {
    const button = this.viewRef;
    value ? button.activate() : button.deactivate();
  }
  _getSubmitAction() {
    let needValidate = true;
    let validationStatus = "valid";
    return this._createAction((_ref2) => {
      let {
        event,
        submitInput
      } = _ref2;
      if (needValidate) {
        const validationGroup = this._validationGroupConfig;
        if (void 0 !== validationGroup && "" !== validationGroup) {
          const validationResult = validationGroup.validate();
          validationStatus = validationResult.status;
          if ("pending" === validationResult.status) {
            needValidate = false;
            this.option("disabled", true);
            validationResult.complete.then((_ref3) => {
              let {
                status
              } = _ref3;
              this.option("disabled", false);
              validationStatus = status;
              "valid" === validationStatus && submitInput.click();
              needValidate = true;
            });
          }
        }
      }
      "valid" !== validationStatus && event.preventDefault();
      event.stopPropagation();
    });
  }
  _initializeComponent() {
    super._initializeComponent();
    this._addAction("onSubmit", this._getSubmitAction());
    this._clickAction = this._createClickAction();
  }
  _initMarkup() {
    super._initMarkup();
    const $content = this.$element().find(".dx-button-content").first();
    const $template = $content.children().filter(".dx-template-wrapper");
    const $input = $content.children().filter(".dx-button-submit-input");
    if ($template.length) {
      $template.addClass("dx-button-content");
      $template.append($input);
      $content.replaceWith($template);
    }
  }
  _patchOptionValues(options2) {
    return super._patchOptionValues(_extends({}, options2, {
      templateData: options2._templateData
    }));
  }
  _findGroup() {
    const $element = this.$element();
    const validationGroup = this.option("validationGroup");
    return void 0 !== validationGroup && "" !== validationGroup ? validationGroup : validation_engine_default.findGroup($element, this._modelByElement($element));
  }
  _createClickAction() {
    return this._createActionByOption("onClick", {
      excludeValidators: ["readOnly"]
    });
  }
  _optionChanged(option) {
    if ("onClick" === option.name) {
      this._clickAction = this._createClickAction();
    }
    super._optionChanged(option);
  }
};

// node_modules/devextreme/esm/renovation/ui/button.js
init_extends();

// node_modules/devextreme/esm/renovation/utils/combine_classes.js
function combineClasses(classesMap) {
  return Object.keys(classesMap).filter((p2) => classesMap[p2]).join(" ");
}

// node_modules/devextreme/esm/renovation/ui/button.js
init_inflector();

// node_modules/devextreme/esm/renovation/ui/common/icon.js
init_extends();
var _excluded2 = ["iconTemplate", "position", "source"];
var viewFunction = (_ref) => {
  let {
    iconClassName,
    props: {
      iconTemplate: IconTemplate,
      source
    },
    sourceType
  } = _ref;
  return createFragment(["dxIcon" === sourceType && createVNode(1, "i", iconClassName), "fontIcon" === sourceType && createVNode(1, "i", iconClassName), "image" === sourceType && createVNode(1, "img", iconClassName, null, 1, {
    alt: "",
    src: source
  }), IconTemplate && createVNode(1, "i", iconClassName, IconTemplate({}), 0)], 0);
};
var IconProps = {
  position: "left",
  source: ""
};
var getTemplate = (TemplateProp) => TemplateProp && (TemplateProp.defaultProps ? (props) => normalizeProps(createComponentVNode(2, TemplateProp, _extends({}, props))) : TemplateProp);
var Icon = class extends BaseInfernoComponent {
  constructor(props) {
    super(props);
    this.state = {};
  }
  get sourceType() {
    return getImageSourceType(this.props.source);
  }
  get cssClass() {
    return "left" !== this.props.position ? "dx-icon-right" : "";
  }
  get iconClassName() {
    const generalClasses = {
      "dx-icon": true,
      [this.cssClass]: !!this.cssClass
    };
    const {
      source
    } = this.props;
    if ("dxIcon" === this.sourceType) {
      return combineClasses(_extends({}, generalClasses, {
        [`dx-icon-${source}`]: true
      }));
    }
    if ("fontIcon" === this.sourceType) {
      return combineClasses(_extends({}, generalClasses, {
        [String(source)]: !!source
      }));
    }
    if ("image" === this.sourceType) {
      return combineClasses(generalClasses);
    }
    if ("svg" === this.sourceType) {
      return combineClasses(_extends({}, generalClasses, {
        "dx-svg-icon": true
      }));
    }
    return "";
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded2);
    return restProps;
  }
  render() {
    const props = this.props;
    return viewFunction({
      props: _extends({}, props, {
        iconTemplate: getTemplate(props.iconTemplate)
      }),
      sourceType: this.sourceType,
      cssClass: this.cssClass,
      iconClassName: this.iconClassName,
      restAttributes: this.restAttributes
    });
  }
};
Icon.defaultProps = IconProps;

// node_modules/devextreme/esm/renovation/ui/common/ink_ripple.js
init_extends();

// node_modules/devextreme/esm/ui/widget/utils.ink_ripple.js
init_size();
init_renderer();
var INKRIPPLE_SHOWING_CLASS = "dx-inkripple-showing";
var INKRIPPLE_HIDING_CLASS = "dx-inkripple-hiding";
var initConfig = function() {
  let config = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  const {
    useHoldAnimation,
    waveSizeCoefficient,
    isCentered,
    wavesNumber
  } = config;
  return {
    waveSizeCoefficient: waveSizeCoefficient || 2,
    isCentered: isCentered || false,
    wavesNumber: wavesNumber || 1,
    durations: getDurations(useHoldAnimation ?? true)
  };
};
var render3 = function(args) {
  const config = initConfig(args);
  return {
    showWave: showWave.bind(this, config),
    hideWave: hideWave.bind(this, config)
  };
};
var getInkRipple = function(element) {
  let result2 = element.children(".dx-inkripple");
  if (0 === result2.length) {
    result2 = renderer_default("<div>").addClass("dx-inkripple").appendTo(element);
  }
  return result2;
};
var getWaves = function(element, wavesNumber) {
  const inkRipple = getInkRipple(renderer_default(element));
  const result2 = inkRipple.children(".dx-inkripple-wave").toArray();
  for (let i = result2.length; i < wavesNumber; i++) {
    const $currentWave = renderer_default("<div>").appendTo(inkRipple).addClass("dx-inkripple-wave");
    result2.push($currentWave[0]);
  }
  return renderer_default(result2);
};
var getWaveStyleConfig = function(args, config) {
  const element = renderer_default(config.element);
  const elementWidth = getOuterWidth(element);
  const elementHeight = getOuterHeight(element);
  const elementDiagonal = parseInt(Math.sqrt(elementWidth * elementWidth + elementHeight * elementHeight));
  const waveSize = Math.min(4e3, parseInt(elementDiagonal * args.waveSizeCoefficient));
  let left;
  let top;
  if (args.isCentered) {
    left = (elementWidth - waveSize) / 2;
    top = (elementHeight - waveSize) / 2;
  } else {
    const event = config.event;
    const position = element.offset();
    const x = event.pageX - position.left;
    const y = event.pageY - position.top;
    left = x - waveSize / 2;
    top = y - waveSize / 2;
  }
  return {
    left,
    top,
    height: waveSize,
    width: waveSize
  };
};
function showWave(args, config) {
  const $wave = getWaves(config.element, args.wavesNumber).eq(config.wave || 0);
  args.hidingTimeout && clearTimeout(args.hidingTimeout);
  hideSelectedWave($wave);
  $wave.css(getWaveStyleConfig(args, config));
  args.showingTimeout = setTimeout(showingWaveHandler.bind(this, args, $wave), 0);
}
function showingWaveHandler(args, $wave) {
  const durationCss = args.durations.showingScale + "ms";
  $wave.addClass(INKRIPPLE_SHOWING_CLASS).css("transitionDuration", durationCss);
}
function getDurations(useHoldAnimation) {
  return {
    showingScale: useHoldAnimation ? 1e3 : 300,
    hidingScale: 300,
    hidingOpacity: 300
  };
}
function hideSelectedWave($wave) {
  $wave.removeClass(INKRIPPLE_HIDING_CLASS).css("transitionDuration", "");
}
function hideWave(args, config) {
  args.showingTimeout && clearTimeout(args.showingTimeout);
  const $wave = getWaves(config.element, config.wavesNumber).eq(config.wave || 0);
  const durations = args.durations;
  const durationCss = durations.hidingScale + "ms, " + durations.hidingOpacity + "ms";
  $wave.addClass(INKRIPPLE_HIDING_CLASS).removeClass(INKRIPPLE_SHOWING_CLASS).css("transitionDuration", durationCss);
  const animationDuration = Math.max(durations.hidingScale, durations.hidingOpacity);
  args.hidingTimeout = setTimeout(hideSelectedWave.bind(this, $wave), animationDuration);
}

// node_modules/devextreme/esm/renovation/ui/common/ink_ripple.js
var _excluded3 = ["config"];
var viewFunction2 = (model) => normalizeProps(createVNode(1, "div", "dx-inkripple", null, 1, _extends({}, model.restAttributes)));
var InkRippleProps = {
  config: Object.freeze({})
};
var InkRipple = class extends BaseInfernoComponent {
  constructor(props) {
    super(props);
    this.state = {};
    this.__getterCache = {};
    this.hideWave = this.hideWave.bind(this);
    this.showWave = this.showWave.bind(this);
  }
  get getConfig() {
    if (void 0 !== this.__getterCache.getConfig) {
      return this.__getterCache.getConfig;
    }
    return this.__getterCache.getConfig = (() => {
      const {
        config
      } = this.props;
      return initConfig(config);
    })();
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded3);
    return restProps;
  }
  hideWave(opts) {
    hideWave(this.getConfig, opts);
  }
  showWave(opts) {
    showWave(this.getConfig, opts);
  }
  componentWillUpdate(nextProps, nextState, context) {
    if (this.props.config !== nextProps.config) {
      this.__getterCache.getConfig = void 0;
    }
  }
  render() {
    const props = this.props;
    return viewFunction2({
      props: _extends({}, props),
      getConfig: this.getConfig,
      restAttributes: this.restAttributes
    });
  }
};
InkRipple.defaultProps = InkRippleProps;

// node_modules/devextreme/esm/renovation/ui/common/widget.js
init_extends();
init_type();

// node_modules/devextreme/esm/renovation/utils/subscribe_to_event.js
init_events_engine();

// node_modules/devextreme/esm/events/gesture/emitter.gesture.scroll.js
init_events_engine();
init_class();
var abstract = class_default.abstract;
var realDevice = devices_default.real();
var Locker = class_default.inherit(function() {
  const NAMESPACED_SCROLL_EVENT = addNamespace("scroll", "dxScrollEmitter");
  return {
    ctor: function(element) {
      this._element = element;
      this._locked = false;
      this._proxiedScroll = (e) => {
        if (!this._disposed) {
          this._scroll(e);
        }
      };
      events_engine_default.on(this._element, NAMESPACED_SCROLL_EVENT, this._proxiedScroll);
    },
    _scroll: abstract,
    check: function(e, callback) {
      if (this._locked) {
        callback();
      }
    },
    dispose: function() {
      this._disposed = true;
      events_engine_default.off(this._element, NAMESPACED_SCROLL_EVENT, this._proxiedScroll);
    }
  };
}());
var TimeoutLocker = Locker.inherit({
  ctor: function(element, timeout) {
    this.callBase(element);
    this._timeout = timeout;
  },
  _scroll: function() {
    this._prepare();
    this._forget();
  },
  _prepare: function() {
    if (this._timer) {
      this._clearTimer();
    }
    this._locked = true;
  },
  _clearTimer: function() {
    clearTimeout(this._timer);
    this._locked = false;
    this._timer = null;
  },
  _forget: function() {
    const that = this;
    this._timer = setTimeout(function() {
      that._clearTimer();
    }, this._timeout);
  },
  dispose: function() {
    this.callBase();
    this._clearTimer();
  }
});
var WheelLocker = TimeoutLocker.inherit({
  ctor: function(element) {
    this.callBase(element, 400);
    this._lastWheelDirection = null;
  },
  check: function(e, callback) {
    this._checkDirectionChanged(e);
    this.callBase(e, callback);
  },
  _checkDirectionChanged: function(e) {
    if (!isDxMouseWheelEvent(e)) {
      this._lastWheelDirection = null;
      return;
    }
    const direction = e.shiftKey || false;
    const directionChange = null !== this._lastWheelDirection && direction !== this._lastWheelDirection;
    this._lastWheelDirection = direction;
    this._locked = this._locked && !directionChange;
  }
});
var PointerLocker = TimeoutLocker.inherit({
  ctor: function(element) {
    this.callBase(element, 400);
  }
});
!function() {
  const {
    ios: isIos,
    android: isAndroid
  } = realDevice;
  if (!(isIos || isAndroid)) {
    return;
  }
  PointerLocker = Locker.inherit({
    _scroll: function() {
      this._locked = true;
      const that = this;
      cancelAnimationFrame(this._scrollFrame);
      this._scrollFrame = requestAnimationFrame(function() {
        that._locked = false;
      });
    },
    check: function(e, callback) {
      cancelAnimationFrame(this._scrollFrame);
      cancelAnimationFrame(this._checkFrame);
      const that = this;
      const callBase = this.callBase;
      this._checkFrame = requestAnimationFrame(function() {
        callBase.call(that, e, callback);
        that._locked = false;
      });
    },
    dispose: function() {
      this.callBase();
      cancelAnimationFrame(this._scrollFrame);
      cancelAnimationFrame(this._checkFrame);
    }
  });
}();
var ScrollEmitter = emitter_gesture_default.inherit(function() {
  const FRAME_DURATION2 = Math.round(1e3 / 60);
  return {
    ctor: function(element) {
      this.callBase.apply(this, arguments);
      this.direction = "both";
      this._pointerLocker = new PointerLocker(element);
      this._wheelLocker = new WheelLocker(element);
    },
    validate: function() {
      return true;
    },
    configure: function(data) {
      if (data.scrollTarget) {
        this._pointerLocker.dispose();
        this._wheelLocker.dispose();
        this._pointerLocker = new PointerLocker(data.scrollTarget);
        this._wheelLocker = new WheelLocker(data.scrollTarget);
      }
      this.callBase(data);
    },
    _init: function(e) {
      this._wheelLocker.check(e, function() {
        if (isDxMouseWheelEvent(e)) {
          this._accept(e);
        }
      }.bind(this));
      this._pointerLocker.check(e, function() {
        const skipCheck = this.isNative && isMouseEvent(e);
        if (!isDxMouseWheelEvent(e) && !skipCheck) {
          this._accept(e);
        }
      }.bind(this));
      this._fireEvent("dxscrollinit", e);
      this._prevEventData = eventData(e);
    },
    move: function(e) {
      this.callBase.apply(this, arguments);
      e.isScrollingEvent = this.isNative || e.isScrollingEvent;
    },
    _start: function(e) {
      this._savedEventData = eventData(e);
      this._fireEvent("dxscrollstart", e);
      this._prevEventData = eventData(e);
    },
    _move: function(e) {
      const currentEventData = eventData(e);
      this._fireEvent("dxscroll", e, {
        delta: eventDelta(this._prevEventData, currentEventData)
      });
      const delta = eventDelta(this._savedEventData, currentEventData);
      if (delta.time > 200) {
        this._savedEventData = this._prevEventData;
      }
      this._prevEventData = eventData(e);
    },
    _end: function(e) {
      const endEventDelta = eventDelta(this._prevEventData, eventData(e));
      let velocity = {
        x: 0,
        y: 0
      };
      if (!isDxMouseWheelEvent(e) && endEventDelta.time < 100) {
        const delta = eventDelta(this._savedEventData, this._prevEventData);
        const velocityMultiplier = FRAME_DURATION2 / delta.time;
        velocity = {
          x: delta.x * velocityMultiplier,
          y: delta.y * velocityMultiplier
        };
      }
      this._fireEvent("dxscrollend", e, {
        velocity
      });
    },
    _stop: function(e) {
      this._fireEvent("dxscrollstop", e);
    },
    cancel: function(e) {
      this.callBase.apply(this, arguments);
      this._fireEvent("dxscrollcancel", e);
    },
    dispose: function() {
      this.callBase.apply(this, arguments);
      this._pointerLocker.dispose();
      this._wheelLocker.dispose();
    },
    _clearSelection: function() {
      if (this.isNative) {
        return;
      }
      return this.callBase.apply(this, arguments);
    },
    _toggleGestureCover: function() {
      if (this.isNative) {
        return;
      }
      return this.callBase.apply(this, arguments);
    }
  };
}());
emitter_registrator_default({
  emitter: ScrollEmitter,
  events: ["dxscrollinit", "dxscrollstart", "dxscroll", "dxscrollend", "dxscrollstop", "dxscrollcancel"]
});
var emitter_gesture_scroll_default = {
  init: "dxscrollinit",
  start: "dxscrollstart",
  move: "dxscroll",
  end: "dxscrollend",
  stop: "dxscrollstop",
  cancel: "dxscrollcancel",
  scroll: "scroll"
};

// node_modules/devextreme/esm/renovation/utils/subscribe_to_event.js
function subscribeToEvent(eventName) {
  return (element, handler, eventData2, namespace) => {
    const event = namespace ? addNamespace(eventName, namespace) : eventName;
    if (handler) {
      events_engine_default.on(element, event, eventData2, handler);
      return () => {
        events_engine_default.off(element, event, handler);
      };
    }
    return;
  };
}
var subscribeToClickEvent = subscribeToEvent(CLICK_EVENT_NAME);
var subscribeToScrollEvent = subscribeToEvent(emitter_gesture_scroll_default.scroll);
var subscribeToScrollInitEvent = subscribeToEvent(emitter_gesture_scroll_default.init);
var subscribeToDXScrollStartEvent = subscribeToEvent(emitter_gesture_scroll_default.start);
var subscribeToDXScrollMoveEvent = subscribeToEvent(emitter_gesture_scroll_default.move);
var subscribeToDXScrollEndEvent = subscribeToEvent(emitter_gesture_scroll_default.end);
var subscribeToDXScrollStopEvent = subscribeToEvent(emitter_gesture_scroll_default.stop);
var subscribeToDXScrollCancelEvent = subscribeToEvent(emitter_gesture_scroll_default.cancel);
var subscribeToDXPointerDownEvent = subscribeToEvent(pointer_default.down);
var subscribeToDXPointerUpEvent = subscribeToEvent(pointer_default.up);
var subscribeToDXPointerMoveEvent = subscribeToEvent(pointer_default.move);
var subscribeToMouseEnterEvent = subscribeToEvent("mouseenter");
var subscribeToMouseLeaveEvent = subscribeToEvent("mouseleave");
var subscribeToKeyDownEvent = subscribeToEvent("keydown");
var subscribeToDxActiveEvent = subscribeToEvent("dxactive");
var subscribeToDxInactiveEvent = subscribeToEvent("dxinactive");
var subscribeToDxHoverStartEvent = subscribeToEvent("dxhoverstart");
var subscribeToDxHoverEndEvent = subscribeToEvent("dxhoverend");
var subscribeToDxFocusInEvent = subscribeToEvent("focusin");
var subscribeToDxFocusOutEvent = subscribeToEvent("focusout");

// node_modules/devextreme/esm/renovation/ui/common/widget.js
init_extend();
init_style();

// node_modules/devextreme/esm/renovation/ui/common/base_props.js
var BaseWidgetProps = {
  className: "",
  activeStateEnabled: false,
  disabled: false,
  focusStateEnabled: false,
  hoverStateEnabled: false,
  tabIndex: 0,
  visible: true
};

// node_modules/devextreme/esm/renovation/common/config_context.js
var ConfigContext = createContext(void 0);

// node_modules/devextreme/esm/renovation/common/config_provider.js
init_extends();
var _excluded4 = ["children", "rtlEnabled"];
var viewFunction3 = (viewModel) => viewModel.props.children;
var ConfigProviderProps = {};
var ConfigProvider = class extends BaseInfernoComponent {
  constructor(props) {
    super(props);
    this.state = {};
    this.__getterCache = {};
  }
  getChildContext() {
    return _extends({}, this.context, {
      [ConfigContext.id]: this.config || ConfigContext.defaultValue
    });
  }
  get config() {
    if (void 0 !== this.__getterCache.config) {
      return this.__getterCache.config;
    }
    return this.__getterCache.config = (() => ({
      rtlEnabled: this.props.rtlEnabled
    }))();
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded4);
    return restProps;
  }
  componentWillUpdate(nextProps, nextState, context) {
    if (this.props.rtlEnabled !== nextProps.rtlEnabled) {
      this.__getterCache.config = void 0;
    }
  }
  render() {
    const props = this.props;
    return viewFunction3({
      props: _extends({}, props),
      config: this.config,
      restAttributes: this.restAttributes
    });
  }
};
ConfigProvider.defaultProps = ConfigProviderProps;

// node_modules/devextreme/esm/renovation/utils/resolve_rtl.js
init_type();
init_config();
function resolveRtlEnabled(rtlProp, config) {
  if (void 0 !== rtlProp) {
    return rtlProp;
  }
  if (void 0 !== (null === config || void 0 === config ? void 0 : config.rtlEnabled)) {
    return config.rtlEnabled;
  }
  return config_default().rtlEnabled;
}
function resolveRtlEnabledDefinition(rtlProp, config) {
  const isPropDefined = isDefined(rtlProp);
  const onlyGlobalDefined = isDefined(config_default().rtlEnabled) && !isPropDefined && !isDefined(null === config || void 0 === config ? void 0 : config.rtlEnabled);
  return isPropDefined && rtlProp !== (null === config || void 0 === config ? void 0 : config.rtlEnabled) || onlyGlobalDefined;
}

// node_modules/devextreme/esm/renovation/ui/common/widget.js
init_errors();
init_dom_adapter();
var _excluded5 = ["_feedbackHideTimeout", "_feedbackShowTimeout", "accessKey", "activeStateEnabled", "activeStateUnit", "addWidgetClass", "aria", "children", "className", "classes", "cssText", "disabled", "focusStateEnabled", "height", "hint", "hoverStateEnabled", "name", "onActive", "onClick", "onDimensionChanged", "onFocusIn", "onFocusOut", "onHoverEnd", "onHoverStart", "onInactive", "onKeyDown", "onRootElementRendered", "onVisibilityChange", "rootElementRef", "rtlEnabled", "tabIndex", "visible", "width"];
var getAria = (args) => Object.keys(args).reduce((r, key) => {
  if (args[key]) {
    return _extends({}, r, {
      ["role" === key || "id" === key ? key : `aria-${key}`]: String(args[key])
    });
  }
  return r;
}, {});
var viewFunction4 = (viewModel) => {
  const widget = normalizeProps(createVNode(1, "div", viewModel.cssClasses, viewModel.props.children, 0, _extends({}, viewModel.attributes, {
    tabIndex: viewModel.tabIndex,
    title: viewModel.props.hint,
    style: normalizeStyles(viewModel.styles)
  }), null, viewModel.widgetElementRef));
  return viewModel.shouldRenderConfigProvider ? createComponentVNode(2, ConfigProvider, {
    rtlEnabled: viewModel.rtlEnabled,
    children: widget
  }) : widget;
};
var WidgetProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(BaseWidgetProps), Object.getOwnPropertyDescriptors({
  _feedbackHideTimeout: 400,
  _feedbackShowTimeout: 30,
  cssText: "",
  aria: Object.freeze({}),
  classes: "",
  name: "",
  addWidgetClass: true
})));
var Widget = class extends InfernoWrapperComponent {
  get config() {
    if (this.context[ConfigContext.id]) {
      return this.context[ConfigContext.id];
    }
    return ConfigContext.defaultValue;
  }
  constructor(props) {
    super(props);
    this.widgetElementRef = createRef();
    this.state = {
      active: false,
      focused: false,
      hovered: false
    };
    this.setRootElementRef = this.setRootElementRef.bind(this);
    this.activeEffect = this.activeEffect.bind(this);
    this.inactiveEffect = this.inactiveEffect.bind(this);
    this.clickEffect = this.clickEffect.bind(this);
    this.focus = this.focus.bind(this);
    this.blur = this.blur.bind(this);
    this.activate = this.activate.bind(this);
    this.deactivate = this.deactivate.bind(this);
    this.focusInEffect = this.focusInEffect.bind(this);
    this.focusOutEffect = this.focusOutEffect.bind(this);
    this.hoverStartEffect = this.hoverStartEffect.bind(this);
    this.hoverEndEffect = this.hoverEndEffect.bind(this);
    this.keyboardEffect = this.keyboardEffect.bind(this);
    this.resizeEffect = this.resizeEffect.bind(this);
    this.windowResizeEffect = this.windowResizeEffect.bind(this);
    this.visibilityEffect = this.visibilityEffect.bind(this);
    this.checkDeprecation = this.checkDeprecation.bind(this);
    this.applyCssTextEffect = this.applyCssTextEffect.bind(this);
  }
  createEffects() {
    return [new InfernoEffect(this.setRootElementRef, []), new InfernoEffect(this.activeEffect, [this.props._feedbackShowTimeout, this.props.activeStateEnabled, this.props.activeStateUnit, this.props.disabled, this.props.onActive]), new InfernoEffect(this.inactiveEffect, [this.props._feedbackHideTimeout, this.props.activeStateEnabled, this.props.activeStateUnit, this.props.onInactive, this.state.active]), new InfernoEffect(this.clickEffect, [this.props.disabled, this.props.name, this.props.onClick]), new InfernoEffect(this.focusInEffect, [this.props.disabled, this.props.focusStateEnabled, this.props.name, this.props.onFocusIn]), new InfernoEffect(this.focusOutEffect, [this.props.focusStateEnabled, this.props.name, this.props.onFocusOut, this.state.focused]), new InfernoEffect(this.hoverStartEffect, [this.props.activeStateUnit, this.props.disabled, this.props.hoverStateEnabled, this.props.onHoverStart, this.state.active]), new InfernoEffect(this.hoverEndEffect, [this.props.activeStateUnit, this.props.hoverStateEnabled, this.props.onHoverEnd, this.state.hovered]), new InfernoEffect(this.keyboardEffect, [this.props.focusStateEnabled, this.props.onKeyDown]), new InfernoEffect(this.resizeEffect, [this.props.name, this.props.onDimensionChanged]), new InfernoEffect(this.windowResizeEffect, [this.props.onDimensionChanged]), new InfernoEffect(this.visibilityEffect, [this.props.name, this.props.onVisibilityChange]), new InfernoEffect(this.checkDeprecation, [this.props.height, this.props.width]), new InfernoEffect(this.applyCssTextEffect, [this.props.cssText]), createReRenderEffect()];
  }
  updateEffects() {
    var _this$_effects$, _this$_effects$2, _this$_effects$3, _this$_effects$4, _this$_effects$5, _this$_effects$6, _this$_effects$7, _this$_effects$8, _this$_effects$9, _this$_effects$10, _this$_effects$11, _this$_effects$12, _this$_effects$13;
    null === (_this$_effects$ = this._effects[1]) || void 0 === _this$_effects$ || _this$_effects$.update([this.props._feedbackShowTimeout, this.props.activeStateEnabled, this.props.activeStateUnit, this.props.disabled, this.props.onActive]);
    null === (_this$_effects$2 = this._effects[2]) || void 0 === _this$_effects$2 || _this$_effects$2.update([this.props._feedbackHideTimeout, this.props.activeStateEnabled, this.props.activeStateUnit, this.props.onInactive, this.state.active]);
    null === (_this$_effects$3 = this._effects[3]) || void 0 === _this$_effects$3 || _this$_effects$3.update([this.props.disabled, this.props.name, this.props.onClick]);
    null === (_this$_effects$4 = this._effects[4]) || void 0 === _this$_effects$4 || _this$_effects$4.update([this.props.disabled, this.props.focusStateEnabled, this.props.name, this.props.onFocusIn]);
    null === (_this$_effects$5 = this._effects[5]) || void 0 === _this$_effects$5 || _this$_effects$5.update([this.props.focusStateEnabled, this.props.name, this.props.onFocusOut, this.state.focused]);
    null === (_this$_effects$6 = this._effects[6]) || void 0 === _this$_effects$6 || _this$_effects$6.update([this.props.activeStateUnit, this.props.disabled, this.props.hoverStateEnabled, this.props.onHoverStart, this.state.active]);
    null === (_this$_effects$7 = this._effects[7]) || void 0 === _this$_effects$7 || _this$_effects$7.update([this.props.activeStateUnit, this.props.hoverStateEnabled, this.props.onHoverEnd, this.state.hovered]);
    null === (_this$_effects$8 = this._effects[8]) || void 0 === _this$_effects$8 || _this$_effects$8.update([this.props.focusStateEnabled, this.props.onKeyDown]);
    null === (_this$_effects$9 = this._effects[9]) || void 0 === _this$_effects$9 || _this$_effects$9.update([this.props.name, this.props.onDimensionChanged]);
    null === (_this$_effects$10 = this._effects[10]) || void 0 === _this$_effects$10 || _this$_effects$10.update([this.props.onDimensionChanged]);
    null === (_this$_effects$11 = this._effects[11]) || void 0 === _this$_effects$11 || _this$_effects$11.update([this.props.name, this.props.onVisibilityChange]);
    null === (_this$_effects$12 = this._effects[12]) || void 0 === _this$_effects$12 || _this$_effects$12.update([this.props.height, this.props.width]);
    null === (_this$_effects$13 = this._effects[13]) || void 0 === _this$_effects$13 || _this$_effects$13.update([this.props.cssText]);
  }
  setRootElementRef() {
    const {
      onRootElementRendered,
      rootElementRef
    } = this.props;
    if (rootElementRef) {
      rootElementRef.current = this.widgetElementRef.current;
    }
    null === onRootElementRendered || void 0 === onRootElementRendered || onRootElementRendered(this.widgetElementRef.current);
  }
  activeEffect() {
    const {
      _feedbackShowTimeout,
      activeStateEnabled,
      activeStateUnit,
      disabled,
      onActive
    } = this.props;
    const selector = activeStateUnit;
    if (activeStateEnabled) {
      if (!disabled) {
        return subscribeToDxActiveEvent(this.widgetElementRef.current, (event) => {
          this.setState((__state_argument) => ({
            active: true
          }));
          null === onActive || void 0 === onActive || onActive(event);
        }, {
          timeout: _feedbackShowTimeout,
          selector
        }, "UIFeedback");
      }
    }
    return;
  }
  inactiveEffect() {
    const {
      _feedbackHideTimeout,
      activeStateEnabled,
      activeStateUnit,
      onInactive
    } = this.props;
    const selector = activeStateUnit;
    if (activeStateEnabled) {
      return subscribeToDxInactiveEvent(this.widgetElementRef.current, (event) => {
        if (this.state.active) {
          this.setState((__state_argument) => ({
            active: false
          }));
          null === onInactive || void 0 === onInactive || onInactive(event);
        }
      }, {
        timeout: _feedbackHideTimeout,
        selector
      }, "UIFeedback");
    }
    return;
  }
  clickEffect() {
    const {
      disabled,
      name: name2,
      onClick
    } = this.props;
    const namespace = name2;
    if (onClick && !disabled) {
      dxClick.on(this.widgetElementRef.current, onClick, {
        namespace
      });
      return () => dxClick.off(this.widgetElementRef.current, {
        namespace
      });
    }
    return;
  }
  focusInEffect() {
    const {
      disabled,
      focusStateEnabled,
      name: name2,
      onFocusIn
    } = this.props;
    const namespace = `${name2}Focus`;
    if (focusStateEnabled) {
      if (!disabled) {
        return subscribeToDxFocusInEvent(this.widgetElementRef.current, (event) => {
          if (!event.isDefaultPrevented()) {
            this.setState((__state_argument) => ({
              focused: true
            }));
            null === onFocusIn || void 0 === onFocusIn || onFocusIn(event);
          }
        }, null, namespace);
      }
    }
    return;
  }
  focusOutEffect() {
    const {
      focusStateEnabled,
      name: name2,
      onFocusOut
    } = this.props;
    const namespace = `${name2}Focus`;
    if (focusStateEnabled) {
      return subscribeToDxFocusOutEvent(this.widgetElementRef.current, (event) => {
        if (!event.isDefaultPrevented() && this.state.focused) {
          this.setState((__state_argument) => ({
            focused: false
          }));
          null === onFocusOut || void 0 === onFocusOut || onFocusOut(event);
        }
      }, null, namespace);
    }
    return;
  }
  hoverStartEffect() {
    const {
      activeStateUnit,
      disabled,
      hoverStateEnabled,
      onHoverStart
    } = this.props;
    const selector = activeStateUnit;
    if (hoverStateEnabled) {
      if (!disabled) {
        return subscribeToDxHoverStartEvent(this.widgetElementRef.current, (event) => {
          !this.state.active && this.setState((__state_argument) => ({
            hovered: true
          }));
          null === onHoverStart || void 0 === onHoverStart || onHoverStart(event);
        }, {
          selector
        }, "UIFeedback");
      }
    }
    return;
  }
  hoverEndEffect() {
    const {
      activeStateUnit,
      hoverStateEnabled,
      onHoverEnd
    } = this.props;
    const selector = activeStateUnit;
    if (hoverStateEnabled) {
      return subscribeToDxHoverEndEvent(this.widgetElementRef.current, (event) => {
        if (this.state.hovered) {
          this.setState((__state_argument) => ({
            hovered: false
          }));
          null === onHoverEnd || void 0 === onHoverEnd || onHoverEnd(event);
        }
      }, {
        selector
      }, "UIFeedback");
    }
    return;
  }
  keyboardEffect() {
    const {
      focusStateEnabled,
      onKeyDown
    } = this.props;
    if (focusStateEnabled && onKeyDown) {
      const id = keyboard.on(this.widgetElementRef.current, this.widgetElementRef.current, (e) => onKeyDown(e));
      return () => keyboard.off(id);
    }
    return;
  }
  resizeEffect() {
    const namespace = `${this.props.name}VisibilityChange`;
    const {
      onDimensionChanged
    } = this.props;
    if (onDimensionChanged) {
      resize.on(this.widgetElementRef.current, onDimensionChanged, {
        namespace
      });
      return () => resize.off(this.widgetElementRef.current, {
        namespace
      });
    }
    return;
  }
  windowResizeEffect() {
    const {
      onDimensionChanged
    } = this.props;
    if (onDimensionChanged) {
      resize_callbacks_default.add(onDimensionChanged);
      return () => {
        resize_callbacks_default.remove(onDimensionChanged);
      };
    }
    return;
  }
  visibilityEffect() {
    const {
      name: name2,
      onVisibilityChange
    } = this.props;
    const namespace = `${name2}VisibilityChange`;
    if (onVisibilityChange) {
      visibility.on(this.widgetElementRef.current, () => onVisibilityChange(true), () => onVisibilityChange(false), {
        namespace
      });
      return () => visibility.off(this.widgetElementRef.current, {
        namespace
      });
    }
    return;
  }
  checkDeprecation() {
    const {
      height,
      width
    } = this.props;
    if (isFunction(width)) {
      errors_default.log("W0017", "width");
    }
    if (isFunction(height)) {
      errors_default.log("W0017", "height");
    }
  }
  applyCssTextEffect() {
    const {
      cssText
    } = this.props;
    if ("" !== cssText) {
      this.widgetElementRef.current.style.cssText = cssText;
    }
  }
  get shouldRenderConfigProvider() {
    const {
      rtlEnabled
    } = this.props;
    return resolveRtlEnabledDefinition(rtlEnabled, this.config);
  }
  get rtlEnabled() {
    const {
      rtlEnabled
    } = this.props;
    return resolveRtlEnabled(rtlEnabled, this.config);
  }
  get attributes() {
    const {
      aria,
      disabled,
      focusStateEnabled,
      visible
    } = this.props;
    const accessKey = focusStateEnabled && !disabled && this.props.accessKey;
    return _extends({}, extend({}, accessKey && {
      accessKey
    }), getAria(_extends({}, aria, {
      disabled,
      hidden: !visible
    })), extend({}, this.restAttributes));
  }
  get styles() {
    const {
      height,
      width
    } = this.props;
    const style = this.restAttributes.style || {};
    const computedWidth = normalizeStyleProp("width", isFunction(width) ? width() : width);
    const computedHeight = normalizeStyleProp("height", isFunction(height) ? height() : height);
    return _extends({}, style, {
      height: computedHeight ?? style.height,
      width: computedWidth ?? style.width
    });
  }
  get cssClasses() {
    const {
      activeStateEnabled,
      addWidgetClass,
      className,
      classes,
      disabled,
      focusStateEnabled,
      hoverStateEnabled,
      onVisibilityChange,
      visible
    } = this.props;
    const isFocusable = !!focusStateEnabled && !disabled;
    const isHoverable = !!hoverStateEnabled && !disabled;
    const canBeActive = !!activeStateEnabled && !disabled;
    const classesMap = {
      "dx-widget": !!addWidgetClass,
      [String(classes)]: !!classes,
      [String(className)]: !!className,
      "dx-state-disabled": !!disabled,
      "dx-state-invisible": !visible,
      "dx-state-focused": !!this.state.focused && isFocusable,
      "dx-state-active": !!this.state.active && canBeActive,
      "dx-state-hover": !!this.state.hovered && isHoverable && !this.state.active,
      "dx-rtl": !!this.rtlEnabled,
      "dx-visibility-change-handler": !!onVisibilityChange
    };
    return combineClasses(classesMap);
  }
  get tabIndex() {
    const {
      disabled,
      focusStateEnabled,
      tabIndex
    } = this.props;
    const isFocusable = focusStateEnabled && !disabled;
    return isFocusable ? tabIndex : void 0;
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded5);
    return restProps;
  }
  focus() {
    focus.trigger(this.widgetElementRef.current);
  }
  blur() {
    const activeElement = dom_adapter_default.getActiveElement(this.widgetElementRef.current);
    if (this.widgetElementRef.current === activeElement) {
      activeElement.blur();
    }
  }
  activate() {
    this.setState((__state_argument) => ({
      active: true
    }));
  }
  deactivate() {
    this.setState((__state_argument) => ({
      active: false
    }));
  }
  render() {
    const props = this.props;
    return viewFunction4({
      props: _extends({}, props),
      active: this.state.active,
      focused: this.state.focused,
      hovered: this.state.hovered,
      widgetElementRef: this.widgetElementRef,
      config: this.config,
      shouldRenderConfigProvider: this.shouldRenderConfigProvider,
      rtlEnabled: this.rtlEnabled,
      attributes: this.attributes,
      styles: this.styles,
      cssClasses: this.cssClasses,
      tabIndex: this.tabIndex,
      restAttributes: this.restAttributes
    });
  }
};
Widget.defaultProps = WidgetProps;

// node_modules/devextreme/esm/renovation/ui/button.js
var _excluded6 = ["accessKey", "activeStateEnabled", "children", "className", "disabled", "focusStateEnabled", "height", "hint", "hoverStateEnabled", "icon", "iconPosition", "iconTemplate", "onClick", "onKeyDown", "onSubmit", "pressed", "rtlEnabled", "stylingMode", "tabIndex", "template", "templateData", "text", "type", "useInkRipple", "useSubmitBehavior", "visible", "width"];
var stylingModes = ["outlined", "text", "contained"];
var getCssClasses = (model) => {
  const {
    icon,
    iconPosition,
    stylingMode,
    text,
    type
  } = model;
  const isValidStylingMode = stylingMode && stylingModes.includes(stylingMode);
  const classesMap = {
    "dx-button": true,
    [`dx-button-mode-${isValidStylingMode ? stylingMode : "contained"}`]: true,
    [`dx-button-${type ?? "normal"}`]: true,
    "dx-button-has-text": !!text,
    "dx-button-has-icon": !!icon,
    "dx-button-icon-right": "left" !== iconPosition
  };
  return combineClasses(classesMap);
};
var viewFunction5 = (viewModel) => {
  const {
    children,
    iconPosition,
    iconTemplate: IconTemplate,
    template: ButtonTemplate,
    text
  } = viewModel.props;
  const renderText = !viewModel.props.template && !children && "" !== text;
  const isIconLeft = "left" === iconPosition;
  const iconComponent = !viewModel.props.template && !children && (viewModel.iconSource || viewModel.props.iconTemplate) && createComponentVNode(2, Icon, {
    source: viewModel.iconSource,
    position: iconPosition,
    iconTemplate: IconTemplate
  });
  return normalizeProps(createComponentVNode(2, Widget, _extends({
    accessKey: viewModel.props.accessKey,
    activeStateEnabled: viewModel.props.activeStateEnabled,
    aria: viewModel.aria,
    className: viewModel.props.className,
    classes: viewModel.cssClasses,
    disabled: viewModel.props.disabled,
    focusStateEnabled: viewModel.props.focusStateEnabled,
    height: viewModel.props.height,
    hint: viewModel.props.hint,
    hoverStateEnabled: viewModel.props.hoverStateEnabled,
    onActive: viewModel.onActive,
    onClick: viewModel.onWidgetClick,
    onInactive: viewModel.onInactive,
    onKeyDown: viewModel.keyDown,
    rtlEnabled: viewModel.props.rtlEnabled,
    tabIndex: viewModel.props.tabIndex,
    visible: viewModel.props.visible,
    width: viewModel.props.width
  }, viewModel.restAttributes, {
    children: createVNode(1, "div", "dx-button-content", [viewModel.props.template && ButtonTemplate({
      data: viewModel.buttonTemplateData
    }), !viewModel.props.template && children, isIconLeft && iconComponent, renderText && createVNode(1, "span", "dx-button-text", text, 0), !isIconLeft && iconComponent, viewModel.props.useSubmitBehavior && createVNode(64, "input", "dx-button-submit-input", null, 1, {
      type: "submit",
      tabIndex: -1
    }, null, viewModel.submitInputRef), viewModel.props.useInkRipple && createComponentVNode(2, InkRipple, {
      config: viewModel.inkRippleConfig
    }, null, viewModel.inkRippleRef)], 0, null, null, viewModel.contentRef)
  }), null, viewModel.widgetRef));
};
var ButtonProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(BaseWidgetProps), Object.getOwnPropertyDescriptors({
  activeStateEnabled: true,
  hoverStateEnabled: true,
  icon: "",
  iconPosition: "left",
  stylingMode: "contained",
  text: "",
  type: "normal",
  useInkRipple: false,
  useSubmitBehavior: false,
  templateData: Object.freeze({})
})));
var defaultOptionRules = createDefaultOptionRules([{
  device: () => "desktop" === devices_default.real().deviceType && !devices_default.isSimulator(),
  options: {
    focusStateEnabled: true
  }
}, {
  device: () => isMaterial(current()),
  options: {
    useInkRipple: true
  }
}]);
var getTemplate2 = (TemplateProp) => TemplateProp && (TemplateProp.defaultProps ? (props) => normalizeProps(createComponentVNode(2, TemplateProp, _extends({}, props))) : TemplateProp);
var Button = class extends InfernoWrapperComponent {
  constructor(props) {
    super(props);
    this.state = {};
    this.contentRef = createRef();
    this.inkRippleRef = createRef();
    this.submitInputRef = createRef();
    this.widgetRef = createRef();
    this.__getterCache = {};
    this.focus = this.focus.bind(this);
    this.activate = this.activate.bind(this);
    this.deactivate = this.deactivate.bind(this);
    this.submitEffect = this.submitEffect.bind(this);
    this.onActive = this.onActive.bind(this);
    this.onInactive = this.onInactive.bind(this);
    this.onWidgetClick = this.onWidgetClick.bind(this);
    this.keyDown = this.keyDown.bind(this);
    this.emitClickEvent = this.emitClickEvent.bind(this);
  }
  createEffects() {
    return [new InfernoEffect(this.submitEffect, [this.props.onSubmit, this.props.useSubmitBehavior]), createReRenderEffect()];
  }
  updateEffects() {
    var _this$_effects$;
    null === (_this$_effects$ = this._effects[0]) || void 0 === _this$_effects$ || _this$_effects$.update([this.props.onSubmit, this.props.useSubmitBehavior]);
  }
  submitEffect() {
    const {
      onSubmit,
      useSubmitBehavior
    } = this.props;
    if (useSubmitBehavior && onSubmit) {
      click.on(this.submitInputRef.current, (event) => onSubmit({
        event,
        submitInput: this.submitInputRef.current
      }), {
        namespace: "UIFeedback"
      });
      return () => click.off(this.submitInputRef.current, {
        namespace: "UIFeedback"
      });
    }
    return;
  }
  onActive(event) {
    const {
      useInkRipple
    } = this.props;
    useInkRipple && this.inkRippleRef.current.showWave({
      element: this.contentRef.current,
      event
    });
  }
  onInactive(event) {
    const {
      useInkRipple
    } = this.props;
    useInkRipple && this.inkRippleRef.current.hideWave({
      element: this.contentRef.current,
      event
    });
  }
  onWidgetClick(event) {
    const {
      onClick,
      useSubmitBehavior
    } = this.props;
    null === onClick || void 0 === onClick || onClick({
      event
    });
    useSubmitBehavior && this.submitInputRef.current.click();
  }
  keyDown(e) {
    const {
      onKeyDown
    } = this.props;
    const {
      keyName,
      originalEvent,
      which
    } = e;
    const result2 = null === onKeyDown || void 0 === onKeyDown ? void 0 : onKeyDown(e);
    if (null !== result2 && void 0 !== result2 && result2.cancel) {
      return result2;
    }
    if ("space" === keyName || "space" === which || "enter" === keyName || "enter" === which) {
      originalEvent.preventDefault();
      this.emitClickEvent();
    }
    return;
  }
  emitClickEvent() {
    this.contentRef.current.click();
  }
  get aria() {
    const {
      icon,
      text
    } = this.props;
    let label = text ?? "";
    if (!text && icon) {
      const iconSource = getImageSourceType(icon);
      switch (iconSource) {
        case "image": {
          const notURLRegexp = /^(?!(?:https?:\/\/)|(?:ftp:\/\/)|(?:www\.))[^\s]+$/;
          const isPathToImage = !icon.includes("base64") && notURLRegexp.test(icon);
          label = isPathToImage ? icon.replace(/.+\/([^.]+)\..+$/, "$1") : "";
          break;
        }
        case "dxIcon":
          label = message_default.format(camelize(icon, true)) || icon;
          break;
        case "fontIcon":
          label = icon;
          break;
        case "svg": {
          var _titleRegexp$exec;
          const titleRegexp = /<title>(.*?)<\/title>/;
          const title = (null === (_titleRegexp$exec = titleRegexp.exec(icon)) || void 0 === _titleRegexp$exec ? void 0 : _titleRegexp$exec[1]) ?? "";
          label = title;
          break;
        }
      }
    }
    return _extends({
      role: "button"
    }, label ? {
      label
    } : {});
  }
  get cssClasses() {
    return getCssClasses(this.props);
  }
  get iconSource() {
    const {
      icon
    } = this.props;
    return icon ?? "";
  }
  get inkRippleConfig() {
    if (void 0 !== this.__getterCache.inkRippleConfig) {
      return this.__getterCache.inkRippleConfig;
    }
    return this.__getterCache.inkRippleConfig = (() => {
      const {
        icon,
        text
      } = this.props;
      return !text && icon ? {
        isCentered: true,
        useHoldAnimation: false,
        waveSizeCoefficient: 1
      } : {};
    })();
  }
  get buttonTemplateData() {
    const {
      icon,
      templateData,
      text
    } = this.props;
    return _extends({
      icon,
      text
    }, templateData);
  }
  get restAttributes() {
    const _this$props = this.props, restProps = _objectWithoutPropertiesLoose(_this$props, _excluded6);
    return restProps;
  }
  focus() {
    this.widgetRef.current.focus();
  }
  activate() {
    this.widgetRef.current.activate();
  }
  deactivate() {
    this.widgetRef.current.deactivate();
  }
  componentWillUpdate(nextProps, nextState, context) {
    super.componentWillUpdate();
    if (this.props.icon !== nextProps.icon || this.props.text !== nextProps.text) {
      this.__getterCache.inkRippleConfig = void 0;
    }
  }
  render() {
    const props = this.props;
    return viewFunction5({
      props: _extends({}, props, {
        template: getTemplate2(props.template),
        iconTemplate: getTemplate2(props.iconTemplate)
      }),
      contentRef: this.contentRef,
      submitInputRef: this.submitInputRef,
      inkRippleRef: this.inkRippleRef,
      widgetRef: this.widgetRef,
      onActive: this.onActive,
      onInactive: this.onInactive,
      onWidgetClick: this.onWidgetClick,
      keyDown: this.keyDown,
      emitClickEvent: this.emitClickEvent,
      aria: this.aria,
      cssClasses: this.cssClasses,
      iconSource: this.iconSource,
      inkRippleConfig: this.inkRippleConfig,
      buttonTemplateData: this.buttonTemplateData,
      restAttributes: this.restAttributes
    });
  }
};
Button.defaultProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(ButtonProps), Object.getOwnPropertyDescriptors(_extends({}, convertRulesToOptions(defaultOptionRules)))));
var __defaultOptionRules = [];
function defaultOptions(rule) {
  __defaultOptionRules.push(rule);
  Button.defaultProps = Object.create(Object.prototype, Object.assign(Object.getOwnPropertyDescriptors(Button.defaultProps), Object.getOwnPropertyDescriptors(convertRulesToOptions(defaultOptionRules)), Object.getOwnPropertyDescriptors(convertRulesToOptions(__defaultOptionRules))));
}

// node_modules/devextreme/esm/renovation/ui/button.j.js
var Button2 = class extends ButtonWrapper {
  getProps() {
    const props = super.getProps();
    props.onKeyDown = this._wrapKeyDownHandler(props.onKeyDown);
    return props;
  }
  focus() {
    var _this$viewRef;
    return null === (_this$viewRef = this.viewRef) || void 0 === _this$viewRef ? void 0 : _this$viewRef.focus(...arguments);
  }
  activate() {
    var _this$viewRef2;
    return null === (_this$viewRef2 = this.viewRef) || void 0 === _this$viewRef2 ? void 0 : _this$viewRef2.activate(...arguments);
  }
  deactivate() {
    var _this$viewRef3;
    return null === (_this$viewRef3 = this.viewRef) || void 0 === _this$viewRef3 ? void 0 : _this$viewRef3.deactivate(...arguments);
  }
  _getActionConfigs() {
    return {
      onClick: {
        excludeValidators: ["readOnly"]
      },
      onSubmit: {}
    };
  }
  get _propsInfo() {
    return {
      twoWay: [],
      allowNull: [],
      elements: ["onSubmit"],
      templates: ["template", "iconTemplate"],
      props: ["activeStateEnabled", "hoverStateEnabled", "icon", "iconPosition", "onClick", "onSubmit", "pressed", "stylingMode", "template", "iconTemplate", "text", "type", "useInkRipple", "useSubmitBehavior", "templateData", "className", "accessKey", "disabled", "focusStateEnabled", "height", "hint", "onKeyDown", "rtlEnabled", "tabIndex", "visible", "width"]
    };
  }
  get _viewComponent() {
    return Button;
  }
};
component_registrator_default("dxButton", Button2);
Button2.defaultOptions = defaultOptions;

// node_modules/devextreme/esm/ui/button.js
var button_default = Button2;

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.live_update.js
init_dom_adapter();
init_renderer();

// node_modules/devextreme/esm/core/utils/array_compare.js
init_type();
var getKeyWrapper = function(item, getKey) {
  const key = getKey(item);
  if (isObject(key)) {
    try {
      return JSON.stringify(key);
    } catch (e) {
      return key;
    }
  }
  return key;
};
var getSameNewByOld = function(oldItem, newItems, newIndexByKey, getKey) {
  const key = getKeyWrapper(oldItem, getKey);
  return newItems[newIndexByKey[key]];
};
var isKeysEqual = function(oldKeys, newKeys) {
  if (oldKeys.length !== newKeys.length) {
    return false;
  }
  for (let i = 0; i < newKeys.length; i++) {
    if (oldKeys[i] !== newKeys[i]) {
      return false;
    }
  }
  return true;
};
var findChanges = function(oldItems, newItems, getKey, isItemEquals) {
  const oldIndexByKey = {};
  const newIndexByKey = {};
  let addedCount = 0;
  let removeCount = 0;
  const result2 = [];
  oldItems.forEach(function(item, index) {
    const key = getKeyWrapper(item, getKey);
    oldIndexByKey[key] = index;
  });
  newItems.forEach(function(item, index) {
    const key = getKeyWrapper(item, getKey);
    newIndexByKey[key] = index;
  });
  const itemCount = Math.max(oldItems.length, newItems.length);
  for (let index = 0; index < itemCount + addedCount; index++) {
    const newItem = newItems[index];
    const oldNextIndex = index - addedCount + removeCount;
    const nextOldItem = oldItems[oldNextIndex];
    const isRemoved = !newItem || nextOldItem && !getSameNewByOld(nextOldItem, newItems, newIndexByKey, getKey);
    if (isRemoved) {
      if (nextOldItem) {
        result2.push({
          type: "remove",
          key: getKey(nextOldItem),
          index,
          oldItem: nextOldItem
        });
        removeCount++;
        index--;
      }
    } else {
      const key = getKeyWrapper(newItem, getKey);
      const oldIndex = oldIndexByKey[key];
      const oldItem = oldItems[oldIndex];
      if (!oldItem) {
        addedCount++;
        result2.push({
          type: "insert",
          data: newItem,
          index
        });
      } else if (oldIndex === oldNextIndex) {
        if (!isItemEquals(oldItem, newItem)) {
          result2.push({
            type: "update",
            data: newItem,
            key: getKey(newItem),
            index,
            oldItem
          });
        }
      } else {
        return;
      }
    }
  }
  return result2;
};

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.live_update.js
init_common();
init_deferred();
init_extend();
init_iterator();
init_array_utils();
init_utils();

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.edit.js
init_renderer();
init_common();
init_data();
init_deferred();
init_extend();
init_iterator();
init_type();

// node_modules/devextreme/esm/data/data_source/data_source.js
init_extends();
init_class();
init_extend();
init_common();
init_iterator();
init_type();
init_utils();
init_array_utils();
init_custom_store();
init_events_strategy();
init_errors2();

// node_modules/devextreme/esm/core/utils/queue.js
init_errors();
init_deferred();
function createQueue(discardPendingTasks) {
  let _tasks = [];
  let _busy = false;
  function exec() {
    while (_tasks.length) {
      _busy = true;
      const task = _tasks.shift();
      const result2 = task();
      if (void 0 === result2) {
        continue;
      }
      if (result2.then) {
        when(result2).always(exec);
        return;
      }
      throw errors_default.Error("E0015");
    }
    _busy = false;
  }
  return {
    add: function(task, removeTaskCallback) {
      if (!discardPendingTasks) {
        _tasks.push(task);
      } else {
        if (_tasks[0] && removeTaskCallback) {
          removeTaskCallback(_tasks[0]);
        }
        _tasks = [task];
      }
      if (!_busy) {
        exec();
      }
    },
    busy: function() {
      return _busy;
    }
  };
}
var enqueue = createQueue().add;

// node_modules/devextreme/esm/data/data_source/data_source.js
init_deferred();

// node_modules/devextreme/esm/data/data_source/utils.js
init_extends();
init_ajax();
init_abstract_store();

// node_modules/devextreme/esm/data/array_store.js
init_utils();
init_errors2();
init_abstract_store();
init_array_utils();
var ArrayStore = abstract_store_default.inherit({
  ctor: function(options2) {
    if (Array.isArray(options2)) {
      options2 = {
        data: options2
      };
    } else {
      options2 = options2 || {};
    }
    this.callBase(options2);
    const initialArray = options2.data;
    if (initialArray && !Array.isArray(initialArray)) {
      throw errors.Error("E4006");
    }
    this._array = initialArray || [];
  },
  createQuery: function() {
    return query_default(this._array, {
      errorHandler: this._errorHandler
    });
  },
  _byKeyImpl: function(key) {
    const index = indexByKey(this, this._array, key);
    if (-1 === index) {
      return rejectedPromise(errors.Error("E4009"));
    }
    return trivialPromise(this._array[index]);
  },
  _insertImpl: function(values) {
    return insert(this, this._array, values);
  },
  _pushImpl: function(changes) {
    applyBatch({
      keyInfo: this,
      data: this._array,
      changes
    });
  },
  _updateImpl: function(key, values) {
    return update(this, this._array, key, values);
  },
  _removeImpl: function(key) {
    return remove(this, this._array, key);
  },
  clear: function() {
    this._eventsStrategy.fireEvent("modifying");
    this._array = [];
    this._eventsStrategy.fireEvent("modified");
  }
}, "array");
var array_store_default = ArrayStore;

// node_modules/devextreme/esm/data/data_source/utils.js
init_iterator();
init_custom_store();
init_extend();
init_type();
init_utils();
var _excluded7 = ["items"];
var CANCELED_TOKEN = "canceled";
var isPending = (deferred) => "pending" === deferred.state();
var normalizeStoreLoadOptionAccessorArguments = (originalArguments) => {
  switch (originalArguments.length) {
    case 0:
      return;
    case 1:
      return originalArguments[0];
  }
  return [].slice.call(originalArguments);
};
var mapGroup = (group, level, mapper) => map(group, (item) => {
  const restItem = _objectWithoutPropertiesLoose(item, _excluded7);
  return _extends({}, restItem, {
    items: mapRecursive(item.items, level - 1, mapper)
  });
});
var mapRecursive = (items, level, mapper) => {
  if (!Array.isArray(items)) {
    return items;
  }
  return level ? mapGroup(items, level, mapper) : map(items, mapper);
};
var mapDataRespectingGrouping = (items, mapper, groupInfo) => {
  const level = groupInfo ? normalizeSortingInfo(groupInfo).length : 0;
  return mapRecursive(items, level, mapper);
};
var normalizeLoadResult = (data, extra) => {
  var _data;
  if (null !== (_data = data) && void 0 !== _data && _data.data) {
    extra = data;
    data = data.data;
  }
  if (!Array.isArray(data)) {
    data = [data];
  }
  return {
    data,
    extra
  };
};
var createCustomStoreFromLoadFunc = (options2) => {
  const storeConfig = {};
  each(["useDefaultSearch", "key", "load", "loadMode", "cacheRawData", "byKey", "lookup", "totalCount", "insert", "update", "remove"], function() {
    storeConfig[this] = options2[this];
    delete options2[this];
  });
  return new custom_store_default(storeConfig);
};
var createStoreFromConfig = (storeConfig) => {
  const alias = storeConfig.type;
  delete storeConfig.type;
  return abstract_store_default.create(alias, storeConfig);
};
var createCustomStoreFromUrl = (url, normalizationOptions) => new custom_store_default({
  load: () => ajax_default.sendRequest({
    url,
    dataType: "json"
  }),
  loadMode: null === normalizationOptions || void 0 === normalizationOptions ? void 0 : normalizationOptions.fromUrlLoadMode
});
var normalizeDataSourceOptions = (options2, normalizationOptions) => {
  let store;
  if ("string" === typeof options2) {
    options2 = {
      paginate: false,
      store: createCustomStoreFromUrl(options2, normalizationOptions)
    };
  }
  if (void 0 === options2) {
    options2 = [];
  }
  if (Array.isArray(options2) || options2 instanceof abstract_store_default) {
    options2 = {
      store: options2
    };
  } else {
    options2 = extend({}, options2);
  }
  if (void 0 === options2.store) {
    options2.store = [];
  }
  store = options2.store;
  if ("load" in options2) {
    store = createCustomStoreFromLoadFunc(options2);
  } else if (Array.isArray(store)) {
    store = new array_store_default(store);
  } else if (isPlainObject(store)) {
    store = createStoreFromConfig(extend({}, store));
  }
  options2.store = store;
  return options2;
};

// node_modules/devextreme/esm/data/data_source/operation_manager.js
var OperationManager = class {
  constructor() {
    this._counter = -1;
    this._deferreds = {};
  }
  add(deferred) {
    this._counter++;
    this._deferreds[this._counter] = deferred;
    return this._counter;
  }
  remove(operationId) {
    return delete this._deferreds[operationId];
  }
  cancel(operationId) {
    if (operationId in this._deferreds) {
      this._deferreds[operationId].reject(CANCELED_TOKEN);
      return true;
    }
    return false;
  }
  cancelAll() {
    while (this._counter > -1) {
      this.cancel(this._counter);
      this._counter--;
    }
  }
};

// node_modules/devextreme/esm/data/data_source/data_source.js
var DataSource = class_default.inherit({
  ctor(options2) {
    options2 = normalizeDataSourceOptions(options2);
    this._eventsStrategy = new EventsStrategy(this, {
      syncStrategy: true
    });
    this._store = options2.store;
    this._changedTime = 0;
    const needThrottling = 0 !== options2.pushAggregationTimeout;
    if (needThrottling) {
      const throttlingTimeout = void 0 === options2.pushAggregationTimeout ? () => 5 * this._changedTime : options2.pushAggregationTimeout;
      let pushDeferred;
      let lastPushWaiters;
      const throttlingPushHandler = throttleChanges((changes) => {
        pushDeferred.resolve();
        const storePushPending = when(...lastPushWaiters);
        storePushPending.done(() => this._onPush(changes));
        lastPushWaiters = void 0;
        pushDeferred = void 0;
      }, throttlingTimeout);
      this._onPushHandler = (args) => {
        this._aggregationTimeoutId = throttlingPushHandler(args.changes);
        if (!pushDeferred) {
          pushDeferred = new Deferred();
        }
        lastPushWaiters = args.waitFor;
        args.waitFor.push(pushDeferred.promise());
      };
      this._store.on("beforePushAggregation", this._onPushHandler);
    } else {
      this._onPushHandler = (changes) => this._onPush(changes);
      this._store.on("push", this._onPushHandler);
    }
    this._storeLoadOptions = this._extractLoadOptions(options2);
    this._mapFunc = options2.map;
    this._postProcessFunc = options2.postProcess;
    this._pageIndex = void 0 !== options2.pageIndex ? options2.pageIndex : 0;
    this._pageSize = void 0 !== options2.pageSize ? options2.pageSize : 20;
    this._loadingCount = 0;
    this._loadQueue = this._createLoadQueue();
    this._searchValue = "searchValue" in options2 ? options2.searchValue : null;
    this._searchOperation = options2.searchOperation || "contains";
    this._searchExpr = options2.searchExpr;
    this._paginate = options2.paginate;
    this._reshapeOnPush = options2.reshapeOnPush ?? false;
    each(["onChanged", "onLoadError", "onLoadingChanged", "onCustomizeLoadResult", "onCustomizeStoreLoadOptions"], (_, optionName) => {
      if (optionName in options2) {
        this.on(optionName.substr(2, 1).toLowerCase() + optionName.substr(3), options2[optionName]);
      }
    });
    this._operationManager = new OperationManager();
    this._init();
  },
  _init() {
    this._items = [];
    this._userData = {};
    this._totalCount = -1;
    this._isLoaded = false;
    if (!isDefined(this._paginate)) {
      this._paginate = !this.group();
    }
    this._isLastPage = !this._paginate;
  },
  dispose() {
    var _this$_delayedLoadTas;
    this._store.off("beforePushAggregation", this._onPushHandler);
    this._store.off("push", this._onPushHandler);
    this._eventsStrategy.dispose();
    clearTimeout(this._aggregationTimeoutId);
    null === (_this$_delayedLoadTas = this._delayedLoadTask) || void 0 === _this$_delayedLoadTas || _this$_delayedLoadTas.abort();
    this._operationManager.cancelAll();
    delete this._store;
    delete this._items;
    delete this._delayedLoadTask;
    this._disposed = true;
  },
  _extractLoadOptions(options2) {
    const result2 = {};
    let names = ["sort", "filter", "langParams", "select", "group", "requireTotalCount"];
    const customNames = this._store._customLoadOptions();
    if (customNames) {
      names = names.concat(customNames);
    }
    each(names, function() {
      result2[this] = options2[this];
    });
    return result2;
  },
  loadOptions() {
    return this._storeLoadOptions;
  },
  items() {
    return this._items;
  },
  pageIndex(newIndex) {
    if (!isNumeric(newIndex)) {
      return this._pageIndex;
    }
    this._pageIndex = newIndex;
    this._isLastPage = !this._paginate;
  },
  paginate(value) {
    if (!isBoolean(value)) {
      return this._paginate;
    }
    if (this._paginate !== value) {
      this._paginate = value;
      this.pageIndex(0);
    }
  },
  pageSize(value) {
    if (!isNumeric(value)) {
      return this._pageSize;
    }
    this._pageSize = value;
  },
  isLastPage() {
    return this._isLastPage;
  },
  generateStoreLoadOptionAccessor(optionName) {
    return (args) => {
      const normalizedArgs = normalizeStoreLoadOptionAccessorArguments(args);
      if (void 0 === normalizedArgs) {
        return this._storeLoadOptions[optionName];
      }
      this._storeLoadOptions[optionName] = normalizedArgs;
    };
  },
  sort() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return this.generateStoreLoadOptionAccessor("sort")(args);
  },
  filter() {
    const newFilter = normalizeStoreLoadOptionAccessorArguments(arguments);
    if (void 0 === newFilter) {
      return this._storeLoadOptions.filter;
    }
    this._storeLoadOptions.filter = newFilter;
    this.pageIndex(0);
  },
  group() {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    return this.generateStoreLoadOptionAccessor("group")(args);
  },
  select() {
    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }
    return this.generateStoreLoadOptionAccessor("select")(args);
  },
  requireTotalCount(value) {
    if (!isBoolean(value)) {
      return this._storeLoadOptions.requireTotalCount;
    }
    this._storeLoadOptions.requireTotalCount = value;
  },
  searchValue(value) {
    if (arguments.length < 1) {
      return this._searchValue;
    }
    this._searchValue = value;
    this.pageIndex(0);
  },
  searchOperation(op) {
    if (!isString(op)) {
      return this._searchOperation;
    }
    this._searchOperation = op;
    this.pageIndex(0);
  },
  searchExpr(expr) {
    const argc = arguments.length;
    if (0 === argc) {
      return this._searchExpr;
    }
    if (argc > 1) {
      expr = [].slice.call(arguments);
    }
    this._searchExpr = expr;
    this.pageIndex(0);
  },
  store() {
    return this._store;
  },
  key() {
    var _this$_store;
    return null === (_this$_store = this._store) || void 0 === _this$_store ? void 0 : _this$_store.key();
  },
  totalCount() {
    return this._totalCount;
  },
  isLoaded() {
    return this._isLoaded;
  },
  isLoading() {
    return this._loadingCount > 0;
  },
  beginLoading() {
    this._changeLoadingCount(1);
  },
  endLoading() {
    this._changeLoadingCount(-1);
  },
  _createLoadQueue: () => createQueue(),
  _changeLoadingCount(increment) {
    const oldLoading = this.isLoading();
    this._loadingCount += increment;
    const newLoading = this.isLoading();
    if (oldLoading ^ newLoading) {
      this._eventsStrategy.fireEvent("loadingChanged", [newLoading]);
    }
  },
  _scheduleLoadCallbacks(deferred) {
    this.beginLoading();
    deferred.always(() => {
      this.endLoading();
    });
  },
  _scheduleFailCallbacks(deferred) {
    var _this = this;
    deferred.fail(function() {
      for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        args[_key4] = arguments[_key4];
      }
      if (args[0] === CANCELED_TOKEN) {
        return;
      }
      _this._eventsStrategy.fireEvent("loadError", args);
    });
  },
  _fireChanged(args) {
    const date = /* @__PURE__ */ new Date();
    this._eventsStrategy.fireEvent("changed", args);
    this._changedTime = /* @__PURE__ */ new Date() - date;
  },
  _scheduleChangedCallbacks(deferred) {
    deferred.done(() => this._fireChanged());
  },
  loadSingle(propName, propValue) {
    const d = new Deferred();
    const key = this.key();
    const store = this._store;
    const options2 = this._createStoreLoadOptions();
    this._scheduleFailCallbacks(d);
    if (arguments.length < 2) {
      propValue = propName;
      propName = key;
    }
    delete options2.skip;
    delete options2.group;
    delete options2.refresh;
    delete options2.pageIndex;
    delete options2.searchString;
    (() => {
      if (propName === key || store instanceof custom_store_default && !store._byKeyViaLoad()) {
        return store.byKey(propValue, options2);
      }
      options2.take = 1;
      options2.filter = options2.filter ? [options2.filter, [propName, propValue]] : [propName, propValue];
      return store.load(options2);
    })().fail(d.reject).done((data) => {
      const isEmptyArray = Array.isArray(data) && !data.length;
      if (!isDefined(data) || isEmptyArray) {
        d.reject(new errors.Error("E4009"));
      } else {
        if (!Array.isArray(data)) {
          data = [data];
        }
        d.resolve(this._applyMapFunction(data)[0]);
      }
    });
    return d.promise();
  },
  load() {
    const d = new Deferred();
    const loadTask = () => {
      if (this._disposed) {
        return;
      }
      if (!isPending(d)) {
        return;
      }
      return this._loadFromStore(loadOperation, d);
    };
    this._scheduleLoadCallbacks(d);
    this._scheduleFailCallbacks(d);
    this._scheduleChangedCallbacks(d);
    const loadOperation = this._createLoadOperation(d);
    this._eventsStrategy.fireEvent("customizeStoreLoadOptions", [loadOperation]);
    this._loadQueue.add(() => {
      if ("number" === typeof loadOperation.delay) {
        this._delayedLoadTask = executeAsync(loadTask, loadOperation.delay);
      } else {
        loadTask();
      }
      return d.promise();
    });
    return d.promise({
      operationId: loadOperation.operationId
    });
  },
  _onPush(changes) {
    if (this._reshapeOnPush) {
      this.load();
    } else {
      const changingArgs = {
        changes
      };
      this._eventsStrategy.fireEvent("changing", [changingArgs]);
      const group = this.group();
      const items = this.items();
      let groupLevel = 0;
      let dataSourceChanges = this.paginate() || group ? changes.filter((item) => "update" === item.type) : changes;
      if (group) {
        groupLevel = Array.isArray(group) ? group.length : 1;
      }
      if (this._mapFunc) {
        dataSourceChanges.forEach((item) => {
          if ("insert" === item.type) {
            item.data = this._mapFunc(item.data);
          }
        });
      }
      if (changingArgs.postProcessChanges) {
        dataSourceChanges = changingArgs.postProcessChanges(dataSourceChanges);
      }
      applyBatch({
        keyInfo: this.store(),
        data: items,
        changes: dataSourceChanges,
        groupCount: groupLevel,
        useInsertIndex: true
      });
      this._fireChanged([{
        changes
      }]);
    }
  },
  _createLoadOperation(deferred) {
    const operationId = this._operationManager.add(deferred);
    const storeLoadOptions = this._createStoreLoadOptions();
    if (this._store && !isEmptyObject(null === storeLoadOptions || void 0 === storeLoadOptions ? void 0 : storeLoadOptions.langParams)) {
      this._store._langParams = _extends({}, this._store._langParams, storeLoadOptions.langParams);
    }
    deferred.always(() => this._operationManager.remove(operationId));
    return {
      operationId,
      storeLoadOptions
    };
  },
  reload() {
    const store = this.store();
    store._clearCache();
    this._init();
    return this.load();
  },
  cancel(operationId) {
    return this._operationManager.cancel(operationId);
  },
  cancelAll() {
    return this._operationManager.cancelAll();
  },
  _addSearchOptions(storeLoadOptions) {
    if (this._disposed) {
      return;
    }
    if (this.store()._useDefaultSearch) {
      this._addSearchFilter(storeLoadOptions);
    } else {
      storeLoadOptions.searchOperation = this._searchOperation;
      storeLoadOptions.searchValue = this._searchValue;
      storeLoadOptions.searchExpr = this._searchExpr;
    }
  },
  _createStoreLoadOptions() {
    const result2 = extend({}, this._storeLoadOptions);
    this._addSearchOptions(result2);
    if (this._paginate) {
      if (this._pageSize) {
        result2.skip = this._pageIndex * this._pageSize;
        result2.take = this._pageSize;
      }
    }
    result2.userData = this._userData;
    return result2;
  },
  _addSearchFilter(storeLoadOptions) {
    const value = this._searchValue;
    const op = this._searchOperation;
    let selector = this._searchExpr;
    const searchFilter = [];
    if (!value) {
      return;
    }
    if (!selector) {
      selector = "this";
    }
    if (!Array.isArray(selector)) {
      selector = [selector];
    }
    each(selector, function(i, item) {
      if (searchFilter.length) {
        searchFilter.push("or");
      }
      searchFilter.push([item, op, value]);
    });
    if (storeLoadOptions.filter) {
      storeLoadOptions.filter = [searchFilter, storeLoadOptions.filter];
    } else {
      storeLoadOptions.filter = searchFilter;
    }
  },
  _loadFromStore(loadOptions, pendingDeferred) {
    const handleSuccess = (data, extra) => {
      if (this._disposed) {
        return;
      }
      if (!isPending(pendingDeferred)) {
        return;
      }
      const loadResult = extend(normalizeLoadResult(data, extra), loadOptions);
      this._eventsStrategy.fireEvent("customizeLoadResult", [loadResult]);
      when(loadResult.data).done((data2) => {
        loadResult.data = data2;
        this._processStoreLoadResult(loadResult, pendingDeferred);
      }).fail(pendingDeferred.reject);
    };
    if (loadOptions.data) {
      return new Deferred().resolve(loadOptions.data).done(handleSuccess);
    }
    return this.store().load(loadOptions.storeLoadOptions).done(handleSuccess).fail(pendingDeferred.reject);
  },
  _processStoreLoadResult(loadResult, pendingDeferred) {
    let data = loadResult.data;
    let extra = loadResult.extra;
    const storeLoadOptions = loadResult.storeLoadOptions;
    const resolvePendingDeferred = () => {
      this._isLoaded = true;
      this._totalCount = isFinite(extra.totalCount) ? extra.totalCount : -1;
      return pendingDeferred.resolve(data, extra);
    };
    const proceedLoadingTotalCount = () => {
      this.store().totalCount(storeLoadOptions).done(function(count) {
        extra.totalCount = count;
        resolvePendingDeferred();
      }).fail(pendingDeferred.reject);
    };
    if (this._disposed) {
      return;
    }
    data = this._applyPostProcessFunction(this._applyMapFunction(data));
    if (!isObject(extra)) {
      extra = {};
    }
    this._items = data;
    if (!data.length || !this._paginate || this._pageSize && data.length < this._pageSize) {
      this._isLastPage = true;
    }
    if (storeLoadOptions.requireTotalCount && !isFinite(extra.totalCount)) {
      proceedLoadingTotalCount();
    } else {
      resolvePendingDeferred();
    }
  },
  _applyMapFunction(data) {
    if (this._mapFunc) {
      return mapDataRespectingGrouping(data, this._mapFunc, this.group());
    }
    return data;
  },
  _applyPostProcessFunction(data) {
    if (this._postProcessFunc) {
      return this._postProcessFunc(data);
    }
    return data;
  },
  on(eventName, eventHandler) {
    this._eventsStrategy.on(eventName, eventHandler);
    return this;
  },
  off(eventName, eventHandler) {
    this._eventsStrategy.off(eventName, eventHandler);
    return this;
  }
});

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.edit.js
init_events_engine();

// node_modules/devextreme/esm/__internal/ui/selection/m_selection.js
init_common();
init_deferred();
init_extend();
init_type();

// node_modules/devextreme/esm/__internal/ui/selection/m_selection.strategy.deferred.js
init_deferred();
init_type();

// node_modules/devextreme/esm/__internal/ui/selection/m_selection.strategy.js
init_common();
init_deferred();
init_type();
var SelectionStrategy = class {
  constructor(options2) {
    this.options = options2;
    this._setOption("disabledItemKeys", []);
    this._clearItemKeys();
  }
  _clearItemKeys() {
    this._setOption("addedItemKeys", []);
    this._setOption("removedItemKeys", []);
    this._setOption("removedItems", []);
    this._setOption("addedItems", []);
  }
  validate() {
  }
  _setOption(name2, value) {
    this.options[name2] = value;
  }
  onSelectionChanged() {
    const {
      addedItemKeys
    } = this.options;
    const {
      removedItemKeys
    } = this.options;
    const {
      addedItems
    } = this.options;
    const {
      removedItems
    } = this.options;
    const {
      selectedItems
    } = this.options;
    const {
      selectedItemKeys
    } = this.options;
    const onSelectionChanged = this.options.onSelectionChanged || noop;
    this._clearItemKeys();
    onSelectionChanged({
      selectedItems,
      selectedItemKeys,
      addedItemKeys,
      removedItemKeys,
      addedItems,
      removedItems
    });
  }
  equalKeys(key1, key2) {
    if (this.options.equalByReference) {
      if (isObject(key1) && isObject(key2)) {
        return key1 === key2;
      }
    }
    return equalByValue(key1, key2);
  }
  getSelectableItems(items) {
    return items.filter((item) => !(null !== item && void 0 !== item && item.disabled));
  }
  _clearSelection(keys, preserve, isDeselect, isSelectAll) {
    keys = keys || [];
    keys = Array.isArray(keys) ? keys : [keys];
    this.validate();
    return this.selectedItemKeys(keys, preserve, isDeselect, isSelectAll);
  }
  _removeTemplateProperty(remoteFilter) {
    if (Array.isArray(remoteFilter)) {
      return remoteFilter.map((f) => this._removeTemplateProperty(f));
    }
    if (isObject(remoteFilter)) {
      delete remoteFilter.template;
    }
    return remoteFilter;
  }
  _loadFilteredData(remoteFilter, localFilter, select, isSelectAll) {
    const filterLength = encodeURI(JSON.stringify(this._removeTemplateProperty(remoteFilter))).length;
    const needLoadAllData = this.options.maxFilterLengthInRequest && filterLength > this.options.maxFilterLengthInRequest;
    const deferred = Deferred();
    const loadOptions = {
      filter: needLoadAllData ? void 0 : remoteFilter,
      select: needLoadAllData ? this.options.dataFields() : select || this.options.dataFields()
    };
    if (remoteFilter && 0 === remoteFilter.length) {
      deferred.resolve([]);
    } else {
      this.options.load(loadOptions).done((items) => {
        let filteredItems = isPlainObject(items) ? items.data : items;
        if (localFilter && !isSelectAll) {
          filteredItems = filteredItems.filter(localFilter);
        } else if (needLoadAllData) {
          filteredItems = query_default(filteredItems).filter(remoteFilter).toArray();
        }
        deferred.resolve(filteredItems);
      }).fail(deferred.reject.bind(deferred));
    }
    return deferred;
  }
  updateSelectedItemKeyHash(keys) {
    for (let i = 0; i < keys.length; i++) {
      const keyHash = getKeyHash(keys[i]);
      if (!isObject(keyHash)) {
        this.options.keyHashIndices[keyHash] = this.options.keyHashIndices[keyHash] || [];
        const keyIndices = this.options.keyHashIndices[keyHash];
        keyIndices.push(i);
      }
    }
  }
  _isAnyItemSelected(items) {
    for (let i = 0; i < items.length; i++) {
      if (this.options.isItemSelected(items[i])) {
        return;
      }
    }
    return false;
  }
  _getFullSelectAllState() {
    const items = this.options.plainItems();
    const dataFilter = this.options.filter();
    let selectedItems = this.options.ignoreDisabledItems ? this.options.selectedItems : this.options.selectedItems.filter((item) => !(null !== item && void 0 !== item && item.disabled));
    if (dataFilter) {
      selectedItems = query_default(selectedItems).filter(dataFilter).toArray();
    }
    const selectedItemsLength = selectedItems.length;
    const disabledItemsLength = items.length - this.getSelectableItems(items).length;
    if (!selectedItemsLength) {
      return this._isAnyItemSelected(items);
    }
    if (selectedItemsLength >= this.options.totalCount() - disabledItemsLength) {
      return true;
    }
    return;
  }
  _getVisibleSelectAllState() {
    const items = this.getSelectableItems(this.options.plainItems());
    let hasSelectedItems = false;
    let hasUnselectedItems = false;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const itemData = this.options.getItemData(item);
      const key = this.options.keyOf(itemData);
      if (this.options.isSelectableItem(item)) {
        if (this.isItemKeySelected(key)) {
          hasSelectedItems = true;
        } else {
          hasUnselectedItems = true;
        }
      }
    }
    if (hasSelectedItems) {
      return !hasUnselectedItems ? true : void 0;
    }
    return false;
  }
};

// node_modules/devextreme/esm/__internal/ui/selection/m_selection.strategy.deferred.js
var DeferredStrategy = class extends SelectionStrategy {
  getSelectedItems() {
    return this._loadFilteredData(this.options.selectionFilter);
  }
  getSelectedItemKeys() {
    const d = Deferred();
    const that = this;
    const key = this.options.key();
    const select = isString(key) ? [key] : key;
    this._loadFilteredData(this.options.selectionFilter, null, select).done((items) => {
      const keys = items.map((item) => that.options.keyOf(item));
      d.resolve(keys);
    }).fail(d.reject);
    return d.promise();
  }
  selectedItemKeys(keys, preserve, isDeselect, isSelectAll) {
    if (isSelectAll) {
      const filter = this.options.filter();
      const needResetSelectionFilter = !filter || JSON.stringify(filter) === JSON.stringify(this.options.selectionFilter) && isDeselect;
      if (needResetSelectionFilter) {
        this._setOption("selectionFilter", isDeselect ? [] : null);
      } else {
        this._addSelectionFilter(isDeselect, filter, isSelectAll);
      }
    } else {
      if (!preserve) {
        this._setOption("selectionFilter", []);
      }
      for (let i = 0; i < keys.length; i++) {
        if (isDeselect) {
          this.removeSelectedItem(keys[i]);
        } else {
          this.addSelectedItem(keys[i], isSelectAll, !preserve);
        }
      }
    }
    this.onSelectionChanged();
    return Deferred().resolve();
  }
  setSelectedItems(keys) {
    this._setOption("selectionFilter", null);
    for (let i = 0; i < keys.length; i++) {
      this.addSelectedItem(keys[i]);
    }
  }
  isItemDataSelected(itemData) {
    return this.isItemKeySelected(itemData);
  }
  isItemKeySelected(itemData) {
    const {
      selectionFilter,
      sensitivity
    } = this.options;
    if (!selectionFilter) {
      return true;
    }
    const queryParams = {
      langParams: {
        collatorOptions: {
          sensitivity
        }
      }
    };
    return !!query_default([itemData], queryParams).filter(selectionFilter).toArray().length;
  }
  _getKeyExpr() {
    const keyField = this.options.key();
    if (Array.isArray(keyField) && 1 === keyField.length) {
      return keyField[0];
    }
    return keyField;
  }
  _normalizeKey(key) {
    const keyExpr = this.options.key();
    if (Array.isArray(keyExpr) && 1 === keyExpr.length) {
      return key[keyExpr[0]];
    }
    return key;
  }
  _getFilterByKey(key) {
    const keyField = this._getKeyExpr();
    let filter = [keyField, "=", this._normalizeKey(key)];
    if (Array.isArray(keyField)) {
      filter = [];
      for (let i = 0; i < keyField.length; i++) {
        filter.push([keyField[i], "=", key[keyField[i]]]);
        if (i !== keyField.length - 1) {
          filter.push("and");
        }
      }
    }
    return filter;
  }
  addSelectedItem(key, isSelectAll, skipFilter) {
    const filter = this._getFilterByKey(key);
    this._addSelectionFilter(false, filter, isSelectAll, skipFilter);
  }
  removeSelectedItem(key) {
    const filter = this._getFilterByKey(key);
    this._addSelectionFilter(true, filter);
  }
  validate() {
    const {
      key
    } = this.options;
    if (key && void 0 === key()) {
      throw ui_errors_default.Error("E1042", "Deferred selection");
    }
  }
  _findSubFilter(selectionFilter, filter) {
    if (!selectionFilter) {
      return -1;
    }
    const filterString = JSON.stringify(filter);
    for (let index = 0; index < selectionFilter.length; index++) {
      const subFilter = selectionFilter[index];
      if (subFilter && JSON.stringify(subFilter) === filterString) {
        return index;
      }
    }
    return -1;
  }
  _isLastSubFilter(selectionFilter, filter) {
    if (selectionFilter && filter) {
      return this._findSubFilter(selectionFilter, filter) === selectionFilter.length - 1 || 0 === this._findSubFilter([selectionFilter], filter);
    }
    return false;
  }
  _addFilterOperator(selectionFilter, filterOperator) {
    if (selectionFilter.length > 1 && isString(selectionFilter[1]) && selectionFilter[1] !== filterOperator) {
      selectionFilter = [selectionFilter];
    }
    if (selectionFilter.length) {
      selectionFilter.push(filterOperator);
    }
    return selectionFilter;
  }
  _denormalizeFilter(filter) {
    if (filter && isString(filter[0])) {
      filter = [filter];
    }
    return filter;
  }
  _isOnlyNegativeFiltersLeft(filters) {
    return filters.every((filterItem, i) => {
      if (i % 2 === 0) {
        return Array.isArray(filterItem) && "!" === filterItem[0];
      }
      return "and" === filterItem;
    });
  }
  _addSelectionFilter(isDeselect, filter, isSelectAll, skipFilter) {
    var _selectionFilter;
    const that = this;
    const currentFilter = isDeselect ? ["!", filter] : filter;
    const currentOperation = isDeselect ? "and" : "or";
    let needAddFilter = true;
    let selectionFilter = that.options.selectionFilter || [];
    selectionFilter = that._denormalizeFilter(selectionFilter);
    if (null !== (_selectionFilter = selectionFilter) && void 0 !== _selectionFilter && _selectionFilter.length && !skipFilter) {
      const removedIndex = that._removeSameFilter(selectionFilter, filter, isDeselect, isSelectAll);
      const filterIndex = that._removeSameFilter(selectionFilter, filter, !isDeselect);
      const shouldCleanFilter = isDeselect && (-1 !== removedIndex || -1 !== filterIndex) && this._isOnlyNegativeFiltersLeft(selectionFilter);
      if (shouldCleanFilter) {
        selectionFilter = [];
      }
      const isKeyOperatorsAfterRemoved = this._isKeyFilter(filter) && this._hasKeyFiltersOnlyStartingFromIndex(selectionFilter, filterIndex);
      needAddFilter = filter.length && !isKeyOperatorsAfterRemoved;
    }
    if (needAddFilter) {
      selectionFilter = that._addFilterOperator(selectionFilter, currentOperation);
      selectionFilter.push(currentFilter);
    }
    selectionFilter = that._normalizeFilter(selectionFilter);
    that._setOption("selectionFilter", !isDeselect && !selectionFilter.length ? null : selectionFilter);
  }
  _normalizeFilter(filter) {
    if (filter && 1 === filter.length) {
      filter = filter[0];
    }
    return filter;
  }
  _removeFilterByIndex(filter, filterIndex, isSelectAll) {
    const operation = filter[1];
    if (filterIndex > 0) {
      filter.splice(filterIndex - 1, 2);
    } else {
      filter.splice(filterIndex, 2);
    }
    if (isSelectAll && "and" === operation) {
      filter.splice(0, filter.length);
    }
  }
  _isSimpleKeyFilter(filter, key) {
    return 3 === filter.length && filter[0] === key && "=" === filter[1];
  }
  _isKeyFilter(filter) {
    if (2 === filter.length && "!" === filter[0]) {
      return this._isKeyFilter(filter[1]);
    }
    const keyField = this._getKeyExpr();
    if (Array.isArray(keyField)) {
      if (filter.length !== 2 * keyField.length - 1) {
        return false;
      }
      for (let i = 0; i < keyField.length; i++) {
        if (i > 0 && "and" !== filter[2 * i - 1]) {
          return false;
        }
        if (!this._isSimpleKeyFilter(filter[2 * i], keyField[i])) {
          return false;
        }
      }
      return true;
    }
    return this._isSimpleKeyFilter(filter, keyField);
  }
  _hasKeyFiltersOnlyStartingFromIndex(selectionFilter, filterIndex) {
    if (filterIndex >= 0) {
      for (let i = filterIndex; i < selectionFilter.length; i++) {
        if ("string" !== typeof selectionFilter[i] && !this._isKeyFilter(selectionFilter[i])) {
          return false;
        }
      }
      return true;
    }
    return false;
  }
  _removeSameFilter(selectionFilter, filter, inverted, isSelectAll) {
    filter = inverted ? ["!", filter] : filter;
    if (JSON.stringify(filter) === JSON.stringify(selectionFilter)) {
      selectionFilter.splice(0, selectionFilter.length);
      return 0;
    }
    const filterIndex = this._findSubFilter(selectionFilter, filter);
    if (filterIndex >= 0) {
      this._removeFilterByIndex(selectionFilter, filterIndex, isSelectAll);
      return filterIndex;
    }
    for (let i = 0; i < selectionFilter.length; i++) {
      if (Array.isArray(selectionFilter[i]) && selectionFilter[i].length > 2) {
        const filterIndex2 = this._removeSameFilter(selectionFilter[i], filter, false, isSelectAll);
        if (filterIndex2 >= 0) {
          if (!selectionFilter[i].length) {
            this._removeFilterByIndex(selectionFilter, i, isSelectAll);
          } else if (1 === selectionFilter[i].length) {
            selectionFilter[i] = selectionFilter[i][0];
          }
          return filterIndex2;
        }
      }
    }
    return -1;
  }
  getSelectAllState() {
    const filter = this.options.filter();
    let {
      selectionFilter
    } = this.options;
    if (!selectionFilter) {
      return true;
    }
    if (!selectionFilter.length) {
      return false;
    }
    if (!filter || !filter.length) {
      return;
    }
    selectionFilter = this._denormalizeFilter(selectionFilter);
    if (this._isLastSubFilter(selectionFilter, filter)) {
      return true;
    }
    if (this._isLastSubFilter(selectionFilter, ["!", filter])) {
      return false;
    }
    return;
  }
  loadSelectedItemsWithFilter() {
    const componentFilter = this.options.filter();
    const {
      selectionFilter
    } = this.options;
    const filter = componentFilter ? [componentFilter, "and", selectionFilter] : selectionFilter;
    return this._loadFilteredData(filter);
  }
};

// node_modules/devextreme/esm/__internal/ui/selection/m_selection.strategy.standard.js
init_common();
init_deferred();

// node_modules/devextreme/esm/core/utils/selection_filter.js
init_common();
init_type();
init_data();
var SelectionFilterCreator = function(selectedItemKeys, isSelectAll) {
  this.getLocalFilter = function(keyGetter, equalKeys, equalByReference, keyExpr) {
    equalKeys = void 0 === equalKeys ? equalByValue : equalKeys;
    return functionFilter.bind(this, equalKeys, keyGetter, equalByReference, keyExpr);
  };
  this.getExpr = function(keyExpr) {
    if (!keyExpr) {
      return;
    }
    let filterExpr;
    selectedItemKeys.forEach(function(key, index) {
      filterExpr = filterExpr || [];
      let filterExprPart;
      if (index > 0) {
        filterExpr.push(isSelectAll ? "and" : "or");
      }
      if (isString(keyExpr)) {
        filterExprPart = getFilterForPlainKey(keyExpr, key);
      } else {
        filterExprPart = function(keyExpr2, itemKeyValue) {
          const filterExpr2 = [];
          for (let i = 0, length = keyExpr2.length; i < length; i++) {
            const currentKeyExpr = keyExpr2[i];
            const keyValueGetter = compileGetter(currentKeyExpr);
            const currentKeyValue = itemKeyValue && keyValueGetter(itemKeyValue);
            const filterExprPart2 = getFilterForPlainKey(currentKeyExpr, currentKeyValue);
            if (!filterExprPart2) {
              break;
            }
            if (i > 0) {
              filterExpr2.push(isSelectAll ? "or" : "and");
            }
            filterExpr2.push(filterExprPart2);
          }
          return filterExpr2;
        }(keyExpr, key);
      }
      filterExpr.push(filterExprPart);
    });
    if (filterExpr && 1 === filterExpr.length) {
      filterExpr = filterExpr[0];
    }
    return filterExpr;
  };
  this.getCombinedFilter = function(keyExpr, dataSourceFilter) {
    let forceCombinedFilter = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : false;
    const filterExpr = this.getExpr(keyExpr);
    let combinedFilter = filterExpr;
    if ((forceCombinedFilter || isSelectAll) && dataSourceFilter) {
      if (filterExpr) {
        combinedFilter = [];
        combinedFilter.push(filterExpr);
        combinedFilter.push(dataSourceFilter);
      } else {
        combinedFilter = dataSourceFilter;
      }
    }
    return combinedFilter;
  };
  let selectedItemKeyHashesMap;
  const getSelectedItemKeyHashesMap = function(keyOf, keyExpr) {
    if (!selectedItemKeyHashesMap) {
      selectedItemKeyHashesMap = {};
      const normalizedKeys = normalizeKeys(selectedItemKeys, keyOf, keyExpr);
      for (let i = 0; i < normalizedKeys.length; i++) {
        selectedItemKeyHashesMap[getKeyHash(normalizedKeys[i])] = true;
      }
    }
    return selectedItemKeyHashesMap;
  };
  const normalizeKeys = function(keys, keyOf, keyExpr) {
    return Array.isArray(keyExpr) ? keys.map((key) => keyOf(key)) : keys;
  };
  function functionFilter(equalKeys, keyOf, equalByReference, keyExpr, item) {
    const key = keyOf(item);
    let keyHash;
    let i;
    if (!equalByReference) {
      keyHash = getKeyHash(key);
      if (!isObject(keyHash)) {
        const selectedKeyHashesMap = getSelectedItemKeyHashesMap(keyOf, keyExpr);
        if (selectedKeyHashesMap[keyHash]) {
          return !isSelectAll;
        }
        return !!isSelectAll;
      }
    }
    for (i = 0; i < selectedItemKeys.length; i++) {
      if (equalKeys(selectedItemKeys[i], key)) {
        return !isSelectAll;
      }
    }
    return !!isSelectAll;
  }
  function getFilterForPlainKey(keyExpr, keyValue) {
    if (void 0 === keyValue) {
      return;
    }
    return [keyExpr, isSelectAll ? "<>" : "=", keyValue];
  }
};

// node_modules/devextreme/esm/__internal/ui/selection/m_selection.strategy.standard.js
init_type();
var StandardStrategy = class extends SelectionStrategy {
  constructor(options2) {
    super(options2);
    this._initSelectedItemKeyHash();
  }
  _initSelectedItemKeyHash() {
    this._setOption("keyHashIndices", this.options.equalByReference ? null : {});
  }
  getSelectedItemKeys() {
    return this.options.selectedItemKeys.slice(0);
  }
  getSelectedItems() {
    return this.options.selectedItems.slice(0);
  }
  _preserveSelectionUpdate(items, isDeselect) {
    const {
      keyOf
    } = this.options;
    let keyIndicesToRemoveMap;
    let keyIndex;
    let i;
    if (!keyOf) {
      return;
    }
    const isBatchDeselect = isDeselect && items.length > 1 && !this.options.equalByReference;
    if (isBatchDeselect) {
      keyIndicesToRemoveMap = {};
    }
    for (i = 0; i < items.length; i++) {
      const item = items[i];
      const key = keyOf(item);
      if (isDeselect) {
        keyIndex = this.removeSelectedItem(key, keyIndicesToRemoveMap, null === item || void 0 === item ? void 0 : item.disabled);
        if (keyIndicesToRemoveMap && keyIndex >= 0) {
          keyIndicesToRemoveMap[keyIndex] = true;
        }
      } else {
        this.addSelectedItem(key, item);
      }
    }
    if (isBatchDeselect) {
      this._batchRemoveSelectedItems(keyIndicesToRemoveMap);
    }
  }
  _batchRemoveSelectedItems(keyIndicesToRemoveMap) {
    const selectedItemKeys = this.options.selectedItemKeys.slice(0);
    const selectedItems = this.options.selectedItems.slice(0);
    this.options.selectedItemKeys.length = 0;
    this.options.selectedItems.length = 0;
    for (let i = 0; i < selectedItemKeys.length; i++) {
      if (!keyIndicesToRemoveMap[i]) {
        this.options.selectedItemKeys.push(selectedItemKeys[i]);
        this.options.selectedItems.push(selectedItems[i]);
      }
    }
    this._initSelectedItemKeyHash();
    this.updateSelectedItemKeyHash(this.options.selectedItemKeys);
  }
  _loadSelectedItemsCore(keys, isDeselect, isSelectAll, filter) {
    let forceCombinedFilter = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : false;
    let deferred = Deferred();
    const key = this.options.key();
    if (!keys.length && !isSelectAll) {
      deferred.resolve([]);
      return deferred;
    }
    if (isSelectAll && isDeselect && !filter) {
      deferred.resolve(this.getSelectedItems());
      return deferred;
    }
    const selectionFilterCreator = new SelectionFilterCreator(keys, isSelectAll);
    const combinedFilter = selectionFilterCreator.getCombinedFilter(key, filter, forceCombinedFilter);
    let deselectedItems = [];
    if (isDeselect) {
      const {
        selectedItems
      } = this.options;
      deselectedItems = combinedFilter && keys.length !== selectedItems.length ? query_default(selectedItems).filter(combinedFilter).toArray() : selectedItems.slice(0);
    }
    let filteredItems = deselectedItems.length ? deselectedItems : this.options.plainItems(true).filter(this.options.isSelectableItem).map(this.options.getItemData);
    const localFilter = selectionFilterCreator.getLocalFilter(this.options.keyOf, this.equalKeys.bind(this), this.options.equalByReference, key);
    filteredItems = filteredItems.filter(localFilter);
    if (deselectedItems.length || !isSelectAll && filteredItems.length === keys.length) {
      deferred.resolve(filteredItems);
    } else {
      deferred = this._loadFilteredData(combinedFilter, localFilter, null, isSelectAll);
    }
    return deferred;
  }
  _replaceSelectionUpdate(items) {
    const internalKeys = [];
    const {
      keyOf
    } = this.options;
    if (!keyOf) {
      return;
    }
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const key = keyOf(item);
      internalKeys.push(key);
    }
    this.setSelectedItems(internalKeys, items);
  }
  _warnOnIncorrectKeys(keys) {
    const {
      allowNullValue
    } = this.options;
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      if ((!allowNullValue || null !== key) && !this.isItemKeySelected(key)) {
        ui_errors_default.log("W1002", key);
      }
    }
  }
  _isMultiSelectEnabled() {
    const {
      mode
    } = this.options;
    return "all" === mode || "multiple" === mode;
  }
  _requestInProgress() {
    var _this$_lastLoadDeferr;
    return "pending" === (null === (_this$_lastLoadDeferr = this._lastLoadDeferred) || void 0 === _this$_lastLoadDeferr ? void 0 : _this$_lastLoadDeferr.state());
  }
  _concatRequestsItems(keys, isDeselect, oldRequestItems, updatedKeys) {
    let selectedItems;
    const deselectedItems = isDeselect ? keys : [];
    if (updatedKeys) {
      selectedItems = updatedKeys;
    } else {
      selectedItems = removeDuplicates(keys, this.options.selectedItemKeys);
    }
    return {
      addedItems: oldRequestItems.added.concat(selectedItems),
      removedItems: oldRequestItems.removed.concat(deselectedItems),
      keys
    };
  }
  _collectLastRequestData(keys, isDeselect, isSelectAll, updatedKeys) {
    const isDeselectAll = isDeselect && isSelectAll;
    const oldRequestItems = {
      added: [],
      removed: []
    };
    const multiSelectEnabled = this._isMultiSelectEnabled();
    let lastRequestData = multiSelectEnabled ? this._lastRequestData : {};
    if (multiSelectEnabled) {
      if (this._shouldMergeWithLastRequest) {
        if (isDeselectAll) {
          this._lastLoadDeferred.reject();
          lastRequestData = {};
        } else if (!isKeysEqual(keys, this.options.selectedItemKeys)) {
          oldRequestItems.added = lastRequestData.addedItems;
          oldRequestItems.removed = lastRequestData.removedItems;
          if (!isDeselect) {
            this._lastLoadDeferred.reject();
          }
        }
      }
      lastRequestData = this._concatRequestsItems(keys, isDeselect, oldRequestItems, this._shouldMergeWithLastRequest ? void 0 : updatedKeys);
    }
    return lastRequestData;
  }
  _updateKeysByLastRequestData(keys, isDeselect, isSelectAll) {
    let currentKeys = keys;
    if (this._isMultiSelectEnabled() && this._shouldMergeWithLastRequest && !isDeselect && !isSelectAll) {
      var _this$_lastRequestDat, _this$_lastRequestDat2;
      currentKeys = removeDuplicates(keys.concat(null === (_this$_lastRequestDat = this._lastRequestData) || void 0 === _this$_lastRequestDat ? void 0 : _this$_lastRequestDat.addedItems), null === (_this$_lastRequestDat2 = this._lastRequestData) || void 0 === _this$_lastRequestDat2 ? void 0 : _this$_lastRequestDat2.removedItems);
      currentKeys = getUniqueValues(currentKeys);
    }
    return currentKeys;
  }
  _loadSelectedItems(keys, isDeselect, isSelectAll, updatedKeys) {
    let forceCombinedFilter = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : false;
    const that = this;
    const deferred = Deferred();
    const filter = that.options.filter();
    this._shouldMergeWithLastRequest = this._requestInProgress();
    this._lastRequestData = this._collectLastRequestData(keys, isDeselect, isSelectAll, updatedKeys);
    when(that._lastLoadDeferred).always(() => {
      const currentKeys = that._updateKeysByLastRequestData(keys, isDeselect, isSelectAll);
      that._shouldMergeWithLastRequest = false;
      that._loadSelectedItemsCore(currentKeys, isDeselect, isSelectAll, filter, forceCombinedFilter).done(deferred.resolve).fail(deferred.reject);
    });
    that._lastLoadDeferred = deferred;
    return deferred;
  }
  selectedItemKeys(keys, preserve, isDeselect, isSelectAll, updatedKeys) {
    let forceCombinedFilter = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : false;
    const that = this;
    const deferred = that._loadSelectedItems(keys, isDeselect, isSelectAll, updatedKeys, forceCombinedFilter);
    deferred.done((items) => {
      if (preserve) {
        that._preserveSelectionUpdate(items, isDeselect);
      } else {
        that._replaceSelectionUpdate(items);
      }
      that.onSelectionChanged();
    });
    return deferred;
  }
  addSelectedItem(key, itemData) {
    if (isDefined(itemData) && !this.options.ignoreDisabledItems && itemData.disabled) {
      if (-1 === this.options.disabledItemKeys.indexOf(key)) {
        this.options.disabledItemKeys.push(key);
      }
      return;
    }
    const keyHash = this._getKeyHash(key);
    if (-1 === this._indexOfSelectedItemKey(keyHash)) {
      if (!isObject(keyHash) && this.options.keyHashIndices) {
        this.options.keyHashIndices[keyHash] = [this.options.selectedItemKeys.length];
      }
      this.options.selectedItemKeys.push(key);
      this.options.addedItemKeys.push(key);
      this.options.addedItems.push(itemData);
      this.options.selectedItems.push(itemData);
    }
  }
  _getSelectedIndexByKey(key, ignoreIndicesMap) {
    const {
      selectedItemKeys
    } = this.options;
    for (let index = 0; index < selectedItemKeys.length; index++) {
      if ((!ignoreIndicesMap || !ignoreIndicesMap[index]) && this.equalKeys(selectedItemKeys[index], key)) {
        return index;
      }
    }
    return -1;
  }
  _getSelectedIndexByHash(key, ignoreIndicesMap) {
    let indices = this.options.keyHashIndices[key];
    if (indices && indices.length > 1 && ignoreIndicesMap) {
      indices = indices.filter((index) => !ignoreIndicesMap[index]);
    }
    return indices && indices[0] >= 0 ? indices[0] : -1;
  }
  _indexOfSelectedItemKey(key, ignoreIndicesMap) {
    let selectedIndex;
    if (this.options.equalByReference) {
      selectedIndex = this.options.selectedItemKeys.indexOf(key);
    } else if (isObject(key)) {
      selectedIndex = this._getSelectedIndexByKey(key, ignoreIndicesMap);
    } else {
      selectedIndex = this._getSelectedIndexByHash(key, ignoreIndicesMap);
    }
    return selectedIndex;
  }
  _shiftSelectedKeyIndices(keyIndex) {
    for (let currentKeyIndex = keyIndex; currentKeyIndex < this.options.selectedItemKeys.length; currentKeyIndex++) {
      const currentKey = this.options.selectedItemKeys[currentKeyIndex];
      const currentKeyHash = getKeyHash(currentKey);
      const currentKeyIndices = this.options.keyHashIndices[currentKeyHash];
      if (!currentKeyIndices) {
        continue;
      }
      for (let i = 0; i < currentKeyIndices.length; i++) {
        if (currentKeyIndices[i] > keyIndex) {
          currentKeyIndices[i]--;
        }
      }
    }
  }
  removeSelectedItem(key, keyIndicesToRemoveMap, isDisabled) {
    if (!this.options.ignoreDisabledItems && isDisabled) {
      return;
    }
    const keyHash = this._getKeyHash(key);
    const isBatchDeselect = !!keyIndicesToRemoveMap;
    const keyIndex = this._indexOfSelectedItemKey(keyHash, keyIndicesToRemoveMap);
    if (keyIndex < 0) {
      return keyIndex;
    }
    this.options.removedItemKeys.push(key);
    this.options.removedItems.push(this.options.selectedItems[keyIndex]);
    if (isBatchDeselect) {
      return keyIndex;
    }
    this.options.selectedItemKeys.splice(keyIndex, 1);
    this.options.selectedItems.splice(keyIndex, 1);
    if (isObject(keyHash) || !this.options.keyHashIndices) {
      return keyIndex;
    }
    const keyIndices = this.options.keyHashIndices[keyHash];
    if (!keyIndices) {
      return keyIndex;
    }
    keyIndices.shift();
    if (!keyIndices.length) {
      delete this.options.keyHashIndices[keyHash];
    }
    this._shiftSelectedKeyIndices(keyIndex);
    return keyIndex;
  }
  _updateAddedItemKeys(keys, items) {
    for (let i = 0; i < keys.length; i++) {
      if (!this.isItemKeySelected(keys[i])) {
        this.options.addedItemKeys.push(keys[i]);
        this.options.addedItems.push(items[i]);
      }
    }
  }
  _updateRemovedItemKeys(keys, oldSelectedKeys, oldSelectedItems) {
    for (let i = 0; i < oldSelectedKeys.length; i++) {
      if (!this.isItemKeySelected(oldSelectedKeys[i])) {
        this.options.removedItemKeys.push(oldSelectedKeys[i]);
        this.options.removedItems.push(oldSelectedItems[i]);
      }
    }
  }
  _isItemSelectionInProgress(key, checkPending) {
    const shouldCheckPending = checkPending && this._lastRequestData && this._requestInProgress();
    if (shouldCheckPending) {
      const addedItems = this._lastRequestData.addedItems ?? [];
      return addedItems.includes(key);
    }
    return false;
  }
  _getKeyHash(key) {
    return this.options.equalByReference ? key : getKeyHash(key);
  }
  setSelectedItems(keys, items) {
    this._updateAddedItemKeys(keys, items);
    const oldSelectedKeys = this.options.selectedItemKeys;
    const oldSelectedItems = this.options.selectedItems;
    if (!this.options.equalByReference) {
      this._initSelectedItemKeyHash();
      this.updateSelectedItemKeyHash(keys);
    }
    this._setOption("selectedItemKeys", keys);
    this._setOption("selectedItems", items);
    this._updateRemovedItemKeys(keys, oldSelectedKeys, oldSelectedItems);
  }
  isItemDataSelected(itemData) {
    let options2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    const key = this.options.keyOf(itemData);
    return this.isItemKeySelected(key, options2);
  }
  isItemKeySelected(key) {
    let options2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    let result2 = this._isItemSelectionInProgress(key, options2.checkPending);
    if (!result2) {
      const keyHash = this._getKeyHash(key);
      const index = this._indexOfSelectedItemKey(keyHash);
      result2 = -1 !== index;
    }
    return result2;
  }
  getSelectAllState(visibleOnly) {
    if (visibleOnly) {
      return this._getVisibleSelectAllState();
    }
    return this._getFullSelectAllState();
  }
  loadSelectedItemsWithFilter() {
    const keyExpr = this.options.key();
    const keys = this.getSelectedItemKeys();
    const filter = this.options.filter();
    if (!keys.length) {
      return Deferred().resolve([]);
    }
    const selectionFilterCreator = new SelectionFilterCreator(keys);
    const combinedFilter = selectionFilterCreator.getCombinedFilter(keyExpr, filter, true);
    return this._loadFilteredData(combinedFilter);
  }
};

// node_modules/devextreme/esm/__internal/ui/selection/m_selection.js
var Selection = class {
  constructor(options2) {
    this.options = extend(this._getDefaultOptions(), options2, {
      selectedItemKeys: options2.selectedKeys || []
    });
    this._selectionStrategy = this.options.deferred ? new DeferredStrategy(this.options) : new StandardStrategy(this.options);
    this._focusedItemIndex = -1;
    if (!this.options.equalByReference) {
      this._selectionStrategy.updateSelectedItemKeyHash(this.options.selectedItemKeys);
    }
  }
  _getDefaultOptions() {
    return {
      allowNullValue: false,
      deferred: false,
      equalByReference: false,
      mode: "multiple",
      selectedItems: [],
      selectionFilter: [],
      maxFilterLengthInRequest: 0,
      onSelectionChanged: noop,
      key: noop,
      keyOf: (item) => item,
      load: () => Deferred().resolve([]),
      totalCount: () => -1,
      isSelectableItem: () => true,
      isItemSelected: () => false,
      getItemData: (item) => item,
      dataFields: noop,
      filter: noop
    };
  }
  validate() {
    this._selectionStrategy.validate();
  }
  getSelectedItemKeys() {
    return this._selectionStrategy.getSelectedItemKeys();
  }
  getSelectedItems() {
    return this._selectionStrategy.getSelectedItems();
  }
  selectionFilter(value) {
    if (void 0 === value) {
      return this.options.selectionFilter;
    }
    const filterIsChanged = this.options.selectionFilter !== value && JSON.stringify(this.options.selectionFilter) !== JSON.stringify(value);
    this.options.selectionFilter = value;
    filterIsChanged && this.onSelectionChanged();
  }
  setSelection(keys, updatedKeys) {
    return this.selectedItemKeys(keys, false, false, false, updatedKeys);
  }
  select(keys) {
    return this.selectedItemKeys(keys, true);
  }
  deselect(keys) {
    return this.selectedItemKeys(keys, true, true);
  }
  selectedItemKeys(keys, preserve, isDeselect, isSelectAll, updatedKeys) {
    keys = keys ?? [];
    keys = Array.isArray(keys) ? keys : [keys];
    this.validate();
    return this._selectionStrategy.selectedItemKeys(keys, preserve, isDeselect, isSelectAll, updatedKeys);
  }
  clearSelection() {
    return this.selectedItemKeys([]);
  }
  _addSelectedItem(itemData, key) {
    this._selectionStrategy.addSelectedItem(key, itemData);
  }
  _removeSelectedItem(key) {
    this._selectionStrategy.removeSelectedItem(key);
  }
  _setSelectedItems(keys, items) {
    this._selectionStrategy.setSelectedItems(keys, items);
  }
  onSelectionChanged() {
    this._selectionStrategy.onSelectionChanged();
  }
  changeItemSelection(itemIndex, keys, setFocusOnly) {
    var _this$options$allowLo, _this$options;
    let isSelectedItemsChanged;
    const items = this.options.plainItems();
    const item = items[itemIndex];
    let deferred;
    const {
      isVirtualPaging
    } = this.options;
    const allowLoadByRange = null === (_this$options$allowLo = (_this$options = this.options).allowLoadByRange) || void 0 === _this$options$allowLo ? void 0 : _this$options$allowLo.call(_this$options);
    const {
      alwaysSelectByShift
    } = this.options;
    let indexOffset;
    let focusedItemNotInLoadedRange = false;
    let shiftFocusedItemNotInLoadedRange = false;
    const itemIsNotInLoadedRange = (index) => index >= 0 && !items.filter((it) => it.loadIndex === index).length;
    if (isVirtualPaging && isDefined(item)) {
      if (allowLoadByRange) {
        indexOffset = item.loadIndex - itemIndex;
        itemIndex = item.loadIndex;
      }
      focusedItemNotInLoadedRange = itemIsNotInLoadedRange(this._focusedItemIndex);
      if (isDefined(this._shiftFocusedItemIndex)) {
        shiftFocusedItemNotInLoadedRange = itemIsNotInLoadedRange(this._shiftFocusedItemIndex);
      }
    }
    if (!this.isSelectable() || !this.isDataItem(item)) {
      return false;
    }
    const itemData = this.options.getItemData(item);
    const itemKey = this.options.keyOf(itemData);
    keys = keys || {};
    let allowSelectByShift = keys.shift;
    if (false === alwaysSelectByShift && allowSelectByShift) {
      allowSelectByShift = false !== allowLoadByRange || !focusedItemNotInLoadedRange && !shiftFocusedItemNotInLoadedRange;
    }
    if (allowSelectByShift && "multiple" === this.options.mode && this._focusedItemIndex >= 0) {
      if (allowLoadByRange && (focusedItemNotInLoadedRange || shiftFocusedItemNotInLoadedRange)) {
        isSelectedItemsChanged = itemIndex !== this._shiftFocusedItemIndex || this._focusedItemIndex !== this._shiftFocusedItemIndex;
        if (isSelectedItemsChanged) {
          deferred = this.changeItemSelectionWhenShiftKeyInVirtualPaging(itemIndex);
        }
      } else {
        isSelectedItemsChanged = this.changeItemSelectionWhenShiftKeyPressed(itemIndex, items, indexOffset);
      }
    } else if (keys.control) {
      this._resetItemSelectionWhenShiftKeyPressed();
      if (!setFocusOnly) {
        const isSelected = this._selectionStrategy.isItemDataSelected(itemData);
        if ("single" === this.options.mode) {
          this.clearSelectedItems();
        }
        if (isSelected) {
          this._removeSelectedItem(itemKey);
        } else {
          this._addSelectedItem(itemData, itemKey);
        }
      }
      isSelectedItemsChanged = true;
    } else {
      this._resetItemSelectionWhenShiftKeyPressed();
      const isKeysEqual2 = this._selectionStrategy.equalKeys(this.options.selectedItemKeys[0], itemKey);
      if (1 !== this.options.selectedItemKeys.length || !isKeysEqual2) {
        this._setSelectedItems([itemKey], [itemData]);
        isSelectedItemsChanged = true;
      }
    }
    if (isSelectedItemsChanged) {
      when(deferred).done(() => {
        this._focusedItemIndex = itemIndex;
        !setFocusOnly && this.onSelectionChanged();
      });
      return true;
    }
  }
  isDataItem(item) {
    return this.options.isSelectableItem(item);
  }
  isSelectable() {
    return "single" === this.options.mode || "multiple" === this.options.mode;
  }
  isItemDataSelected(data) {
    return this._selectionStrategy.isItemDataSelected(data, {
      checkPending: true
    });
  }
  isItemSelected(arg, options2) {
    return this._selectionStrategy.isItemKeySelected(arg, options2);
  }
  _resetItemSelectionWhenShiftKeyPressed() {
    delete this._shiftFocusedItemIndex;
  }
  _resetFocusedItemIndex() {
    this._focusedItemIndex = -1;
  }
  changeItemSelectionWhenShiftKeyInVirtualPaging(loadIndex) {
    const loadOptions = this.options.getLoadOptions(loadIndex, this._focusedItemIndex, this._shiftFocusedItemIndex);
    const deferred = Deferred();
    const indexOffset = loadOptions.skip;
    this.options.load(loadOptions).done((items) => {
      this.changeItemSelectionWhenShiftKeyPressed(loadIndex, items, indexOffset);
      deferred.resolve();
    });
    return deferred.promise();
  }
  changeItemSelectionWhenShiftKeyPressed(itemIndex, items, indexOffset) {
    let isSelectedItemsChanged = false;
    let itemIndexStep;
    const indexOffsetDefined = isDefined(indexOffset);
    let index = indexOffsetDefined ? this._focusedItemIndex - indexOffset : this._focusedItemIndex;
    const {
      keyOf
    } = this.options;
    const focusedItem = items[index];
    const focusedData = this.options.getItemData(focusedItem);
    const focusedKey = keyOf(focusedData);
    const isFocusedItemSelected = focusedItem && this.isItemDataSelected(focusedData);
    if (!isDefined(this._shiftFocusedItemIndex)) {
      this._shiftFocusedItemIndex = this._focusedItemIndex;
    }
    let data;
    let itemKey;
    let startIndex;
    let endIndex;
    if (this._shiftFocusedItemIndex !== this._focusedItemIndex) {
      itemIndexStep = this._focusedItemIndex < this._shiftFocusedItemIndex ? 1 : -1;
      startIndex = indexOffsetDefined ? this._focusedItemIndex - indexOffset : this._focusedItemIndex;
      endIndex = indexOffsetDefined ? this._shiftFocusedItemIndex - indexOffset : this._shiftFocusedItemIndex;
      for (index = startIndex; index !== endIndex; index += itemIndexStep) {
        if (indexOffsetDefined || this.isDataItem(items[index])) {
          itemKey = keyOf(this.options.getItemData(items[index]));
          this._removeSelectedItem(itemKey);
          isSelectedItemsChanged = true;
        }
      }
    }
    if (itemIndex !== this._shiftFocusedItemIndex) {
      itemIndexStep = itemIndex < this._shiftFocusedItemIndex ? 1 : -1;
      startIndex = indexOffsetDefined ? itemIndex - indexOffset : itemIndex;
      endIndex = indexOffsetDefined ? this._shiftFocusedItemIndex - indexOffset : this._shiftFocusedItemIndex;
      for (index = startIndex; index !== endIndex; index += itemIndexStep) {
        if (indexOffsetDefined || this.isDataItem(items[index])) {
          data = this.options.getItemData(items[index]);
          itemKey = keyOf(data);
          this._addSelectedItem(data, itemKey);
          isSelectedItemsChanged = true;
        }
      }
    }
    if ((indexOffsetDefined || this.isDataItem(focusedItem)) && !isFocusedItemSelected) {
      this._addSelectedItem(focusedData, focusedKey);
      isSelectedItemsChanged = true;
    }
    return isSelectedItemsChanged;
  }
  clearSelectedItems() {
    this._setSelectedItems([], []);
  }
  selectAll(isOnePage) {
    this._resetFocusedItemIndex();
    if (isOnePage) {
      return this._onePageSelectAll(false);
    }
    return this.selectedItemKeys([], true, false, true);
  }
  deselectAll(isOnePage) {
    this._resetFocusedItemIndex();
    if (isOnePage) {
      return this._onePageSelectAll(true);
    }
    return this.selectedItemKeys([], true, true, true);
  }
  _onePageSelectAll(isDeselect) {
    const items = this._selectionStrategy.getSelectableItems(this.options.plainItems());
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (this.isDataItem(item)) {
        const itemData = this.options.getItemData(item);
        const itemKey = this.options.keyOf(itemData);
        const isSelected = this.isItemSelected(itemKey);
        if (!isSelected && !isDeselect) {
          this._addSelectedItem(itemData, itemKey);
        }
        if (isSelected && isDeselect) {
          this._removeSelectedItem(itemKey);
        }
      }
    }
    this.onSelectionChanged();
    return Deferred().resolve();
  }
  getSelectAllState(visibleOnly) {
    return this._selectionStrategy.getSelectAllState(visibleOnly);
  }
  loadSelectedItemsWithFilter() {
    return this._selectionStrategy.loadSelectedItemsWithFilter();
  }
};

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.base.js
init_extends();
init_dom_adapter();
init_guid();
init_renderer();
init_common();
init_data();
init_deferred();
init_extend();
init_iterator();
init_size();
init_type();

// node_modules/devextreme/esm/data_helper.js
init_extend();

// node_modules/devextreme/esm/__internal/ui/collection/m_data_controller.js
init_common();
init_deferred();
var DataControllerMock = {
  load: () => Deferred().reject(),
  loadSingle: () => Deferred().reject(),
  loadFromStore: () => Deferred().reject(),
  loadNextPage: () => Deferred().reject(),
  loadOptions: noop,
  userData: noop,
  cancel: noop,
  cancelAll: noop,
  filter: noop,
  addSearchFilter: noop,
  group: noop,
  paginate: noop,
  pageSize: noop,
  pageIndex: noop,
  resetDataSourcePageIndex: noop,
  totalCount: noop,
  isLastPage: noop,
  isLoading: noop,
  isLoaded: noop,
  searchValue: noop,
  searchOperation: noop,
  searchExpr: noop,
  select: noop,
  key: noop,
  keyOf: noop,
  store: noop,
  items: noop,
  applyMapFunction: noop,
  getDataSource: noop,
  reload: noop,
  on: noop,
  off: noop
};
var DataController = class {
  constructor(dataSource) {
    if (!dataSource) {
      return DataControllerMock;
    }
    this._dataSource = dataSource;
  }
  load() {
    return this._dataSource.load();
  }
  loadSingle(propName, propValue) {
    if (arguments.length < 2) {
      propValue = propName;
      propName = this.key();
    }
    return this._dataSource.loadSingle(propName, propValue);
  }
  loadFromStore(loadOptions) {
    return this.store().load(loadOptions);
  }
  loadNextPage() {
    this.pageIndex(1 + this.pageIndex());
    return this.load();
  }
  loadOptions() {
    return this._dataSource.loadOptions();
  }
  userData() {
    return this._dataSource._userData;
  }
  cancel(operationId) {
    this._dataSource.cancel(operationId);
  }
  cancelAll() {
    this._dataSource.cancelAll();
  }
  filter(filter) {
    return this._dataSource.filter(filter);
  }
  addSearchFilter(storeLoadOptions) {
    this._dataSource._addSearchFilter(storeLoadOptions);
  }
  group(group) {
    return this._dataSource.group(group);
  }
  paginate() {
    return this._dataSource.paginate();
  }
  pageSize() {
    return this._dataSource._pageSize;
  }
  pageIndex(pageIndex) {
    return this._dataSource.pageIndex(pageIndex);
  }
  resetDataSourcePageIndex() {
    if (this.pageIndex()) {
      this.pageIndex(0);
      this.load();
    }
  }
  totalCount() {
    return this._dataSource.totalCount();
  }
  isLastPage() {
    return this._dataSource.isLastPage() || !this._dataSource._pageSize;
  }
  isLoading() {
    return this._dataSource.isLoading();
  }
  isLoaded() {
    return this._dataSource.isLoaded();
  }
  searchValue(value) {
    if (!arguments.length) {
      return this._dataSource.searchValue();
    }
    return this._dataSource.searchValue(value);
  }
  searchOperation(operation) {
    return this._dataSource.searchOperation(operation);
  }
  searchExpr(expr) {
    if (!arguments.length) {
      return this._dataSource.searchExpr();
    }
    return this._dataSource.searchExpr(expr);
  }
  select() {
    return this._dataSource.select(...arguments);
  }
  key() {
    return this._dataSource.key();
  }
  keyOf(item) {
    return this.store().keyOf(item);
  }
  store() {
    return this._dataSource.store();
  }
  items() {
    return this._dataSource.items();
  }
  applyMapFunction(data) {
    return this._dataSource._applyMapFunction(data);
  }
  getDataSource() {
    return this._dataSource || null;
  }
  reload() {
    return this._dataSource.reload();
  }
  on(event, handler) {
    this._dataSource.on(event, handler);
  }
  off(event, handler) {
    this._dataSource.off(event, handler);
  }
};
var m_data_controller_default = DataController;

// node_modules/devextreme/esm/data_helper.js
var DATA_SOURCE_CHANGED_METHOD = "_dataSourceChangedHandler";
var SPECIFIC_DATA_SOURCE_OPTION = "_getSpecificDataSourceOption";
var NORMALIZE_DATA_SOURCE = "_normalizeDataSource";
var DataHelperMixin = {
  postCtor: function() {
    this.on("disposing", function() {
      this._disposeDataSource();
    }.bind(this));
  },
  _refreshDataSource: function() {
    this._initDataSource();
    this._loadDataSource();
  },
  _initDataSource: function() {
    let dataSourceOptions = SPECIFIC_DATA_SOURCE_OPTION in this ? this[SPECIFIC_DATA_SOURCE_OPTION]() : this.option("dataSource");
    let widgetDataSourceOptions;
    let dataSourceType;
    this._disposeDataSource();
    if (dataSourceOptions) {
      if (dataSourceOptions instanceof DataSource) {
        this._isSharedDataSource = true;
        this._dataSource = dataSourceOptions;
      } else {
        widgetDataSourceOptions = "_dataSourceOptions" in this ? this._dataSourceOptions() : {};
        dataSourceType = this._dataSourceType ? this._dataSourceType() : DataSource;
        dataSourceOptions = normalizeDataSourceOptions(dataSourceOptions, {
          fromUrlLoadMode: "_dataSourceFromUrlLoadMode" in this && this._dataSourceFromUrlLoadMode()
        });
        this._dataSource = new dataSourceType(extend(true, {}, widgetDataSourceOptions, dataSourceOptions));
      }
      if (NORMALIZE_DATA_SOURCE in this) {
        this._dataSource = this[NORMALIZE_DATA_SOURCE](this._dataSource);
      }
      this._addDataSourceHandlers();
      this._initDataController();
    }
  },
  _initDataController: function() {
    var _this$option;
    const dataController = null === (_this$option = this.option) || void 0 === _this$option ? void 0 : _this$option.call(this, "_dataController");
    const dataSource = this._dataSource;
    if (dataController) {
      this._dataController = dataController;
    } else {
      this._dataController = new m_data_controller_default(dataSource);
    }
  },
  _addDataSourceHandlers: function() {
    if (DATA_SOURCE_CHANGED_METHOD in this) {
      this._addDataSourceChangeHandler();
    }
    if ("_dataSourceLoadErrorHandler" in this) {
      this._addDataSourceLoadErrorHandler();
    }
    if ("_dataSourceLoadingChangedHandler" in this) {
      this._addDataSourceLoadingChangedHandler();
    }
    this._addReadyWatcher();
  },
  _addReadyWatcher: function() {
    this.readyWatcher = function(isLoading) {
      this._ready && this._ready(!isLoading);
    }.bind(this);
    this._dataSource.on("loadingChanged", this.readyWatcher);
  },
  _addDataSourceChangeHandler: function() {
    const dataSource = this._dataSource;
    this._proxiedDataSourceChangedHandler = function(e) {
      this[DATA_SOURCE_CHANGED_METHOD](dataSource.items(), e);
    }.bind(this);
    dataSource.on("changed", this._proxiedDataSourceChangedHandler);
  },
  _addDataSourceLoadErrorHandler: function() {
    this._proxiedDataSourceLoadErrorHandler = this._dataSourceLoadErrorHandler.bind(this);
    this._dataSource.on("loadError", this._proxiedDataSourceLoadErrorHandler);
  },
  _addDataSourceLoadingChangedHandler: function() {
    this._proxiedDataSourceLoadingChangedHandler = this._dataSourceLoadingChangedHandler.bind(this);
    this._dataSource.on("loadingChanged", this._proxiedDataSourceLoadingChangedHandler);
  },
  _loadDataSource: function() {
    const dataSource = this._dataSource;
    if (dataSource) {
      if (dataSource.isLoaded()) {
        this._proxiedDataSourceChangedHandler && this._proxiedDataSourceChangedHandler();
      } else {
        dataSource.load();
      }
    }
  },
  _loadSingle: function(key, value) {
    key = "this" === key ? this._dataSource.key() || "this" : key;
    return this._dataSource.loadSingle(key, value);
  },
  _isLastPage: function() {
    return !this._dataSource || this._dataSource.isLastPage() || !this._dataSource._pageSize;
  },
  _isDataSourceLoading: function() {
    return this._dataSource && this._dataSource.isLoading();
  },
  _disposeDataSource: function() {
    if (this._dataSource) {
      if (this._isSharedDataSource) {
        delete this._isSharedDataSource;
        this._proxiedDataSourceChangedHandler && this._dataSource.off("changed", this._proxiedDataSourceChangedHandler);
        this._proxiedDataSourceLoadErrorHandler && this._dataSource.off("loadError", this._proxiedDataSourceLoadErrorHandler);
        this._proxiedDataSourceLoadingChangedHandler && this._dataSource.off("loadingChanged", this._proxiedDataSourceLoadingChangedHandler);
        if (this._dataSource._eventsStrategy) {
          this._dataSource._eventsStrategy.off("loadingChanged", this.readyWatcher);
        }
      } else {
        this._dataSource.dispose();
      }
      delete this._dataSource;
      delete this._proxiedDataSourceChangedHandler;
      delete this._proxiedDataSourceLoadErrorHandler;
      delete this._proxiedDataSourceLoadingChangedHandler;
    }
  },
  getDataSource: function() {
    return this._dataSource || null;
  }
};
var data_helper_default = DataHelperMixin;

// node_modules/devextreme/esm/events/contextmenu.js
init_renderer();
init_events_engine();
init_class();
var CONTEXTMENU_NAMESPACED_EVENT_NAME = addNamespace("contextmenu", "dxContexMenu");
var HOLD_NAMESPACED_EVENT_NAME = addNamespace(hold_default.name, "dxContexMenu");
var ContextMenu = class_default.inherit({
  setup: function(element) {
    const $element = renderer_default(element);
    events_engine_default.on($element, CONTEXTMENU_NAMESPACED_EVENT_NAME, this._contextMenuHandler.bind(this));
    if (touch || devices_default.isSimulator()) {
      events_engine_default.on($element, HOLD_NAMESPACED_EVENT_NAME, this._holdHandler.bind(this));
    }
  },
  _holdHandler: function(e) {
    if (isMouseEvent(e) && !devices_default.isSimulator()) {
      return;
    }
    this._fireContextMenu(e);
  },
  _contextMenuHandler: function(e) {
    this._fireContextMenu(e);
  },
  _fireContextMenu: function(e) {
    return fireEvent({
      type: "dxcontextmenu",
      originalEvent: e
    });
  },
  teardown: function(element) {
    events_engine_default.off(element, ".dxContexMenu");
  }
});
event_registrator_default("dxcontextmenu", new ContextMenu());
var name = "dxcontextmenu";

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.base.js
init_events_engine();

// node_modules/devextreme/esm/__internal/ui/collection/m_item.js
init_class();
init_renderer();
init_iterator();
var forcibleWatcher = function(watchMethod, fn, callback) {
  const filteredCallback = /* @__PURE__ */ function() {
    let oldValue;
    return function(value) {
      if (oldValue !== value) {
        callback(value, oldValue);
        oldValue = value;
      }
    };
  }();
  return {
    dispose: watchMethod(fn, filteredCallback),
    force() {
      filteredCallback(fn());
    }
  };
};
var CollectionItem = class_default.inherit({
  ctor($element, options2, rawData) {
    this._$element = $element;
    this._options = options2;
    this._rawData = rawData;
    attachInstanceToElement($element, this, this._dispose);
    this._render();
  },
  _render() {
    const $placeholder = renderer_default("<div>").addClass("dx-item-content-placeholder");
    this._$element.append($placeholder);
    this._watchers = [];
    this._renderWatchers();
  },
  _renderWatchers() {
    this._startWatcher("disabled", this._renderDisabled.bind(this));
    this._startWatcher("visible", this._renderVisible.bind(this));
  },
  _startWatcher(field, render4) {
    const rawData = this._rawData;
    const exprGetter = this._options.fieldGetter(field);
    const watcher = forcibleWatcher(this._options.watchMethod(), () => exprGetter(rawData), (value, oldValue) => {
      this._dirty = true;
      render4(value, oldValue);
    });
    this._watchers.push(watcher);
  },
  setDataField() {
    this._dirty = false;
    each(this._watchers, (_, watcher) => {
      watcher.force();
    });
    if (this._dirty) {
      return true;
    }
  },
  _renderDisabled(value, oldValue) {
    this._$element.toggleClass("dx-state-disabled", !!value);
    this._$element.attr("aria-disabled", !!value);
    this._updateOwnerFocus(value);
  },
  _updateOwnerFocus(isDisabled) {
    const ownerComponent = this._options.owner;
    if (ownerComponent && isDisabled) {
      ownerComponent._resetItemFocus(this._$element);
    }
  },
  _renderVisible(value, oldValue) {
    this._$element.toggleClass("dx-state-invisible", void 0 !== value && !value);
  },
  _dispose() {
    each(this._watchers, (_, watcher) => {
      watcher.dispose();
    });
  }
});
CollectionItem.getInstance = function($element) {
  return getInstanceByElement($element, this);
};
var m_item_default = CollectionItem;

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.base.js
var ITEM_CLASS = "dx-item";
var EMPTY_COLLECTION = "dx-empty-collection";
var ITEM_PATH_REGEX = /^([^.]+\[\d+\]\.)+([\w.]+)$/;
var CollectionWidget = ui_widget_default.inherit({
  _activeStateUnit: `.${ITEM_CLASS}`,
  _supportedKeys() {
    const move2 = function(location, e) {
      if (!isCommandKeyPressed(e)) {
        e.preventDefault();
        e.stopPropagation();
        this._moveFocus(location, e);
      }
    };
    return extend(this.callBase(), {
      space: function(e) {
        e.preventDefault();
        this._enterKeyHandler(e);
      },
      enter: this._enterKeyHandler,
      leftArrow: move2.bind(this, "left"),
      rightArrow: move2.bind(this, "right"),
      upArrow: move2.bind(this, "up"),
      downArrow: move2.bind(this, "down"),
      pageUp: move2.bind(this, "up"),
      pageDown: move2.bind(this, "down"),
      home: move2.bind(this, "first"),
      end: move2.bind(this, "last")
    });
  },
  _enterKeyHandler(e) {
    const $itemElement = renderer_default(this.option("focusedElement"));
    if (!$itemElement.length) {
      return;
    }
    const itemData = this._getItemData($itemElement);
    if (null !== itemData && void 0 !== itemData && itemData.onClick) {
      this._itemEventHandlerByHandler($itemElement, itemData.onClick, {
        event: e
      });
    }
    this._itemClickHandler(extend({}, e, {
      target: $itemElement.get(0),
      currentTarget: $itemElement.get(0)
    }));
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      selectOnFocus: false,
      loopItemFocus: true,
      items: [],
      itemTemplate: "item",
      onItemRendered: null,
      onItemClick: null,
      onItemHold: null,
      itemHoldTimeout: 750,
      onItemContextMenu: null,
      onFocusedItemChanged: null,
      noDataText: message_default.format("dxCollectionWidget-noDataText"),
      encodeNoDataText: false,
      dataSource: null,
      _dataController: null,
      _itemAttributes: {},
      itemTemplateProperty: "template",
      focusOnSelectedItem: true,
      focusedElement: null,
      displayExpr: void 0,
      disabledExpr: (data) => data ? data.disabled : void 0,
      visibleExpr: (data) => data ? data.visible : void 0
    });
  },
  _init() {
    this._compileDisplayGetter();
    this._initDataController();
    this.callBase();
    this._cleanRenderedItems();
    this._refreshDataSource();
  },
  _compileDisplayGetter() {
    const displayExpr = this.option("displayExpr");
    this._displayGetter = displayExpr ? compileGetter(this.option("displayExpr")) : void 0;
  },
  _initTemplates() {
    this._initItemsFromMarkup();
    this._initDefaultItemTemplate();
    this.callBase();
  },
  _getAnonymousTemplateName: () => "item",
  _initDefaultItemTemplate() {
    const fieldsMap = this._getFieldsMap();
    this._templateManager.addDefaultTemplates({
      item: new BindableTemplate(($container, data) => {
        if (isPlainObject(data)) {
          this._prepareDefaultItemTemplate(data, $container);
        } else {
          if (fieldsMap && isFunction(fieldsMap.text)) {
            data = fieldsMap.text(data);
          }
          $container.text(String(ensureDefined(data, "")));
        }
      }, this._getBindableFields(), this.option("integrationOptions.watchMethod"), fieldsMap)
    });
  },
  _getBindableFields: () => ["text", "html"],
  _getFieldsMap() {
    if (this._displayGetter) {
      return {
        text: this._displayGetter
      };
    }
  },
  _prepareDefaultItemTemplate(data, $container) {
    if (isDefined(data.text)) {
      $container.text(data.text);
    }
    if (isDefined(data.html)) {
      $container.html(data.html);
    }
  },
  _initItemsFromMarkup() {
    const rawItems = findTemplates(this.$element(), "dxItem");
    if (!rawItems.length || this.option("items").length) {
      return;
    }
    const items = rawItems.map((_ref) => {
      let {
        element,
        options: options2
      } = _ref;
      const isTemplateRequired = /\S/.test(element.innerHTML) && !options2.template;
      if (isTemplateRequired) {
        options2.template = this._prepareItemTemplate(element);
      } else {
        renderer_default(element).remove();
      }
      return options2;
    });
    this.option("items", items);
  },
  _prepareItemTemplate(item) {
    const templateId = "tmpl-" + new guid_default();
    const $template = renderer_default(item).detach().clone().removeAttr("data-options").addClass("dx-template-wrapper");
    this._saveTemplate(templateId, $template);
    return templateId;
  },
  _dataSourceOptions: () => ({
    paginate: false
  }),
  _cleanRenderedItems() {
    this._renderedItemsCount = 0;
  },
  _focusTarget() {
    return this.$element();
  },
  _focusInHandler(e) {
    this.callBase.apply(this, arguments);
    if (!this._isFocusTarget(e.target)) {
      return;
    }
    const $focusedElement = renderer_default(this.option("focusedElement"));
    if ($focusedElement.length) {
      this._setFocusedItem($focusedElement);
    } else {
      const $activeItem = this._getActiveItem();
      if ($activeItem.length) {
        this.option("focusedElement", getPublicElement($activeItem));
      }
    }
  },
  _focusOutHandler() {
    this.callBase.apply(this, arguments);
    const $target = renderer_default(this.option("focusedElement"));
    this._updateFocusedItemState($target, false);
  },
  _findActiveTarget($element) {
    return $element.find(this._activeStateUnit);
  },
  _getActiveItem(last) {
    const $focusedElement = renderer_default(this.option("focusedElement"));
    if ($focusedElement.length) {
      return $focusedElement;
    }
    let index = this.option("focusOnSelectedItem") ? this.option("selectedIndex") : 0;
    const activeElements = this._getActiveElement();
    const lastIndex = activeElements.length - 1;
    if (index < 0) {
      index = last ? lastIndex : 0;
    }
    return activeElements.eq(index);
  },
  _moveFocus(location) {
    const $items = this._getAvailableItems();
    let $newTarget;
    switch (location) {
      case "pageup":
      case "up":
        $newTarget = this._prevItem($items);
        break;
      case "pagedown":
      case "down":
        $newTarget = this._nextItem($items);
        break;
      case "right":
        $newTarget = this.option("rtlEnabled") ? this._prevItem($items) : this._nextItem($items);
        break;
      case "left":
        $newTarget = this.option("rtlEnabled") ? this._nextItem($items) : this._prevItem($items);
        break;
      case "first":
        $newTarget = $items.first();
        break;
      case "last":
        $newTarget = $items.last();
        break;
      default:
        return false;
    }
    if (0 !== $newTarget.length) {
      this.option("focusedElement", getPublicElement($newTarget));
    }
  },
  _getVisibleItems($itemElements) {
    $itemElements = $itemElements || this._itemElements();
    return $itemElements.filter(":visible");
  },
  _getAvailableItems($itemElements) {
    return this._getVisibleItems($itemElements);
  },
  _prevItem($items) {
    const $target = this._getActiveItem();
    const targetIndex = $items.index($target);
    const $last = $items.last();
    let $item = renderer_default($items[targetIndex - 1]);
    const loop = this.option("loopItemFocus");
    if (0 === $item.length && loop) {
      $item = $last;
    }
    return $item;
  },
  _nextItem($items) {
    const $target = this._getActiveItem(true);
    const targetIndex = $items.index($target);
    const $first = $items.first();
    let $item = renderer_default($items[targetIndex + 1]);
    const loop = this.option("loopItemFocus");
    if (0 === $item.length && loop) {
      $item = $first;
    }
    return $item;
  },
  _selectFocusedItem($target) {
    this.selectItem($target);
  },
  _updateFocusedItemState(target, isFocused, needCleanItemId) {
    const $target = renderer_default(target);
    if ($target.length) {
      this._refreshActiveDescendant();
      this._refreshItemId($target, needCleanItemId);
      this._toggleFocusClass(isFocused, $target);
    }
    this._updateParentActiveDescendant();
  },
  _refreshActiveDescendant($target) {
    this.setAria("activedescendant", isDefined(this.option("focusedElement")) ? this.getFocusedItemId() : null, $target);
  },
  _refreshItemId($target, needCleanItemId) {
    if (!needCleanItemId && this.option("focusedElement")) {
      this.setAria("id", this.getFocusedItemId(), $target);
    } else {
      this.setAria("id", null, $target);
    }
  },
  _isDisabled: ($element) => $element && "true" === renderer_default($element).attr("aria-disabled"),
  _setFocusedItem($target) {
    if (!$target || !$target.length) {
      return;
    }
    this._updateFocusedItemState($target, true);
    this.onFocusedItemChanged(this.getFocusedItemId());
    const {
      selectOnFocus
    } = this.option();
    const isTargetDisabled = this._isDisabled($target);
    if (selectOnFocus && !isTargetDisabled) {
      this._selectFocusedItem($target);
    }
  },
  _findItemElementByItem(item) {
    let result2 = renderer_default();
    const that = this;
    this.itemElements().each(function() {
      const $item = renderer_default(this);
      if ($item.data(that._itemDataKey()) === item) {
        result2 = $item;
        return false;
      }
    });
    return result2;
  },
  _getIndexByItem(item) {
    return this.option("items").indexOf(item);
  },
  _itemOptionChanged(item, property, value, oldValue) {
    const $item = this._findItemElementByItem(item);
    if (!$item.length) {
      return;
    }
    if (!this.constructor.ItemClass.getInstance($item).setDataField(property, value)) {
      this._refreshItem($item, item);
    }
    const isDisabling = "disabled" === property && value;
    if (isDisabling) {
      this._resetItemFocus($item);
    }
  },
  _resetItemFocus($item) {
    if ($item.is(this.option("focusedElement"))) {
      this.option("focusedElement", null);
    }
  },
  _refreshItem($item) {
    const itemData = this._getItemData($item);
    const index = $item.data(this._itemIndexKey());
    this._renderItem(this._renderedItemsCount + index, itemData, null, $item);
  },
  _updateParentActiveDescendant: noop,
  _optionChanged(args) {
    if ("items" === args.name) {
      const matches = args.fullName.match(ITEM_PATH_REGEX);
      if (matches && matches.length) {
        const property = matches[matches.length - 1];
        const itemPath = args.fullName.replace(`.${property}`, "");
        const item = this.option(itemPath);
        this._itemOptionChanged(item, property, args.value, args.previousValue);
        return;
      }
    }
    switch (args.name) {
      case "items":
      case "_itemAttributes":
      case "itemTemplateProperty":
      case "useItemTextAsTitle":
        this._cleanRenderedItems();
        this._invalidate();
        break;
      case "dataSource":
        this._refreshDataSource();
        this._renderEmptyMessage();
        break;
      case "noDataText":
      case "encodeNoDataText":
        this._renderEmptyMessage();
        break;
      case "itemTemplate":
      case "visibleExpr":
      case "disabledExpr":
        this._invalidate();
        break;
      case "onItemRendered":
        this._createItemRenderAction();
        break;
      case "onItemClick":
      case "selectOnFocus":
      case "loopItemFocus":
      case "focusOnSelectedItem":
        break;
      case "onItemHold":
      case "itemHoldTimeout":
        this._attachHoldEvent();
        break;
      case "onItemContextMenu":
        this._attachContextMenuEvent();
        break;
      case "onFocusedItemChanged":
        this.onFocusedItemChanged = this._createActionByOption("onFocusedItemChanged");
        break;
      case "focusedElement":
        this._updateFocusedItemState(args.previousValue, false, true);
        this._setFocusedItem(renderer_default(args.value));
        break;
      case "displayExpr":
        this._compileDisplayGetter();
        this._initDefaultItemTemplate();
        this._invalidate();
        break;
      default:
        this.callBase(args);
    }
  },
  _invalidate() {
    this.option("focusedElement", null);
    return this.callBase.apply(this, arguments);
  },
  _loadNextPage() {
    this._expectNextPageLoading();
    return this._dataController.loadNextPage();
  },
  _expectNextPageLoading() {
    this._startIndexForAppendedItems = 0;
  },
  _expectLastItemLoading() {
    this._startIndexForAppendedItems = -1;
  },
  _forgetNextPageLoading() {
    this._startIndexForAppendedItems = null;
  },
  _dataSourceChangedHandler(newItems) {
    const items = this.option("items");
    if (this._initialized && items && this._shouldAppendItems()) {
      this._renderedItemsCount = items.length;
      if (!this._isLastPage() || -1 !== this._startIndexForAppendedItems) {
        this.option().items = items.concat(newItems.slice(this._startIndexForAppendedItems));
      }
      this._forgetNextPageLoading();
      this._refreshContent();
    } else {
      this.option("items", newItems.slice());
    }
  },
  _refreshContent() {
    this._prepareContent();
    this._renderContent();
  },
  _dataSourceLoadErrorHandler() {
    this._forgetNextPageLoading();
    this.option("items", this.option("items"));
  },
  _shouldAppendItems() {
    return null != this._startIndexForAppendedItems && this._allowDynamicItemsAppend();
  },
  _allowDynamicItemsAppend: () => false,
  _clean() {
    this._cleanFocusState();
    this._cleanItemContainer();
    this._inkRipple && delete this._inkRipple;
    this._resetActiveState();
  },
  _cleanItemContainer() {
    renderer_default(this._itemContainer()).empty();
  },
  _dispose() {
    this.callBase();
    clearTimeout(this._itemFocusTimeout);
  },
  _refresh() {
    this._cleanRenderedItems();
    this.callBase.apply(this, arguments);
  },
  _itemContainer() {
    return this.$element();
  },
  _itemClass: () => ITEM_CLASS,
  _itemContentClass() {
    return this._itemClass() + "-content";
  },
  _selectedItemClass: () => "dx-item-selected",
  _itemResponseWaitClass: () => "dx-item-response-wait",
  _itemSelector() {
    return `.${this._itemClass()}`;
  },
  _itemDataKey: () => "dxItemData",
  _itemIndexKey: () => "dxItemIndex",
  _itemElements() {
    return this._itemContainer().find(this._itemSelector());
  },
  _initMarkup() {
    this.callBase();
    this.onFocusedItemChanged = this._createActionByOption("onFocusedItemChanged");
    this.$element().addClass("dx-collection");
    this._prepareContent();
  },
  _prepareContent: deferRenderer(function() {
    this._renderContentImpl();
  }),
  _renderContent() {
    this._fireContentReadyAction();
  },
  _render() {
    this.callBase();
    this._attachClickEvent();
    this._attachHoldEvent();
    this._attachContextMenuEvent();
  },
  _getPointerEvent: () => pointer_default.down,
  _attachClickEvent() {
    const itemSelector = this._itemSelector();
    const pointerEvent = this._getPointerEvent();
    const clickEventNamespace = addNamespace(CLICK_EVENT_NAME, this.NAME);
    const pointerEventNamespace = addNamespace(pointerEvent, this.NAME);
    const pointerAction = new Action((args) => {
      const {
        event
      } = args;
      this._itemPointerDownHandler(event);
    });
    events_engine_default.off(this._itemContainer(), clickEventNamespace, itemSelector);
    events_engine_default.off(this._itemContainer(), pointerEventNamespace, itemSelector);
    events_engine_default.on(this._itemContainer(), clickEventNamespace, itemSelector, (e) => this._itemClickHandler(e));
    events_engine_default.on(this._itemContainer(), pointerEventNamespace, itemSelector, (e) => {
      pointerAction.execute({
        element: renderer_default(e.target),
        event: e
      });
    });
  },
  _itemClickHandler(e, args, config) {
    this._itemDXEventHandler(e, "onItemClick", args, config);
  },
  _itemPointerDownHandler(e) {
    if (!this.option("focusStateEnabled")) {
      return;
    }
    this._itemFocusHandler = function() {
      clearTimeout(this._itemFocusTimeout);
      this._itemFocusHandler = null;
      if (e.isDefaultPrevented()) {
        return;
      }
      const $target = renderer_default(e.target);
      const $closestItem = $target.closest(this._itemElements());
      const $closestFocusable = this._closestFocusable($target);
      if ($closestItem.length && this._isFocusTarget(null === $closestFocusable || void 0 === $closestFocusable ? void 0 : $closestFocusable.get(0))) {
        this.option("focusedElement", getPublicElement($closestItem));
      }
    }.bind(this);
    this._itemFocusTimeout = setTimeout(this._forcePointerDownFocus.bind(this));
  },
  _closestFocusable($target) {
    if ($target.is(focusable)) {
      return $target;
    }
    $target = $target.parent();
    while ($target.length && !dom_adapter_default.isDocument($target.get(0)) && !dom_adapter_default.isDocumentFragment($target.get(0))) {
      if ($target.is(focusable)) {
        return $target;
      }
      $target = $target.parent();
    }
  },
  _forcePointerDownFocus() {
    this._itemFocusHandler && this._itemFocusHandler();
  },
  _updateFocusState() {
    this.callBase.apply(this, arguments);
    this._forcePointerDownFocus();
  },
  _attachHoldEvent() {
    const $itemContainer = this._itemContainer();
    const itemSelector = this._itemSelector();
    const eventName = addNamespace(hold_default.name, this.NAME);
    events_engine_default.off($itemContainer, eventName, itemSelector);
    events_engine_default.on($itemContainer, eventName, itemSelector, {
      timeout: this._getHoldTimeout()
    }, this._itemHoldHandler.bind(this));
  },
  _getHoldTimeout() {
    return this.option("itemHoldTimeout");
  },
  _shouldFireHoldEvent() {
    return this.hasActionSubscription("onItemHold");
  },
  _itemHoldHandler(e) {
    if (this._shouldFireHoldEvent()) {
      this._itemDXEventHandler(e, "onItemHold");
    } else {
      e.cancel = true;
    }
  },
  _attachContextMenuEvent() {
    const $itemContainer = this._itemContainer();
    const itemSelector = this._itemSelector();
    const eventName = addNamespace(name, this.NAME);
    events_engine_default.off($itemContainer, eventName, itemSelector);
    events_engine_default.on($itemContainer, eventName, itemSelector, this._itemContextMenuHandler.bind(this));
  },
  _shouldFireContextMenuEvent() {
    return this.hasActionSubscription("onItemContextMenu");
  },
  _itemContextMenuHandler(e) {
    if (this._shouldFireContextMenuEvent()) {
      this._itemDXEventHandler(e, "onItemContextMenu");
    } else {
      e.cancel = true;
    }
  },
  _renderContentImpl() {
    const items = this.option("items") || [];
    if (this._renderedItemsCount) {
      this._renderItems(items.slice(this._renderedItemsCount));
    } else {
      this._renderItems(items);
    }
  },
  _renderItems(items) {
    if (items.length) {
      each(items, (index, itemData) => {
        this._renderItem(this._renderedItemsCount + index, itemData);
      });
    }
    this._renderEmptyMessage();
  },
  _getItemsContainer() {
    return this._itemContainer();
  },
  _setAttributes($element) {
    const attributes = _extends({}, this.option("_itemAttributes"));
    const {
      class: customClassValue
    } = attributes;
    if (customClassValue) {
      const currentClassValue = $element.get(0).className;
      attributes.class = [currentClassValue, customClassValue].join(" ");
    }
    $element.attr(attributes);
  },
  _renderItem(index, itemData, $container, $itemToReplace) {
    const itemIndex = (null === index || void 0 === index ? void 0 : index.item) ?? index;
    $container = $container || this._getItemsContainer();
    const $itemFrame = this._renderItemFrame(itemIndex, itemData, $container, $itemToReplace);
    this._setElementData($itemFrame, itemData, itemIndex);
    this._setAttributes($itemFrame);
    this._attachItemClickEvent(itemData, $itemFrame);
    const $itemContent = this._getItemContent($itemFrame);
    const renderContentPromise = this._renderItemContent({
      index: itemIndex,
      itemData,
      container: getPublicElement($itemContent),
      contentClass: this._itemContentClass(),
      defaultTemplateName: this.option("itemTemplate")
    });
    const that = this;
    when(renderContentPromise).done(($itemContent2) => {
      that._postprocessRenderItem({
        itemElement: $itemFrame,
        itemContent: $itemContent2,
        itemData,
        itemIndex
      });
      that._executeItemRenderAction(index, itemData, getPublicElement($itemFrame));
    });
    return $itemFrame;
  },
  _getItemContent($itemFrame) {
    const $itemContent = $itemFrame.find(".dx-item-content-placeholder");
    $itemContent.removeClass("dx-item-content-placeholder");
    return $itemContent;
  },
  _attachItemClickEvent(itemData, $itemElement) {
    if (!itemData || !itemData.onClick) {
      return;
    }
    events_engine_default.on($itemElement, CLICK_EVENT_NAME, (e) => {
      this._itemEventHandlerByHandler($itemElement, itemData.onClick, {
        event: e
      });
    });
  },
  _renderItemContent(args) {
    const itemTemplateName = this._getItemTemplateName(args);
    const itemTemplate = this._getTemplate(itemTemplateName);
    this._addItemContentClasses(args);
    const $templateResult = renderer_default(this._createItemByTemplate(itemTemplate, args));
    if (!$templateResult.hasClass("dx-template-wrapper")) {
      return args.container;
    }
    return this._renderItemContentByNode(args, $templateResult);
  },
  _renderItemContentByNode(args, $node) {
    renderer_default(args.container).replaceWith($node);
    args.container = getPublicElement($node);
    this._addItemContentClasses(args);
    return $node;
  },
  _addItemContentClasses(args) {
    const classes = [ITEM_CLASS + "-content", args.contentClass];
    renderer_default(args.container).addClass(classes.join(" "));
  },
  _appendItemToContainer($container, $itemFrame, index) {
    $itemFrame.appendTo($container);
  },
  _renderItemFrame(index, itemData, $container, $itemToReplace) {
    const $itemFrame = renderer_default("<div>");
    new this.constructor.ItemClass($itemFrame, this._itemOptions(), itemData || {});
    if ($itemToReplace && $itemToReplace.length) {
      $itemToReplace.replaceWith($itemFrame);
    } else {
      this._appendItemToContainer.call(this, $container, $itemFrame, index);
    }
    if (this.option("useItemTextAsTitle")) {
      const displayValue = this._displayGetter ? this._displayGetter(itemData) : itemData;
      $itemFrame.attr("title", displayValue);
    }
    return $itemFrame;
  },
  _itemOptions() {
    const that = this;
    return {
      watchMethod: () => that.option("integrationOptions.watchMethod"),
      owner: that,
      fieldGetter(field) {
        const expr = that.option(`${field}Expr`);
        const getter = compileGetter(expr);
        return getter;
      }
    };
  },
  _postprocessRenderItem: noop,
  _executeItemRenderAction(index, itemData, itemElement) {
    this._getItemRenderAction()({
      itemElement,
      itemIndex: index,
      itemData
    });
  },
  _setElementData(element, data, index) {
    element.addClass([ITEM_CLASS, this._itemClass()].join(" ")).data(this._itemDataKey(), data).data(this._itemIndexKey(), index);
  },
  _createItemRenderAction() {
    return this._itemRenderAction = this._createActionByOption("onItemRendered", {
      element: this.element(),
      excludeValidators: ["disabled", "readOnly"],
      category: "rendering"
    });
  },
  _getItemRenderAction() {
    return this._itemRenderAction || this._createItemRenderAction();
  },
  _getItemTemplateName(args) {
    const data = args.itemData;
    const templateProperty = args.templateProperty || this.option("itemTemplateProperty");
    const template = data && data[templateProperty];
    return template || args.defaultTemplateName;
  },
  _createItemByTemplate(itemTemplate, renderArgs) {
    return itemTemplate.render({
      model: renderArgs.itemData,
      container: renderArgs.container,
      index: renderArgs.index,
      onRendered: this._onItemTemplateRendered(itemTemplate, renderArgs)
    });
  },
  _onItemTemplateRendered: () => noop,
  _emptyMessageContainer() {
    return this._itemContainer();
  },
  _renderEmptyMessage(items) {
    items = items || this.option("items");
    const noDataText = this.option("noDataText");
    const hideNoData = !noDataText || items && items.length || this._dataController.isLoading();
    if (hideNoData && this._$noData) {
      this._$noData.remove();
      this._$noData = null;
      this.setAria("label", void 0);
    }
    if (!hideNoData) {
      this._$noData = this._$noData || renderer_default("<div>").addClass("dx-empty-message");
      this._$noData.appendTo(this._emptyMessageContainer());
      if (this.option("encodeNoDataText")) {
        this._$noData.text(noDataText);
      } else {
        this._$noData.html(noDataText);
      }
    }
    this.$element().toggleClass(EMPTY_COLLECTION, !hideNoData);
  },
  _itemDXEventHandler(dxEvent, handlerOptionName, actionArgs, actionConfig) {
    this._itemEventHandler(dxEvent.target, handlerOptionName, extend(actionArgs, {
      event: dxEvent
    }), actionConfig);
  },
  _itemEventHandler(initiator, handlerOptionName, actionArgs, actionConfig) {
    const action = this._createActionByOption(handlerOptionName, extend({
      validatingTargetName: "itemElement"
    }, actionConfig));
    return this._itemEventHandlerImpl(initiator, action, actionArgs);
  },
  _itemEventHandlerByHandler(initiator, handler, actionArgs, actionConfig) {
    const action = this._createAction(handler, extend({
      validatingTargetName: "itemElement"
    }, actionConfig));
    return this._itemEventHandlerImpl(initiator, action, actionArgs);
  },
  _itemEventHandlerImpl(initiator, action, actionArgs) {
    const $itemElement = this._closestItemElement(renderer_default(initiator));
    const args = extend({}, actionArgs);
    return action(extend(actionArgs, this._extendActionArgs($itemElement), args));
  },
  _extendActionArgs($itemElement) {
    return {
      itemElement: getPublicElement($itemElement),
      itemIndex: this._itemElements().index($itemElement),
      itemData: this._getItemData($itemElement)
    };
  },
  _closestItemElement($element) {
    return renderer_default($element).closest(this._itemSelector());
  },
  _getItemData(itemElement) {
    return renderer_default(itemElement).data(this._itemDataKey());
  },
  _getSummaryItemsSize(dimension, items, includeMargin) {
    let result2 = 0;
    if (items) {
      each(items, (_, item) => {
        if ("width" === dimension) {
          result2 += getOuterWidth(item, includeMargin || false);
        } else if ("height" === dimension) {
          result2 += getOuterHeight(item, includeMargin || false);
        }
      });
    }
    return result2;
  },
  getFocusedItemId() {
    if (!this._focusedItemId) {
      this._focusedItemId = `dx-${new guid_default()}`;
    }
    return this._focusedItemId;
  },
  itemElements() {
    return this._itemElements();
  },
  itemsContainer() {
    return this._itemContainer();
  }
}).include(data_helper_default);
CollectionWidget.ItemClass = m_item_default;
var m_collection_widget_base_default = CollectionWidget;

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.edit.strategy.js
init_class();
init_dom_adapter();
init_renderer();
init_common();
init_type();
var {
  abstract: abstract2
} = class_default;
var EditStrategy = class_default.inherit({
  ctor(collectionWidget) {
    this._collectionWidget = collectionWidget;
  },
  getIndexByItemData: abstract2,
  getItemDataByIndex: abstract2,
  getKeysByItems: abstract2,
  getItemsByKeys: abstract2,
  itemsGetter: abstract2,
  getKeyByIndex(index) {
    const resultIndex = this._denormalizeItemIndex(index);
    return this.getKeysByItems([this.getItemDataByIndex(resultIndex)])[0];
  },
  _equalKeys(key1, key2) {
    if (this._collectionWidget._isKeySpecified()) {
      return equalByValue(key1, key2);
    }
    return key1 === key2;
  },
  beginCache() {
    this._cache = {};
  },
  endCache() {
    this._cache = null;
  },
  getIndexByKey: abstract2,
  getNormalizedIndex(value) {
    if (this._isNormalizedItemIndex(value)) {
      return value;
    }
    if (this._isItemIndex(value)) {
      return this._normalizeItemIndex(value);
    }
    if (this._isNode(value)) {
      return this._getNormalizedItemIndex(value);
    }
    return this._normalizeItemIndex(this.getIndexByItemData(value));
  },
  getIndex(value) {
    if (this._isNormalizedItemIndex(value)) {
      return this._denormalizeItemIndex(value);
    }
    if (this._isItemIndex(value)) {
      return value;
    }
    if (this._isNode(value)) {
      return this._denormalizeItemIndex(this._getNormalizedItemIndex(value));
    }
    return this.getIndexByItemData(value);
  },
  getItemElement(value) {
    if (this._isNormalizedItemIndex(value)) {
      return this._getItemByNormalizedIndex(value);
    }
    if (this._isItemIndex(value)) {
      return this._getItemByNormalizedIndex(this._normalizeItemIndex(value));
    }
    if (this._isNode(value)) {
      return renderer_default(value);
    }
    const normalizedItemIndex = this._normalizeItemIndex(this.getIndexByItemData(value));
    return this._getItemByNormalizedIndex(normalizedItemIndex);
  },
  _isNode: (el) => dom_adapter_default.isNode(el && isRenderer(el) ? el.get(0) : el),
  deleteItemAtIndex: abstract2,
  itemPlacementFunc(movingIndex, destinationIndex) {
    return this._itemsFromSameParent(movingIndex, destinationIndex) && movingIndex < destinationIndex ? "after" : "before";
  },
  moveItemAtIndexToIndex: abstract2,
  _isNormalizedItemIndex: (index) => "number" === typeof index && Math.round(index) === index,
  _isItemIndex: abstract2,
  _getNormalizedItemIndex: abstract2,
  _normalizeItemIndex: abstract2,
  _denormalizeItemIndex: abstract2,
  _getItemByNormalizedIndex: abstract2,
  _itemsFromSameParent: abstract2
});
var m_collection_widget_edit_strategy_default = EditStrategy;

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.edit.strategy.plain.js
var PlainEditStrategy = m_collection_widget_edit_strategy_default.inherit({
  _getPlainItems() {
    return this._collectionWidget.option("items") || [];
  },
  getIndexByItemData(itemData) {
    const keyOf = this._collectionWidget.keyOf.bind(this._collectionWidget);
    if (keyOf) {
      return this.getIndexByKey(keyOf(itemData));
    }
    return this._getPlainItems().indexOf(itemData);
  },
  getItemDataByIndex(index) {
    return this._getPlainItems()[index];
  },
  deleteItemAtIndex(index) {
    this._getPlainItems().splice(index, 1);
  },
  itemsGetter() {
    return this._getPlainItems();
  },
  getKeysByItems(items) {
    const keyOf = this._collectionWidget.keyOf.bind(this._collectionWidget);
    let result2 = items;
    if (keyOf) {
      result2 = [];
      for (let i = 0; i < items.length; i++) {
        result2.push(keyOf(items[i]));
      }
    }
    return result2;
  },
  getIndexByKey(key) {
    const cache = this._cache;
    const keys = cache && cache.keys || this.getKeysByItems(this._getPlainItems());
    if (cache && !cache.keys) {
      cache.keys = keys;
    }
    if ("object" === typeof key) {
      for (let i = 0, {
        length
      } = keys; i < length; i++) {
        if (this._equalKeys(key, keys[i])) {
          return i;
        }
      }
    } else {
      return keys.indexOf(key);
    }
    return -1;
  },
  getItemsByKeys: (keys, items) => (items || keys).slice(),
  moveItemAtIndexToIndex(movingIndex, destinationIndex) {
    const items = this._getPlainItems();
    const movedItemData = items[movingIndex];
    items.splice(movingIndex, 1);
    items.splice(destinationIndex, 0, movedItemData);
  },
  _isItemIndex: (index) => "number" === typeof index && Math.round(index) === index,
  _getNormalizedItemIndex(itemElement) {
    return this._collectionWidget._itemElements().index(itemElement);
  },
  _normalizeItemIndex: (index) => index,
  _denormalizeItemIndex: (index) => index,
  _getItemByNormalizedIndex(index) {
    return index > -1 ? this._collectionWidget._itemElements().eq(index) : null;
  },
  _itemsFromSameParent: () => true
});
var m_collection_widget_edit_strategy_plain_default = PlainEditStrategy;

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.edit.js
var indexExists = function(index) {
  return -1 !== index;
};
var CollectionWidget2 = m_collection_widget_base_default.inherit({
  _setOptionsByReference() {
    this.callBase();
    extend(this._optionsByReference, {
      selectedItem: true
    });
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      selectionMode: "none",
      selectionRequired: false,
      selectByClick: true,
      selectedItems: [],
      selectedItemKeys: [],
      maxFilterLengthInRequest: 1500,
      keyExpr: null,
      selectedIndex: -1,
      selectedItem: null,
      onSelectionChanged: null,
      onItemReordered: null,
      onItemDeleting: null,
      onItemDeleted: null
    });
  },
  ctor(element, options2) {
    this._userOptions = options2 || {};
    this.callBase(element, options2);
  },
  _init() {
    this._initEditStrategy();
    this.callBase();
    this._initKeyGetter();
    this._initSelectionModule();
  },
  _initKeyGetter() {
    this._keyGetter = compileGetter(this.option("keyExpr"));
  },
  _getKeysByItems(selectedItems) {
    return this._editStrategy.getKeysByItems(selectedItems);
  },
  _getItemsByKeys(selectedItemKeys, selectedItems) {
    return this._editStrategy.getItemsByKeys(selectedItemKeys, selectedItems);
  },
  _getKeyByIndex(index) {
    return this._editStrategy.getKeyByIndex(index);
  },
  _getIndexByKey(key) {
    return this._editStrategy.getIndexByKey(key);
  },
  _getIndexByItemData(itemData) {
    return this._editStrategy.getIndexByItemData(itemData);
  },
  _isKeySpecified() {
    return !!this._dataController.key();
  },
  _getCombinedFilter() {
    return this._dataController.filter();
  },
  key() {
    if (this.option("keyExpr")) {
      return this.option("keyExpr");
    }
    return this._dataController.key();
  },
  keyOf(item) {
    let key = item;
    if (this.option("keyExpr")) {
      key = this._keyGetter(item);
    } else if (this._dataController.store()) {
      key = this._dataController.keyOf(item);
    }
    return key;
  },
  _nullValueSelectionSupported: () => false,
  _initSelectionModule() {
    const that = this;
    const {
      itemsGetter
    } = that._editStrategy;
    this._selection = new Selection({
      allowNullValue: this._nullValueSelectionSupported(),
      mode: this.option("selectionMode"),
      maxFilterLengthInRequest: this.option("maxFilterLengthInRequest"),
      equalByReference: !this._isKeySpecified(),
      onSelectionChanged(args) {
        if (args.addedItemKeys.length || args.removedItemKeys.length) {
          that.option("selectedItems", that._getItemsByKeys(args.selectedItemKeys, args.selectedItems));
          that._updateSelectedItems(args);
        }
      },
      filter: that._getCombinedFilter.bind(that),
      totalCount() {
        const items = that.option("items");
        const totalCount = that._dataController.totalCount();
        return totalCount >= 0 ? totalCount : that._getItemsCount(items);
      },
      key: that.key.bind(that),
      keyOf: that.keyOf.bind(that),
      load(options2) {
        var _dataController$loadO;
        const dataController = that._dataController;
        options2.customQueryParams = null === (_dataController$loadO = dataController.loadOptions()) || void 0 === _dataController$loadO ? void 0 : _dataController$loadO.customQueryParams;
        options2.userData = dataController.userData();
        if (dataController.store()) {
          return dataController.loadFromStore(options2).done((loadResult) => {
            if (that._disposed) {
              return;
            }
            const items = normalizeLoadResult(loadResult).data;
            dataController.applyMapFunction(items);
          });
        }
        return Deferred().resolve(this.plainItems());
      },
      dataFields: () => that._dataController.select(),
      plainItems: itemsGetter.bind(that._editStrategy)
    });
  },
  _getItemsCount(items) {
    return items.reduce((itemsCount, item) => itemsCount + (item.items ? this._getItemsCount(item.items) : 1), 0);
  },
  _initEditStrategy() {
    const Strategy = m_collection_widget_edit_strategy_plain_default;
    this._editStrategy = new Strategy(this);
  },
  _getSelectedItemIndices(keys) {
    const that = this;
    const indices = [];
    keys = keys || this._selection.getSelectedItemKeys();
    that._editStrategy.beginCache();
    each(keys, (_, key) => {
      const selectedIndex = that._getIndexByKey(key);
      if (indexExists(selectedIndex)) {
        indices.push(selectedIndex);
      }
    });
    that._editStrategy.endCache();
    return indices;
  },
  _initMarkup() {
    this._rendering = true;
    if (!this._dataController.isLoading()) {
      this._syncSelectionOptions().done(() => this._normalizeSelectedItems());
    }
    this.callBase();
  },
  _render() {
    this.callBase();
    this._rendering = false;
  },
  _fireContentReadyAction() {
    this._rendering = false;
    this._rendered = true;
    this.callBase.apply(this, arguments);
  },
  _syncSelectionOptions(byOption) {
    byOption = byOption || this._chooseSelectOption();
    let selectedItem;
    let selectedIndex;
    let selectedItemKeys;
    let selectedItems;
    switch (byOption) {
      case "selectedIndex":
        selectedItem = this._editStrategy.getItemDataByIndex(this.option("selectedIndex"));
        if (isDefined(selectedItem)) {
          this._setOptionWithoutOptionChange("selectedItems", [selectedItem]);
          this._setOptionWithoutOptionChange("selectedItem", selectedItem);
          this._setOptionWithoutOptionChange("selectedItemKeys", this._editStrategy.getKeysByItems([selectedItem]));
        } else {
          this._setOptionWithoutOptionChange("selectedItems", []);
          this._setOptionWithoutOptionChange("selectedItemKeys", []);
          this._setOptionWithoutOptionChange("selectedItem", null);
        }
        break;
      case "selectedItems":
        selectedItems = this.option("selectedItems") || [];
        selectedIndex = selectedItems.length ? this._editStrategy.getIndexByItemData(selectedItems[0]) : -1;
        if (this.option("selectionRequired") && !indexExists(selectedIndex)) {
          return this._syncSelectionOptions("selectedIndex");
        }
        this._setOptionWithoutOptionChange("selectedItem", selectedItems[0]);
        this._setOptionWithoutOptionChange("selectedIndex", selectedIndex);
        this._setOptionWithoutOptionChange("selectedItemKeys", this._editStrategy.getKeysByItems(selectedItems));
        break;
      case "selectedItem":
        selectedItem = this.option("selectedItem");
        selectedIndex = this._editStrategy.getIndexByItemData(selectedItem);
        if (this.option("selectionRequired") && !indexExists(selectedIndex)) {
          return this._syncSelectionOptions("selectedIndex");
        }
        if (isDefined(selectedItem)) {
          this._setOptionWithoutOptionChange("selectedItems", [selectedItem]);
          this._setOptionWithoutOptionChange("selectedIndex", selectedIndex);
          this._setOptionWithoutOptionChange("selectedItemKeys", this._editStrategy.getKeysByItems([selectedItem]));
        } else {
          this._setOptionWithoutOptionChange("selectedItems", []);
          this._setOptionWithoutOptionChange("selectedItemKeys", []);
          this._setOptionWithoutOptionChange("selectedIndex", -1);
        }
        break;
      case "selectedItemKeys":
        selectedItemKeys = this.option("selectedItemKeys");
        if (this.option("selectionRequired")) {
          const selectedItemIndex = this._getIndexByKey(selectedItemKeys[0]);
          if (!indexExists(selectedItemIndex)) {
            return this._syncSelectionOptions("selectedIndex");
          }
        }
        return this._selection.setSelection(selectedItemKeys);
    }
    return Deferred().resolve().promise();
  },
  _chooseSelectOption() {
    let optionName = "selectedIndex";
    const isOptionDefined = function(optionName2) {
      const optionValue = this.option(optionName2);
      const length = isDefined(optionValue) && optionValue.length;
      return length || optionName2 in this._userOptions;
    }.bind(this);
    if (isOptionDefined("selectedItems")) {
      optionName = "selectedItems";
    } else if (isOptionDefined("selectedItem")) {
      optionName = "selectedItem";
    } else if (isOptionDefined("selectedItemKeys")) {
      optionName = "selectedItemKeys";
    }
    return optionName;
  },
  _compareKeys(oldKeys, newKeys) {
    if (oldKeys.length !== newKeys.length) {
      return false;
    }
    for (let i = 0; i < newKeys.length; i++) {
      if (oldKeys[i] !== newKeys[i]) {
        return false;
      }
    }
    return true;
  },
  _normalizeSelectedItems() {
    if ("none" === this.option("selectionMode")) {
      this._setOptionWithoutOptionChange("selectedItems", []);
      this._syncSelectionOptions("selectedItems");
    } else if ("single" === this.option("selectionMode")) {
      const newSelection = this.option("selectedItems");
      if (newSelection.length > 1 || !newSelection.length && this.option("selectionRequired") && this.option("items") && this.option("items").length) {
        const currentSelection = this._selection.getSelectedItems();
        let normalizedSelection = void 0 === newSelection[0] ? currentSelection[0] : newSelection[0];
        if (void 0 === normalizedSelection) {
          normalizedSelection = this._editStrategy.itemsGetter()[0];
        }
        if (this.option("grouped") && normalizedSelection && normalizedSelection.items) {
          normalizedSelection.items = [normalizedSelection.items[0]];
        }
        this._selection.setSelection(this._getKeysByItems([normalizedSelection]));
        this._setOptionWithoutOptionChange("selectedItems", [normalizedSelection]);
        return this._syncSelectionOptions("selectedItems");
      }
      this._selection.setSelection(this._getKeysByItems(newSelection));
    } else {
      const newKeys = this._getKeysByItems(this.option("selectedItems"));
      const oldKeys = this._selection.getSelectedItemKeys();
      if (!this._compareKeys(oldKeys, newKeys)) {
        this._selection.setSelection(newKeys);
      }
    }
    return Deferred().resolve().promise();
  },
  _itemClickHandler(e) {
    let itemSelectPromise = Deferred().resolve();
    const {
      callBase
    } = this;
    this._createAction((e2) => {
      itemSelectPromise = this._itemSelectHandler(e2.event) ?? itemSelectPromise;
    }, {
      validatingTargetName: "itemElement"
    })({
      itemElement: renderer_default(e.currentTarget),
      event: e
    });
    itemSelectPromise.always(() => {
      callBase.apply(this, arguments);
    });
  },
  _itemSelectHandler(e) {
    var _itemSelectPromise;
    let itemSelectPromise;
    if (!this.option("selectByClick")) {
      return;
    }
    const $itemElement = e.currentTarget;
    if (this.isItemSelected($itemElement)) {
      this.unselectItem(e.currentTarget);
    } else {
      itemSelectPromise = this.selectItem(e.currentTarget);
    }
    return null === (_itemSelectPromise = itemSelectPromise) || void 0 === _itemSelectPromise ? void 0 : _itemSelectPromise.promise();
  },
  _selectedItemElement(index) {
    return this._itemElements().eq(index);
  },
  _postprocessRenderItem(args) {
    if ("none" !== this.option("selectionMode")) {
      const $itemElement = renderer_default(args.itemElement);
      const normalizedItemIndex = this._editStrategy.getNormalizedIndex($itemElement);
      const isItemSelected = this._isItemSelected(normalizedItemIndex);
      this._processSelectableItem($itemElement, isItemSelected);
    }
  },
  _processSelectableItem($itemElement, isSelected) {
    $itemElement.toggleClass(this._selectedItemClass(), isSelected);
    this._setAriaSelectionAttribute($itemElement, String(isSelected));
  },
  _updateSelectedItems(args) {
    const that = this;
    const {
      addedItemKeys
    } = args;
    const {
      removedItemKeys
    } = args;
    if (that._rendered && (addedItemKeys.length || removedItemKeys.length)) {
      const selectionChangePromise = that._selectionChangePromise;
      if (!that._rendering) {
        const addedSelection = [];
        let normalizedIndex;
        const removedSelection = [];
        that._editStrategy.beginCache();
        for (let i = 0; i < addedItemKeys.length; i++) {
          normalizedIndex = that._getIndexByKey(addedItemKeys[i]);
          addedSelection.push(normalizedIndex);
          that._addSelection(normalizedIndex);
        }
        for (let i = 0; i < removedItemKeys.length; i++) {
          normalizedIndex = that._getIndexByKey(removedItemKeys[i]);
          removedSelection.push(normalizedIndex);
          that._removeSelection(normalizedIndex);
        }
        that._editStrategy.endCache();
        that._updateSelection(addedSelection, removedSelection);
      }
      when(selectionChangePromise).done(() => {
        that._fireSelectionChangeEvent(args.addedItems, args.removedItems);
      });
    }
  },
  _fireSelectionChangeEvent(addedItems, removedItems) {
    this._createActionByOption("onSelectionChanged", {
      excludeValidators: ["disabled", "readOnly"]
    })({
      addedItems,
      removedItems
    });
  },
  _updateSelection: noop,
  _setAriaSelectionAttribute($target, value) {
    this.setAria("selected", value, $target);
  },
  _removeSelection(normalizedIndex) {
    const $itemElement = this._editStrategy.getItemElement(normalizedIndex);
    if (indexExists(normalizedIndex)) {
      this._processSelectableItem($itemElement, false);
      events_engine_default.triggerHandler($itemElement, "stateChanged", false);
    }
  },
  _addSelection(normalizedIndex) {
    const $itemElement = this._editStrategy.getItemElement(normalizedIndex);
    if (indexExists(normalizedIndex)) {
      this._processSelectableItem($itemElement, true);
      events_engine_default.triggerHandler($itemElement, "stateChanged", true);
    }
  },
  _isItemSelected(index) {
    const key = this._getKeyByIndex(index);
    return this._selection.isItemSelected(key, {
      checkPending: true
    });
  },
  _optionChanged(args) {
    switch (args.name) {
      case "selectionMode":
        this._invalidate();
        break;
      case "dataSource":
        if (!args.value || Array.isArray(args.value) && !args.value.length) {
          this.option("selectedItemKeys", []);
        }
        this.callBase(args);
        break;
      case "selectedIndex":
      case "selectedItem":
      case "selectedItems":
      case "selectedItemKeys":
        this._syncSelectionOptions(args.name).done(() => this._normalizeSelectedItems());
        break;
      case "keyExpr":
        this._initKeyGetter();
        break;
      case "selectionRequired":
        this._normalizeSelectedItems();
        break;
      case "selectByClick":
      case "onSelectionChanged":
      case "onItemDeleting":
      case "onItemDeleted":
      case "onItemReordered":
      case "maxFilterLengthInRequest":
        break;
      default:
        this.callBase(args);
    }
  },
  _clearSelectedItems() {
    this._setOptionWithoutOptionChange("selectedItems", []);
    this._syncSelectionOptions("selectedItems");
  },
  _waitDeletingPrepare($itemElement) {
    if ($itemElement.data("dxItemDeleting")) {
      return Deferred().resolve().promise();
    }
    $itemElement.data("dxItemDeleting", true);
    const deferred = Deferred();
    const deletingActionArgs = {
      cancel: false
    };
    const deletePromise = this._itemEventHandler($itemElement, "onItemDeleting", deletingActionArgs, {
      excludeValidators: ["disabled", "readOnly"]
    });
    when(deletePromise).always(function(value) {
      const deletePromiseExists = !deletePromise;
      const deletePromiseResolved = !deletePromiseExists && "resolved" === deletePromise.state();
      const argumentsSpecified = !!arguments.length;
      const shouldDelete = deletePromiseExists || deletePromiseResolved && !argumentsSpecified || deletePromiseResolved && value;
      when(fromPromise(deletingActionArgs.cancel)).always(() => {
        $itemElement.data("dxItemDeleting", false);
      }).done((cancel) => {
        shouldDelete && !cancel ? deferred.resolve() : deferred.reject();
      }).fail(deferred.reject);
    });
    return deferred.promise();
  },
  _deleteItemFromDS($item) {
    const dataController = this._dataController;
    const deferred = Deferred();
    const disabledState = this.option("disabled");
    const dataStore = dataController.store();
    if (!dataStore) {
      return Deferred().resolve().promise();
    }
    if (!dataStore.remove) {
      throw ui_errors_default.Error("E1011");
    }
    this.option("disabled", true);
    dataStore.remove(dataController.keyOf(this._getItemData($item))).done((key) => {
      if (void 0 !== key) {
        deferred.resolve();
      } else {
        deferred.reject();
      }
    }).fail(() => {
      deferred.reject();
    });
    deferred.always(() => {
      this.option("disabled", disabledState);
    });
    return deferred;
  },
  _tryRefreshLastPage() {
    const deferred = Deferred();
    if (this._isLastPage() || this.option("grouped")) {
      deferred.resolve();
    } else {
      this._refreshLastPage().done(() => {
        deferred.resolve();
      });
    }
    return deferred.promise();
  },
  _refreshLastPage() {
    this._expectLastItemLoading();
    return this._dataController.load();
  },
  _updateSelectionAfterDelete(index) {
    const key = this._getKeyByIndex(index);
    this._selection.deselect([key]);
  },
  _updateIndicesAfterIndex(index) {
    const itemElements = this._itemElements();
    for (let i = index + 1; i < itemElements.length; i++) {
      renderer_default(itemElements[i]).data(this._itemIndexKey(), i - 1);
    }
  },
  _simulateOptionChange(optionName) {
    const optionValue = this.option(optionName);
    if (optionValue instanceof DataSource) {
      return;
    }
    this._optionChangedAction({
      name: optionName,
      fullName: optionName,
      value: optionValue
    });
  },
  isItemSelected(itemElement) {
    return this._isItemSelected(this._editStrategy.getNormalizedIndex(itemElement));
  },
  selectItem(itemElement) {
    if ("none" === this.option("selectionMode")) {
      return;
    }
    const itemIndex = this._editStrategy.getNormalizedIndex(itemElement);
    if (!indexExists(itemIndex)) {
      return;
    }
    const key = this._getKeyByIndex(itemIndex);
    if (this._selection.isItemSelected(key)) {
      return;
    }
    if ("single" === this.option("selectionMode")) {
      return this._selection.setSelection([key]);
    }
    const selectedItemKeys = this.option("selectedItemKeys") || [];
    return this._selection.setSelection([...selectedItemKeys, key], [key]);
  },
  unselectItem(itemElement) {
    const itemIndex = this._editStrategy.getNormalizedIndex(itemElement);
    if (!indexExists(itemIndex)) {
      return;
    }
    const selectedItemKeys = this._selection.getSelectedItemKeys();
    if (this.option("selectionRequired") && selectedItemKeys.length <= 1) {
      return;
    }
    const key = this._getKeyByIndex(itemIndex);
    if (!this._selection.isItemSelected(key, {
      checkPending: true
    })) {
      return;
    }
    this._selection.deselect([key]);
  },
  _deleteItemElementByIndex(index) {
    this._updateSelectionAfterDelete(index);
    this._updateIndicesAfterIndex(index);
    this._editStrategy.deleteItemAtIndex(index);
  },
  _afterItemElementDeleted($item, deletedActionArgs) {
    const changingOption = this._dataController.getDataSource() ? "dataSource" : "items";
    this._simulateOptionChange(changingOption);
    this._itemEventHandler($item, "onItemDeleted", deletedActionArgs, {
      beforeExecute() {
        $item.remove();
      },
      excludeValidators: ["disabled", "readOnly"]
    });
    this._renderEmptyMessage();
  },
  deleteItem(itemElement) {
    const that = this;
    const deferred = Deferred();
    const $item = this._editStrategy.getItemElement(itemElement);
    const index = this._editStrategy.getNormalizedIndex(itemElement);
    const itemResponseWaitClass = this._itemResponseWaitClass();
    if (indexExists(index)) {
      this._waitDeletingPrepare($item).done(() => {
        $item.addClass(itemResponseWaitClass);
        const deletedActionArgs = that._extendActionArgs($item);
        that._deleteItemFromDS($item).done(() => {
          that._deleteItemElementByIndex(index);
          that._afterItemElementDeleted($item, deletedActionArgs);
          that._tryRefreshLastPage().done(() => {
            deferred.resolveWith(that);
          });
        }).fail(() => {
          $item.removeClass(itemResponseWaitClass);
          deferred.rejectWith(that);
        });
      }).fail(() => {
        deferred.rejectWith(that);
      });
    } else {
      deferred.rejectWith(that);
    }
    return deferred.promise();
  },
  reorderItem(itemElement, toItemElement) {
    const deferred = Deferred();
    const that = this;
    const strategy = this._editStrategy;
    const $movingItem = strategy.getItemElement(itemElement);
    const $destinationItem = strategy.getItemElement(toItemElement);
    const movingIndex = strategy.getNormalizedIndex(itemElement);
    const destinationIndex = strategy.getNormalizedIndex(toItemElement);
    const changingOption = this._dataController.getDataSource() ? "dataSource" : "items";
    const canMoveItems = indexExists(movingIndex) && indexExists(destinationIndex) && movingIndex !== destinationIndex;
    if (canMoveItems) {
      deferred.resolveWith(this);
    } else {
      deferred.rejectWith(this);
    }
    return deferred.promise().done(function() {
      $destinationItem[strategy.itemPlacementFunc(movingIndex, destinationIndex)]($movingItem);
      strategy.moveItemAtIndexToIndex(movingIndex, destinationIndex);
      this._updateIndicesAfterIndex(movingIndex);
      that.option("selectedItems", that._getItemsByKeys(that._selection.getSelectedItemKeys(), that._selection.getSelectedItems()));
      if ("items" === changingOption) {
        that._simulateOptionChange(changingOption);
      }
      that._itemEventHandler($movingItem, "onItemReordered", {
        fromIndex: strategy.getIndex(movingIndex),
        toIndex: strategy.getIndex(destinationIndex)
      }, {
        excludeValidators: ["disabled", "readOnly"]
      });
    });
  }
});
var m_collection_widget_edit_default = CollectionWidget2;

// node_modules/devextreme/esm/__internal/ui/collection/m_collection_widget.live_update.js
var PRIVATE_KEY_FIELD = "__dx_key__";
var m_collection_widget_live_update_default = m_collection_widget_edit_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      repaintChangesOnly: false
    });
  },
  ctor() {
    var _this$_dataController;
    this.callBase.apply(this, arguments);
    this._customizeStoreLoadOptions = (e) => {
      const dataController = this._dataController;
      if (dataController.getDataSource() && !this._dataController.isLoaded()) {
        this._correctionIndex = 0;
      }
      if (this._correctionIndex && e.storeLoadOptions) {
        e.storeLoadOptions.skip += this._correctionIndex;
      }
    };
    null === (_this$_dataController = this._dataController) || void 0 === _this$_dataController || _this$_dataController.on("customizeStoreLoadOptions", this._customizeStoreLoadOptions);
  },
  reload() {
    this._correctionIndex = 0;
  },
  _init() {
    this.callBase();
    this._refreshItemsCache();
    this._correctionIndex = 0;
  },
  _findItemElementByKey(key) {
    let result2 = renderer_default();
    const keyExpr = this.key();
    this.itemElements().each((_, item) => {
      const $item = renderer_default(item);
      const itemData = this._getItemData($item);
      if (keyExpr ? keysEqual(keyExpr, this.keyOf(itemData), key) : this._isItemEquals(itemData, key)) {
        result2 = $item;
        return false;
      }
    });
    return result2;
  },
  _dataSourceChangedHandler(newItems, e) {
    if (null !== e && void 0 !== e && e.changes) {
      this._modifyByChanges(e.changes);
    } else {
      this.callBase(newItems, e);
      this._refreshItemsCache();
    }
  },
  _isItemEquals(item1, item2) {
    if (item1 && item1.__dx_key__) {
      item1 = item1.data;
    }
    try {
      return JSON.stringify(item1) === JSON.stringify(item2);
    } catch (e) {
      return item1 === item2;
    }
  },
  _isItemStrictEquals(item1, item2) {
    return this._isItemEquals(item1, item2);
  },
  _shouldAddNewGroup(changes, items) {
    let result2 = false;
    if (this.option("grouped")) {
      if (!changes.length) {
        result2 = true;
      }
      each(changes, (i, change) => {
        if ("insert" === change.type) {
          result2 = true;
          each(items, (_, item) => {
            if (void 0 !== change.data.key && change.data.key === item.key) {
              result2 = false;
              return false;
            }
          });
        }
      });
    }
    return result2;
  },
  _partialRefresh() {
    if (this.option("repaintChangesOnly")) {
      const keyOf = (data) => {
        if (data && void 0 !== data.__dx_key__) {
          return data.__dx_key__;
        }
        return this.keyOf(data);
      };
      const result2 = findChanges(this._itemsCache, this._editStrategy.itemsGetter(), keyOf, this._isItemStrictEquals.bind(this));
      if (result2 && this._itemsCache.length && !this._shouldAddNewGroup(result2, this._itemsCache)) {
        this._modifyByChanges(result2, true);
        this._renderEmptyMessage();
        return true;
      }
      this._refreshItemsCache();
    }
    return false;
  },
  _refreshItemsCache() {
    if (this.option("repaintChangesOnly")) {
      const items = this._editStrategy.itemsGetter();
      try {
        this._itemsCache = extend(true, [], items);
        if (!this.key()) {
          this._itemsCache = this._itemsCache.map((itemCache, index) => ({
            [PRIVATE_KEY_FIELD]: items[index],
            data: itemCache
          }));
        }
      } catch (e) {
        this._itemsCache = extend([], items);
      }
    }
  },
  _dispose() {
    this._dataController.off("customizeStoreLoadOptions", this._customizeStoreLoadOptions);
    this.callBase();
  },
  _updateByChange(keyInfo, items, change, isPartialRefresh) {
    if (isPartialRefresh) {
      this._renderItem(change.index, change.data, null, this._findItemElementByKey(change.key));
    } else {
      const changedItem = items[indexByKey(keyInfo, items, change.key)];
      if (changedItem) {
        update(keyInfo, items, change.key, change.data).done(() => {
          this._renderItem(items.indexOf(changedItem), changedItem, null, this._findItemElementByKey(change.key));
        });
      }
    }
  },
  _insertByChange(keyInfo, items, change, isPartialRefresh) {
    when(isPartialRefresh || insert(keyInfo, items, change.data, change.index)).done(() => {
      this._beforeItemElementInserted(change);
      this._renderItem(change.index ?? items.length, change.data);
      this._afterItemElementInserted();
      this._correctionIndex++;
    });
  },
  _updateSelectionAfterRemoveByChange(removeIndex) {
    const selectedIndex = this.option("selectedIndex");
    if (selectedIndex > removeIndex) {
      this.option("selectedIndex", selectedIndex - 1);
    } else if (selectedIndex === removeIndex && 1 === this.option("selectedItems").length) {
      this.option("selectedItems", []);
    } else {
      this._normalizeSelectedItems();
    }
  },
  _beforeItemElementInserted(change) {
    const selectedIndex = this.option("selectedIndex");
    if (change.index <= selectedIndex) {
      this.option("selectedIndex", selectedIndex + 1);
    }
  },
  _afterItemElementInserted: noop,
  _removeByChange(keyInfo, items, change, isPartialRefresh) {
    const index = isPartialRefresh ? change.index : indexByKey(keyInfo, items, change.key);
    const removedItem = isPartialRefresh ? change.oldItem : items[index];
    if (removedItem) {
      const $removedItemElement = this._findItemElementByKey(change.key);
      const deletedActionArgs = this._extendActionArgs($removedItemElement);
      this._waitDeletingPrepare($removedItemElement).done(() => {
        if (isPartialRefresh) {
          this._updateIndicesAfterIndex(index - 1);
          this._afterItemElementDeleted($removedItemElement, deletedActionArgs);
          this._updateSelectionAfterRemoveByChange(index);
        } else {
          this._deleteItemElementByIndex(index);
          this._afterItemElementDeleted($removedItemElement, deletedActionArgs);
        }
      });
      this._correctionIndex--;
    }
  },
  _modifyByChanges(changes, isPartialRefresh) {
    const items = this._editStrategy.itemsGetter();
    const keyInfo = {
      key: this.key.bind(this),
      keyOf: this.keyOf.bind(this)
    };
    const dataController = this._dataController;
    const paginate = dataController.paginate();
    const group = dataController.group();
    if (paginate || group) {
      changes = changes.filter((item) => "insert" !== item.type || void 0 !== item.index);
    }
    changes.forEach((change) => this[`_${change.type}ByChange`](keyInfo, items, change, isPartialRefresh));
    this._renderedItemsCount = items.length;
    this._refreshItemsCache();
    this._fireContentReadyAction();
  },
  _appendItemToContainer($container, $itemFrame, index) {
    const nextSiblingElement = $container.children(this._itemSelector()).get(index);
    dom_adapter_default.insertElement($container.get(0), $itemFrame.get(0), nextSiblingElement);
  },
  _optionChanged(args) {
    switch (args.name) {
      case "items": {
        const isItemsUpdated = this._partialRefresh(args.value);
        if (!isItemsUpdated) {
          this.callBase(args);
        }
        break;
      }
      case "dataSource":
        if (!this.option("repaintChangesOnly") || !args.value) {
          this.option("items", []);
        }
        this.callBase(args);
        break;
      case "repaintChangesOnly":
        break;
      default:
        this.callBase(args);
    }
  }
});

// node_modules/devextreme/esm/ui/collection/ui.collection_widget.live_update.js
var ui_collection_widget_live_update_default = m_collection_widget_live_update_default;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollable.js
init_renderer();
init_common();
init_deferred();
init_extend();
init_size();
init_type();
init_window();
init_events_engine();

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/get_element_location_internal.js
init_extends();
init_inflector();

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/get_relative_offset.js
function getRelativeOffset(targetElementClass, sourceElement) {
  const offset = {
    left: 0,
    top: 0
  };
  let element = sourceElement;
  while (null !== (_element = element) && void 0 !== _element && _element.offsetParent && !element.classList.contains(targetElementClass)) {
    var _element;
    const parentElement = element.offsetParent;
    const elementRect = element.getBoundingClientRect();
    const parentElementRect = parentElement.getBoundingClientRect();
    offset.left += elementRect.left - parentElementRect.left;
    offset.top += elementRect.top - parentElementRect.top;
    element = element.offsetParent;
  }
  return offset;
}

// node_modules/devextreme/esm/renovation/ui/scroll_view/utils/get_element_location_internal.js
function getElementLocationInternal(targetElement, direction, containerElement, scrollOffset, offset) {
  const additionalOffset = _extends({
    top: 0,
    left: 0,
    right: 0,
    bottom: 0
  }, offset);
  const isVertical = direction === DIRECTION_VERTICAL;
  const prop = isVertical ? "top" : "left";
  const inverseProp = isVertical ? "bottom" : "right";
  const dimension = isVertical ? "height" : "width";
  const containerOffsetSize = containerElement[`offset${titleize(dimension)}`];
  const containerClientSize = containerElement[`client${titleize(dimension)}`];
  const containerSize = containerElement.getBoundingClientRect()[dimension];
  const elementSize = targetElement.getBoundingClientRect()[dimension];
  let scale = 1;
  if (Math.abs(containerSize - containerOffsetSize) > 1) {
    scale = containerSize / containerOffsetSize;
  }
  const relativeElementOffset = getRelativeOffset(SCROLLABLE_CONTENT_CLASS, targetElement)[prop] / scale;
  const containerScrollOffset = scrollOffset[prop];
  const relativeStartOffset = containerScrollOffset - relativeElementOffset + additionalOffset[prop];
  const relativeEndOffset = containerScrollOffset - relativeElementOffset - elementSize / scale + containerClientSize - additionalOffset[inverseProp];
  if (relativeStartOffset <= 0 && relativeEndOffset >= 0) {
    return containerScrollOffset;
  }
  return containerScrollOffset - (Math.abs(relativeStartOffset) > Math.abs(relativeEndOffset) ? relativeEndOffset : relativeStartOffset);
}

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollable.device.js
var deviceDependentOptions = function() {
  return [{
    device: () => !nativeScrolling,
    options: {
      useNative: false
    }
  }, {
    device: (device) => !devices_default.isSimulator() && "desktop" === devices_default.real().deviceType && "generic" === device.platform,
    options: {
      bounceEnabled: false,
      scrollByThumb: true,
      scrollByContent: touch,
      showScrollbar: "onHover"
    }
  }];
};

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollable.native.js
init_class();
init_renderer();
init_common();
init_iterator();
init_size();
init_events_engine();

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollbar.js
init_dom_adapter();
init_renderer();
init_common();
init_extend();
init_ready_callbacks();
init_type();
init_events_engine();
var SCROLLBAR = "dxScrollbar";
var HOVER_ENABLED_STATE = "dx-scrollbar-hoverable";
var HORIZONTAL = "horizontal";
var SCROLLBAR_VISIBLE = {
  onScroll: "onScroll",
  onHover: "onHover",
  always: "always",
  never: "never"
};
var activeScrollbar = null;
var Scrollbar = ui_widget_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      direction: null,
      visible: false,
      activeStateEnabled: false,
      visibilityMode: SCROLLBAR_VISIBLE.onScroll,
      containerSize: 0,
      contentSize: 0,
      expandable: true,
      scaleRatio: 1
    });
  },
  _init() {
    this.callBase();
    this._isHovered = false;
  },
  _initMarkup() {
    this._renderThumb();
    this.callBase();
  },
  _render() {
    this.callBase();
    this._renderDirection();
    this._update();
    this._attachPointerDownHandler();
    this.option("hoverStateEnabled", this._isHoverMode());
    this.$element().toggleClass(HOVER_ENABLED_STATE, this.option("hoverStateEnabled"));
  },
  _renderThumb() {
    this._$thumb = renderer_default("<div>").addClass("dx-scrollable-scroll");
    renderer_default("<div>").addClass("dx-scrollable-scroll-content").appendTo(this._$thumb);
    this.$element().addClass("dx-scrollable-scrollbar").append(this._$thumb);
  },
  isThumb($element) {
    return !!this.$element().find($element).length;
  },
  _isHoverMode() {
    const visibilityMode = this.option("visibilityMode");
    return (visibilityMode === SCROLLBAR_VISIBLE.onHover || visibilityMode === SCROLLBAR_VISIBLE.always) && this.option("expandable");
  },
  _renderDirection() {
    const direction = this.option("direction");
    this.$element().addClass(`dx-scrollbar-${direction}`);
    this._dimension = direction === HORIZONTAL ? "width" : "height";
    this._prop = direction === HORIZONTAL ? "left" : "top";
  },
  _attachPointerDownHandler() {
    events_engine_default.on(this._$thumb, addNamespace(pointer_default.down, SCROLLBAR), this.feedbackOn.bind(this));
  },
  feedbackOn(e) {
    null === e || void 0 === e || e.preventDefault();
    this.$element().addClass("dx-scrollable-scrollbar-active");
    activeScrollbar = this;
  },
  feedbackOff() {
    this.$element().removeClass("dx-scrollable-scrollbar-active");
    activeScrollbar = null;
  },
  cursorEnter() {
    this._isHovered = true;
    if (this._needScrollbar()) {
      this.option("visible", true);
    }
  },
  cursorLeave() {
    this._isHovered = false;
    this.option("visible", false);
  },
  _renderDimensions() {
    this._$thumb.css({
      width: this.option("width"),
      height: this.option("height")
    });
  },
  _toggleVisibility(visible) {
    if (this.option("visibilityMode") === SCROLLBAR_VISIBLE.onScroll) {
      this._$thumb.css("opacity");
    }
    visible = this._adjustVisibility(visible);
    this.option().visible = visible;
    this._$thumb.toggleClass("dx-state-invisible", !visible);
  },
  _adjustVisibility(visible) {
    if (this._baseContainerToContentRatio && !this._needScrollbar()) {
      return false;
    }
    switch (this.option("visibilityMode")) {
      case SCROLLBAR_VISIBLE.onScroll:
        break;
      case SCROLLBAR_VISIBLE.onHover:
        visible = visible || !!this._isHovered;
        break;
      case SCROLLBAR_VISIBLE.never:
        visible = false;
        break;
      case SCROLLBAR_VISIBLE.always:
        visible = true;
    }
    return visible;
  },
  moveTo(location) {
    if (this._isHidden()) {
      return;
    }
    if (isPlainObject(location)) {
      location = location[this._prop] || 0;
    }
    const scrollBarLocation = {};
    scrollBarLocation[this._prop] = this._calculateScrollBarPosition(location);
    move(this._$thumb, scrollBarLocation);
  },
  _calculateScrollBarPosition(location) {
    return -location * this._thumbRatio;
  },
  _update() {
    const containerSize = Math.round(this.option("containerSize"));
    const contentSize = Math.round(this.option("contentSize"));
    let baseContainerSize = Math.round(this.option("baseContainerSize"));
    let baseContentSize = Math.round(this.option("baseContentSize"));
    if (isNaN(baseContainerSize)) {
      baseContainerSize = containerSize;
      baseContentSize = contentSize;
    }
    this._baseContainerToContentRatio = baseContentSize ? baseContainerSize / baseContentSize : baseContainerSize;
    this._realContainerToContentRatio = contentSize ? containerSize / contentSize : containerSize;
    const thumbSize = Math.round(Math.max(Math.round(containerSize * this._realContainerToContentRatio), 15));
    this._thumbRatio = (containerSize - thumbSize) / (this.option("scaleRatio") * (contentSize - containerSize));
    this.option(this._dimension, thumbSize / this.option("scaleRatio"));
    this.$element().css("display", this._needScrollbar() ? "" : "none");
  },
  _isHidden() {
    return this.option("visibilityMode") === SCROLLBAR_VISIBLE.never;
  },
  _needScrollbar() {
    return !this._isHidden() && this._baseContainerToContentRatio < 1;
  },
  containerToContentRatio() {
    return this._realContainerToContentRatio;
  },
  _normalizeSize(size) {
    return isPlainObject(size) ? size[this._dimension] || 0 : size;
  },
  _clean() {
    this.callBase();
    if (this === activeScrollbar) {
      activeScrollbar = null;
    }
    events_engine_default.off(this._$thumb, `.${SCROLLBAR}`);
  },
  _optionChanged(args) {
    if (this._isHidden()) {
      return;
    }
    switch (args.name) {
      case "containerSize":
      case "contentSize":
        this.option()[args.name] = this._normalizeSize(args.value);
        this._update();
        break;
      case "baseContentSize":
      case "baseContainerSize":
      case "scaleRatio":
        this._update();
        break;
      case "visibilityMode":
      case "direction":
        this._invalidate();
        break;
      default:
        this.callBase.apply(this, arguments);
    }
  },
  update: deferRenderer(function() {
    this._adjustVisibility() && this.option("visible", true);
  })
});
ready_callbacks_default.add(() => {
  events_engine_default.subscribeGlobal(dom_adapter_default.getDocument(), addNamespace(pointer_default.up, SCROLLBAR), () => {
    if (activeScrollbar) {
      activeScrollbar.feedbackOff();
    }
  });
});
var m_scrollbar_default = Scrollbar;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollable.native.js
var SCROLLABLE_NATIVE = "dxNativeScrollable";
var SCROLLABLE_SCROLLBAR_SIMULATED = "dx-scrollable-scrollbar-simulated";
var SCROLLABLE_SCROLLBARS_HIDDEN = "dx-scrollable-scrollbars-hidden";
var VERTICAL = "vertical";
var HORIZONTAL2 = "horizontal";
var NativeStrategy = class_default.inherit({
  ctor(scrollable) {
    this._init(scrollable);
  },
  _init(scrollable) {
    this._component = scrollable;
    this._$element = scrollable.$element();
    this._$container = renderer_default(scrollable.container());
    this._$content = scrollable.$content();
    this._direction = scrollable.option("direction");
    this._useSimulatedScrollbar = scrollable.option("useSimulatedScrollbar");
    this.option = scrollable.option.bind(scrollable);
    this._createActionByOption = scrollable._createActionByOption.bind(scrollable);
    this._isLocked = scrollable._isLocked.bind(scrollable);
    this._isDirection = scrollable._isDirection.bind(scrollable);
    this._allowedDirection = scrollable._allowedDirection.bind(scrollable);
    this._getMaxOffset = scrollable._getMaxOffset.bind(scrollable);
    this._isRtlNativeStrategy = scrollable._isRtlNativeStrategy.bind(scrollable);
  },
  render() {
    const device = devices_default.real();
    const deviceType = device.platform;
    this._$element.addClass("dx-scrollable-native").addClass(`dx-scrollable-native-${deviceType}`).toggleClass(SCROLLABLE_SCROLLBARS_HIDDEN, !this._isScrollbarVisible());
    if (this._isScrollbarVisible() && this._useSimulatedScrollbar) {
      this._renderScrollbars();
    }
  },
  updateRtlPosition(isFirstRender) {
    if (isFirstRender && this.option("rtlEnabled")) {
      if (this._isScrollbarVisible() && this._useSimulatedScrollbar) {
        this._moveScrollbars();
      }
    }
  },
  _renderScrollbars() {
    this._scrollbars = {};
    this._hideScrollbarTimeout = 0;
    this._$element.addClass(SCROLLABLE_SCROLLBAR_SIMULATED);
    this._renderScrollbar(VERTICAL);
    this._renderScrollbar(HORIZONTAL2);
  },
  _renderScrollbar(direction) {
    if (!this._isDirection(direction)) {
      return;
    }
    this._scrollbars[direction] = new m_scrollbar_default(renderer_default("<div>").appendTo(this._$element), {
      direction,
      expandable: this._component.option("scrollByThumb")
    });
  },
  handleInit: noop,
  handleStart: noop,
  handleMove(e) {
    if (this._isLocked()) {
      e.cancel = true;
      return;
    }
    if (this._allowedDirection()) {
      e.originalEvent.isScrollingEvent = true;
    }
  },
  handleEnd: noop,
  handleCancel: noop,
  handleStop: noop,
  _eachScrollbar(callback) {
    callback = callback.bind(this);
    each(this._scrollbars || {}, (direction, scrollbar) => {
      callback(scrollbar, direction);
    });
  },
  createActions() {
    this._scrollAction = this._createActionByOption("onScroll");
    this._updateAction = this._createActionByOption("onUpdated");
  },
  _createActionArgs() {
    const {
      left,
      top
    } = this.location();
    return {
      event: this._eventForUserAction,
      scrollOffset: this._getScrollOffset(),
      reachedLeft: this._isRtlNativeStrategy() ? this._isReachedRight(-left) : this._isReachedLeft(left),
      reachedRight: this._isRtlNativeStrategy() ? this._isReachedLeft(-Math.abs(left)) : this._isReachedRight(left),
      reachedTop: this._isDirection(VERTICAL) ? Math.round(top) >= 0 : void 0,
      reachedBottom: this._isDirection(VERTICAL) ? Math.round(Math.abs(top) - this._getMaxOffset().top) >= 0 : void 0
    };
  },
  _getScrollOffset() {
    const {
      top,
      left
    } = this.location();
    return {
      top: -top,
      left: this._normalizeOffsetLeft(-left)
    };
  },
  _normalizeOffsetLeft(scrollLeft) {
    if (this._isRtlNativeStrategy()) {
      return this._getMaxOffset().left + scrollLeft;
    }
    return scrollLeft;
  },
  _isReachedLeft(left) {
    return this._isDirection(HORIZONTAL2) ? Math.round(left) >= 0 : void 0;
  },
  _isReachedRight(left) {
    return this._isDirection(HORIZONTAL2) ? Math.round(Math.abs(left) - this._getMaxOffset().left) >= 0 : void 0;
  },
  _isScrollbarVisible() {
    const {
      showScrollbar
    } = this.option();
    return "never" !== showScrollbar && false !== showScrollbar;
  },
  handleScroll(e) {
    this._eventForUserAction = e;
    this._moveScrollbars();
    this._scrollAction(this._createActionArgs());
  },
  _moveScrollbars() {
    const {
      top,
      left
    } = this._getScrollOffset();
    this._eachScrollbar((scrollbar) => {
      scrollbar.moveTo({
        top: -top,
        left: -left
      });
      scrollbar.option("visible", true);
    });
    this._hideScrollbars();
  },
  _hideScrollbars() {
    clearTimeout(this._hideScrollbarTimeout);
    this._hideScrollbarTimeout = setTimeout(() => {
      this._eachScrollbar((scrollbar) => {
        scrollbar.option("visible", false);
      });
    }, 500);
  },
  location() {
    return {
      left: -this._$container.scrollLeft(),
      top: -this._$container.scrollTop()
    };
  },
  disabledChanged: noop,
  update() {
    this._update();
    this._updateAction(this._createActionArgs());
  },
  _update() {
    this._updateDimensions();
    this._updateScrollbars();
  },
  _updateDimensions() {
    this._containerSize = {
      height: getHeight(this._$container),
      width: getWidth(this._$container)
    };
    this._componentContentSize = {
      height: getHeight(this._component.$content()),
      width: getWidth(this._component.$content())
    };
    this._contentSize = {
      height: getHeight(this._$content),
      width: getWidth(this._$content)
    };
  },
  _updateScrollbars() {
    this._eachScrollbar(function(scrollbar, direction) {
      const dimension = direction === VERTICAL ? "height" : "width";
      scrollbar.option({
        containerSize: this._containerSize[dimension],
        contentSize: this._componentContentSize[dimension]
      });
      scrollbar.update();
    });
  },
  _allowedDirections() {
    return {
      vertical: this._isDirection(VERTICAL) && this._contentSize.height > this._containerSize.height,
      horizontal: this._isDirection(HORIZONTAL2) && this._contentSize.width > this._containerSize.width
    };
  },
  dispose() {
    const {
      className
    } = this._$element.get(0);
    const scrollableNativeRegexp = new RegExp("dx-scrollable-native\\S*", "g");
    if (scrollableNativeRegexp.test(className)) {
      this._$element.removeClass(className.match(scrollableNativeRegexp).join(" "));
    }
    events_engine_default.off(this._$element, `.${SCROLLABLE_NATIVE}`);
    events_engine_default.off(this._$container, `.${SCROLLABLE_NATIVE}`);
    this._removeScrollbars();
    clearTimeout(this._hideScrollbarTimeout);
  },
  _removeScrollbars() {
    this._eachScrollbar((scrollbar) => {
      scrollbar.$element().remove();
    });
  },
  scrollBy(distance) {
    const location = this.location();
    this._$container.scrollTop(Math.round(-location.top - distance.top));
    this._$container.scrollLeft(Math.round(-location.left - distance.left));
  },
  validate(e) {
    if (this.option("disabled")) {
      return false;
    }
    if (isDxMouseWheelEvent(e) && this._isScrolledInMaxDirection(e)) {
      return false;
    }
    return !!this._allowedDirection();
  },
  _isScrolledInMaxDirection(e) {
    const container = this._$container.get(0);
    let result2;
    if (e.delta > 0) {
      result2 = e.shiftKey ? !container.scrollLeft : !container.scrollTop;
    } else if (e.shiftKey) {
      result2 = container.scrollLeft >= this._getMaxOffset().left;
    } else {
      result2 = container.scrollTop >= this._getMaxOffset().top;
    }
    return result2;
  },
  getDirection() {
    return this._allowedDirection();
  }
});
var m_scrollable_native_default = NativeStrategy;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollable.simulated.js
init_class();
init_dom_adapter();
init_renderer();
init_common();
init_deferred();
init_extend();
init_inflector();
init_iterator();
init_size();
init_type();
init_window();
init_events_engine();

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_animator.js
init_class();
init_common();
var {
  abstract: abstract3
} = class_default;
var Animator = class_default.inherit({
  ctor() {
    this._finished = true;
    this._stopped = false;
    this._proxiedStepCore = this._stepCore.bind(this);
  },
  start() {
    this._stopped = false;
    this._finished = false;
    this._stepCore();
  },
  stop() {
    this._stopped = true;
    cancelAnimationFrame(this._stepAnimationFrame);
  },
  _stepCore() {
    if (this._isStopped()) {
      this._stop();
      return;
    }
    if (this._isFinished()) {
      this._finished = true;
      this._complete();
      return;
    }
    this._step();
    this._stepAnimationFrame = requestAnimationFrame(this._proxiedStepCore);
  },
  _step: abstract3,
  _isFinished: noop,
  _stop: noop,
  _complete: noop,
  _isStopped() {
    return this._stopped;
  },
  inProgress() {
    return !(this._stopped || this._finished);
  }
});
var m_animator_default = Animator;

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollable.simulated.js
var SCROLLABLE_SIMULATED = "dxSimulatedScrollable";
var SCROLLABLE_STRATEGY = "dxScrollableStrategy";
var SCROLLABLE_SIMULATED_CURSOR = `${SCROLLABLE_SIMULATED}Cursor`;
var SCROLLABLE_SIMULATED_KEYBOARD = `${SCROLLABLE_SIMULATED}Keyboard`;
var SCROLLABLE_SCROLLBARS_ALWAYSVISIBLE = "dx-scrollable-scrollbars-alwaysvisible";
var VERTICAL2 = "vertical";
var HORIZONTAL3 = "horizontal";
var FRAME_DURATION = Math.round(1e3 / 60);
var BOUNCE_FRAMES = 400 / FRAME_DURATION;
var BOUNCE_ACCELERATION_SUM = (1 - 0.92 ** BOUNCE_FRAMES) / (1 - 0.92);
var KEY_CODES = {
  PAGE_UP: "pageUp",
  PAGE_DOWN: "pageDown",
  END: "end",
  HOME: "home",
  LEFT: "leftArrow",
  UP: "upArrow",
  RIGHT: "rightArrow",
  DOWN: "downArrow",
  TAB: "tab"
};
var InertiaAnimator = m_animator_default.inherit({
  ctor(scroller) {
    this.callBase();
    this.scroller = scroller;
  },
  VELOCITY_LIMIT: 1,
  _isFinished() {
    return Math.abs(this.scroller._velocity) <= this.VELOCITY_LIMIT;
  },
  _step() {
    this.scroller._scrollStep(this.scroller._velocity);
    this.scroller._velocity *= this._acceleration();
  },
  _acceleration() {
    return this.scroller._inBounds() ? 0.92 : 0.5;
  },
  _complete() {
    this.scroller._scrollComplete();
  }
});
var BounceAnimator = InertiaAnimator.inherit({
  VELOCITY_LIMIT: 0.2,
  _isFinished() {
    return this.scroller._crossBoundOnNextStep() || this.callBase();
  },
  _acceleration: () => 0.92,
  _complete() {
    this.scroller._move(this.scroller._bounceLocation);
    this.callBase();
  }
});
var Scroller = class_default.inherit({
  ctor(options2) {
    this._initOptions(options2);
    this._initAnimators();
    this._initScrollbar();
  },
  _initOptions(options2) {
    this._location = 0;
    this._topReached = false;
    this._bottomReached = false;
    this._axis = options2.direction === HORIZONTAL3 ? "x" : "y";
    this._prop = options2.direction === HORIZONTAL3 ? "left" : "top";
    this._dimension = options2.direction === HORIZONTAL3 ? "width" : "height";
    this._scrollProp = options2.direction === HORIZONTAL3 ? "scrollLeft" : "scrollTop";
    each(options2, (optionName, optionValue) => {
      this[`_${optionName}`] = optionValue;
    });
  },
  _initAnimators() {
    this._inertiaAnimator = new InertiaAnimator(this);
    this._bounceAnimator = new BounceAnimator(this);
  },
  _initScrollbar() {
    this._scrollbar = new m_scrollbar_default(renderer_default("<div>").appendTo(this._$container), {
      direction: this._direction,
      visible: this._scrollByThumb,
      visibilityMode: this._visibilityModeNormalize(this._scrollbarVisible),
      expandable: this._scrollByThumb
    });
    this._$scrollbar = this._scrollbar.$element();
  },
  _visibilityModeNormalize: (mode) => true === mode ? "onScroll" : false === mode ? "never" : mode,
  _scrollStep(delta) {
    const prevLocation = this._location;
    this._location += delta;
    this._suppressBounce();
    this._move();
    if (Math.abs(prevLocation - this._location) < 1) {
      return;
    }
    events_engine_default.triggerHandler(this._$container, {
      type: "scroll"
    });
  },
  _suppressBounce() {
    if (this._bounceEnabled || this._inBounds(this._location)) {
      return;
    }
    this._velocity = 0;
    this._location = this._boundLocation();
  },
  _boundLocation(location) {
    location = void 0 !== location ? location : this._location;
    return Math.max(Math.min(location, this._maxOffset), this._minOffset);
  },
  _move(location) {
    this._location = void 0 !== location ? location * this._getScaleRatio() : this._location;
    this._moveContent();
    this._moveScrollbar();
  },
  _moveContent() {
    const location = this._location;
    this._$container[this._scrollProp](-location / this._getScaleRatio());
    this._moveContentByTranslator(location);
  },
  _getScaleRatio() {
    if (hasWindow() && !this._scaleRatio) {
      const element = this._$element.get(0);
      const realDimension = this._getRealDimension(element, this._dimension);
      const baseDimension = this._getBaseDimension(element, this._dimension);
      this._scaleRatio = Math.round(realDimension / baseDimension * 100) / 100;
    }
    return this._scaleRatio || 1;
  },
  _getRealDimension: (element, dimension) => Math.round(getBoundingRect(element)[dimension]),
  _getBaseDimension(element, dimension) {
    const dimensionName = `offset${titleize(dimension)}`;
    return element[dimensionName];
  },
  _moveContentByTranslator(location) {
    let translateOffset;
    const minOffset = -this._maxScrollPropValue;
    if (location > 0) {
      translateOffset = location;
    } else if (location <= minOffset) {
      translateOffset = location - minOffset;
    } else {
      translateOffset = location % 1;
    }
    if (this._translateOffset === translateOffset) {
      return;
    }
    const targetLocation = {};
    targetLocation[this._prop] = translateOffset;
    this._translateOffset = translateOffset;
    if (0 === translateOffset) {
      resetPosition(this._$content);
      return;
    }
    move(this._$content, targetLocation);
  },
  _moveScrollbar() {
    this._scrollbar.moveTo(this._location);
  },
  _scrollComplete() {
    if (this._inBounds()) {
      this._hideScrollbar();
      if (this._completeDeferred) {
        this._completeDeferred.resolve();
      }
    }
    this._scrollToBounds();
  },
  _scrollToBounds() {
    if (this._inBounds()) {
      return;
    }
    this._bounceAction();
    this._setupBounce();
    this._bounceAnimator.start();
  },
  _setupBounce() {
    const boundLocation = this._bounceLocation = this._boundLocation();
    const bounceDistance = boundLocation - this._location;
    this._velocity = bounceDistance / BOUNCE_ACCELERATION_SUM;
  },
  _inBounds(location) {
    location = void 0 !== location ? location : this._location;
    return this._boundLocation(location) === location;
  },
  _crossBoundOnNextStep() {
    const location = this._location;
    const nextLocation = location + this._velocity;
    return location < this._minOffset && nextLocation >= this._minOffset || location > this._maxOffset && nextLocation <= this._maxOffset;
  },
  _initHandler(e) {
    this._stopScrolling();
    this._prepareThumbScrolling(e);
  },
  _stopScrolling: deferRenderer(function() {
    this._hideScrollbar();
    this._inertiaAnimator.stop();
    this._bounceAnimator.stop();
  }),
  _prepareThumbScrolling(e) {
    if (isDxMouseWheelEvent(e.originalEvent)) {
      return;
    }
    const $target = renderer_default(e.originalEvent.target);
    const scrollbarClicked = this._isScrollbar($target);
    if (scrollbarClicked) {
      this._moveToMouseLocation(e);
    }
    this._thumbScrolling = scrollbarClicked || this._isThumb($target);
    this._crossThumbScrolling = !this._thumbScrolling && this._isAnyThumbScrolling($target);
    if (this._thumbScrolling) {
      this._scrollbar.feedbackOn();
    }
  },
  _isThumbScrollingHandler($target) {
    return this._isThumb($target);
  },
  _moveToMouseLocation(e) {
    const mouseLocation = e[`page${this._axis.toUpperCase()}`] - this._$element.offset()[this._prop];
    const location = this._location + mouseLocation / this._containerToContentRatio() - getHeight(this._$container) / 2;
    this._scrollStep(-Math.round(location));
  },
  _startHandler() {
    this._showScrollbar();
  },
  _moveHandler(delta) {
    if (this._crossThumbScrolling) {
      return;
    }
    if (this._thumbScrolling) {
      delta[this._axis] = -Math.round(delta[this._axis] / this._containerToContentRatio());
    }
    this._scrollBy(delta);
  },
  _scrollBy(delta) {
    delta = delta[this._axis];
    if (!this._inBounds()) {
      delta *= 0.5;
    }
    this._scrollStep(delta);
  },
  _scrollByHandler(delta) {
    this._scrollBy(delta);
    this._scrollComplete();
  },
  _containerToContentRatio() {
    return this._scrollbar.containerToContentRatio();
  },
  _endHandler(velocity) {
    this._completeDeferred = Deferred();
    this._velocity = velocity[this._axis];
    this._inertiaHandler();
    this._resetThumbScrolling();
    return this._completeDeferred.promise();
  },
  _inertiaHandler() {
    this._suppressInertia();
    this._inertiaAnimator.start();
  },
  _suppressInertia() {
    if (!this._inertiaEnabled || this._thumbScrolling) {
      this._velocity = 0;
    }
  },
  _resetThumbScrolling() {
    this._thumbScrolling = false;
    this._crossThumbScrolling = false;
  },
  _stopHandler() {
    if (this._thumbScrolling) {
      this._scrollComplete();
    }
    this._resetThumbScrolling();
    this._scrollToBounds();
  },
  _disposeHandler() {
    this._stopScrolling();
    this._$scrollbar.remove();
  },
  _updateHandler() {
    this._update();
    this._moveToBounds();
  },
  _update() {
    this._stopScrolling();
    return deferUpdate(() => {
      this._resetScaleRatio();
      this._updateLocation();
      this._updateBounds();
      this._updateScrollbar();
      deferRender(() => {
        this._moveScrollbar();
        this._scrollbar.update();
      });
    });
  },
  _resetScaleRatio() {
    this._scaleRatio = null;
  },
  _updateLocation() {
    this._location = (locate(this._$content)[this._prop] - this._$container[this._scrollProp]()) * this._getScaleRatio();
  },
  _updateBounds() {
    this._maxOffset = this._getMaxOffset();
    this._minOffset = this._getMinOffset();
  },
  _getMaxOffset: () => 0,
  _getMinOffset() {
    this._maxScrollPropValue = Math.max(this._contentSize() - this._containerSize(), 0);
    return -this._maxScrollPropValue;
  },
  _updateScrollbar: deferUpdater(function() {
    const containerSize = this._containerSize();
    const contentSize = this._contentSize();
    const baseContainerSize = this._getBaseDimension(this._$container.get(0), this._dimension);
    const baseContentSize = this._getBaseDimension(this._$content.get(0), this._dimension);
    deferRender(() => {
      this._scrollbar.option({
        containerSize,
        contentSize,
        baseContainerSize,
        baseContentSize,
        scaleRatio: this._getScaleRatio()
      });
    });
  }),
  _moveToBounds: deferRenderer(deferUpdater(deferRenderer(function() {
    const location = this._boundLocation();
    const locationChanged = location !== this._location;
    this._location = location;
    this._move();
    if (locationChanged) {
      this._scrollAction();
    }
  }))),
  _createActionsHandler(actions) {
    this._scrollAction = actions.scroll;
    this._bounceAction = actions.bounce;
  },
  _showScrollbar() {
    this._scrollbar.option("visible", true);
  },
  _hideScrollbar() {
    this._scrollbar.option("visible", false);
  },
  _containerSize() {
    return this._getRealDimension(this._$container.get(0), this._dimension);
  },
  _contentSize() {
    const isOverflowHidden = "hidden" === this._$content.css(`overflow${this._axis.toUpperCase()}`);
    let contentSize = this._getRealDimension(this._$content.get(0), this._dimension);
    if (!isOverflowHidden) {
      const containerScrollSize = this._$content[0][`scroll${titleize(this._dimension)}`] * this._getScaleRatio();
      contentSize = Math.max(containerScrollSize, contentSize);
    }
    return contentSize;
  },
  _validateEvent(e) {
    const $target = renderer_default(e.originalEvent.target);
    return this._isThumb($target) || this._isScrollbar($target);
  },
  _isThumb($element) {
    return this._scrollByThumb && this._scrollbar.isThumb($element);
  },
  _isScrollbar($element) {
    return this._scrollByThumb && $element && $element.is(this._$scrollbar);
  },
  _reachedMin() {
    return Math.round(this._location - this._minOffset) <= 0;
  },
  _reachedMax() {
    return Math.round(this._location - this._maxOffset) >= 0;
  },
  _cursorEnterHandler() {
    this._resetScaleRatio();
    this._updateScrollbar();
    this._scrollbar.cursorEnter();
  },
  _cursorLeaveHandler() {
    this._scrollbar.cursorLeave();
  },
  dispose: noop
});
var hoveredScrollable;
var activeScrollable;
var SimulatedStrategy = class_default.inherit({
  ctor(scrollable) {
    this._init(scrollable);
  },
  _init(scrollable) {
    this._component = scrollable;
    this._$element = scrollable.$element();
    this._$container = renderer_default(scrollable.container());
    this._$wrapper = scrollable._$wrapper;
    this._$content = scrollable.$content();
    this.option = scrollable.option.bind(scrollable);
    this._createActionByOption = scrollable._createActionByOption.bind(scrollable);
    this._isLocked = scrollable._isLocked.bind(scrollable);
    this._isDirection = scrollable._isDirection.bind(scrollable);
    this._allowedDirection = scrollable._allowedDirection.bind(scrollable);
    this._getMaxOffset = scrollable._getMaxOffset.bind(scrollable);
  },
  render() {
    this._$element.addClass("dx-scrollable-simulated");
    this._createScrollers();
    if (this.option("useKeyboard")) {
      this._$container.prop("tabIndex", 0);
    }
    this._attachKeyboardHandler();
    this._attachCursorHandlers();
  },
  _createScrollers() {
    this._scrollers = {};
    if (this._isDirection(HORIZONTAL3)) {
      this._createScroller(HORIZONTAL3);
    }
    if (this._isDirection(VERTICAL2)) {
      this._createScroller(VERTICAL2);
    }
    this._$element.toggleClass(SCROLLABLE_SCROLLBARS_ALWAYSVISIBLE, "always" === this.option("showScrollbar"));
  },
  _createScroller(direction) {
    this._scrollers[direction] = new Scroller(this._scrollerOptions(direction));
  },
  _scrollerOptions(direction) {
    return {
      direction,
      $content: this._$content,
      $container: this._$container,
      $wrapper: this._$wrapper,
      $element: this._$element,
      scrollByThumb: this.option("scrollByThumb"),
      scrollbarVisible: this.option("showScrollbar"),
      bounceEnabled: this.option("bounceEnabled"),
      inertiaEnabled: this.option("inertiaEnabled"),
      isAnyThumbScrolling: this._isAnyThumbScrolling.bind(this)
    };
  },
  _applyScaleRatio(targetLocation) {
    for (const direction in this._scrollers) {
      const prop = this._getPropByDirection(direction);
      if (isDefined(targetLocation[prop])) {
        const scroller = this._scrollers[direction];
        targetLocation[prop] *= scroller._getScaleRatio();
      }
    }
    return targetLocation;
  },
  _isAnyThumbScrolling($target) {
    let result2 = false;
    this._eventHandler("isThumbScrolling", $target).done((isThumbScrollingVertical, isThumbScrollingHorizontal) => {
      result2 = isThumbScrollingVertical || isThumbScrollingHorizontal;
    });
    return result2;
  },
  handleInit(e) {
    this._suppressDirections(e);
    this._eventForUserAction = e;
    this._eventHandler("init", e);
  },
  _suppressDirections(e) {
    if (isDxMouseWheelEvent(e.originalEvent)) {
      this._prepareDirections(true);
      return;
    }
    this._prepareDirections();
    this._eachScroller(function(scroller, direction) {
      const $target = renderer_default(e.originalEvent.target);
      const isValid = scroller._validateEvent(e) || this.option("scrollByContent") && this._isContent($target);
      this._validDirections[direction] = isValid;
    });
  },
  _isContent($element) {
    return !!$element.closest(this._$element).length;
  },
  _prepareDirections(value) {
    value = value || false;
    this._validDirections = {};
    this._validDirections[HORIZONTAL3] = value;
    this._validDirections[VERTICAL2] = value;
  },
  _eachScroller(callback) {
    callback = callback.bind(this);
    each(this._scrollers, (direction, scroller) => {
      callback(scroller, direction);
    });
  },
  handleStart(e) {
    this._eventForUserAction = e;
    this._eventHandler("start").done(this._startAction);
  },
  _saveActive() {
    activeScrollable = this;
  },
  _resetActive() {
    if (activeScrollable === this) {
      activeScrollable = null;
    }
  },
  handleMove(e) {
    if (this._isLocked()) {
      e.cancel = true;
      this._resetActive();
      return;
    }
    this._saveActive();
    e.preventDefault && e.preventDefault();
    this._adjustDistance(e, e.delta);
    this._eventForUserAction = e;
    this._eventHandler("move", e.delta);
  },
  _adjustDistance(e, distance) {
    distance.x *= this._validDirections[HORIZONTAL3];
    distance.y *= this._validDirections[VERTICAL2];
    const devicePixelRatio = this._tryGetDevicePixelRatio();
    if (devicePixelRatio && isDxMouseWheelEvent(e.originalEvent)) {
      distance.x = Math.round(distance.x / devicePixelRatio * 100) / 100;
      distance.y = Math.round(distance.y / devicePixelRatio * 100) / 100;
    }
  },
  _tryGetDevicePixelRatio() {
    if (hasWindow()) {
      return getWindow().devicePixelRatio;
    }
  },
  handleEnd(e) {
    this._resetActive();
    this._refreshCursorState(e.originalEvent && e.originalEvent.target);
    this._adjustDistance(e, e.velocity);
    this._eventForUserAction = e;
    return this._eventHandler("end", e.velocity).done(this._endAction);
  },
  handleCancel(e) {
    this._resetActive();
    this._eventForUserAction = e;
    return this._eventHandler("end", {
      x: 0,
      y: 0
    });
  },
  handleStop() {
    this._resetActive();
    this._eventHandler("stop");
  },
  handleScroll() {
    this._updateRtlConfig();
    this._scrollAction();
  },
  _attachKeyboardHandler() {
    events_engine_default.off(this._$element, `.${SCROLLABLE_SIMULATED_KEYBOARD}`);
    if (!this.option("disabled") && this.option("useKeyboard")) {
      events_engine_default.on(this._$element, addNamespace("keydown", SCROLLABLE_SIMULATED_KEYBOARD), this._keyDownHandler.bind(this));
    }
  },
  _keyDownHandler(e) {
    clearTimeout(this._updateHandlerTimeout);
    this._updateHandlerTimeout = setTimeout(() => {
      if (normalizeKeyName(e) === KEY_CODES.TAB) {
        this._eachScroller((scroller) => {
          scroller._updateHandler();
        });
      }
    });
    if (!this._$container.is(dom_adapter_default.getActiveElement(this._$container.get(0)))) {
      return;
    }
    let handled = true;
    switch (normalizeKeyName(e)) {
      case KEY_CODES.DOWN:
        this._scrollByLine({
          y: 1
        });
        break;
      case KEY_CODES.UP:
        this._scrollByLine({
          y: -1
        });
        break;
      case KEY_CODES.RIGHT:
        this._scrollByLine({
          x: 1
        });
        break;
      case KEY_CODES.LEFT:
        this._scrollByLine({
          x: -1
        });
        break;
      case KEY_CODES.PAGE_DOWN:
        this._scrollByPage(1);
        break;
      case KEY_CODES.PAGE_UP:
        this._scrollByPage(-1);
        break;
      case KEY_CODES.HOME:
        this._scrollToHome();
        break;
      case KEY_CODES.END:
        this._scrollToEnd();
        break;
      default:
        handled = false;
    }
    if (handled) {
      e.stopPropagation();
      e.preventDefault();
    }
  },
  _scrollByLine(lines) {
    const devicePixelRatio = this._tryGetDevicePixelRatio();
    let scrollOffset = 40;
    if (devicePixelRatio) {
      scrollOffset = Math.abs(scrollOffset / devicePixelRatio * 100) / 100;
    }
    this.scrollBy({
      top: (lines.y || 0) * -scrollOffset,
      left: (lines.x || 0) * -scrollOffset
    });
  },
  _scrollByPage(page) {
    const prop = this._wheelProp();
    const dimension = this._dimensionByProp(prop);
    const distance = {};
    const getter = "width" === dimension ? getWidth : getHeight;
    distance[prop] = page * -getter(this._$container);
    this.scrollBy(distance);
  },
  _dimensionByProp: (prop) => "left" === prop ? "width" : "height",
  _getPropByDirection: (direction) => direction === HORIZONTAL3 ? "left" : "top",
  _scrollToHome() {
    const prop = this._wheelProp();
    const distance = {};
    distance[prop] = 0;
    this._component.scrollTo(distance);
  },
  _scrollToEnd() {
    const prop = this._wheelProp();
    const dimension = this._dimensionByProp(prop);
    const distance = {};
    const getter = "width" === dimension ? getWidth : getHeight;
    distance[prop] = getter(this._$content) - getter(this._$container);
    this._component.scrollTo(distance);
  },
  createActions() {
    this._startAction = this._createActionHandler("onStart");
    this._endAction = this._createActionHandler("onEnd");
    this._updateAction = this._createActionHandler("onUpdated");
    this._createScrollerActions();
  },
  _createScrollerActions() {
    this._scrollAction = this._createActionHandler("onScroll");
    this._bounceAction = this._createActionHandler("onBounce");
    this._eventHandler("createActions", {
      scroll: this._scrollAction,
      bounce: this._bounceAction
    });
  },
  _createActionHandler(optionName) {
    const actionHandler = this._createActionByOption(optionName);
    return () => {
      actionHandler(extend(this._createActionArgs(), arguments));
    };
  },
  _createActionArgs() {
    const {
      horizontal: scrollerX,
      vertical: scrollerY
    } = this._scrollers;
    const offset = this._getScrollOffset();
    this._scrollOffset = {
      top: scrollerY && offset.top,
      left: scrollerX && offset.left
    };
    return {
      event: this._eventForUserAction,
      scrollOffset: this._scrollOffset,
      reachedLeft: scrollerX && scrollerX._reachedMax(),
      reachedRight: scrollerX && scrollerX._reachedMin(),
      reachedTop: scrollerY && scrollerY._reachedMax(),
      reachedBottom: scrollerY && scrollerY._reachedMin()
    };
  },
  _getScrollOffset() {
    return {
      top: -this.location().top,
      left: -this.location().left
    };
  },
  _eventHandler(eventName) {
    const args = [].slice.call(arguments).slice(1);
    const deferreds = map(this._scrollers, (scroller) => scroller[`_${eventName}Handler`].apply(scroller, args));
    return when.apply(renderer_default, deferreds).promise();
  },
  location() {
    const location = locate(this._$content);
    location.top -= this._$container.scrollTop();
    location.left -= this._$container.scrollLeft();
    return location;
  },
  disabledChanged() {
    this._attachCursorHandlers();
  },
  _attachCursorHandlers() {
    events_engine_default.off(this._$element, `.${SCROLLABLE_SIMULATED_CURSOR}`);
    if (!this.option("disabled") && this._isHoverMode()) {
      events_engine_default.on(this._$element, addNamespace("mouseenter", SCROLLABLE_SIMULATED_CURSOR), this._cursorEnterHandler.bind(this));
      events_engine_default.on(this._$element, addNamespace("mouseleave", SCROLLABLE_SIMULATED_CURSOR), this._cursorLeaveHandler.bind(this));
    }
  },
  _isHoverMode() {
    return "onHover" === this.option("showScrollbar");
  },
  _cursorEnterHandler(e) {
    e = e || {};
    e.originalEvent = e.originalEvent || {};
    if (activeScrollable || e.originalEvent._hoverHandled) {
      return;
    }
    if (hoveredScrollable) {
      hoveredScrollable._cursorLeaveHandler();
    }
    hoveredScrollable = this;
    this._eventHandler("cursorEnter");
    e.originalEvent._hoverHandled = true;
  },
  _cursorLeaveHandler(e) {
    if (hoveredScrollable !== this || activeScrollable === hoveredScrollable) {
      return;
    }
    this._eventHandler("cursorLeave");
    hoveredScrollable = null;
    this._refreshCursorState(e && e.relatedTarget);
  },
  _refreshCursorState(target) {
    if (!this._isHoverMode() && (!target || activeScrollable)) {
      return;
    }
    const $target = renderer_default(target);
    const $scrollable = $target.closest(".dx-scrollable-simulated:not(.dx-state-disabled)");
    const targetScrollable = $scrollable.length && $scrollable.data(SCROLLABLE_STRATEGY);
    if (hoveredScrollable && hoveredScrollable !== targetScrollable) {
      hoveredScrollable._cursorLeaveHandler();
    }
    if (targetScrollable) {
      targetScrollable._cursorEnterHandler();
    }
  },
  update() {
    const result2 = this._eventHandler("update").done(this._updateAction);
    return when(result2, deferUpdate(() => {
      const allowedDirections = this._allowedDirections();
      deferRender(() => {
        let touchDirection = allowedDirections.vertical ? "pan-x" : "";
        touchDirection = allowedDirections.horizontal ? "pan-y" : touchDirection;
        touchDirection = allowedDirections.vertical && allowedDirections.horizontal ? "none" : touchDirection;
        this._$container.css("touchAction", touchDirection);
      });
      return when().promise();
    }));
  },
  _allowedDirections() {
    const bounceEnabled = this.option("bounceEnabled");
    const verticalScroller = this._scrollers[VERTICAL2];
    const horizontalScroller = this._scrollers[HORIZONTAL3];
    return {
      vertical: verticalScroller && (verticalScroller._minOffset < 0 || bounceEnabled),
      horizontal: horizontalScroller && (horizontalScroller._minOffset < 0 || bounceEnabled)
    };
  },
  _updateBounds() {
    this._scrollers[HORIZONTAL3] && this._scrollers[HORIZONTAL3]._updateBounds();
  },
  _isHorizontalAndRtlEnabled() {
    return this.option("rtlEnabled") && this.option("direction") !== VERTICAL2;
  },
  updateRtlPosition(needInitializeRtlConfig) {
    if (needInitializeRtlConfig) {
      this._rtlConfig = {
        scrollRight: 0,
        clientWidth: this._$container.get(0).clientWidth,
        windowPixelRatio: this._getWindowDevicePixelRatio()
      };
    }
    this._updateBounds();
    if (this._isHorizontalAndRtlEnabled()) {
      let scrollLeft = this._getMaxOffset().left - this._rtlConfig.scrollRight;
      if (scrollLeft <= 0) {
        scrollLeft = 0;
        this._rtlConfig.scrollRight = this._getMaxOffset().left;
      }
      if (this._getScrollOffset().left !== scrollLeft) {
        this._rtlConfig.skipUpdating = true;
        this._component.scrollTo({
          left: scrollLeft
        });
        this._rtlConfig.skipUpdating = false;
      }
    }
  },
  _updateRtlConfig() {
    if (this._isHorizontalAndRtlEnabled() && !this._rtlConfig.skipUpdating) {
      const {
        clientWidth,
        scrollLeft
      } = this._$container.get(0);
      const windowPixelRatio = this._getWindowDevicePixelRatio();
      if (this._rtlConfig.windowPixelRatio === windowPixelRatio && this._rtlConfig.clientWidth === clientWidth) {
        this._rtlConfig.scrollRight = this._getMaxOffset().left - scrollLeft;
      }
      this._rtlConfig.clientWidth = clientWidth;
      this._rtlConfig.windowPixelRatio = windowPixelRatio;
    }
  },
  _getWindowDevicePixelRatio: () => hasWindow() ? getWindow().devicePixelRatio : 1,
  scrollBy(distance) {
    const verticalScroller = this._scrollers[VERTICAL2];
    const horizontalScroller = this._scrollers[HORIZONTAL3];
    if (verticalScroller) {
      distance.top = verticalScroller._boundLocation(distance.top + verticalScroller._location) - verticalScroller._location;
    }
    if (horizontalScroller) {
      distance.left = horizontalScroller._boundLocation(distance.left + horizontalScroller._location) - horizontalScroller._location;
    }
    this._prepareDirections(true);
    this._startAction();
    this._eventHandler("scrollBy", {
      x: distance.left,
      y: distance.top
    });
    this._endAction();
    this._updateRtlConfig();
  },
  validate(e) {
    if (isDxMouseWheelEvent(e) && isCommandKeyPressed(e)) {
      return false;
    }
    if (this.option("disabled")) {
      return false;
    }
    if (this.option("bounceEnabled")) {
      return true;
    }
    return isDxMouseWheelEvent(e) ? this._validateWheel(e) : this._validateMove(e);
  },
  _validateWheel(e) {
    const scroller = this._scrollers[this._wheelDirection(e)];
    const reachedMin = scroller._reachedMin();
    const reachedMax = scroller._reachedMax();
    const contentGreaterThanContainer = !reachedMin || !reachedMax;
    const locatedNotAtBound = !reachedMin && !reachedMax;
    const scrollFromMin = reachedMin && e.delta > 0;
    const scrollFromMax = reachedMax && e.delta < 0;
    let validated = contentGreaterThanContainer && (locatedNotAtBound || scrollFromMin || scrollFromMax);
    validated = validated || void 0 !== this._validateWheelTimer;
    if (validated) {
      clearTimeout(this._validateWheelTimer);
      this._validateWheelTimer = setTimeout(() => {
        this._validateWheelTimer = void 0;
      }, 500);
    }
    return validated;
  },
  _validateMove(e) {
    if (!this.option("scrollByContent") && !renderer_default(e.target).closest(".dx-scrollable-scrollbar").length) {
      return false;
    }
    return this._allowedDirection();
  },
  getDirection(e) {
    return isDxMouseWheelEvent(e) ? this._wheelDirection(e) : this._allowedDirection();
  },
  _wheelProp() {
    return this._wheelDirection() === HORIZONTAL3 ? "left" : "top";
  },
  _wheelDirection(e) {
    switch (this.option("direction")) {
      case HORIZONTAL3:
        return HORIZONTAL3;
      case VERTICAL2:
        return VERTICAL2;
      default:
        return e && e.shiftKey ? HORIZONTAL3 : VERTICAL2;
    }
  },
  dispose() {
    this._resetActive();
    if (hoveredScrollable === this) {
      hoveredScrollable = null;
    }
    this._eventHandler("dispose");
    this._detachEventHandlers();
    this._$element.removeClass("dx-scrollable-simulated");
    this._eventForUserAction = null;
    clearTimeout(this._validateWheelTimer);
    clearTimeout(this._updateHandlerTimeout);
  },
  _detachEventHandlers() {
    events_engine_default.off(this._$element, `.${SCROLLABLE_SIMULATED_CURSOR}`);
    events_engine_default.off(this._$container, `.${SCROLLABLE_SIMULATED_KEYBOARD}`);
  }
});

// node_modules/devextreme/esm/__internal/ui/scroll_view/m_scrollable.js
var SCROLLABLE = "dxScrollable";
var SCROLLABLE_STRATEGY2 = "dxScrollableStrategy";
var VERTICAL3 = "vertical";
var HORIZONTAL4 = "horizontal";
var BOTH = "both";
var Scrollable = dom_component_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      disabled: false,
      onScroll: null,
      direction: VERTICAL3,
      showScrollbar: "onScroll",
      useNative: true,
      bounceEnabled: true,
      scrollByContent: true,
      scrollByThumb: false,
      onUpdated: null,
      onStart: null,
      onEnd: null,
      onBounce: null,
      useSimulatedScrollbar: false,
      useKeyboard: true,
      inertiaEnabled: true,
      updateManually: false,
      _onVisibilityChanged: noop
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat(deviceDependentOptions(), [{
      device: () => nativeScrolling && "android" === devices_default.real().platform && !browser_default.mozilla,
      options: {
        useSimulatedScrollbar: true
      }
    }]);
  },
  _initOptions(options2) {
    this.callBase(options2);
    if (!("useSimulatedScrollbar" in options2)) {
      this._setUseSimulatedScrollbar();
    }
  },
  _setUseSimulatedScrollbar() {
    if (!this.initialOption("useSimulatedScrollbar")) {
      this.option("useSimulatedScrollbar", !this.option("useNative"));
    }
  },
  _init() {
    this.callBase();
    this._initScrollableMarkup();
    this._locked = false;
  },
  _visibilityChanged(visible) {
    if (visible) {
      this.update();
      this._updateRtlPosition();
      this._savedScrollOffset && this.scrollTo(this._savedScrollOffset);
      delete this._savedScrollOffset;
      this.option("_onVisibilityChanged")(this);
    } else {
      this._savedScrollOffset = this.scrollOffset();
    }
  },
  _initScrollableMarkup() {
    const $element = this.$element().addClass("dx-scrollable");
    const $container = this._$container = renderer_default("<div>").addClass("dx-scrollable-container");
    const $wrapper = this._$wrapper = renderer_default("<div>").addClass("dx-scrollable-wrapper");
    const $content = this._$content = renderer_default("<div>").addClass("dx-scrollable-content");
    $content.append($element.contents()).appendTo($container);
    $container.appendTo($wrapper);
    $wrapper.appendTo($element);
  },
  _dimensionChanged() {
    this.update();
    this._updateRtlPosition();
  },
  _initMarkup() {
    this.callBase();
    this._renderDirection();
  },
  _render() {
    this._renderStrategy();
    this._attachEventHandlers();
    this._renderDisabledState();
    this._createActions();
    this.update();
    this.callBase();
    this._updateRtlPosition(true);
  },
  _updateRtlPosition(needInitializeRtlConfig) {
    this._strategy.updateRtlPosition(needInitializeRtlConfig);
  },
  _getMaxOffset() {
    const {
      scrollWidth,
      clientWidth,
      scrollHeight,
      clientHeight
    } = renderer_default(this.container()).get(0);
    return {
      left: scrollWidth - clientWidth,
      top: scrollHeight - clientHeight
    };
  },
  _attachEventHandlers() {
    const strategy = this._strategy;
    const initEventData = {
      getDirection: strategy.getDirection.bind(strategy),
      validate: this._validate.bind(this),
      isNative: this.option("useNative"),
      scrollTarget: this._$container
    };
    events_engine_default.off(this._$wrapper, `.${SCROLLABLE}`);
    events_engine_default.on(this._$wrapper, addNamespace(emitter_gesture_scroll_default.init, SCROLLABLE), initEventData, this._initHandler.bind(this));
    events_engine_default.on(this._$wrapper, addNamespace(emitter_gesture_scroll_default.start, SCROLLABLE), strategy.handleStart.bind(strategy));
    events_engine_default.on(this._$wrapper, addNamespace(emitter_gesture_scroll_default.move, SCROLLABLE), strategy.handleMove.bind(strategy));
    events_engine_default.on(this._$wrapper, addNamespace(emitter_gesture_scroll_default.end, SCROLLABLE), strategy.handleEnd.bind(strategy));
    events_engine_default.on(this._$wrapper, addNamespace(emitter_gesture_scroll_default.cancel, SCROLLABLE), strategy.handleCancel.bind(strategy));
    events_engine_default.on(this._$wrapper, addNamespace(emitter_gesture_scroll_default.stop, SCROLLABLE), strategy.handleStop.bind(strategy));
    events_engine_default.off(this._$container, `.${SCROLLABLE}`);
    events_engine_default.on(this._$container, addNamespace("scroll", SCROLLABLE), strategy.handleScroll.bind(strategy));
  },
  _validate(e) {
    if (this._isLocked()) {
      return false;
    }
    this._updateIfNeed();
    return this._moveIsAllowed(e);
  },
  _moveIsAllowed(e) {
    return this._strategy.validate(e);
  },
  handleMove(e) {
    this._strategy.handleMove(e);
  },
  _prepareDirections(value) {
    this._strategy._prepareDirections(value);
  },
  _initHandler() {
    const strategy = this._strategy;
    strategy.handleInit.apply(strategy, arguments);
  },
  _renderDisabledState() {
    this.$element().toggleClass("dx-scrollable-disabled", this.option("disabled"));
    if (this.option("disabled")) {
      this._lock();
    } else {
      this._unlock();
    }
  },
  _renderDirection() {
    this.$element().removeClass(`dx-scrollable-${HORIZONTAL4}`).removeClass(`dx-scrollable-${VERTICAL3}`).removeClass(`dx-scrollable-${BOTH}`).addClass(`dx-scrollable-${this.option("direction")}`);
  },
  _renderStrategy() {
    this._createStrategy();
    this._strategy.render();
    this.$element().data(SCROLLABLE_STRATEGY2, this._strategy);
  },
  _createStrategy() {
    this._strategy = this.option("useNative") ? new m_scrollable_native_default(this) : new SimulatedStrategy(this);
  },
  _createActions() {
    this._strategy && this._strategy.createActions();
  },
  _clean() {
    this._strategy && this._strategy.dispose();
  },
  _optionChanged(args) {
    switch (args.name) {
      case "onStart":
      case "onEnd":
      case "onUpdated":
      case "onScroll":
      case "onBounce":
        this._createActions();
        break;
      case "direction":
        this._resetInactiveDirection();
        this._invalidate();
        break;
      case "useNative":
        this._setUseSimulatedScrollbar();
        this._invalidate();
        break;
      case "inertiaEnabled":
      case "scrollByThumb":
      case "bounceEnabled":
      case "useKeyboard":
      case "showScrollbar":
      case "useSimulatedScrollbar":
        this._invalidate();
        break;
      case "disabled":
        this._renderDisabledState();
        this._strategy && this._strategy.disabledChanged();
        break;
      case "updateManually":
      case "scrollByContent":
      case "_onVisibilityChanged":
        break;
      case "width":
        this.callBase(args);
        this._updateRtlPosition();
        break;
      default:
        this.callBase(args);
    }
  },
  _resetInactiveDirection() {
    const inactiveProp = this._getInactiveProp();
    if (!inactiveProp || !hasWindow()) {
      return;
    }
    const scrollOffset = this.scrollOffset();
    scrollOffset[inactiveProp] = 0;
    this.scrollTo(scrollOffset);
  },
  _getInactiveProp() {
    const direction = this.option("direction");
    if (direction === VERTICAL3) {
      return "left";
    }
    if (direction === HORIZONTAL4) {
      return "top";
    }
  },
  _location() {
    return this._strategy.location();
  },
  _normalizeLocation(location) {
    if (isPlainObject(location)) {
      const left = ensureDefined(location.left, location.x);
      const top = ensureDefined(location.top, location.y);
      return {
        left: isDefined(left) ? -left : void 0,
        top: isDefined(top) ? -top : void 0
      };
    }
    const direction = this.option("direction");
    return {
      left: direction !== VERTICAL3 ? -location : void 0,
      top: direction !== HORIZONTAL4 ? -location : void 0
    };
  },
  _isLocked() {
    return this._locked;
  },
  _lock() {
    this._locked = true;
  },
  _unlock() {
    if (!this.option("disabled")) {
      this._locked = false;
    }
  },
  _isDirection(direction) {
    const current2 = this.option("direction");
    if (direction === VERTICAL3) {
      return current2 !== HORIZONTAL4;
    }
    if (direction === HORIZONTAL4) {
      return current2 !== VERTICAL3;
    }
    return current2 === direction;
  },
  _updateAllowedDirection() {
    const allowedDirections = this._strategy._allowedDirections();
    if (this._isDirection(BOTH) && allowedDirections.vertical && allowedDirections.horizontal) {
      this._allowedDirectionValue = BOTH;
    } else if (this._isDirection(HORIZONTAL4) && allowedDirections.horizontal) {
      this._allowedDirectionValue = HORIZONTAL4;
    } else if (this._isDirection(VERTICAL3) && allowedDirections.vertical) {
      this._allowedDirectionValue = VERTICAL3;
    } else {
      this._allowedDirectionValue = null;
    }
  },
  _allowedDirection() {
    return this._allowedDirectionValue;
  },
  $content() {
    return this._$content;
  },
  content() {
    return getPublicElement(this._$content);
  },
  container() {
    return getPublicElement(this._$container);
  },
  scrollOffset() {
    return this._strategy._getScrollOffset();
  },
  _isRtlNativeStrategy() {
    const {
      useNative,
      rtlEnabled
    } = this.option();
    return useNative && rtlEnabled;
  },
  scrollTop() {
    return this.scrollOffset().top;
  },
  scrollLeft() {
    return this.scrollOffset().left;
  },
  clientHeight() {
    return getHeight(this._$container);
  },
  scrollHeight() {
    return getOuterHeight(this.$content());
  },
  clientWidth() {
    return getWidth(this._$container);
  },
  scrollWidth() {
    return getOuterWidth(this.$content());
  },
  update() {
    if (!this._strategy) {
      return;
    }
    return when(this._strategy.update()).done(() => {
      this._updateAllowedDirection();
    });
  },
  scrollBy(distance) {
    distance = this._normalizeLocation(distance);
    if (!distance.top && !distance.left) {
      return;
    }
    this._updateIfNeed();
    this._strategy.scrollBy(distance);
  },
  scrollTo(targetLocation) {
    targetLocation = this._normalizeLocation(targetLocation);
    this._updateIfNeed();
    let location = this._location();
    if (!this.option("useNative")) {
      targetLocation = this._strategy._applyScaleRatio(targetLocation);
      location = this._strategy._applyScaleRatio(location);
    }
    if (this._isRtlNativeStrategy()) {
      location.left -= this._getMaxOffset().left;
    }
    const distance = this._normalizeLocation({
      left: location.left - ensureDefined(targetLocation.left, location.left),
      top: location.top - ensureDefined(targetLocation.top, location.top)
    });
    if (!distance.top && !distance.left) {
      return;
    }
    this._strategy.scrollBy(distance);
  },
  scrollToElement(element, offset) {
    const $element = renderer_default(element);
    const elementInsideContent = this.$content().find(element).length;
    const elementIsInsideContent = $element.parents(".dx-scrollable").length - $element.parents(".dx-scrollable-content").length === 0;
    if (!elementInsideContent || !elementIsInsideContent) {
      return;
    }
    const scrollPosition = {
      top: 0,
      left: 0
    };
    const direction = this.option("direction");
    if (direction !== VERTICAL3) {
      scrollPosition.left = this.getScrollElementPosition($element, HORIZONTAL4, offset);
    }
    if (direction !== HORIZONTAL4) {
      scrollPosition.top = this.getScrollElementPosition($element, VERTICAL3, offset);
    }
    this.scrollTo(scrollPosition);
  },
  getScrollElementPosition($element, direction, offset) {
    const scrollOffset = this.scrollOffset();
    return getElementLocationInternal($element.get(0), direction, renderer_default(this.container()).get(0), scrollOffset, offset);
  },
  _updateIfNeed() {
    if (!this.option("updateManually")) {
      this.update();
    }
  },
  _useTemplates: () => false,
  isRenovated: () => !!Scrollable.IS_RENOVATED_WIDGET
});
component_registrator_default(SCROLLABLE, Scrollable);
var m_scrollable_default = Scrollable;

// node_modules/devextreme/esm/ui/scroll_view/ui.scrollable.js
var ui_scrollable_default = m_scrollable_default;

// node_modules/devextreme/esm/__internal/ui/tabs/constants.js
var TABS_EXPANDED_CLASS = "dx-tabs-expanded";

// node_modules/devextreme/esm/__internal/ui/tabs/m_item.js
init_renderer();
var TabsItem = m_item_default.inherit({
  _renderWatchers() {
    this.callBase();
    this._startWatcher("badge", this._renderBadge.bind(this));
  },
  _renderBadge(badge) {
    this._$element.children(".dx-badge").remove();
    if (!badge) {
      return;
    }
    const $badge = renderer_default("<div>").addClass("dx-tabs-item-badge").addClass("dx-badge").text(badge);
    this._$element.append($badge);
  }
});
var m_item_default2 = TabsItem;

// node_modules/devextreme/esm/__internal/ui/tabs/m_tabs.js
var TABS_ORIENTATION_CLASS = {
  vertical: "dx-tabs-vertical",
  horizontal: "dx-tabs-horizontal"
};
var INDICATOR_POSITION_CLASS = {
  top: "dx-tab-indicator-position-top",
  right: "dx-tab-indicator-position-right",
  bottom: "dx-tab-indicator-position-bottom",
  left: "dx-tab-indicator-position-left"
};
var TABS_ICON_POSITION_CLASS = {
  top: "dx-tabs-icon-position-top",
  end: "dx-tabs-icon-position-end",
  bottom: "dx-tabs-icon-position-bottom",
  start: "dx-tabs-icon-position-start"
};
var TABS_STYLING_MODE_CLASS = {
  primary: "dx-tabs-styling-mode-primary",
  secondary: "dx-tabs-styling-mode-secondary"
};
var ORIENTATION = {
  horizontal: "horizontal",
  vertical: "vertical"
};
var INDICATOR_POSITION = {
  top: "top",
  right: "right",
  bottom: "bottom",
  left: "left"
};
var SCROLLABLE_DIRECTION = {
  horizontal: "horizontal",
  vertical: "vertical"
};
var ICON_POSITION = {
  top: "top",
  end: "end",
  bottom: "bottom",
  start: "start"
};
var STYLING_MODE = {
  primary: "primary",
  secondary: "secondary"
};
var Tabs = ui_collection_widget_live_update_default.inherit({
  _activeStateUnit: ".dx-tab",
  _getDefaultOptions() {
    return extend(this.callBase(), {
      hoverStateEnabled: true,
      showNavButtons: true,
      scrollByContent: true,
      scrollingEnabled: true,
      selectionMode: "single",
      orientation: ORIENTATION.horizontal,
      iconPosition: ICON_POSITION.start,
      stylingMode: STYLING_MODE.primary,
      activeStateEnabled: true,
      selectionRequired: false,
      selectOnFocus: true,
      loopItemFocus: false,
      useInkRipple: false,
      badgeExpr: (data) => data ? data.badge : void 0,
      _itemAttributes: {
        role: "tab"
      },
      _indicatorPosition: null
    });
  },
  _defaultOptionsRules() {
    const themeName = current();
    return this.callBase().concat([{
      device: () => "desktop" !== devices_default.real().deviceType,
      options: {
        showNavButtons: false
      }
    }, {
      device: {
        deviceType: "desktop"
      },
      options: {
        scrollByContent: false
      }
    }, {
      device: () => "desktop" === devices_default.real().deviceType && !devices_default.isSimulator(),
      options: {
        focusStateEnabled: true
      }
    }, {
      device: () => isFluent(themeName),
      options: {
        iconPosition: ICON_POSITION.top,
        stylingMode: STYLING_MODE.secondary
      }
    }, {
      device: () => isMaterial(themeName),
      options: {
        useInkRipple: true,
        selectOnFocus: false,
        iconPosition: ICON_POSITION.top
      }
    }]);
  },
  _init() {
    const {
      orientation,
      stylingMode,
      scrollingEnabled
    } = this.option();
    const indicatorPosition = this._getIndicatorPosition();
    this.callBase();
    this.setAria("role", "tablist");
    this.$element().addClass("dx-tabs");
    this._toggleScrollingEnabledClass(scrollingEnabled);
    this._toggleOrientationClass(orientation);
    this._toggleIndicatorPositionClass(indicatorPosition);
    this._toggleIconPositionClass();
    this._toggleStylingModeClass(stylingMode);
    this._renderWrapper();
    this._renderMultiple();
    this._feedbackHideTimeout = 100;
  },
  _prepareDefaultItemTemplate(data, $container) {
    const text = isPlainObject(data) ? null === data || void 0 === data ? void 0 : data.text : data;
    if (isDefined(text)) {
      const $tabTextSpan = renderer_default("<span>").addClass("dx-tab-text-span");
      $tabTextSpan.text(text);
      const $tabTextSpanPseudo = renderer_default("<span>").addClass("dx-tab-text-span-pseudo");
      $tabTextSpanPseudo.text(text);
      $tabTextSpanPseudo.appendTo($tabTextSpan);
      $tabTextSpan.appendTo($container);
    }
    if (isDefined(data.html)) {
      $container.html(data.html);
    }
  },
  _initTemplates() {
    this.callBase();
    this._templateManager.addDefaultTemplates({
      item: new BindableTemplate(($container, data) => {
        this._prepareDefaultItemTemplate(data, $container);
        const $iconElement = getImageContainer(data.icon);
        $iconElement && $iconElement.prependTo($container);
        const $tabItem = renderer_default("<div>").addClass("dx-tab-text");
        $container.wrapInner($tabItem);
      }, ["text", "html", "icon"], this.option("integrationOptions.watchMethod"))
    });
  },
  _createItemByTemplate: function(itemTemplate, renderArgs) {
    const {
      itemData,
      container,
      index
    } = renderArgs;
    this._deferredTemplates[index] = Deferred();
    return itemTemplate.render({
      model: itemData,
      container,
      index,
      onRendered: () => this._deferredTemplates[index].resolve()
    });
  },
  _itemClass: () => "dx-tab",
  _selectedItemClass: () => "dx-tab-selected",
  _itemDataKey: () => "dxTabData",
  _initMarkup() {
    this._deferredTemplates = [];
    this.callBase();
    this.option("useInkRipple") && this._renderInkRipple();
    this.$element().addClass("dx-overflow-hidden");
  },
  _render() {
    this.callBase();
    this._deferRenderScrolling();
  },
  _deferRenderScrolling() {
    when.apply(this, this._deferredTemplates).done(() => this._renderScrolling());
  },
  _renderScrolling() {
    const removeClasses = ["dx-tabs-stretched", TABS_EXPANDED_CLASS, "dx-overflow-hidden"];
    this.$element().removeClass(removeClasses.join(" "));
    if (this.option("scrollingEnabled") && this._isItemsSizeExceeded()) {
      if (!this._scrollable) {
        this._renderScrollable();
        this._renderNavButtons();
      }
      const scrollable = this.getScrollable();
      scrollable.update();
      if (this.option("rtlEnabled")) {
        const maxLeftOffset = getScrollLeftMax(renderer_default(this.getScrollable().container()).get(0));
        scrollable.scrollTo({
          left: maxLeftOffset
        });
      }
      this._updateNavButtonsState();
      this._scrollToItem(this.option("selectedItem"));
    }
    if (!(this.option("scrollingEnabled") && this._isItemsSizeExceeded())) {
      this._cleanScrolling();
      if (this._needStretchItems()) {
        this.$element().addClass("dx-tabs-stretched");
      }
      this.$element().removeClass("dx-tabs-nav-buttons").addClass(TABS_EXPANDED_CLASS);
    }
  },
  _isVertical() {
    return this.option("orientation") === ORIENTATION.vertical;
  },
  _isItemsSizeExceeded() {
    const isVertical = this._isVertical();
    const isItemsSizeExceeded = isVertical ? this._isItemsHeightExceeded() : this._isItemsWidthExceeded();
    return isItemsSizeExceeded;
  },
  _isItemsWidthExceeded() {
    const $visibleItems = this._getVisibleItems();
    const tabItemTotalWidth = this._getSummaryItemsSize("width", $visibleItems, true);
    const elementWidth = getWidth(this.$element());
    if ([tabItemTotalWidth, elementWidth].includes(0)) {
      return false;
    }
    const isItemsWidthExceeded = tabItemTotalWidth > elementWidth - 1;
    return isItemsWidthExceeded;
  },
  _isItemsHeightExceeded() {
    const $visibleItems = this._getVisibleItems();
    const itemsHeight = this._getSummaryItemsSize("height", $visibleItems, true);
    const elementHeight = getHeight(this.$element());
    const isItemsHeightExceeded = itemsHeight - 1 > elementHeight;
    return isItemsHeightExceeded;
  },
  _needStretchItems() {
    const $visibleItems = this._getVisibleItems();
    const elementWidth = getWidth(this.$element());
    const itemsWidth = [];
    each($visibleItems, (_, item) => {
      itemsWidth.push(getOuterWidth(item, true));
    });
    const maxTabItemWidth = Math.max.apply(null, itemsWidth);
    const requireWidth = elementWidth / $visibleItems.length;
    const needStretchItems = maxTabItemWidth > requireWidth + 1;
    return needStretchItems;
  },
  _cleanNavButtons() {
    if (!this._leftButton || !this._rightButton) {
      return;
    }
    this._leftButton.$element().remove();
    this._rightButton.$element().remove();
    this._leftButton = null;
    this._rightButton = null;
  },
  _cleanScrolling() {
    if (!this._scrollable) {
      return;
    }
    this._$wrapper.appendTo(this.$element());
    this._scrollable.$element().remove();
    this._scrollable = null;
    this._cleanNavButtons();
  },
  _renderInkRipple() {
    this._inkRipple = render3();
  },
  _getPointerEvent: () => pointer_default.up,
  _toggleActiveState($element, value, e) {
    this.callBase.apply(this, arguments);
    if (!this._inkRipple) {
      return;
    }
    const config = {
      element: $element,
      event: e
    };
    if (value) {
      this._inkRipple.showWave(config);
    } else {
      this._inkRipple.hideWave(config);
    }
  },
  _renderMultiple() {
    if ("multiple" === this.option("selectionMode")) {
      this.option("selectOnFocus", false);
    }
  },
  _renderWrapper() {
    this._$wrapper = renderer_default("<div>").addClass("dx-tabs-wrapper");
    this.$element().append(this._$wrapper);
  },
  _itemContainer() {
    return this._$wrapper;
  },
  _getScrollableDirection() {
    const isVertical = this._isVertical();
    const scrollableDirection = isVertical ? SCROLLABLE_DIRECTION.vertical : SCROLLABLE_DIRECTION.horizontal;
    return scrollableDirection;
  },
  _updateScrollable() {
    if (this.getScrollable()) {
      this._cleanScrolling();
    }
    this._renderScrolling();
  },
  _renderScrollable() {
    const $itemContainer = this.$element().wrapInner(renderer_default("<div>").addClass("dx-tabs-scrollable")).children();
    this._scrollable = this._createComponent($itemContainer, ui_scrollable_default, {
      direction: this._getScrollableDirection(),
      showScrollbar: "never",
      useKeyboard: false,
      useNative: false,
      scrollByContent: this.option("scrollByContent"),
      onScroll: () => {
        this._updateNavButtonsState();
      }
    });
    this.$element().append(this._scrollable.$element());
  },
  _scrollToItem(itemData) {
    if (!this._scrollable) {
      return;
    }
    const $item = this._editStrategy.getItemElement(itemData);
    this._scrollable.scrollToElement($item);
  },
  _renderNavButtons() {
    const {
      showNavButtons,
      rtlEnabled
    } = this.option();
    this.$element().toggleClass("dx-tabs-nav-buttons", showNavButtons);
    if (!showNavButtons) {
      return;
    }
    this._leftButton = this._createNavButton(-30, rtlEnabled ? "chevronnext" : "chevronprev");
    const $leftButton = this._leftButton.$element();
    $leftButton.addClass("dx-tabs-nav-button-left");
    this.$element().prepend($leftButton);
    this._rightButton = this._createNavButton(30, rtlEnabled ? "chevronprev" : "chevronnext");
    const $rightButton = this._rightButton.$element();
    $rightButton.addClass("dx-tabs-nav-button-right");
    this.$element().append($rightButton);
  },
  _updateNavButtonsAriaDisabled() {
    const buttons = [this._leftButton, this._rightButton];
    buttons.forEach((button) => {
      null === button || void 0 === button || button.$element().attr({
        "aria-disabled": null
      });
    });
  },
  _updateNavButtonsState() {
    const isVertical = this._isVertical();
    const scrollable = this.getScrollable();
    if (isVertical) {
      var _this$_leftButton, _this$_rightButton;
      null === (_this$_leftButton = this._leftButton) || void 0 === _this$_leftButton || _this$_leftButton.option("disabled", isReachedTop(scrollable.scrollTop(), 1));
      null === (_this$_rightButton = this._rightButton) || void 0 === _this$_rightButton || _this$_rightButton.option("disabled", isReachedBottom(renderer_default(scrollable.container()).get(0), scrollable.scrollTop(), 0, 1));
    } else {
      var _this$_leftButton2, _this$_rightButton2;
      null === (_this$_leftButton2 = this._leftButton) || void 0 === _this$_leftButton2 || _this$_leftButton2.option("disabled", isReachedLeft(scrollable.scrollLeft(), 1));
      null === (_this$_rightButton2 = this._rightButton) || void 0 === _this$_rightButton2 || _this$_rightButton2.option("disabled", isReachedRight(renderer_default(scrollable.container()).get(0), scrollable.scrollLeft(), 1));
    }
    this._updateNavButtonsAriaDisabled();
  },
  _updateScrollPosition(offset, duration) {
    this._scrollable.update();
    this._scrollable.scrollBy(offset / duration);
  },
  _createNavButton(offset, icon) {
    const holdAction = this._createAction(() => {
      this._holdInterval = setInterval(() => {
        this._updateScrollPosition(offset, 5);
      }, 5);
    });
    const holdEventName = addNamespace(hold_default.name, "dxNavButton");
    const pointerUpEventName = addNamespace(pointer_default.up, "dxNavButton");
    const pointerOutEventName = addNamespace(pointer_default.out, "dxNavButton");
    const navButton = this._createComponent(renderer_default("<div>").addClass("dx-tabs-nav-button"), button_default, {
      focusStateEnabled: false,
      icon,
      integrationOptions: {},
      elementAttr: {
        role: null,
        "aria-label": null,
        "aria-disabled": null
      },
      onClick: () => {
        this._updateScrollPosition(offset, 1);
      }
    });
    const $navButton = navButton.$element();
    events_engine_default.on($navButton, holdEventName, {
      timeout: 300
    }, (e) => {
      holdAction({
        event: e
      });
    });
    events_engine_default.on($navButton, pointerUpEventName, () => {
      this._clearInterval();
    });
    events_engine_default.on($navButton, pointerOutEventName, () => {
      this._clearInterval();
    });
    return navButton;
  },
  _clearInterval() {
    if (this._holdInterval) {
      clearInterval(this._holdInterval);
    }
  },
  _updateSelection(addedSelection) {
    this._scrollable && this._scrollable.scrollToElement(this.itemElements().eq(addedSelection[0]));
  },
  _visibilityChanged(visible) {
    if (visible) {
      this._dimensionChanged();
    }
  },
  _dimensionChanged() {
    this._renderScrolling();
  },
  _itemSelectHandler(e) {
    if ("single" === this.option("selectionMode") && this.isItemSelected(e.currentTarget)) {
      return;
    }
    this.callBase(e);
  },
  _clean() {
    this._deferredTemplates = [];
    this._cleanScrolling();
    this.callBase();
  },
  _toggleTabsVerticalClass(value) {
    this.$element().toggleClass(TABS_ORIENTATION_CLASS.vertical, value);
  },
  _toggleTabsHorizontalClass(value) {
    this.$element().toggleClass(TABS_ORIENTATION_CLASS.horizontal, value);
  },
  _getIndicatorPositionClass: (indicatorPosition) => INDICATOR_POSITION_CLASS[indicatorPosition],
  _getIndicatorPosition() {
    const {
      _indicatorPosition,
      rtlEnabled
    } = this.option();
    if (_indicatorPosition) {
      return _indicatorPosition;
    }
    const isVertical = this._isVertical();
    if (rtlEnabled) {
      return isVertical ? INDICATOR_POSITION.left : INDICATOR_POSITION.bottom;
    }
    return isVertical ? INDICATOR_POSITION.right : INDICATOR_POSITION.bottom;
  },
  _toggleIndicatorPositionClass(indicatorPosition) {
    const newClass = this._getIndicatorPositionClass(indicatorPosition);
    this._toggleElementClasses(INDICATOR_POSITION_CLASS, newClass);
  },
  _toggleScrollingEnabledClass(scrollingEnabled) {
    this.$element().toggleClass("dx-tabs-scrolling-enabled", Boolean(scrollingEnabled));
  },
  _toggleOrientationClass(orientation) {
    const isVertical = orientation === ORIENTATION.vertical;
    this._toggleTabsVerticalClass(isVertical);
    this._toggleTabsHorizontalClass(!isVertical);
  },
  _getTabsIconPositionClass() {
    const position = this.option("iconPosition");
    switch (position) {
      case ICON_POSITION.top:
        return TABS_ICON_POSITION_CLASS.top;
      case ICON_POSITION.end:
        return TABS_ICON_POSITION_CLASS.end;
      case ICON_POSITION.bottom:
        return TABS_ICON_POSITION_CLASS.bottom;
      default:
        return TABS_ICON_POSITION_CLASS.start;
    }
  },
  _toggleIconPositionClass() {
    const newClass = this._getTabsIconPositionClass();
    this._toggleElementClasses(TABS_ICON_POSITION_CLASS, newClass);
  },
  _toggleStylingModeClass(value) {
    const newClass = TABS_STYLING_MODE_CLASS[value] ?? TABS_STYLING_MODE_CLASS.primary;
    this._toggleElementClasses(TABS_STYLING_MODE_CLASS, newClass);
  },
  _toggleElementClasses(classMap, newClass) {
    for (const key in classMap) {
      this.$element().removeClass(classMap[key]);
    }
    this.$element().addClass(newClass);
  },
  _toggleFocusedDisabledNextClass(currentIndex, isNextDisabled) {
    this._itemElements().eq(currentIndex).toggleClass("dx-focused-disabled-next-tab", isNextDisabled);
  },
  _toggleFocusedDisabledPrevClass(currentIndex, isPrevDisabled) {
    this._itemElements().eq(currentIndex).toggleClass("dx-focused-disabled-prev-tab", isPrevDisabled);
  },
  _toggleFocusedDisabledClasses(value) {
    const {
      selectedIndex: currentIndex
    } = this.option();
    this._itemElements().removeClass("dx-focused-disabled-next-tab").removeClass("dx-focused-disabled-prev-tab");
    const prevItemIndex = currentIndex - 1;
    const nextItemIndex = currentIndex + 1;
    const nextFocusedIndex = renderer_default(value).index();
    const isNextDisabled = this._itemElements().eq(nextItemIndex).hasClass("dx-state-disabled");
    const isPrevDisabled = this._itemElements().eq(prevItemIndex).hasClass("dx-state-disabled");
    const shouldNextClassBeSetted = isNextDisabled && nextFocusedIndex === nextItemIndex;
    const shouldPrevClassBeSetted = isPrevDisabled && nextFocusedIndex === prevItemIndex;
    this._toggleFocusedDisabledNextClass(currentIndex, shouldNextClassBeSetted);
    this._toggleFocusedDisabledPrevClass(currentIndex, shouldPrevClassBeSetted);
  },
  _updateFocusedElement() {
    const {
      focusStateEnabled,
      selectedIndex
    } = this.option();
    const itemElements = this._itemElements();
    if (focusStateEnabled && itemElements.length) {
      const selectedItem = itemElements.get(selectedIndex);
      this.option({
        focusedElement: selectedItem
      });
    }
  },
  _optionChanged(args) {
    switch (args.name) {
      case "useInkRipple":
      case "scrollingEnabled":
        this._toggleScrollingEnabledClass(args.value);
        this._invalidate();
        break;
      case "showNavButtons":
      case "badgeExpr":
        this._invalidate();
        break;
      case "scrollByContent":
        this._scrollable && this._scrollable.option(args.name, args.value);
        break;
      case "width":
      case "height":
        this.callBase(args);
        this._dimensionChanged();
        break;
      case "selectionMode":
        this._renderMultiple();
        this.callBase(args);
        break;
      case "focusedElement":
        this._toggleFocusedDisabledClasses(args.value);
        this.callBase(args);
        this._scrollToItem(args.value);
        break;
      case "rtlEnabled": {
        this.callBase(args);
        const indicatorPosition = this._getIndicatorPosition();
        this._toggleIndicatorPositionClass(indicatorPosition);
        break;
      }
      case "orientation": {
        this._toggleOrientationClass(args.value);
        const indicatorPosition = this._getIndicatorPosition();
        this._toggleIndicatorPositionClass(indicatorPosition);
        if (hasWindow()) {
          this._updateScrollable();
        }
        break;
      }
      case "iconPosition":
        this._toggleIconPositionClass();
        if (hasWindow()) {
          this._dimensionChanged();
        }
        break;
      case "stylingMode":
        this._toggleStylingModeClass(args.value);
        if (hasWindow()) {
          this._dimensionChanged();
        }
        break;
      case "_indicatorPosition":
        this._toggleIndicatorPositionClass(args.value);
        break;
      case "selectedIndex":
      case "selectedItem":
      case "selectedItems":
        this.callBase(args);
        this._updateFocusedElement();
        break;
      default:
        this.callBase(args);
    }
  },
  _afterItemElementInserted() {
    this.callBase();
    this._deferRenderScrolling();
  },
  _afterItemElementDeleted($item, deletedActionArgs) {
    this.callBase($item, deletedActionArgs);
    this._renderScrolling();
  },
  getScrollable() {
    return this._scrollable;
  }
});
Tabs.ItemClass = m_item_default2;
component_registrator_default("dxTabs", Tabs);
var m_tabs_default = Tabs;

// node_modules/devextreme/esm/ui/tabs.js
var tabs_default = m_tabs_default;

export {
  BindableTemplate,
  getImageSourceType,
  getImageContainer,
  findChanges,
  array_store_default,
  normalizeLoadResult,
  normalizeDataSourceOptions,
  DataSource,
  SelectionFilterCreator,
  Selection,
  m_data_controller_default,
  data_helper_default,
  hold_default,
  name,
  core_default,
  message_default,
  m_item_default,
  m_collection_widget_edit_strategy_plain_default,
  m_collection_widget_edit_default,
  ui_collection_widget_live_update_default,
  toFixed,
  getFormat,
  number_default2 as number_default,
  m_validation_engine_default,
  validation_engine_default,
  findDOMfromVNode,
  createVNode,
  createComponentVNode,
  createFragment,
  normalizeProps,
  createRef,
  BaseInfernoComponent,
  InfernoComponent,
  InfernoWrapperComponent,
  createContext,
  InfernoEffect,
  createReRenderEffect,
  renderTemplate,
  hasTemplate,
  normalizeStyles,
  inferno_renderer_default,
  component_default,
  combineClasses,
  render3 as render,
  emitter_gesture_scroll_default,
  subscribeToClickEvent,
  BaseWidgetProps,
  ConfigContext,
  WidgetProps,
  Widget,
  button_default,
  m_scrollable_native_default,
  m_animator_default,
  Scroller,
  SimulatedStrategy,
  getRelativeOffset,
  DIRECTION_VERTICAL,
  DIRECTION_HORIZONTAL,
  SCROLLABLE_CONTENT_CLASS,
  deviceDependentOptions,
  m_scrollable_default,
  ui_scrollable_default,
  ScrollDirection,
  tabs_default
};
//# sourceMappingURL=chunk-ULGGFT5V.js.map
