import {
  callbacks_default,
  each,
  init_callbacks,
  init_iterator
} from "./chunk-4MAIXMIT.js";
import {
  init_type,
  isFunction,
  isPlainObject
} from "./chunk-ND5ICVCX.js";
import {
  __esm
} from "./chunk-WOR4A3D2.js";

// node_modules/devextreme/esm/core/events_strategy.js
var EventsStrategy;
var init_events_strategy = __esm({
  "node_modules/devextreme/esm/core/events_strategy.js"() {
    init_callbacks();
    init_iterator();
    init_type();
    EventsStrategy = class _EventsStrategy {
      constructor(owner) {
        let options = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this._events = {};
        this._owner = owner;
        this._options = options;
      }
      static create(owner, strategy) {
        if (strategy) {
          return isFunction(strategy) ? strategy(owner) : strategy;
        } else {
          return new _EventsStrategy(owner);
        }
      }
      hasEvent(eventName) {
        const callbacks = this._events[eventName];
        return callbacks ? callbacks.has() : false;
      }
      fireEvent(eventName, eventArgs) {
        const callbacks = this._events[eventName];
        if (callbacks) {
          callbacks.fireWith(this._owner, eventArgs);
        }
        return this._owner;
      }
      on(eventName, eventHandler) {
        if (isPlainObject(eventName)) {
          each(eventName, (e, h) => {
            this.on(e, h);
          });
        } else {
          let callbacks = this._events[eventName];
          if (!callbacks) {
            callbacks = callbacks_default({
              syncStrategy: this._options.syncStrategy
            });
            this._events[eventName] = callbacks;
          }
          const addFn = callbacks.originalAdd || callbacks.add;
          addFn.call(callbacks, eventHandler);
        }
      }
      off(eventName, eventHandler) {
        const callbacks = this._events[eventName];
        if (callbacks) {
          if (isFunction(eventHandler)) {
            callbacks.remove(eventHandler);
          } else {
            callbacks.empty();
          }
        }
      }
      dispose() {
        each(this._events, (eventName, event) => {
          event.empty();
        });
      }
    };
  }
});

export {
  EventsStrategy,
  init_events_strategy
};
//# sourceMappingURL=chunk-BC4UU3FA.js.map
