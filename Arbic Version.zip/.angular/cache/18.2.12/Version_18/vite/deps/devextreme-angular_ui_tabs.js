import {
  DxTabsComponent,
  DxTabsModule
} from "./chunk-3P5M3HDI.js";
import "./chunk-ULGGFT5V.js";
import "./chunk-4V47G62F.js";
import "./chunk-C5QLDEFD.js";
import "./chunk-I3DYQMSR.js";
import "./chunk-O2ZOTGYJ.js";
import "./chunk-BC4UU3FA.js";
import "./chunk-ICKSQFPZ.js";
import "./chunk-M4PC57RV.js";
import "./chunk-WOX6XKRX.js";
import "./chunk-4MAIXMIT.js";
import "./chunk-ND5ICVCX.js";
import "./chunk-WBCLGCHV.js";
import "./chunk-EBLT4CH3.js";
import "./chunk-74ZAWBSC.js";
import "./chunk-WOR4A3D2.js";
export {
  DxTabsComponent,
  DxTabsModule
};
//# sourceMappingURL=devextreme-angular_ui_tabs.js.map
