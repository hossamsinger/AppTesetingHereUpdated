import {
  EmptyTemplate,
  addNamespace,
  browser_default,
  cancelAnimationFrame,
  changeCallback,
  clearCache,
  component_registrator_default,
  contains,
  devices_default,
  emitter_gesture_default,
  emitter_registrator_default,
  eventData,
  event_registrator_default,
  fireEvent,
  getBoundingRect,
  getPublicElement,
  getTranslate,
  getTranslateCss,
  isCommandKeyPressed,
  keyboard,
  locate,
  move,
  normalizeKeyName,
  parseTranslate,
  pointer_default,
  removeEvent,
  requestAnimationFrame,
  resetActiveElement,
  resetPosition,
  tabbable,
  touch,
  transition,
  transitionEndEventName,
  triggerHidingEvent,
  triggerResizeEvent,
  triggerShownEvent,
  ui_errors_default,
  ui_widget_default,
  value,
  wrapToArray
} from "./chunk-O2ZOTGYJ.js";
import {
  data,
  events_engine_default,
  getHeight,
  getOuterHeight,
  getOuterWidth,
  getWidth,
  init_element_data,
  init_events_engine,
  init_renderer,
  init_size,
  init_style,
  removeData,
  renderer_default,
  setStyle
} from "./chunk-WOX6XKRX.js";
import {
  Deferred,
  dom_adapter_default,
  each,
  ensureDefined,
  getWindow,
  hasWindow,
  init_common,
  init_deferred,
  init_dom_adapter,
  init_iterator,
  init_ready_callbacks,
  init_window,
  map,
  noop,
  pairToObject,
  ready_callbacks_default,
  splitPair,
  when
} from "./chunk-4MAIXMIT.js";
import {
  errors_default,
  extend,
  init_errors,
  init_extend,
  init_type,
  isDefined,
  isEvent,
  isFunction,
  isObject,
  isPlainObject,
  isPromise,
  isString,
  isWindow
} from "./chunk-ND5ICVCX.js";

// node_modules/devextreme/esm/animation/fx.js
init_renderer();
init_window();
init_events_engine();
init_errors();
init_extend();
init_type();
init_iterator();

// node_modules/devextreme/esm/animation/easing.js
init_type();
var CSS_TRANSITION_EASING_REGEX = /cubic-bezier\((\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\)/;
var TransitionTimingFuncMap = {
  linear: "cubic-bezier(0, 0, 1, 1)",
  swing: "cubic-bezier(0.445, 0.05, 0.55, 0.95)",
  ease: "cubic-bezier(0.25, 0.1, 0.25, 1)",
  "ease-in": "cubic-bezier(0.42, 0, 1, 1)",
  "ease-out": "cubic-bezier(0, 0, 0.58, 1)",
  "ease-in-out": "cubic-bezier(0.42, 0, 0.58, 1)"
};
var polynomBezier = function(x1, y1, x2, y2) {
  const Cx = 3 * x1;
  const Bx = 3 * (x2 - x1) - Cx;
  const Ax = 1 - Cx - Bx;
  const Cy = 3 * y1;
  const By = 3 * (y2 - y1) - Cy;
  const Ay = 1 - Cy - By;
  const bezierX = function(t) {
    return t * (Cx + t * (Bx + t * Ax));
  };
  const derivativeX = function(t) {
    return Cx + t * (2 * Bx + 3 * t * Ax);
  };
  return function(t) {
    return function(t2) {
      return t2 * (Cy + t2 * (By + t2 * Ay));
    }(function(t2) {
      let x = t2;
      let i = 0;
      let z;
      while (i < 14) {
        z = bezierX(x) - t2;
        if (Math.abs(z) < 1e-3) {
          break;
        }
        x -= z / derivativeX(x);
        i++;
      }
      return x;
    }(t));
  };
};
var easing = {};
var convertTransitionTimingFuncToEasing = function(cssTransitionEasing) {
  cssTransitionEasing = TransitionTimingFuncMap[cssTransitionEasing] || cssTransitionEasing;
  let coeffs = cssTransitionEasing.match(CSS_TRANSITION_EASING_REGEX);
  let forceName;
  if (!coeffs) {
    forceName = "linear";
    coeffs = TransitionTimingFuncMap[forceName].match(CSS_TRANSITION_EASING_REGEX);
  }
  coeffs = coeffs.slice(1, 5);
  for (let i = 0; i < coeffs.length; i++) {
    coeffs[i] = parseFloat(coeffs[i]);
  }
  const easingName = forceName || "cubicbezier_" + coeffs.join("_").replace(/\./g, "p");
  if (!isFunction(easing[easingName])) {
    easing[easingName] = function(x, t, b, c, d) {
      return c * polynomBezier(coeffs[0], coeffs[1], coeffs[2], coeffs[3])(t / d) + b;
    };
  }
  return easingName;
};
function getEasing(name) {
  return easing[name];
}

// node_modules/devextreme/esm/animation/position.js
init_size();
init_renderer();
init_common();
init_iterator();
init_window();
init_dom_adapter();
init_type();
init_extend();
init_style();
var window = getWindow();
var horzRe = /left|right/;
var vertRe = /top|bottom/;
var collisionRe = /fit|flip|none/;
var scaleRe = /scale\(.+?\)/;
var IS_SAFARI = browser_default.safari;
var normalizeAlign = function(raw) {
  const result = {
    h: "center",
    v: "center"
  };
  const pair = splitPair(raw);
  if (pair) {
    each(pair, function() {
      const w = String(this).toLowerCase();
      if (horzRe.test(w)) {
        result.h = w;
      } else if (vertRe.test(w)) {
        result.v = w;
      }
    });
  }
  return result;
};
var normalizeOffset = function(raw, preventRound) {
  return pairToObject(raw, preventRound);
};
var normalizeCollision = function(raw) {
  const pair = splitPair(raw);
  let h = String(pair && pair[0]).toLowerCase();
  let v = String(pair && pair[1]).toLowerCase();
  if (!collisionRe.test(h)) {
    h = "none";
  }
  if (!collisionRe.test(v)) {
    v = h;
  }
  return {
    h,
    v
  };
};
var getAlignFactor = function(align) {
  switch (align) {
    case "center":
      return 0.5;
    case "right":
    case "bottom":
      return 1;
    default:
      return 0;
  }
};
var inverseAlign = function(align) {
  switch (align) {
    case "left":
      return "right";
    case "right":
      return "left";
    case "top":
      return "bottom";
    case "bottom":
      return "top";
    default:
      return align;
  }
};
var calculateOversize = function(data2, bounds) {
  let oversize = 0;
  if (data2.myLocation < bounds.min) {
    oversize += bounds.min - data2.myLocation;
  }
  if (data2.myLocation > bounds.max) {
    oversize += data2.myLocation - bounds.max;
  }
  return oversize;
};
var collisionSide = function(direction, data2, bounds) {
  if (data2.myLocation < bounds.min) {
    return "h" === direction ? "left" : "top";
  }
  if (data2.myLocation > bounds.max) {
    return "h" === direction ? "right" : "bottom";
  }
  return "none";
};
var initMyLocation = function(data2) {
  data2.myLocation = data2.atLocation + getAlignFactor(data2.atAlign) * data2.atSize - getAlignFactor(data2.myAlign) * data2.mySize + data2.offset;
};
var collisionResolvers = {
  fit: function(data2, bounds) {
    let result = false;
    if (data2.myLocation > bounds.max) {
      data2.myLocation = bounds.max;
      result = true;
    }
    if (data2.myLocation < bounds.min) {
      data2.myLocation = bounds.min;
      result = true;
    }
    data2.fit = result;
  },
  flip: function(data2, bounds) {
    data2.flip = false;
    if ("center" === data2.myAlign && "center" === data2.atAlign) {
      return;
    }
    if (data2.myLocation < bounds.min || data2.myLocation > bounds.max) {
      const inverseData = extend({}, data2, {
        myAlign: inverseAlign(data2.myAlign),
        atAlign: inverseAlign(data2.atAlign),
        offset: -data2.offset
      });
      initMyLocation(inverseData);
      inverseData.oversize = calculateOversize(inverseData, bounds);
      if (inverseData.myLocation >= bounds.min && inverseData.myLocation <= bounds.max || data2.oversize > inverseData.oversize) {
        data2.myLocation = inverseData.myLocation;
        data2.oversize = inverseData.oversize;
        data2.flip = true;
      }
    }
  },
  flipfit: function(data2, bounds) {
    this.flip(data2, bounds);
    this.fit(data2, bounds);
  },
  none: function(data2) {
    data2.oversize = 0;
  }
};
var scrollbarWidth;
var calculateScrollbarWidth = function() {
  const $scrollDiv = renderer_default("<div>").css({
    width: 100,
    height: 100,
    overflow: "scroll",
    position: "absolute",
    top: -9999
  }).appendTo(renderer_default("body"));
  const result = $scrollDiv.get(0).offsetWidth - $scrollDiv.get(0).clientWidth;
  $scrollDiv.remove();
  scrollbarWidth = result;
};
var defaultPositionResult = {
  h: {
    location: 0,
    flip: false,
    fit: false,
    oversize: 0
  },
  v: {
    location: 0,
    flip: false,
    fit: false,
    oversize: 0
  }
};
var calculatePosition = function(what, options) {
  const $what = renderer_default(what);
  const currentOffset = $what.offset();
  const result = extend(true, {}, defaultPositionResult, {
    h: {
      location: currentOffset.left
    },
    v: {
      location: currentOffset.top
    }
  });
  if (!options) {
    return result;
  }
  const my = normalizeAlign(options.my);
  const at = normalizeAlign(options.at);
  let of = renderer_default(options.of).length && options.of || window;
  const offset2 = normalizeOffset(options.offset, options.precise);
  const collision = normalizeCollision(options.collision);
  const boundary = options.boundary;
  const boundaryOffset = normalizeOffset(options.boundaryOffset, options.precise);
  const h = {
    mySize: getOuterWidth($what),
    myAlign: my.h,
    atAlign: at.h,
    offset: offset2.h,
    collision: collision.h,
    boundaryOffset: boundaryOffset.h
  };
  const v = {
    mySize: getOuterHeight($what),
    myAlign: my.v,
    atAlign: at.v,
    offset: offset2.v,
    collision: collision.v,
    boundaryOffset: boundaryOffset.v
  };
  if (of.preventDefault) {
    h.atLocation = of.pageX;
    v.atLocation = of.pageY;
    h.atSize = 0;
    v.atSize = 0;
  } else {
    of = renderer_default(of);
    if (isWindow(of[0])) {
      h.atLocation = of.scrollLeft();
      v.atLocation = of.scrollTop();
      if ("phone" === devices_default.real().deviceType && of[0].visualViewport) {
        h.atLocation = Math.max(h.atLocation, of[0].visualViewport.offsetLeft);
        v.atLocation = Math.max(v.atLocation, of[0].visualViewport.offsetTop);
        h.atSize = of[0].visualViewport.width;
        v.atSize = of[0].visualViewport.height;
      } else {
        h.atSize = of[0].innerWidth > of[0].outerWidth ? of[0].innerWidth : getWidth(of);
        v.atSize = of[0].innerHeight > of[0].outerHeight || IS_SAFARI ? of[0].innerHeight : getHeight(of);
      }
    } else if (9 === of[0].nodeType) {
      h.atLocation = 0;
      v.atLocation = 0;
      h.atSize = getWidth(of);
      v.atSize = getHeight(of);
    } else {
      const ofRect = getBoundingRect(of.get(0));
      const o = getOffsetWithoutScale(of);
      h.atLocation = o.left;
      v.atLocation = o.top;
      h.atSize = Math.max(ofRect.width, getOuterWidth(of));
      v.atSize = Math.max(ofRect.height, getOuterHeight(of));
    }
  }
  initMyLocation(h);
  initMyLocation(v);
  const bounds = function() {
    const win = renderer_default(window);
    const windowWidth = getWidth(win);
    const windowHeight = getHeight(win);
    let left = win.scrollLeft();
    let top = win.scrollTop();
    const documentElement = dom_adapter_default.getDocumentElement();
    const hZoomLevel = touch ? documentElement.clientWidth / windowWidth : 1;
    const vZoomLevel = touch ? documentElement.clientHeight / windowHeight : 1;
    if (void 0 === scrollbarWidth) {
      calculateScrollbarWidth();
    }
    let boundaryWidth = windowWidth;
    let boundaryHeight = windowHeight;
    if (boundary && !isWindow(boundary)) {
      const $boundary = renderer_default(boundary);
      const boundaryPosition = $boundary.offset();
      left = boundaryPosition.left;
      top = boundaryPosition.top;
      boundaryWidth = getWidth($boundary);
      boundaryHeight = getHeight($boundary);
    }
    return {
      h: {
        min: left + h.boundaryOffset,
        max: left + boundaryWidth / hZoomLevel - h.mySize - h.boundaryOffset
      },
      v: {
        min: top + v.boundaryOffset,
        max: top + boundaryHeight / vZoomLevel - v.mySize - v.boundaryOffset
      }
    };
  }();
  h.oversize = calculateOversize(h, bounds.h);
  v.oversize = calculateOversize(v, bounds.v);
  h.collisionSide = collisionSide("h", h, bounds.h);
  v.collisionSide = collisionSide("v", v, bounds.v);
  if (collisionResolvers[h.collision]) {
    collisionResolvers[h.collision](h, bounds.h);
  }
  if (collisionResolvers[v.collision]) {
    collisionResolvers[v.collision](v, bounds.v);
  }
  const preciser = function(number) {
    return options.precise ? number : Math.round(number);
  };
  extend(true, result, {
    h: {
      location: preciser(h.myLocation),
      oversize: preciser(h.oversize),
      fit: h.fit,
      flip: h.flip,
      collisionSide: h.collisionSide
    },
    v: {
      location: preciser(v.myLocation),
      oversize: preciser(v.oversize),
      fit: v.fit,
      flip: v.flip,
      collisionSide: v.collisionSide
    },
    precise: options.precise
  });
  return result;
};
var setScaleProperty = function(element, scale, styleAttr, isEmpty) {
  const stylePropIsValid = isDefined(element.style) && !dom_adapter_default.isNode(element.style);
  const newStyleValue = isEmpty ? styleAttr.replace(scale, "") : styleAttr;
  if (stylePropIsValid) {
    setStyle(element, newStyleValue, false);
  } else {
    const styleAttributeNode = dom_adapter_default.createAttribute("style");
    styleAttributeNode.value = newStyleValue;
    element.setAttributeNode(styleAttributeNode);
  }
};
var getOffsetWithoutScale = function($startElement) {
  var _currentElement$getAt, _style$match;
  let $currentElement = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : $startElement;
  const currentElement = $currentElement.get(0);
  if (!currentElement) {
    return $startElement.offset();
  }
  const style = (null === (_currentElement$getAt = currentElement.getAttribute) || void 0 === _currentElement$getAt ? void 0 : _currentElement$getAt.call(currentElement, "style")) || "";
  const scale = null === (_style$match = style.match(scaleRe)) || void 0 === _style$match ? void 0 : _style$match[0];
  let offset2;
  if (scale) {
    setScaleProperty(currentElement, scale, style, true);
    offset2 = getOffsetWithoutScale($startElement, $currentElement.parent());
    setScaleProperty(currentElement, scale, style, false);
  } else {
    offset2 = getOffsetWithoutScale($startElement, $currentElement.parent());
  }
  return offset2;
};
var position = function(what, options) {
  const $what = renderer_default(what);
  if (!options) {
    return $what.offset();
  }
  resetPosition($what, true);
  const offset2 = getOffsetWithoutScale($what);
  const targetPosition = options.h && options.v ? options : calculatePosition($what, options);
  const preciser = function(number) {
    return options.precise ? number : Math.round(number);
  };
  move($what, {
    left: targetPosition.h.location - preciser(offset2.left),
    top: targetPosition.v.location - preciser(offset2.top)
  });
  return targetPosition;
};
var offset = function(element) {
  element = renderer_default(element).get(0);
  if (isWindow(element)) {
    return null;
  } else if (element && "pageY" in element && "pageX" in element) {
    return {
      top: element.pageY,
      left: element.pageX
    };
  }
  return renderer_default(element).offset();
};
if (!position.inverseAlign) {
  position.inverseAlign = inverseAlign;
}
if (!position.normalizeAlign) {
  position.normalizeAlign = normalizeAlign;
}
var position_default = {
  calculateScrollbarWidth,
  calculate: calculatePosition,
  setup: position,
  offset
};

// node_modules/devextreme/esm/animation/fx.js
init_deferred();
init_common();
var window2 = getWindow();
var removeEventName = addNamespace(removeEvent, "dxFX");
var RELATIVE_VALUE_REGEX = /^([+-])=(.*)/i;
var ANIM_DATA_KEY = "dxAnimData";
var ANIM_QUEUE_KEY = "dxAnimQueue";
var TransitionAnimationStrategy = {
  initAnimation: function($element, config) {
    $element.css({
      transitionProperty: "none"
    });
    if ("string" === typeof config.from) {
      $element.addClass(config.from);
    } else {
      setProps($element, config.from);
    }
    const that = this;
    const deferred = new Deferred();
    const cleanupWhen = config.cleanupWhen;
    config.transitionAnimation = {
      deferred,
      finish: function() {
        that._finishTransition($element);
        if (cleanupWhen) {
          when(deferred, cleanupWhen).always(function() {
            that._cleanup($element, config);
          });
        } else {
          that._cleanup($element, config);
        }
        deferred.resolveWith($element, [config, $element]);
      }
    };
    this._completeAnimationCallback($element, config).done(function() {
      config.transitionAnimation.finish();
    }).fail(function() {
      deferred.rejectWith($element, [config, $element]);
    });
    if (!config.duration) {
      config.transitionAnimation.finish();
    }
    $element.css("transform");
  },
  animate: function($element, config) {
    this._startAnimation($element, config);
    return config.transitionAnimation.deferred.promise();
  },
  _completeAnimationCallback: function($element, config) {
    const that = this;
    const startTime = Date.now() + config.delay;
    const deferred = new Deferred();
    const transitionEndFired = new Deferred();
    const simulatedTransitionEndFired = new Deferred();
    let simulatedEndEventTimer;
    const transitionEndEventFullName = transitionEndEventName() + ".dxFX";
    config.transitionAnimation.cleanup = function() {
      clearTimeout(simulatedEndEventTimer);
      clearTimeout(waitForJSCompleteTimer);
      events_engine_default.off($element, transitionEndEventFullName);
      events_engine_default.off($element, removeEventName);
    };
    events_engine_default.one($element, transitionEndEventFullName, function() {
      if (Date.now() - startTime >= config.duration) {
        transitionEndFired.reject();
      }
    });
    events_engine_default.off($element, removeEventName);
    events_engine_default.on($element, removeEventName, function() {
      that.stop($element, config);
      deferred.reject();
    });
    const waitForJSCompleteTimer = setTimeout(function() {
      simulatedEndEventTimer = setTimeout(function() {
        simulatedTransitionEndFired.reject();
      }, config.duration + config.delay + fx._simulatedTransitionEndDelay);
      when(transitionEndFired, simulatedTransitionEndFired).fail(function() {
        deferred.resolve();
      }.bind(this));
    });
    return deferred.promise();
  },
  _startAnimation: function($element, config) {
    $element.css({
      transitionProperty: "all",
      transitionDelay: config.delay + "ms",
      transitionDuration: config.duration + "ms",
      transitionTimingFunction: config.easing
    });
    if ("string" === typeof config.to) {
      $element[0].className += " " + config.to;
    } else if (config.to) {
      setProps($element, config.to);
    }
  },
  _finishTransition: function($element) {
    $element.css("transition", "none");
  },
  _cleanup: function($element, config) {
    config.transitionAnimation.cleanup();
    if ("string" === typeof config.from) {
      $element.removeClass(config.from);
      $element.removeClass(config.to);
    }
  },
  stop: function($element, config, jumpToEnd) {
    if (!config) {
      return;
    }
    if (jumpToEnd) {
      config.transitionAnimation.finish();
    } else {
      if (isPlainObject(config.to)) {
        each(config.to, function(key) {
          $element.css(key, $element.css(key));
        });
      }
      this._finishTransition($element);
      this._cleanup($element, config);
    }
  }
};
var FrameAnimationStrategy = {
  initAnimation: function($element, config) {
    setProps($element, config.from);
  },
  animate: function($element, config) {
    const deferred = new Deferred();
    const that = this;
    if (!config) {
      return deferred.reject().promise();
    }
    each(config.to, function(prop) {
      if (void 0 === config.from[prop]) {
        config.from[prop] = that._normalizeValue($element.css(prop));
      }
    });
    if (config.to.transform) {
      config.from.transform = that._parseTransform(config.from.transform);
      config.to.transform = that._parseTransform(config.to.transform);
    }
    config.frameAnimation = {
      to: config.to,
      from: config.from,
      currentValue: config.from,
      easing: convertTransitionTimingFuncToEasing(config.easing),
      duration: config.duration,
      startTime: (/* @__PURE__ */ new Date()).valueOf(),
      finish: function() {
        this.currentValue = this.to;
        this.draw();
        cancelAnimationFrame(config.frameAnimation.animationFrameId);
        deferred.resolve();
      },
      draw: function() {
        if (config.draw) {
          config.draw(this.currentValue);
          return;
        }
        const currentValue = extend({}, this.currentValue);
        if (currentValue.transform) {
          currentValue.transform = map(currentValue.transform, function(value2, prop) {
            if ("translate" === prop) {
              return getTranslateCss(value2);
            } else if ("scale" === prop) {
              return "scale(" + value2 + ")";
            } else if ("rotate" === prop.substr(0, prop.length - 1)) {
              return prop + "(" + value2 + "deg)";
            }
          }).join(" ");
        }
        $element.css(currentValue);
      }
    };
    if (config.delay) {
      config.frameAnimation.startTime += config.delay;
      config.frameAnimation.delayTimeout = setTimeout(function() {
        that._startAnimation($element, config);
      }, config.delay);
    } else {
      that._startAnimation($element, config);
    }
    return deferred.promise();
  },
  _startAnimation: function($element, config) {
    events_engine_default.off($element, removeEventName);
    events_engine_default.on($element, removeEventName, function() {
      if (config.frameAnimation) {
        cancelAnimationFrame(config.frameAnimation.animationFrameId);
      }
    });
    this._animationStep($element, config);
  },
  _parseTransform: function(transformString) {
    const result = {};
    each(transformString.match(/\w+\d*\w*\([^)]*\)\s*/g), function(i, part) {
      const translateData = parseTranslate(part);
      const scaleData = part.match(/scale\((.+?)\)/);
      const rotateData = part.match(/(rotate.)\((.+)deg\)/);
      if (translateData) {
        result.translate = translateData;
      }
      if (scaleData && scaleData[1]) {
        result.scale = parseFloat(scaleData[1]);
      }
      if (rotateData && rotateData[1]) {
        result[rotateData[1]] = parseFloat(rotateData[2]);
      }
    });
    return result;
  },
  stop: function($element, config, jumpToEnd) {
    const frameAnimation = config && config.frameAnimation;
    if (!frameAnimation) {
      return;
    }
    cancelAnimationFrame(frameAnimation.animationFrameId);
    clearTimeout(frameAnimation.delayTimeout);
    if (jumpToEnd) {
      frameAnimation.finish();
    }
    delete config.frameAnimation;
  },
  _animationStep: function($element, config) {
    const frameAnimation = config && config.frameAnimation;
    if (!frameAnimation) {
      return;
    }
    const now = (/* @__PURE__ */ new Date()).valueOf();
    if (now >= frameAnimation.startTime + frameAnimation.duration) {
      frameAnimation.finish();
      return;
    }
    frameAnimation.currentValue = this._calcStepValue(frameAnimation, now - frameAnimation.startTime);
    frameAnimation.draw();
    const that = this;
    frameAnimation.animationFrameId = requestAnimationFrame(function() {
      that._animationStep($element, config);
    });
  },
  _calcStepValue: function(frameAnimation, currentDuration) {
    const calcValueRecursively = function(from, to) {
      const result = Array.isArray(to) ? [] : {};
      each(to, function(propName, endPropValue) {
        if ("string" === typeof endPropValue && false === parseFloat(endPropValue)) {
          return true;
        }
        result[propName] = "object" === typeof endPropValue ? calcValueRecursively(from[propName], endPropValue) : function(propName2) {
          const x = currentDuration / frameAnimation.duration;
          const t = currentDuration;
          const b = 1 * from[propName2];
          const c = to[propName2] - from[propName2];
          const d = frameAnimation.duration;
          return getEasing(frameAnimation.easing)(x, t, b, c, d);
        }(propName);
      });
      return result;
    };
    return calcValueRecursively(frameAnimation.from, frameAnimation.to);
  },
  _normalizeValue: function(value2) {
    const numericValue = parseFloat(value2);
    if (false === numericValue) {
      return value2;
    }
    return numericValue;
  }
};
var FallbackToNoAnimationStrategy = {
  initAnimation: function() {
  },
  animate: function() {
    return new Deferred().resolve().promise();
  },
  stop: noop,
  isSynchronous: true
};
var getAnimationStrategy = function(config) {
  config = config || {};
  const animationStrategies = {
    transition: transition() ? TransitionAnimationStrategy : FrameAnimationStrategy,
    frame: FrameAnimationStrategy,
    noAnimation: FallbackToNoAnimationStrategy
  };
  let strategy = config.strategy || "transition";
  if ("css" === config.type && !transition()) {
    strategy = "noAnimation";
  }
  return animationStrategies[strategy];
};
var baseConfigValidator = function(config, animationType, validate, typeMessage) {
  each(["from", "to"], function() {
    if (!validate(config[this])) {
      throw errors_default.Error("E0010", animationType, this, typeMessage);
    }
  });
};
var isObjectConfigValidator = function(config, animationType) {
  return baseConfigValidator(config, animationType, function(target) {
    return isPlainObject(target);
  }, "a plain object");
};
var isStringConfigValidator = function(config, animationType) {
  return baseConfigValidator(config, animationType, function(target) {
    return "string" === typeof target;
  }, "a string");
};
var CustomAnimationConfigurator = {
  setup: function() {
  }
};
var CssAnimationConfigurator = {
  validateConfig: function(config) {
    isStringConfigValidator(config, "css");
  },
  setup: function() {
  }
};
var positionAliases = {
  top: {
    my: "bottom center",
    at: "top center"
  },
  bottom: {
    my: "top center",
    at: "bottom center"
  },
  right: {
    my: "left center",
    at: "right center"
  },
  left: {
    my: "right center",
    at: "left center"
  }
};
var SlideAnimationConfigurator = {
  validateConfig: function(config) {
    isObjectConfigValidator(config, "slide");
  },
  setup: function($element, config) {
    const location = locate($element);
    if ("slide" !== config.type) {
      const positioningConfig = "slideIn" === config.type ? config.from : config.to;
      positioningConfig.position = extend({
        of: window2
      }, positionAliases[config.direction]);
      setupPosition($element, positioningConfig);
    }
    this._setUpConfig(location, config.from);
    this._setUpConfig(location, config.to);
    clearCache($element);
  },
  _setUpConfig: function(location, config) {
    config.left = "left" in config ? config.left : "+=0";
    config.top = "top" in config ? config.top : "+=0";
    this._initNewPosition(location, config);
  },
  _initNewPosition: function(location, config) {
    const position2 = {
      left: config.left,
      top: config.top
    };
    delete config.left;
    delete config.top;
    let relativeValue = this._getRelativeValue(position2.left);
    if (void 0 !== relativeValue) {
      position2.left = relativeValue + location.left;
    } else {
      config.left = 0;
    }
    relativeValue = this._getRelativeValue(position2.top);
    if (void 0 !== relativeValue) {
      position2.top = relativeValue + location.top;
    } else {
      config.top = 0;
    }
    config.transform = getTranslateCss({
      x: position2.left,
      y: position2.top
    });
  },
  _getRelativeValue: function(value2) {
    let relativeValue;
    if ("string" === typeof value2 && (relativeValue = RELATIVE_VALUE_REGEX.exec(value2))) {
      return parseInt(relativeValue[1] + "1") * relativeValue[2];
    }
  }
};
var FadeAnimationConfigurator = {
  setup: function($element, config) {
    const from = config.from;
    const to = config.to;
    const defaultFromOpacity = "fadeOut" === config.type ? 1 : 0;
    const defaultToOpacity = "fadeOut" === config.type ? 0 : 1;
    let fromOpacity = isPlainObject(from) ? String(from.opacity ?? defaultFromOpacity) : String(from);
    let toOpacity = isPlainObject(to) ? String(to.opacity ?? defaultToOpacity) : String(to);
    if (!config.skipElementInitialStyles) {
      fromOpacity = $element.css("opacity");
    }
    switch (config.type) {
      case "fadeIn":
        toOpacity = 1;
        break;
      case "fadeOut":
        toOpacity = 0;
    }
    config.from = {
      visibility: "visible",
      opacity: fromOpacity
    };
    config.to = {
      opacity: toOpacity
    };
  }
};
var PopAnimationConfigurator = {
  validateConfig: function(config) {
    isObjectConfigValidator(config, "pop");
  },
  setup: function($element, config) {
    const from = config.from;
    const to = config.to;
    const fromOpacity = "opacity" in from ? from.opacity : $element.css("opacity");
    const toOpacity = "opacity" in to ? to.opacity : 1;
    const fromScale = "scale" in from ? from.scale : 0;
    const toScale = "scale" in to ? to.scale : 1;
    config.from = {
      opacity: fromOpacity
    };
    const translate = getTranslate($element);
    config.from.transform = this._getCssTransform(translate, fromScale);
    config.to = {
      opacity: toOpacity
    };
    config.to.transform = this._getCssTransform(translate, toScale);
  },
  _getCssTransform: function(translate, scale) {
    return getTranslateCss(translate) + "scale(" + scale + ")";
  }
};
var animationConfigurators = {
  custom: CustomAnimationConfigurator,
  slide: SlideAnimationConfigurator,
  slideIn: SlideAnimationConfigurator,
  slideOut: SlideAnimationConfigurator,
  fade: FadeAnimationConfigurator,
  fadeIn: FadeAnimationConfigurator,
  fadeOut: FadeAnimationConfigurator,
  pop: PopAnimationConfigurator,
  css: CssAnimationConfigurator
};
var getAnimationConfigurator = function(config) {
  const result = animationConfigurators[config.type];
  if (!result) {
    throw errors_default.Error("E0011", config.type);
  }
  return result;
};
var defaultJSConfig = {
  type: "custom",
  from: {},
  to: {},
  duration: 400,
  start: noop,
  complete: noop,
  easing: "ease",
  delay: 0
};
var defaultCssConfig = {
  duration: 400,
  easing: "ease",
  delay: 0
};
function setupAnimationOnElement() {
  const $element = this.element;
  const config = this.config;
  setupPosition($element, config.from);
  setupPosition($element, config.to);
  this.configurator.setup($element, config);
  $element.data(ANIM_DATA_KEY, this);
  if (fx.off) {
    config.duration = 0;
    config.delay = 0;
  }
  this.strategy.initAnimation($element, config);
  if (config.start) {
    const element = getPublicElement($element);
    config.start.apply(this, [element, config]);
  }
}
var onElementAnimationComplete = function(animation) {
  const $element = animation.element;
  const config = animation.config;
  $element.removeData(ANIM_DATA_KEY);
  if (config.complete) {
    const element = getPublicElement($element);
    config.complete.apply(this, [element, config]);
  }
  animation.deferred.resolveWith(this, [$element, config]);
};
var startAnimationOnElement = function() {
  const animation = this;
  const $element = animation.element;
  const config = animation.config;
  animation.isStarted = true;
  return animation.strategy.animate($element, config).done(function() {
    onElementAnimationComplete(animation);
  }).fail(function() {
    animation.deferred.rejectWith(this, [$element, config]);
  });
};
var stopAnimationOnElement = function(jumpToEnd) {
  const animation = this;
  const $element = animation.element;
  const config = animation.config;
  clearTimeout(animation.startTimeout);
  if (!animation.isStarted) {
    animation.start();
  }
  animation.strategy.stop($element, config, jumpToEnd);
};
var scopedRemoveEvent = addNamespace(removeEvent, "dxFXStartAnimation");
var subscribeToRemoveEvent = function(animation) {
  events_engine_default.off(animation.element, scopedRemoveEvent);
  events_engine_default.on(animation.element, scopedRemoveEvent, function() {
    fx.stop(animation.element);
  });
  animation.deferred.always(function() {
    events_engine_default.off(animation.element, scopedRemoveEvent);
  });
};
var createAnimation = function(element, initialConfig) {
  const defaultConfig = "css" === initialConfig.type ? defaultCssConfig : defaultJSConfig;
  const config = extend(true, {}, defaultConfig, initialConfig);
  const configurator = getAnimationConfigurator(config);
  const strategy = getAnimationStrategy(config);
  const animation = {
    element: renderer_default(element),
    config,
    configurator,
    strategy,
    isSynchronous: strategy.isSynchronous,
    setup: setupAnimationOnElement,
    start: startAnimationOnElement,
    stop: stopAnimationOnElement,
    deferred: new Deferred()
  };
  if (isFunction(configurator.validateConfig)) {
    configurator.validateConfig(config);
  }
  subscribeToRemoveEvent(animation);
  return animation;
};
var animate = function(element, config) {
  const $element = renderer_default(element);
  if (!$element.length) {
    return new Deferred().resolve().promise();
  }
  const animation = createAnimation($element, config);
  pushInAnimationQueue($element, animation);
  return animation.deferred.promise();
};
function pushInAnimationQueue($element, animation) {
  const queueData = getAnimQueueData($element);
  writeAnimQueueData($element, queueData);
  queueData.push(animation);
  if (!isAnimating($element)) {
    shiftFromAnimationQueue($element, queueData);
  }
}
function getAnimQueueData($element) {
  return $element.data(ANIM_QUEUE_KEY) || [];
}
function writeAnimQueueData($element, queueData) {
  $element.data(ANIM_QUEUE_KEY, queueData);
}
var destroyAnimQueueData = function($element) {
  $element.removeData(ANIM_QUEUE_KEY);
};
function isAnimating($element) {
  return !!$element.data(ANIM_DATA_KEY);
}
function shiftFromAnimationQueue($element, queueData) {
  queueData = getAnimQueueData($element);
  if (!queueData.length) {
    return;
  }
  const animation = queueData.shift();
  if (0 === queueData.length) {
    destroyAnimQueueData($element);
  }
  executeAnimation(animation).done(function() {
    if (!isAnimating($element)) {
      shiftFromAnimationQueue($element);
    }
  });
}
function executeAnimation(animation) {
  animation.setup();
  if (fx.off || animation.isSynchronous) {
    animation.start();
  } else {
    animation.startTimeout = setTimeout(function() {
      animation.start();
    });
  }
  return animation.deferred.promise();
}
function setupPosition($element, config) {
  if (!config || !config.position) {
    return;
  }
  const win = renderer_default(window2);
  let left = 0;
  let top = 0;
  const position2 = position_default.calculate($element, config.position);
  const offset2 = $element.offset();
  const currentPosition = $element.position();
  if (currentPosition.top > offset2.top) {
    top = win.scrollTop();
  }
  if (currentPosition.left > offset2.left) {
    left = win.scrollLeft();
  }
  extend(config, {
    left: position2.h.location - offset2.left + currentPosition.left - left,
    top: position2.v.location - offset2.top + currentPosition.top - top
  });
  delete config.position;
}
function setProps($element, props) {
  each(props, function(key, value2) {
    try {
      $element.css(key, isFunction(value2) ? value2() : value2);
    } catch (e) {
    }
  });
}
var stop = function(element, jumpToEnd) {
  const $element = renderer_default(element);
  const queueData = getAnimQueueData($element);
  each(queueData, function(_, animation2) {
    animation2.config.delay = 0;
    animation2.config.duration = 0;
    animation2.isSynchronous = true;
  });
  if (!isAnimating($element)) {
    shiftFromAnimationQueue($element, queueData);
  }
  const animation = $element.data(ANIM_DATA_KEY);
  if (animation) {
    animation.stop(jumpToEnd);
  }
  $element.removeData(ANIM_DATA_KEY);
  destroyAnimQueueData($element);
};
var fx = {
  off: false,
  animationTypes: animationConfigurators,
  animate,
  createAnimation,
  isAnimating,
  stop,
  _simulatedTransitionEndDelay: 100
};
var fx_default = fx;

// node_modules/devextreme/esm/__internal/ui/overlay/m_overlay.js
init_dom_adapter();
init_errors();
init_renderer();
init_common();
init_deferred();
init_extend();
init_iterator();
init_ready_callbacks();
init_size();
init_type();
init_window();
init_events_engine();

// node_modules/devextreme/esm/events/drag.js
init_renderer();
init_element_data();
init_iterator();
var DRAG_START_EVENT = "dxdragstart";
var DRAG_EVENT = "dxdrag";
var DRAG_END_EVENT = "dxdragend";
var DRAG_ENTER_EVENT = "dxdragenter";
var DRAG_LEAVE_EVENT = "dxdragleave";
var DROP_EVENT = "dxdrop";
var knownDropTargets = [];
var knownDropTargetSelectors = [];
var knownDropTargetConfigs = [];
var dropTargetRegistration = {
  setup: function(element, data2) {
    const knownDropTarget = knownDropTargets.includes(element);
    if (!knownDropTarget) {
      knownDropTargets.push(element);
      knownDropTargetSelectors.push([]);
      knownDropTargetConfigs.push(data2 || {});
    }
  },
  add: function(element, handleObj) {
    const index = knownDropTargets.indexOf(element);
    this.updateEventsCounter(element, handleObj.type, 1);
    const selector = handleObj.selector;
    if (!knownDropTargetSelectors[index].includes(selector)) {
      knownDropTargetSelectors[index].push(selector);
    }
  },
  updateEventsCounter: function(element, event, value2) {
    if ([DRAG_ENTER_EVENT, DRAG_LEAVE_EVENT, DROP_EVENT].indexOf(event) > -1) {
      const eventsCount = data(element, "dxDragEventsCount") || 0;
      data(element, "dxDragEventsCount", Math.max(0, eventsCount + value2));
    }
  },
  remove: function(element, handleObj) {
    this.updateEventsCounter(element, handleObj.type, -1);
  },
  teardown: function(element) {
    const handlersCount = data(element, "dxDragEventsCount");
    if (!handlersCount) {
      const index = knownDropTargets.indexOf(element);
      knownDropTargets.splice(index, 1);
      knownDropTargetSelectors.splice(index, 1);
      knownDropTargetConfigs.splice(index, 1);
      removeData(element, "dxDragEventsCount");
    }
  }
};
event_registrator_default(DRAG_ENTER_EVENT, dropTargetRegistration);
event_registrator_default(DRAG_LEAVE_EVENT, dropTargetRegistration);
event_registrator_default(DROP_EVENT, dropTargetRegistration);
var getItemDelegatedTargets = function($element) {
  const dropTargetIndex = knownDropTargets.indexOf($element.get(0));
  const dropTargetSelectors = knownDropTargetSelectors[dropTargetIndex].filter((selector) => selector);
  let $delegatedTargets = $element.find(dropTargetSelectors.join(", "));
  if (knownDropTargetSelectors[dropTargetIndex].includes(void 0)) {
    $delegatedTargets = $delegatedTargets.add($element);
  }
  return $delegatedTargets;
};
var getItemConfig = function($element) {
  const dropTargetIndex = knownDropTargets.indexOf($element.get(0));
  return knownDropTargetConfigs[dropTargetIndex];
};
var getItemPosition = function(dropTargetConfig, $element) {
  if (dropTargetConfig.itemPositionFunc) {
    return dropTargetConfig.itemPositionFunc($element);
  } else {
    return $element.offset();
  }
};
var getItemSize = function(dropTargetConfig, $element) {
  if (dropTargetConfig.itemSizeFunc) {
    return dropTargetConfig.itemSizeFunc($element);
  }
  return {
    width: $element.get(0).getBoundingClientRect().width,
    height: $element.get(0).getBoundingClientRect().height
  };
};
var DragEmitter = emitter_gesture_default.inherit({
  ctor: function(element) {
    this.callBase(element);
    this.direction = "both";
  },
  _init: function(e) {
    this._initEvent = e;
  },
  _start: function(e) {
    e = this._fireEvent("dxdragstart", this._initEvent);
    this._maxLeftOffset = e.maxLeftOffset;
    this._maxRightOffset = e.maxRightOffset;
    this._maxTopOffset = e.maxTopOffset;
    this._maxBottomOffset = e.maxBottomOffset;
    if (e.targetElements || null === e.targetElements) {
      const dropTargets = wrapToArray(e.targetElements || []);
      this._dropTargets = map(dropTargets, function(element) {
        return renderer_default(element).get(0);
      });
    } else {
      this._dropTargets = knownDropTargets;
    }
  },
  _move: function(e) {
    const eventData2 = eventData(e);
    const dragOffset = this._calculateOffset(eventData2);
    e = this._fireEvent("dxdrag", e, {
      offset: dragOffset
    });
    this._processDropTargets(e);
    if (!e._cancelPreventDefault) {
      e.preventDefault();
    }
  },
  _calculateOffset: function(eventData2) {
    return {
      x: this._calculateXOffset(eventData2),
      y: this._calculateYOffset(eventData2)
    };
  },
  _calculateXOffset: function(eventData2) {
    if ("vertical" !== this.direction) {
      const offset2 = eventData2.x - this._startEventData.x;
      return this._fitOffset(offset2, this._maxLeftOffset, this._maxRightOffset);
    }
    return 0;
  },
  _calculateYOffset: function(eventData2) {
    if ("horizontal" !== this.direction) {
      const offset2 = eventData2.y - this._startEventData.y;
      return this._fitOffset(offset2, this._maxTopOffset, this._maxBottomOffset);
    }
    return 0;
  },
  _fitOffset: function(offset2, minOffset, maxOffset) {
    if (null != minOffset) {
      offset2 = Math.max(offset2, -minOffset);
    }
    if (null != maxOffset) {
      offset2 = Math.min(offset2, maxOffset);
    }
    return offset2;
  },
  _processDropTargets: function(e) {
    const target = this._findDropTarget(e);
    const sameTarget = target === this._currentDropTarget;
    if (!sameTarget) {
      this._fireDropTargetEvent(e, DRAG_LEAVE_EVENT);
      this._currentDropTarget = target;
      this._fireDropTargetEvent(e, DRAG_ENTER_EVENT);
    }
  },
  _fireDropTargetEvent: function(event, eventName) {
    if (!this._currentDropTarget) {
      return;
    }
    const eventData2 = {
      type: eventName,
      originalEvent: event,
      draggingElement: this._$element.get(0),
      target: this._currentDropTarget
    };
    fireEvent(eventData2);
  },
  _findDropTarget: function(e) {
    const that = this;
    let result;
    each(knownDropTargets, function(_, target) {
      if (!that._checkDropTargetActive(target)) {
        return;
      }
      const $target = renderer_default(target);
      each(getItemDelegatedTargets($target), function(_2, delegatedTarget) {
        const $delegatedTarget = renderer_default(delegatedTarget);
        if (that._checkDropTarget(getItemConfig($target), $delegatedTarget, renderer_default(result), e)) {
          result = delegatedTarget;
        }
      });
    });
    return result;
  },
  _checkDropTargetActive: function(target) {
    let active = false;
    each(this._dropTargets, function(_, activeTarget) {
      active = active || activeTarget === target || contains(activeTarget, target);
      return !active;
    });
    return active;
  },
  _checkDropTarget: function(config, $target, $prevTarget, e) {
    const isDraggingElement = $target.get(0) === renderer_default(e.target).get(0);
    if (isDraggingElement) {
      return false;
    }
    const targetPosition = getItemPosition(config, $target);
    if (e.pageX < targetPosition.left) {
      return false;
    }
    if (e.pageY < targetPosition.top) {
      return false;
    }
    const targetSize = getItemSize(config, $target);
    if (e.pageX > targetPosition.left + targetSize.width) {
      return false;
    }
    if (e.pageY > targetPosition.top + targetSize.height) {
      return false;
    }
    if ($prevTarget.length && $prevTarget.closest($target).length) {
      return false;
    }
    if (config.checkDropTarget && !config.checkDropTarget($target, e)) {
      return false;
    }
    return $target;
  },
  _end: function(e) {
    const eventData2 = eventData(e);
    this._fireEvent("dxdragend", e, {
      offset: this._calculateOffset(eventData2)
    });
    this._fireDropTargetEvent(e, DROP_EVENT);
    delete this._currentDropTarget;
  }
});
emitter_registrator_default({
  emitter: DragEmitter,
  events: ["dxdragstart", "dxdrag", "dxdragend"]
});

// node_modules/devextreme/esm/mobile/hide_callback.js
var hideCallback = /* @__PURE__ */ function() {
  let callbacks = [];
  return {
    add: function(callback) {
      if (!callbacks.includes(callback)) {
        callbacks.push(callback);
      }
    },
    remove: function(callback) {
      const indexOfCallback = callbacks.indexOf(callback);
      if (-1 !== indexOfCallback) {
        callbacks.splice(indexOfCallback, 1);
      }
    },
    fire: function() {
      const callback = callbacks.pop();
      const result = !!callback;
      if (result) {
        callback();
      }
      return result;
    },
    hasCallback: function() {
      return callbacks.length > 0;
    }
  };
}();

// node_modules/devextreme/esm/__internal/ui/overlay/m_overlay_position_controller.js
init_renderer();
init_extend();
init_type();
init_window();

// node_modules/devextreme/esm/ui/widget/swatch_container.js
init_renderer();
var getSwatchContainer = (element) => {
  const $element = renderer_default(element);
  const swatchContainer = $element.closest('[class^="dx-swatch-"], [class*=" dx-swatch-"]');
  const viewport = value();
  if (!swatchContainer.length) {
    return viewport;
  }
  const swatchClassRegex = new RegExp("(\\s|^)(dx-swatch-.*?)(\\s|$)");
  const swatchClass = swatchContainer[0].className.match(swatchClassRegex)[2];
  let viewportSwatchContainer = viewport.children("." + swatchClass);
  if (!viewportSwatchContainer.length) {
    viewportSwatchContainer = renderer_default("<div>").addClass(swatchClass).appendTo(viewport);
  }
  return viewportSwatchContainer;
};
var swatch_container_default = {
  getSwatchContainer
};

// node_modules/devextreme/esm/__internal/ui/overlay/m_overlay_position_controller.js
var window3 = getWindow();
var OVERLAY_POSITION_ALIASES = {
  top: {
    my: "top center",
    at: "top center"
  },
  bottom: {
    my: "bottom center",
    at: "bottom center"
  },
  right: {
    my: "right center",
    at: "right center"
  },
  left: {
    my: "left center",
    at: "left center"
  },
  center: {
    my: "center",
    at: "center"
  },
  "right bottom": {
    my: "right bottom",
    at: "right bottom"
  },
  "right top": {
    my: "right top",
    at: "right top"
  },
  "left bottom": {
    my: "left bottom",
    at: "left bottom"
  },
  "left top": {
    my: "left top",
    at: "left top"
  }
};
var OVERLAY_DEFAULT_BOUNDARY_OFFSET = {
  h: 0,
  v: 0
};
var OverlayPositionController = class {
  constructor(_ref) {
    let {
      position: position2,
      container,
      visualContainer,
      $root,
      $content,
      $wrapper,
      onPositioned,
      onVisualPositionChanged,
      restorePosition,
      _fixWrapperPosition,
      _skipContentPositioning
    } = _ref;
    this._props = {
      position: position2,
      container,
      visualContainer,
      restorePosition,
      onPositioned,
      onVisualPositionChanged,
      _fixWrapperPosition,
      _skipContentPositioning
    };
    this._$root = $root;
    this._$content = $content;
    this._$wrapper = $wrapper;
    this._$markupContainer = void 0;
    this._$visualContainer = void 0;
    this._shouldRenderContentInitialPosition = true;
    this._visualPosition = void 0;
    this._initialPosition = void 0;
    this._previousVisualPosition = void 0;
    this.updateContainer(container);
    this.updatePosition(position2);
    this.updateVisualContainer(visualContainer);
  }
  get $container() {
    this.updateContainer();
    return this._$markupContainer;
  }
  get $visualContainer() {
    return this._$visualContainer;
  }
  get position() {
    return this._position;
  }
  set fixWrapperPosition(fixWrapperPosition) {
    this._props._fixWrapperPosition = fixWrapperPosition;
    this.styleWrapperPosition();
  }
  set restorePosition(restorePosition) {
    this._props.restorePosition = restorePosition;
  }
  restorePositionOnNextRender(value2) {
    this._shouldRenderContentInitialPosition = value2 || !this._visualPosition;
  }
  openingHandled() {
    const shouldRestorePosition = this._props.restorePosition;
    this.restorePositionOnNextRender(shouldRestorePosition);
  }
  updatePosition(positionProp) {
    this._props.position = positionProp;
    this._position = this._normalizePosition(positionProp);
    this.updateVisualContainer();
  }
  updateContainer() {
    let containerProp = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._props.container;
    this._props.container = containerProp;
    this._$markupContainer = containerProp ? renderer_default(containerProp) : swatch_container_default.getSwatchContainer(this._$root);
    this.updateVisualContainer(this._props.visualContainer);
  }
  updateVisualContainer() {
    let visualContainer = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._props.visualContainer;
    this._props.visualContainer = visualContainer;
    this._$visualContainer = this._getVisualContainer();
  }
  detectVisualPositionChange(event) {
    this._updateVisualPositionValue();
    this._raisePositionedEvents(event);
  }
  positionContent() {
    if (this._shouldRenderContentInitialPosition) {
      this._renderContentInitialPosition();
    } else {
      move(this._$content, this._visualPosition);
      this.detectVisualPositionChange();
    }
  }
  positionWrapper() {
    if (this._$visualContainer) {
      position_default.setup(this._$wrapper, {
        my: "top left",
        at: "top left",
        of: this._$visualContainer
      });
    }
  }
  styleWrapperPosition() {
    const useFixed = isWindow(this.$visualContainer.get(0)) || this._props._fixWrapperPosition;
    const positionStyle = useFixed ? "fixed" : "absolute";
    this._$wrapper.css("position", positionStyle);
  }
  _updateVisualPositionValue() {
    this._previousVisualPosition = this._visualPosition;
    this._visualPosition = locate(this._$content);
  }
  _renderContentInitialPosition() {
    this._renderBoundaryOffset();
    resetPosition(this._$content);
    const wrapperOverflow = this._$wrapper.css("overflow");
    this._$wrapper.css("overflow", "hidden");
    if (!this._props._skipContentPositioning) {
      const resultPosition = position_default.setup(this._$content, this._position);
      this._initialPosition = resultPosition;
    }
    this._$wrapper.css("overflow", wrapperOverflow);
    this.detectVisualPositionChange();
  }
  _raisePositionedEvents(event) {
    const previousPosition = this._previousVisualPosition;
    const newPosition = this._visualPosition;
    const isVisualPositionChanged = (null === previousPosition || void 0 === previousPosition ? void 0 : previousPosition.top) !== newPosition.top || (null === previousPosition || void 0 === previousPosition ? void 0 : previousPosition.left) !== newPosition.left;
    if (isVisualPositionChanged) {
      this._props.onVisualPositionChanged({
        previousPosition,
        position: newPosition,
        event
      });
    }
    this._props.onPositioned({
      position: this._initialPosition
    });
  }
  _renderBoundaryOffset() {
    const boundaryOffset = this._position ?? {
      boundaryOffset: OVERLAY_DEFAULT_BOUNDARY_OFFSET
    };
    this._$content.css("margin", `${boundaryOffset.v}px ${boundaryOffset.h}px`);
  }
  _getVisualContainer() {
    var _this$_props$position, _this$_props$position2;
    const containerProp = this._props.container;
    const visualContainerProp = this._props.visualContainer;
    const positionOf = isEvent(null === (_this$_props$position = this._props.position) || void 0 === _this$_props$position ? void 0 : _this$_props$position.of) ? this._props.position.of.target : null === (_this$_props$position2 = this._props.position) || void 0 === _this$_props$position2 ? void 0 : _this$_props$position2.of;
    if (visualContainerProp) {
      return renderer_default(visualContainerProp);
    }
    if (containerProp) {
      return renderer_default(containerProp);
    }
    if (positionOf) {
      return renderer_default(positionOf);
    }
    return renderer_default(window3);
  }
  _normalizePosition(positionProp) {
    const defaultPositionConfig = {
      boundaryOffset: OVERLAY_DEFAULT_BOUNDARY_OFFSET
    };
    if (isDefined(positionProp)) {
      return extend(true, {}, defaultPositionConfig, this._positionToObject(positionProp));
    }
    return defaultPositionConfig;
  }
  _positionToObject(position2) {
    if (isString(position2)) {
      return extend({}, OVERLAY_POSITION_ALIASES[position2]);
    }
    return position2;
  }
};

// node_modules/devextreme/esm/__internal/ui/overlay/m_z_index.js
init_common();
var baseZIndex = 1500;
var zIndexStack = [];
var base = (ZIndex) => {
  baseZIndex = ensureDefined(ZIndex, baseZIndex);
  return baseZIndex;
};
var create = function() {
  let baseIndex = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : baseZIndex;
  const {
    length
  } = zIndexStack;
  const index = (length ? zIndexStack[length - 1] : baseIndex) + 1;
  zIndexStack.push(index);
  return index;
};
var remove = (zIndex) => {
  const position2 = zIndexStack.indexOf(zIndex);
  if (position2 >= 0) {
    zIndexStack.splice(position2, 1);
  }
};
var isLastZIndexInStack = (zIndex) => zIndexStack.length && zIndexStack[zIndexStack.length - 1] === zIndex;

// node_modules/devextreme/esm/__internal/ui/overlay/m_overlay.js
var ready = ready_callbacks_default.add;
var window4 = getWindow();
var viewPortChanged = changeCallback;
var OVERLAY_STACK = [];
ready(() => {
  events_engine_default.subscribeGlobal(dom_adapter_default.getDocument(), pointer_default.down, (e) => {
    for (let i = OVERLAY_STACK.length - 1; i >= 0; i--) {
      if (!OVERLAY_STACK[i]._proxiedDocumentDownHandler(e)) {
        return;
      }
    }
  });
});
var Overlay = ui_widget_default.inherit({
  _supportedKeys() {
    return extend(this.callBase(), {
      escape() {
        this.hide();
      }
    });
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      activeStateEnabled: false,
      visible: false,
      deferRendering: true,
      shading: true,
      shadingColor: "",
      wrapperAttr: {},
      position: extend({}, OVERLAY_POSITION_ALIASES.center),
      width: "80vw",
      minWidth: null,
      maxWidth: null,
      height: "80vh",
      minHeight: null,
      maxHeight: null,
      animation: {
        show: {
          type: "pop",
          duration: 300,
          from: {
            scale: 0.55
          }
        },
        hide: {
          type: "pop",
          duration: 300,
          from: {
            opacity: 1,
            scale: 1
          },
          to: {
            opacity: 0,
            scale: 0.55
          }
        }
      },
      closeOnOutsideClick: false,
      hideOnOutsideClick: false,
      _ignorePreventScrollEventsDeprecation: false,
      onShowing: null,
      onShown: null,
      onHiding: null,
      onHidden: null,
      contentTemplate: "content",
      innerOverlay: false,
      restorePosition: true,
      container: void 0,
      visualContainer: void 0,
      hideTopOverlayHandler: () => {
        this.hide();
      },
      hideOnParentScroll: false,
      preventScrollEvents: true,
      onPositioned: null,
      propagateOutsideClick: false,
      ignoreChildEvents: true,
      _checkParentVisibility: true,
      _hideOnParentScrollTarget: void 0,
      _fixWrapperPosition: false
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: () => !hasWindow(),
      options: {
        width: null,
        height: null,
        animation: null,
        _checkParentVisibility: false
      }
    }]);
  },
  _setOptionsByReference() {
    this.callBase();
    extend(this._optionsByReference, {
      animation: true
    });
  },
  $wrapper() {
    return this._$wrapper;
  },
  _eventBindingTarget() {
    return this._$content;
  },
  _setDeprecatedOptions() {
    this.callBase();
    extend(this._deprecatedOptions, {
      closeOnOutsideClick: {
        since: "22.1",
        alias: "hideOnOutsideClick"
      }
    });
  },
  ctor(element, options) {
    this.callBase(element, options);
    if (options) {
      if ("preventScrollEvents" in options && !options._ignorePreventScrollEventsDeprecation) {
        this._logDeprecatedPreventScrollEventsInfo();
      }
    }
  },
  _logDeprecatedPreventScrollEventsInfo() {
    this._logDeprecatedOptionWarning("preventScrollEvents", {
      since: "23.1",
      message: "If you enable this option, end-users may experience scrolling issues."
    });
  },
  _init() {
    this.callBase();
    this._initActions();
    this._initHideOnOutsideClickHandler();
    this._initTabTerminatorHandler();
    this._customWrapperClass = null;
    this._$wrapper = renderer_default("<div>").addClass("dx-overlay-wrapper");
    this._$content = renderer_default("<div>").addClass("dx-overlay-content");
    this._initInnerOverlayClass();
    const $element = this.$element();
    $element.addClass("dx-overlay");
    this._$wrapper.attr("data-bind", "dxControlsDescendantBindings: true");
    this._toggleViewPortSubscription(true);
    this._initHideTopOverlayHandler(this.option("hideTopOverlayHandler"));
    this._parentsScrollSubscriptionInfo = {
      handler: (e) => {
        this._hideOnParentsScrollHandler(e);
      }
    };
    this.warnPositionAsFunction();
  },
  warnPositionAsFunction() {
    if (isFunction(this.option("position"))) {
      errors_default.log("W0018");
    }
  },
  _initInnerOverlayClass() {
    this._$content.toggleClass("dx-inner-overlay", this.option("innerOverlay"));
  },
  _initHideTopOverlayHandler(handler) {
    this._hideTopOverlayHandler = handler;
  },
  _getActionsList: () => ["onShowing", "onShown", "onHiding", "onHidden", "onPositioned", "onVisualPositionChanged"],
  _initActions() {
    this._actions = {};
    const actions = this._getActionsList();
    each(actions, (_, action) => {
      this._actions[action] = this._createActionByOption(action, {
        excludeValidators: ["disabled", "readOnly"]
      }) || noop;
    });
  },
  _initHideOnOutsideClickHandler() {
    var _this = this;
    this._proxiedDocumentDownHandler = function() {
      return _this._documentDownHandler(...arguments);
    };
  },
  _initMarkup() {
    this.callBase();
    this._renderWrapperAttributes();
    this._initPositionController();
  },
  _documentDownHandler(e) {
    if (this._showAnimationProcessing) {
      this._stopAnimation();
    }
    const isAttachedTarget = renderer_default(window4.document).is(e.target) || contains(window4.document, e.target);
    const isInnerOverlay = renderer_default(e.target).closest(".dx-inner-overlay").length;
    const outsideClick = isAttachedTarget && !isInnerOverlay && !(this._$content.is(e.target) || contains(this._$content.get(0), e.target));
    if (outsideClick && this._shouldHideOnOutsideClick(e)) {
      this._outsideClickHandler(e);
    }
    return this.option("propagateOutsideClick");
  },
  _shouldHideOnOutsideClick(e) {
    const {
      hideOnOutsideClick
    } = this.option();
    if (isFunction(hideOnOutsideClick)) {
      return hideOnOutsideClick(e);
    }
    return hideOnOutsideClick;
  },
  _outsideClickHandler(e) {
    if (this.option("shading")) {
      e.preventDefault();
    }
    this.hide();
  },
  _getAnonymousTemplateName: () => "content",
  _initTemplates() {
    this._templateManager.addDefaultTemplates({
      content: new EmptyTemplate()
    });
    this.callBase();
  },
  _isTopOverlay() {
    const overlayStack = this._overlayStack();
    for (let i = overlayStack.length - 1; i >= 0; i--) {
      const tabbableElements = overlayStack[i]._findTabbableBounds();
      if (tabbableElements.first || tabbableElements.last) {
        return overlayStack[i] === this;
      }
    }
    return false;
  },
  _overlayStack: () => OVERLAY_STACK,
  _zIndexInitValue: () => Overlay.baseZIndex(),
  _toggleViewPortSubscription(toggle) {
    var _this2 = this;
    viewPortChanged.remove(this._viewPortChangeHandle);
    if (toggle) {
      this._viewPortChangeHandle = function() {
        _this2._viewPortChangeHandler(...arguments);
      };
      viewPortChanged.add(this._viewPortChangeHandle);
    }
  },
  _viewPortChangeHandler() {
    this._positionController.updateContainer(this.option("container"));
    this._refresh();
  },
  _renderWrapperAttributes() {
    const {
      wrapperAttr
    } = this.option();
    const attributes = extend({}, wrapperAttr);
    const classNames = attributes.class;
    delete attributes.class;
    this.$wrapper().attr(attributes).removeClass(this._customWrapperClass).addClass(classNames);
    this._customWrapperClass = classNames;
  },
  _renderVisibilityAnimate(visible) {
    this._stopAnimation();
    return visible ? this._show() : this._hide();
  },
  _getAnimationConfig() {
    return this._getOptionValue("animation", this);
  },
  _toggleBodyScroll: noop,
  _animateShowing() {
    var _this3 = this;
    const animation = this._getAnimationConfig() ?? {};
    const showAnimation = this._normalizeAnimation(animation.show, "to");
    const startShowAnimation = (null === showAnimation || void 0 === showAnimation ? void 0 : showAnimation.start) ?? noop;
    const completeShowAnimation = (null === showAnimation || void 0 === showAnimation ? void 0 : showAnimation.complete) ?? noop;
    this._animate(showAnimation, function() {
      if (_this3._isAnimationPaused) {
        return;
      }
      if (_this3.option("focusStateEnabled")) {
        events_engine_default.trigger(_this3._focusTarget(), "focus");
      }
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      completeShowAnimation.call(_this3, ...args);
      _this3._showAnimationProcessing = false;
      _this3._isHidden = false;
      _this3._actions.onShown();
      _this3._toggleSafariScrolling();
      _this3._showingDeferred.resolve();
    }, function() {
      if (_this3._isAnimationPaused) {
        return;
      }
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      startShowAnimation.call(_this3, ...args);
      _this3._showAnimationProcessing = true;
    });
  },
  _processShowingHidingCancel(cancelArg, applyFunction, cancelFunction) {
    if (isPromise(cancelArg)) {
      cancelArg.then((shouldCancel) => {
        if (shouldCancel) {
          cancelFunction();
        } else {
          applyFunction();
        }
      }).catch(() => applyFunction());
    } else {
      cancelArg ? cancelFunction() : applyFunction();
    }
  },
  _show() {
    this._showingDeferred = Deferred();
    this._parentHidden = this._isParentHidden();
    this._showingDeferred.done(() => {
      delete this._parentHidden;
    });
    if (this._parentHidden) {
      this._isHidden = true;
      return this._showingDeferred.resolve();
    }
    if (this._currentVisible) {
      return Deferred().resolve().promise();
    }
    this._currentVisible = true;
    if (this._isHidingActionCanceled) {
      delete this._isHidingActionCanceled;
      this._showingDeferred.reject();
    } else {
      const show = () => {
        this._stopAnimation();
        this._toggleBodyScroll(this.option("enableBodyScroll"));
        this._toggleVisibility(true);
        this._$content.css("visibility", "hidden");
        this._$content.toggleClass("dx-state-invisible", false);
        this._updateZIndexStackPosition(true);
        this._positionController.openingHandled();
        this._renderContent();
        const showingArgs = {
          cancel: false
        };
        this._actions.onShowing(showingArgs);
        this._processShowingHidingCancel(showingArgs.cancel, () => {
          this._$content.css("visibility", "");
          this._renderVisibility(true);
          this._animateShowing();
        }, () => {
          this._toggleVisibility(false);
          this._$content.css("visibility", "");
          this._$content.toggleClass("dx-state-invisible", true);
          this._isShowingActionCanceled = true;
          this._moveFromContainer();
          this._toggleBodyScroll(true);
          this.option("visible", false);
          this._showingDeferred.resolve();
        });
      };
      if (this.option("templatesRenderAsynchronously")) {
        this._stopShowTimer();
        this._asyncShowTimeout = setTimeout(show);
      } else {
        show();
      }
    }
    return this._showingDeferred.promise();
  },
  _normalizeAnimation(showHideConfig, direction) {
    if (showHideConfig) {
      showHideConfig = extend({
        type: "slide",
        skipElementInitialStyles: true
      }, showHideConfig);
      if (isObject(showHideConfig[direction])) {
        extend(showHideConfig[direction], {
          position: this._positionController.position
        });
      }
    }
    return showHideConfig;
  },
  _animateHiding() {
    var _this4 = this;
    const animation = this._getAnimationConfig() ?? {};
    const hideAnimation = this._normalizeAnimation(animation.hide, "from");
    const startHideAnimation = (null === hideAnimation || void 0 === hideAnimation ? void 0 : hideAnimation.start) ?? noop;
    const completeHideAnimation = (null === hideAnimation || void 0 === hideAnimation ? void 0 : hideAnimation.complete) ?? noop;
    this._animate(hideAnimation, function() {
      var _this4$_actions;
      _this4._$content.css("pointerEvents", "");
      _this4._renderVisibility(false);
      for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        args[_key3] = arguments[_key3];
      }
      completeHideAnimation.call(_this4, ...args);
      _this4._hideAnimationProcessing = false;
      null === (_this4$_actions = _this4._actions) || void 0 === _this4$_actions || _this4$_actions.onHidden();
      _this4._hidingDeferred.resolve();
    }, function() {
      _this4._$content.css("pointerEvents", "none");
      for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        args[_key4] = arguments[_key4];
      }
      startHideAnimation.call(_this4, ...args);
      _this4._hideAnimationProcessing = true;
    });
  },
  _hide() {
    if (!this._currentVisible) {
      return Deferred().resolve().promise();
    }
    this._currentVisible = false;
    this._hidingDeferred = Deferred();
    const hidingArgs = {
      cancel: false
    };
    if (this._isShowingActionCanceled) {
      delete this._isShowingActionCanceled;
      this._hidingDeferred.reject();
    } else {
      this._actions.onHiding(hidingArgs);
      this._toggleSafariScrolling();
      this._toggleBodyScroll(true);
      const cancelHide = () => {
        this._isHidingActionCanceled = true;
        this._toggleBodyScroll(this.option("enableBodyScroll"));
        this.option("visible", true);
        this._hidingDeferred.resolve();
      };
      const applyHide = () => {
        this._forceFocusLost();
        this._toggleShading(false);
        this._toggleSubscriptions(false);
        this._stopShowTimer();
        this._animateHiding();
      };
      this._processShowingHidingCancel(hidingArgs.cancel, applyHide, cancelHide);
    }
    return this._hidingDeferred.promise();
  },
  _forceFocusLost() {
    const activeElement = dom_adapter_default.getActiveElement();
    const shouldResetActiveElement = !!this._$content.find(activeElement).length;
    if (shouldResetActiveElement) {
      resetActiveElement();
    }
  },
  _animate(animation, completeCallback, startCallback) {
    if (animation) {
      startCallback = startCallback || animation.start || noop;
      fx_default.animate(this._$content, extend({}, animation, {
        start: startCallback,
        complete: completeCallback
      }));
    } else {
      completeCallback();
    }
  },
  _stopAnimation() {
    fx_default.stop(this._$content, true);
  },
  _renderVisibility(visible) {
    if (visible && this._isParentHidden()) {
      return;
    }
    this._currentVisible = visible;
    this._stopAnimation();
    if (!visible) {
      triggerHidingEvent(this._$content);
    }
    if (visible) {
      this._checkContainerExists();
      this._moveToContainer();
      this._renderGeometry();
      triggerShownEvent(this._$content);
      triggerResizeEvent(this._$content);
    } else {
      this._toggleVisibility(visible);
      this._$content.toggleClass("dx-state-invisible", !visible);
      this._updateZIndexStackPosition(visible);
      this._moveFromContainer();
    }
    this._toggleShading(visible);
    this._toggleSubscriptions(visible);
  },
  _updateZIndexStackPosition(pushToStack) {
    const overlayStack = this._overlayStack();
    const index = overlayStack.indexOf(this);
    if (pushToStack) {
      if (-1 === index) {
        this._zIndex = create(this._zIndexInitValue());
        overlayStack.push(this);
      }
      this._$wrapper.css("zIndex", this._zIndex);
      this._$content.css("zIndex", this._zIndex);
    } else if (-1 !== index) {
      overlayStack.splice(index, 1);
      remove(this._zIndex);
    }
  },
  _toggleShading(visible) {
    this._$wrapper.toggleClass("dx-overlay-shader", visible && this.option("shading"));
    this._$wrapper.css("backgroundColor", this.option("shading") ? this.option("shadingColor") : "");
    this._toggleTabTerminator(visible && this.option("shading"));
  },
  _initTabTerminatorHandler() {
    var _this5 = this;
    this._proxiedTabTerminatorHandler = function() {
      _this5._tabKeyHandler(...arguments);
    };
  },
  _toggleTabTerminator(enabled) {
    const eventName = addNamespace("keydown", this.NAME);
    if (enabled) {
      events_engine_default.on(dom_adapter_default.getDocument(), eventName, this._proxiedTabTerminatorHandler);
    } else {
      events_engine_default.off(dom_adapter_default.getDocument(), eventName, this._proxiedTabTerminatorHandler);
    }
  },
  _findTabbableBounds() {
    const $elements = this._$wrapper.find("*");
    const elementsCount = $elements.length - 1;
    const result = {
      first: null,
      last: null
    };
    for (let i = 0; i <= elementsCount; i++) {
      if (!result.first && $elements.eq(i).is(tabbable)) {
        result.first = $elements.eq(i);
      }
      if (!result.last && $elements.eq(elementsCount - i).is(tabbable)) {
        result.last = $elements.eq(elementsCount - i);
      }
      if (result.first && result.last) {
        break;
      }
    }
    return result;
  },
  _tabKeyHandler(e) {
    if ("tab" !== normalizeKeyName(e) || !this._isTopOverlay()) {
      return;
    }
    const tabbableElements = this._findTabbableBounds();
    const $firstTabbable = tabbableElements.first;
    const $lastTabbable = tabbableElements.last;
    const isTabOnLast = !e.shiftKey && e.target === $lastTabbable.get(0);
    const isShiftTabOnFirst = e.shiftKey && e.target === $firstTabbable.get(0);
    const isEmptyTabList = 0 === tabbableElements.length;
    const isOutsideTarget = !contains(this._$wrapper.get(0), e.target);
    if (isTabOnLast || isShiftTabOnFirst || isEmptyTabList || isOutsideTarget) {
      e.preventDefault();
      const $focusElement = e.shiftKey ? $lastTabbable : $firstTabbable;
      events_engine_default.trigger($focusElement, "focusin");
      events_engine_default.trigger($focusElement, "focus");
    }
  },
  _toggleSubscriptions(enabled) {
    if (hasWindow()) {
      this._toggleHideTopOverlayCallback(enabled);
      this._toggleHideOnParentsScrollSubscription(enabled);
    }
  },
  _toggleHideTopOverlayCallback(subscribe) {
    if (!this._hideTopOverlayHandler) {
      return;
    }
    if (subscribe) {
      hideCallback.add(this._hideTopOverlayHandler);
    } else {
      hideCallback.remove(this._hideTopOverlayHandler);
    }
  },
  _toggleHideOnParentsScrollSubscription(needSubscribe) {
    const scrollEvent = addNamespace("scroll", this.NAME);
    const {
      prevTargets,
      handler
    } = this._parentsScrollSubscriptionInfo ?? {};
    events_engine_default.off(prevTargets, scrollEvent, handler);
    const hideOnScroll = this.option("hideOnParentScroll");
    if (needSubscribe && hideOnScroll) {
      let $parents = this._getHideOnParentScrollTarget().parents();
      if ("desktop" === devices_default.real().deviceType) {
        $parents = $parents.add(window4);
      }
      events_engine_default.on($parents, scrollEvent, handler);
      this._parentsScrollSubscriptionInfo.prevTargets = $parents;
    }
  },
  _hideOnParentsScrollHandler(e) {
    let hideHandled = false;
    const hideOnScroll = this.option("hideOnParentScroll");
    if (isFunction(hideOnScroll)) {
      hideHandled = hideOnScroll(e);
    }
    if (!hideHandled && !this._showAnimationProcessing) {
      this.hide();
    }
  },
  _getHideOnParentScrollTarget() {
    const $hideOnParentScrollTarget = renderer_default(this.option("_hideOnParentScrollTarget"));
    if ($hideOnParentScrollTarget.length) {
      return $hideOnParentScrollTarget;
    }
    return this._$wrapper;
  },
  _render() {
    this.callBase();
    this._appendContentToElement();
    this._renderVisibilityAnimate(this.option("visible"));
  },
  _appendContentToElement() {
    if (!this._$content.parent().is(this.$element())) {
      this._$content.appendTo(this.$element());
    }
  },
  _renderContent() {
    const shouldDeferRendering = !this._currentVisible && this.option("deferRendering");
    const isParentHidden = this.option("visible") && this._isParentHidden();
    if (isParentHidden) {
      this._isHidden = true;
      return;
    }
    if (this._contentAlreadyRendered || shouldDeferRendering) {
      return;
    }
    this._contentAlreadyRendered = true;
    this._appendContentToElement();
    this.callBase();
  },
  _isParentHidden() {
    if (!this.option("_checkParentVisibility")) {
      return false;
    }
    if (void 0 !== this._parentHidden) {
      return this._parentHidden;
    }
    const $parent = this.$element().parent();
    if ($parent.is(":visible")) {
      return false;
    }
    let isHidden = false;
    $parent.add($parent.parents()).each((index, element) => {
      const $element = renderer_default(element);
      if ("none" === $element.css("display")) {
        isHidden = true;
        return false;
      }
    });
    return isHidden || !dom_adapter_default.getBody().contains($parent.get(0));
  },
  _renderContentImpl() {
    const whenContentRendered = Deferred();
    const contentTemplateOption = this.option("contentTemplate");
    const contentTemplate = this._getTemplate(contentTemplateOption);
    const transclude = this._templateManager.anonymousTemplateName === contentTemplateOption;
    contentTemplate && contentTemplate.render({
      container: getPublicElement(this.$content()),
      noModel: true,
      transclude,
      onRendered: () => {
        whenContentRendered.resolve();
        if (this.option("templatesRenderAsynchronously")) {
          this._dimensionChanged();
        }
      }
    });
    this._toggleWrapperScrollEventsSubscription(this.option("preventScrollEvents"));
    whenContentRendered.done(() => {
      if (this.option("visible")) {
        this._moveToContainer();
      }
    });
    return whenContentRendered.promise();
  },
  _getPositionControllerConfig() {
    const {
      container,
      visualContainer,
      _fixWrapperPosition,
      restorePosition,
      _skipContentPositioning
    } = this.option();
    return {
      container,
      visualContainer,
      $root: this.$element(),
      $content: this._$content,
      $wrapper: this._$wrapper,
      onPositioned: this._actions.onPositioned,
      onVisualPositionChanged: this._actions.onVisualPositionChanged,
      restorePosition,
      _fixWrapperPosition,
      _skipContentPositioning
    };
  },
  _initPositionController() {
    this._positionController = new OverlayPositionController(this._getPositionControllerConfig());
  },
  _toggleWrapperScrollEventsSubscription(enabled) {
    const eventName = addNamespace(DRAG_EVENT, this.NAME);
    events_engine_default.off(this._$wrapper, eventName);
    if (enabled) {
      events_engine_default.on(this._$wrapper, eventName, {
        validate: () => true,
        getDirection: () => "both",
        _toggleGestureCover(toggle) {
          if (!toggle) {
            this._toggleGestureCoverImpl(toggle);
          }
        },
        _clearSelection: noop,
        isNative: true
      }, (e) => {
        const {
          originalEvent
        } = e.originalEvent;
        const {
          type
        } = originalEvent || {};
        const isWheel = "wheel" === type;
        const isMouseMove = "mousemove" === type;
        const isScrollByWheel = isWheel && !isCommandKeyPressed(e);
        e._cancelPreventDefault = true;
        if (originalEvent && false !== e.cancelable && (!isMouseMove && !isWheel || isScrollByWheel)) {
          e.preventDefault();
        }
      });
    }
  },
  _moveFromContainer() {
    this._$content.appendTo(this.$element());
    this._$wrapper.detach();
  },
  _checkContainerExists() {
    const $wrapperContainer = this._positionController.$container;
    if (void 0 === $wrapperContainer) {
      return;
    }
    const containerExists = $wrapperContainer.length > 0;
    if (!containerExists) {
      ui_errors_default.log("W1021", this.NAME);
    }
  },
  _moveToContainer() {
    const $wrapperContainer = this._positionController.$container;
    this._$wrapper.appendTo($wrapperContainer);
    this._$content.appendTo(this._$wrapper);
  },
  _renderGeometry(options) {
    const {
      visible
    } = this.option();
    if (visible && hasWindow()) {
      this._stopAnimation();
      this._renderGeometryImpl();
    }
  },
  _renderGeometryImpl() {
    this._positionController.updatePosition(this._getOptionValue("position"));
    this._renderWrapper();
    this._renderDimensions();
    this._renderPosition();
  },
  _renderPosition() {
    this._positionController.positionContent();
  },
  _isAllWindowCovered() {
    return isWindow(this._positionController.$visualContainer.get(0)) && this.option("shading");
  },
  _toggleSafariScrolling() {
    const visible = this.option("visible");
    const $body = renderer_default(dom_adapter_default.getBody());
    const isIosSafari = "ios" === devices_default.real().platform && browser_default.safari;
    const isAllWindowCovered = this._isAllWindowCovered();
    const isScrollingPrevented = $body.hasClass("dx-prevent-safari-scrolling");
    const shouldPreventScrolling = !isScrollingPrevented && visible && isAllWindowCovered;
    const shouldEnableScrolling = isScrollingPrevented && (!visible || !isAllWindowCovered || this._disposed);
    if (isIosSafari) {
      if (shouldEnableScrolling) {
        $body.removeClass("dx-prevent-safari-scrolling");
        window4.scrollTo(0, this._cachedBodyScrollTop);
        this._cachedBodyScrollTop = void 0;
      } else if (shouldPreventScrolling) {
        this._cachedBodyScrollTop = window4.pageYOffset;
        $body.addClass("dx-prevent-safari-scrolling");
      }
    }
  },
  _renderWrapper() {
    this._positionController.styleWrapperPosition();
    this._renderWrapperDimensions();
    this._positionController.positionWrapper();
  },
  _renderWrapperDimensions() {
    const {
      $visualContainer
    } = this._positionController;
    const documentElement = dom_adapter_default.getDocumentElement();
    const isVisualContainerWindow = isWindow($visualContainer.get(0));
    const wrapperWidth = isVisualContainerWindow ? documentElement.clientWidth : getOuterWidth($visualContainer);
    const wrapperHeight = isVisualContainerWindow ? window4.innerHeight : getOuterHeight($visualContainer);
    this._$wrapper.css({
      width: wrapperWidth,
      height: wrapperHeight
    });
  },
  _renderDimensions() {
    const content = this._$content.get(0);
    this._$content.css({
      minWidth: this._getOptionValue("minWidth", content),
      maxWidth: this._getOptionValue("maxWidth", content),
      minHeight: this._getOptionValue("minHeight", content),
      maxHeight: this._getOptionValue("maxHeight", content),
      width: this._getOptionValue("width", content),
      height: this._getOptionValue("height", content)
    });
  },
  _focusTarget() {
    return this._$content;
  },
  _attachKeyboardEvents() {
    this._keyboardListenerId = keyboard.on(this._$content, null, (opts) => this._keyboardHandler(opts));
  },
  _keyboardHandler(options) {
    const e = options.originalEvent;
    const $target = renderer_default(e.target);
    if ($target.is(this._$content) || !this.option("ignoreChildEvents")) {
      this.callBase(...arguments);
    }
  },
  _isVisible() {
    return this.option("visible");
  },
  _visibilityChanged(visible) {
    if (visible) {
      if (this.option("visible")) {
        this._renderVisibilityAnimate(visible);
      }
    } else {
      this._renderVisibilityAnimate(visible);
    }
  },
  _dimensionChanged() {
    this._renderGeometry();
  },
  _clean() {
    const options = this.option();
    if (!this._contentAlreadyRendered && !options.isRenovated) {
      this.$content().empty();
    }
    this._renderVisibility(false);
    this._stopShowTimer();
    this._cleanFocusState();
  },
  _stopShowTimer() {
    if (this._asyncShowTimeout) {
      clearTimeout(this._asyncShowTimeout);
    }
    this._asyncShowTimeout = null;
  },
  _dispose() {
    fx_default.stop(this._$content, false);
    clearTimeout(this._deferShowTimer);
    this._toggleViewPortSubscription(false);
    this._toggleSubscriptions(false);
    this._updateZIndexStackPosition(false);
    this._toggleTabTerminator(false);
    this._actions = null;
    this._parentsScrollSubscriptionInfo = null;
    this.callBase();
    this._toggleSafariScrolling();
    this.option("visible") && remove(this._zIndex);
    this._$wrapper.remove();
    this._$content.remove();
  },
  _toggleRTLDirection(rtl) {
    this._$content.toggleClass("dx-rtl", rtl);
  },
  _optionChanged(args) {
    const {
      value: value2,
      name
    } = args;
    if (this._getActionsList().includes(name)) {
      this._initActions();
      return;
    }
    switch (name) {
      case "animation":
      case "closeOnOutsideClick":
      case "hideOnOutsideClick":
      case "propagateOutsideClick":
        break;
      case "shading":
        this._toggleShading(this.option("visible"));
        this._toggleSafariScrolling();
        break;
      case "shadingColor":
        this._toggleShading(this.option("visible"));
        break;
      case "width":
      case "height":
      case "minWidth":
      case "maxWidth":
      case "minHeight":
      case "maxHeight":
        this._renderGeometry();
        break;
      case "position":
        this._positionController.updatePosition(this.option("position"));
        this._positionController.restorePositionOnNextRender(true);
        this._renderGeometry();
        this._toggleSafariScrolling();
        break;
      case "visible":
        this._renderVisibilityAnimate(value2).done(() => {
          var _this$_animateDeferre;
          return null === (_this$_animateDeferre = this._animateDeferred) || void 0 === _this$_animateDeferre ? void 0 : _this$_animateDeferre.resolveWith(this);
        }).fail(() => {
          var _this$_animateDeferre2;
          return null === (_this$_animateDeferre2 = this._animateDeferred) || void 0 === _this$_animateDeferre2 ? void 0 : _this$_animateDeferre2.reject();
        });
        break;
      case "container":
        this._positionController.updateContainer(value2);
        this._invalidate();
        this._toggleSafariScrolling();
        break;
      case "visualContainer":
        this._positionController.updateVisualContainer(value2);
        this._renderWrapper();
        this._toggleSafariScrolling();
        break;
      case "innerOverlay":
        this._initInnerOverlayClass();
        break;
      case "deferRendering":
      case "contentTemplate":
        this._contentAlreadyRendered = false;
        this._clean();
        this._invalidate();
        break;
      case "hideTopOverlayHandler":
        this._toggleHideTopOverlayCallback(false);
        this._initHideTopOverlayHandler(value2);
        this._toggleHideTopOverlayCallback(this.option("visible"));
        break;
      case "hideOnParentScroll":
      case "_hideOnParentScrollTarget":
        this._toggleHideOnParentsScrollSubscription(this.option("visible"));
        break;
      case "rtlEnabled":
        this._contentAlreadyRendered = false;
        this.callBase(args);
        break;
      case "_fixWrapperPosition":
        this._positionController.fixWrapperPosition = value2;
        break;
      case "wrapperAttr":
        this._renderWrapperAttributes();
        break;
      case "restorePosition":
        this._positionController.restorePosition = value2;
        break;
      case "preventScrollEvents":
        this._logDeprecatedPreventScrollEventsInfo();
        this._toggleWrapperScrollEventsSubscription(value2);
        break;
      default:
        this.callBase(args);
    }
  },
  toggle(showing) {
    showing = void 0 === showing ? !this.option("visible") : showing;
    const result = Deferred();
    if (showing === this.option("visible")) {
      return result.resolveWith(this, [showing]).promise();
    }
    const animateDeferred = Deferred();
    this._animateDeferred = animateDeferred;
    this.option("visible", showing);
    animateDeferred.promise().done(() => {
      delete this._animateDeferred;
      result.resolveWith(this, [this.option("visible")]);
    }).fail(() => {
      delete this._animateDeferred;
      result.reject();
    });
    return result.promise();
  },
  $content() {
    return this._$content;
  },
  show() {
    return this.toggle(true);
  },
  hide() {
    return this.toggle(false);
  },
  content() {
    return getPublicElement(this._$content);
  },
  repaint() {
    if (this._contentAlreadyRendered) {
      this._positionController.restorePositionOnNextRender(true);
      this._renderGeometry({
        forceStopAnimation: true
      });
      triggerResizeEvent(this._$content);
    } else {
      this.callBase();
    }
  }
});
Overlay.baseZIndex = (zIndex) => base(zIndex);
component_registrator_default("dxOverlay", Overlay);
var m_overlay_default = Overlay;

// node_modules/devextreme/esm/ui/overlay/ui.overlay.js
var ui_overlay_default = m_overlay_default;

export {
  position_default,
  fx_default,
  DRAG_START_EVENT,
  DRAG_EVENT,
  DRAG_END_EVENT,
  DRAG_ENTER_EVENT,
  DRAG_LEAVE_EVENT,
  DROP_EVENT,
  swatch_container_default,
  OverlayPositionController,
  create,
  remove,
  isLastZIndexInStack,
  ui_overlay_default
};
//# sourceMappingURL=chunk-GAYW56K5.js.map
