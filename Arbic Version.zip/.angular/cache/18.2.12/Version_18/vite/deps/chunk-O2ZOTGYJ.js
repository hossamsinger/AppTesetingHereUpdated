import {
  EventsStrategy,
  init_events_strategy
} from "./chunk-BC4UU3FA.js";
import {
  MemorizedCallbacks,
  beforeCleanData,
  cleanDataRecursive,
  data,
  event_registrator_callbacks_default,
  events_engine_default,
  getEventTarget,
  getHeight,
  getOuterHeight,
  getWidth,
  init_element_data,
  init_event_registrator_callbacks,
  init_event_target,
  init_events_engine,
  init_html_parser,
  init_memorized_callbacks,
  init_renderer,
  init_size,
  init_style,
  parseHTML,
  removeData,
  renderer_default,
  styleProp,
  stylePropPrefix
} from "./chunk-WOX6XKRX.js";
import {
  Deferred,
  _extends,
  addShadowDomStyles,
  call_once_default,
  callbacks_default,
  class_default,
  compileGetter,
  compileSetter,
  deferRender,
  deferRenderer,
  dom_adapter_default,
  each,
  ensureDefined,
  equalByValue,
  findBestMatches,
  getNavigator,
  getPathParts,
  getWindow,
  grep,
  hasProperty,
  hasWindow,
  init_call_once,
  init_callbacks,
  init_class,
  init_common,
  init_data,
  init_deferred,
  init_dom_adapter,
  init_extends,
  init_iterator,
  init_object,
  init_ready_callbacks,
  init_shadow_dom,
  init_window,
  noop,
  orderEach,
  ready_callbacks_default,
  toComparable,
  when
} from "./chunk-4MAIXMIT.js";
import {
  config_default,
  error_default,
  errors_default,
  extend,
  fullVersion,
  init_config,
  init_error,
  init_errors,
  init_extend,
  init_type,
  init_version,
  isDefined,
  isEmptyObject,
  isExponential,
  isFunction,
  isObject,
  isPlainObject,
  isRenderer,
  isString,
  isWindow,
  type
} from "./chunk-ND5ICVCX.js";
import {
  __export
} from "./chunk-WOR4A3D2.js";

// node_modules/devextreme/esm/core/devices.js
init_size();
init_renderer();
init_window();
init_extend();
init_type();
init_errors();
init_callbacks();
init_ready_callbacks();

// node_modules/devextreme/esm/core/utils/resize_callbacks.js
init_window();
init_dom_adapter();
init_callbacks();
init_ready_callbacks();
init_call_once();
var resizeCallbacks = function() {
  let prevSize;
  const callbacks = callbacks_default();
  const originalCallbacksAdd = callbacks.add;
  const originalCallbacksRemove = callbacks.remove;
  if (!hasWindow()) {
    return callbacks;
  }
  const formatSize = function() {
    const window6 = getWindow();
    return {
      width: window6.innerWidth,
      height: window6.innerHeight
    };
  };
  const handleResize = function() {
    const now = formatSize();
    if (now.width === prevSize.width && now.height === prevSize.height) {
      return;
    }
    let changedDimension;
    if (now.width === prevSize.width) {
      changedDimension = "height";
    }
    if (now.height === prevSize.height) {
      changedDimension = "width";
    }
    prevSize = now;
    callbacks.fire(changedDimension);
  };
  const setPrevSize = call_once_default(function() {
    prevSize = formatSize();
  });
  let removeListener;
  callbacks.add = function() {
    const result = originalCallbacksAdd.apply(callbacks, arguments);
    setPrevSize();
    ready_callbacks_default.add(function() {
      if (!removeListener && callbacks.has()) {
        removeListener = dom_adapter_default.listen(getWindow(), "resize", handleResize);
      }
    });
    return result;
  };
  callbacks.remove = function() {
    const result = originalCallbacksRemove.apply(callbacks, arguments);
    if (!callbacks.has() && removeListener) {
      removeListener();
      removeListener = void 0;
    }
    return result;
  };
  return callbacks;
}();
var resize_callbacks_default = resizeCallbacks;

// node_modules/devextreme/esm/core/devices.js
init_events_strategy();

// node_modules/devextreme/esm/core/utils/storage.js
init_window();
var window = getWindow();
var getSessionStorage = function() {
  let sessionStorage;
  try {
    sessionStorage = window.sessionStorage;
  } catch (e) {
  }
  return sessionStorage;
};

// node_modules/devextreme/esm/core/utils/view_port.js
init_renderer();
init_ready_callbacks();
init_callbacks();
var ready = ready_callbacks_default.add;
var changeCallback = callbacks_default();
var $originalViewPort = renderer_default();
var value = /* @__PURE__ */ function() {
  let $current;
  return function(element) {
    if (!arguments.length) {
      return $current;
    }
    const $element = renderer_default(element);
    $originalViewPort = $element;
    const isNewViewportFound = !!$element.length;
    const prevViewPort = value();
    $current = isNewViewportFound ? $element : renderer_default("body");
    changeCallback.fire(isNewViewportFound ? value() : renderer_default(), prevViewPort);
  };
}();
ready(function() {
  value(".dx-viewport");
});
function originalViewPort() {
  return $originalViewPort;
}

// node_modules/devextreme/esm/core/devices.js
init_config();
var window2 = getWindow();
var KNOWN_UA_TABLE = {
  iPhone: "iPhone",
  iPhone5: "iPhone",
  iPhone6: "iPhone",
  iPhone6plus: "iPhone",
  iPad: "iPad",
  iPadMini: "iPad Mini",
  androidPhone: "Android Mobile",
  androidTablet: "Android",
  msSurface: "Windows ARM Tablet PC",
  desktop: "desktop"
};
var DEFAULT_DEVICE = {
  deviceType: "desktop",
  platform: "generic",
  version: [],
  phone: false,
  tablet: false,
  android: false,
  ios: false,
  generic: true,
  grade: "A",
  mac: false
};
var UA_PARSERS = {
  generic(userAgent) {
    const isPhone = /windows phone/i.test(userAgent) || userAgent.match(/WPDesktop/);
    const isTablet = !isPhone && /Windows(.*)arm(.*)Tablet PC/i.test(userAgent);
    const isDesktop = !isPhone && !isTablet && /msapphost/i.test(userAgent);
    const isMac = /((intel|ppc) mac os x)/.test(userAgent.toLowerCase());
    if (!(isPhone || isTablet || isDesktop || isMac)) {
      return null;
    }
    return {
      deviceType: isPhone ? "phone" : isTablet ? "tablet" : "desktop",
      platform: "generic",
      version: [],
      grade: "A",
      mac: isMac
    };
  },
  appleTouchDevice(userAgent) {
    const navigator2 = getNavigator();
    const isIpadOs = /Macintosh/i.test(userAgent) && (null === navigator2 || void 0 === navigator2 ? void 0 : navigator2.maxTouchPoints) > 2;
    const isAppleDevice = /ip(hone|od|ad)/i.test(userAgent);
    if (!isAppleDevice && !isIpadOs) {
      return null;
    }
    const isPhone = /ip(hone|od)/i.test(userAgent);
    const matches = userAgent.match(/os\s{0,}X? (\d+)_(\d+)_?(\d+)?/i);
    const version = matches ? [parseInt(matches[1], 10), parseInt(matches[2], 10), parseInt(matches[3] || 0, 10)] : [];
    const isIPhone4 = 480 === window2.screen.height;
    const grade = isIPhone4 ? "B" : "A";
    return {
      deviceType: isPhone ? "phone" : "tablet",
      platform: "ios",
      version,
      grade
    };
  },
  android(userAgent) {
    const isAndroid = /android|htc_|silk/i.test(userAgent);
    const isWinPhone = /windows phone/i.test(userAgent);
    if (!isAndroid || isWinPhone) {
      return null;
    }
    const isPhone = /mobile/i.test(userAgent);
    const matches = userAgent.match(/android (\d+)\.?(\d+)?\.?(\d+)?/i);
    const version = matches ? [parseInt(matches[1], 10), parseInt(matches[2] || 0, 10), parseInt(matches[3] || 0, 10)] : [];
    const worseThan4_4 = version.length > 1 && (version[0] < 4 || 4 === version[0] && version[1] < 4);
    const grade = worseThan4_4 ? "B" : "A";
    return {
      deviceType: isPhone ? "phone" : "tablet",
      platform: "android",
      version,
      grade
    };
  }
};
var UA_PARSERS_ARRAY = [UA_PARSERS.appleTouchDevice, UA_PARSERS.android, UA_PARSERS.generic];
var Devices = class {
  constructor(options) {
    this._window = (null === options || void 0 === options ? void 0 : options.window) || window2;
    this._realDevice = this._getDevice();
    this._currentDevice = void 0;
    this._currentOrientation = void 0;
    this._eventsStrategy = new EventsStrategy(this);
    this.changed = callbacks_default();
    if (hasWindow()) {
      ready_callbacks_default.add(this._recalculateOrientation.bind(this));
      resize_callbacks_default.add(this._recalculateOrientation.bind(this));
    }
  }
  current(deviceOrName) {
    if (deviceOrName) {
      this._currentDevice = this._getDevice(deviceOrName);
      this._forced = true;
      this.changed.fire();
      return;
    }
    if (!this._currentDevice) {
      deviceOrName = void 0;
      try {
        deviceOrName = this._getDeviceOrNameFromWindowScope();
      } catch (e) {
        deviceOrName = this._getDeviceNameFromSessionStorage();
      } finally {
        if (!deviceOrName) {
          deviceOrName = this._getDeviceNameFromSessionStorage();
        }
        if (deviceOrName) {
          this._forced = true;
        }
      }
      this._currentDevice = this._getDevice(deviceOrName);
    }
    return this._currentDevice;
  }
  real(forceDevice) {
    return extend({}, this._realDevice);
  }
  orientation() {
    return this._currentOrientation;
  }
  isForced() {
    return this._forced;
  }
  isRippleEmulator() {
    return !!this._window.tinyHippos;
  }
  _getCssClasses(device) {
    const result = [];
    const realDevice = this._realDevice;
    device = device || this.current();
    if (device.deviceType) {
      result.push(`dx-device-${device.deviceType}`);
      if ("desktop" !== device.deviceType) {
        result.push("dx-device-mobile");
      }
    }
    result.push(`dx-device-${realDevice.platform}`);
    if (realDevice.version && realDevice.version.length) {
      result.push(`dx-device-${realDevice.platform}-${realDevice.version[0]}`);
    }
    if (this.isSimulator()) {
      result.push("dx-simulator");
    }
    if (config_default().rtlEnabled) {
      result.push("dx-rtl");
    }
    return result;
  }
  attachCssClasses(element, device) {
    this._deviceClasses = this._getCssClasses(device).join(" ");
    renderer_default(element).addClass(this._deviceClasses);
  }
  detachCssClasses(element) {
    renderer_default(element).removeClass(this._deviceClasses);
  }
  isSimulator() {
    try {
      return this._isSimulator || hasWindow() && this._window.top !== this._window.self && this._window.top["dx-force-device"] || this.isRippleEmulator();
    } catch (e) {
      return false;
    }
  }
  forceSimulator() {
    this._isSimulator = true;
  }
  _getDevice(deviceName) {
    if ("genericPhone" === deviceName) {
      deviceName = {
        deviceType: "phone",
        platform: "generic",
        generic: true
      };
    }
    if (isPlainObject(deviceName)) {
      return this._fromConfig(deviceName);
    } else {
      let ua;
      if (deviceName) {
        ua = KNOWN_UA_TABLE[deviceName];
        if (!ua) {
          throw errors_default.Error("E0005");
        }
      } else {
        const navigator2 = getNavigator();
        ua = navigator2.userAgent;
      }
      return this._fromUA(ua);
    }
  }
  _getDeviceOrNameFromWindowScope() {
    let result;
    if (hasWindow() && (this._window.top["dx-force-device-object"] || this._window.top["dx-force-device"])) {
      result = this._window.top["dx-force-device-object"] || this._window.top["dx-force-device"];
    }
    return result;
  }
  _getDeviceNameFromSessionStorage() {
    const sessionStorage = getSessionStorage();
    if (!sessionStorage) {
      return;
    }
    const deviceOrName = sessionStorage.getItem("dx-force-device");
    try {
      return JSON.parse(deviceOrName);
    } catch (ex) {
      return deviceOrName;
    }
  }
  _fromConfig(config) {
    const result = extend({}, DEFAULT_DEVICE, this._currentDevice, config);
    const shortcuts = {
      phone: "phone" === result.deviceType,
      tablet: "tablet" === result.deviceType,
      android: "android" === result.platform,
      ios: "ios" === result.platform,
      generic: "generic" === result.platform
    };
    return extend(result, shortcuts);
  }
  _fromUA(ua) {
    for (let idx = 0; idx < UA_PARSERS_ARRAY.length; idx += 1) {
      const parser = UA_PARSERS_ARRAY[idx];
      const config = parser(ua);
      if (config) {
        return this._fromConfig(config);
      }
    }
    return DEFAULT_DEVICE;
  }
  _changeOrientation() {
    const $window = renderer_default(this._window);
    const orientation = getHeight($window) > getWidth($window) ? "portrait" : "landscape";
    if (this._currentOrientation === orientation) {
      return;
    }
    this._currentOrientation = orientation;
    this._eventsStrategy.fireEvent("orientationChanged", [{
      orientation
    }]);
  }
  _recalculateOrientation() {
    const windowWidth = getWidth(this._window);
    if (this._currentWidth === windowWidth) {
      return;
    }
    this._currentWidth = windowWidth;
    this._changeOrientation();
  }
  on(eventName, eventHandler) {
    this._eventsStrategy.on(eventName, eventHandler);
    return this;
  }
  off(eventName, eventHandler) {
    this._eventsStrategy.off(eventName, eventHandler);
    return this;
  }
};
var devices = new Devices();
var viewPortElement = value();
if (viewPortElement) {
  devices.attachCssClasses(viewPortElement);
}
changeCallback.add((viewPort2, prevViewport) => {
  devices.detachCssClasses(prevViewport);
  devices.attachCssClasses(viewPort2);
});
var devices_default = devices;

// node_modules/devextreme/esm/events/utils/index.js
init_renderer();

// node_modules/devextreme/esm/events/utils/add_namespace.js
init_errors();
var addNamespace = (eventNames, namespace) => {
  if (!namespace) {
    throw errors_default.Error("E0017");
  }
  if (Array.isArray(eventNames)) {
    return eventNames.map((eventName) => addNamespace(eventName, namespace)).join(" ");
  }
  if (-1 !== eventNames.indexOf(" ")) {
    return addNamespace(eventNames.split(/\s+/g), namespace);
  }
  return `${eventNames}.${namespace}`;
};
var add_namespace_default = addNamespace;

// node_modules/devextreme/esm/events/utils/index.js
init_events_engine();
init_iterator();
init_extend();

// node_modules/devextreme/esm/ui/widget/selectors.js
init_renderer();
init_dom_adapter();
var focusableFn = function(element, tabIndex) {
  if (!visible(element)) {
    return false;
  }
  const nodeName = element.nodeName.toLowerCase();
  const isTabIndexNotNaN = !isNaN(tabIndex);
  const isDisabled = element.disabled;
  const isDefaultFocus = /^(input|select|textarea|button|object|iframe)$/.test(nodeName);
  const isHyperlink = "a" === nodeName;
  let isFocusable;
  const isContentEditable = element.isContentEditable;
  if (isDefaultFocus || isContentEditable) {
    isFocusable = !isDisabled;
  } else if (isHyperlink) {
    isFocusable = element.href || isTabIndexNotNaN;
  } else {
    isFocusable = isTabIndexNotNaN;
  }
  return isFocusable;
};
function visible(element) {
  const $element = renderer_default(element);
  return $element.is(":visible") && "hidden" !== $element.css("visibility") && "hidden" !== $element.parents().css("visibility");
}
var focusable = function(index2, element) {
  return focusableFn(element, renderer_default(element).attr("tabIndex"));
};
var tabbable = function(index2, element) {
  const tabIndex = renderer_default(element).attr("tabIndex");
  return (isNaN(tabIndex) || tabIndex >= 0) && focusableFn(element, tabIndex);
};
var focused = function($element) {
  const element = renderer_default($element).get(0);
  return dom_adapter_default.getActiveElement(element) === element;
};

// node_modules/devextreme/esm/events/utils/index.js
var KEY_MAP = {
  backspace: "backspace",
  tab: "tab",
  enter: "enter",
  escape: "escape",
  pageup: "pageUp",
  pagedown: "pageDown",
  end: "end",
  home: "home",
  arrowleft: "leftArrow",
  arrowup: "upArrow",
  arrowright: "rightArrow",
  arrowdown: "downArrow",
  delete: "del",
  " ": "space",
  f: "F",
  a: "A",
  "*": "asterisk",
  "-": "minus",
  alt: "alt",
  control: "control",
  shift: "shift"
};
var LEGACY_KEY_CODES = {
  8: "backspace",
  9: "tab",
  13: "enter",
  27: "escape",
  33: "pageUp",
  34: "pageDown",
  35: "end",
  36: "home",
  37: "leftArrow",
  38: "upArrow",
  39: "rightArrow",
  40: "downArrow",
  46: "del",
  32: "space",
  70: "F",
  65: "A",
  106: "asterisk",
  109: "minus",
  189: "minus",
  173: "minus",
  16: "shift",
  17: "control",
  18: "alt"
};
var EVENT_SOURCES_REGEX = {
  dx: /^dx/i,
  mouse: /(mouse|wheel)/i,
  touch: /^touch/i,
  keyboard: /^key/i,
  pointer: /^(ms)?pointer/i
};
var fixMethod = (e) => e;
var copyEvent = (originalEvent) => fixMethod(events_engine_default.Event(originalEvent, originalEvent), originalEvent);
var isDxEvent = (e) => "dx" === eventSource(e);
var isNativeMouseEvent = (e) => "mouse" === eventSource(e);
var isNativeTouchEvent = (e) => "touch" === eventSource(e);
var eventSource = (_ref) => {
  let {
    type: type2
  } = _ref;
  let result = "other";
  each(EVENT_SOURCES_REGEX, function(key) {
    if (this.test(type2)) {
      result = key;
      return false;
    }
  });
  return result;
};
var isPointerEvent = (e) => "pointer" === eventSource(e);
var isMouseEvent = (e) => isNativeMouseEvent(e) || (isPointerEvent(e) || isDxEvent(e)) && "mouse" === e.pointerType;
var isDxMouseWheelEvent = (e) => e && "dxmousewheel" === e.type;
var isTouchEvent = (e) => isNativeTouchEvent(e) || (isPointerEvent(e) || isDxEvent(e)) && "touch" === e.pointerType;
var isFakeClickEvent = (_ref2) => {
  let {
    screenX,
    offsetX,
    pageX
  } = _ref2;
  return 0 === screenX && !offsetX && 0 === pageX;
};
var eventData = (_ref3) => {
  let {
    pageX,
    pageY,
    timeStamp
  } = _ref3;
  return {
    x: pageX,
    y: pageY,
    time: timeStamp
  };
};
var eventDelta = (from, to) => ({
  x: to.x - from.x,
  y: to.y - from.y,
  time: to.time - from.time || 1
});
var hasTouches = (e) => {
  const {
    originalEvent,
    pointers
  } = e;
  if (isNativeTouchEvent(e)) {
    return (originalEvent.touches || []).length;
  }
  if (isDxEvent(e)) {
    return (pointers || []).length;
  }
  return 0;
};
var skipEvents = false;
var needSkipEvent = (e) => {
  if (skipEvents) {
    return true;
  }
  const {
    target
  } = e;
  const $target = renderer_default(target);
  const isContentEditable = (null === target || void 0 === target ? void 0 : target.isContentEditable) || (null === target || void 0 === target ? void 0 : target.hasAttribute("contenteditable"));
  const touchInEditable = $target.is("input, textarea, select") || isContentEditable;
  if (isDxMouseWheelEvent(e)) {
    const isTextArea = $target.is("textarea") && $target.hasClass("dx-texteditor-input");
    if (isTextArea || isContentEditable) {
      return false;
    }
    const isInputFocused = $target.is("input[type='number'], textarea, select") && $target.is(":focus");
    return isInputFocused;
  }
  if (isMouseEvent(e)) {
    return touchInEditable || e.which > 1;
  }
  if (isTouchEvent(e)) {
    return touchInEditable && focused($target);
  }
};
var createEvent = (originalEvent, args) => {
  const event = copyEvent(originalEvent);
  args && extend(event, args);
  return event;
};
var fireEvent = (props) => {
  const {
    originalEvent,
    delegateTarget
  } = props;
  const event = createEvent(originalEvent, props);
  events_engine_default.trigger(delegateTarget || event.target, event);
  return event;
};
var normalizeKeyName = (_ref4) => {
  let {
    key,
    which
  } = _ref4;
  const normalizedKey = KEY_MAP[null === key || void 0 === key ? void 0 : key.toLowerCase()] || key;
  const normalizedKeyFromWhich = LEGACY_KEY_CODES[which];
  if (normalizedKeyFromWhich && normalizedKey === key) {
    return normalizedKeyFromWhich;
  } else if (!normalizedKey && which) {
    return String.fromCharCode(which);
  }
  return normalizedKey;
};
var getChar = (_ref5) => {
  let {
    key,
    which
  } = _ref5;
  return key || String.fromCharCode(which);
};
var addNamespace2 = add_namespace_default;
var isCommandKeyPressed = (_ref6) => {
  let {
    ctrlKey,
    metaKey
  } = _ref6;
  return ctrlKey || metaKey;
};

// node_modules/devextreme/esm/core/component_registrator.js
init_renderer();

// node_modules/devextreme/esm/core/component_registrator_callbacks.js
init_memorized_callbacks();
var component_registrator_callbacks_default = new MemorizedCallbacks();

// node_modules/devextreme/esm/core/component_registrator.js
init_errors();

// node_modules/devextreme/esm/core/utils/public_component.js
init_element_data();
init_events_engine();
init_type();

// node_modules/devextreme/esm/events/remove.js
init_renderer();
init_element_data();
init_events_engine();

// node_modules/devextreme/esm/events/core/event_registrator.js
init_iterator();
init_event_registrator_callbacks();
var registerEvent = function(name, eventObject) {
  const strategy2 = {};
  if ("noBubble" in eventObject) {
    strategy2.noBubble = eventObject.noBubble;
  }
  if ("bindType" in eventObject) {
    strategy2.bindType = eventObject.bindType;
  }
  if ("delegateType" in eventObject) {
    strategy2.delegateType = eventObject.delegateType;
  }
  each(["setup", "teardown", "add", "remove", "trigger", "handle", "_default", "dispose"], function(_, methodName) {
    if (!eventObject[methodName]) {
      return;
    }
    strategy2[methodName] = function() {
      const args = [].slice.call(arguments);
      args.unshift(this);
      return eventObject[methodName].apply(eventObject, args);
    };
  });
  event_registrator_callbacks_default.fire(name, strategy2);
};
registerEvent.callbacks = event_registrator_callbacks_default;
var event_registrator_default = registerEvent;

// node_modules/devextreme/esm/events/remove.js
var removeEvent = "dxremove";
var eventPropName = "dxRemoveEvent";
beforeCleanData(function(elements) {
  elements = [].slice.call(elements);
  for (let i = 0; i < elements.length; i++) {
    const $element = renderer_default(elements[i]);
    if ($element.prop(eventPropName)) {
      $element[0][eventPropName] = null;
      events_engine_default.triggerHandler($element, "dxremove");
    }
  }
});
event_registrator_default("dxremove", {
  noBubble: true,
  setup: function(element) {
    renderer_default(element).prop(eventPropName, true);
  }
});

// node_modules/devextreme/esm/core/utils/public_component.js
var componentNames = /* @__PURE__ */ new WeakMap();
var nextAnonymousComponent = 0;
var getName = function(componentClass, newName) {
  if (isDefined(newName)) {
    componentNames.set(componentClass, newName);
    return;
  }
  if (!componentNames.has(componentClass)) {
    const generatedName = "dxPrivateComponent" + nextAnonymousComponent++;
    componentNames.set(componentClass, generatedName);
    return generatedName;
  }
  return componentNames.get(componentClass);
};
function attachInstanceToElement($element, componentInstance, disposeFn) {
  const data2 = data($element.get(0));
  const name = getName(componentInstance.constructor);
  data2[name] = componentInstance;
  if (disposeFn) {
    events_engine_default.one($element, removeEvent, function() {
      disposeFn.call(componentInstance);
    });
  }
  if (!data2.dxComponents) {
    data2.dxComponents = [];
  }
  data2.dxComponents.push(name);
}
function getInstanceByElement($element, componentClass) {
  const name = getName(componentClass);
  return data($element.get(0), name);
}

// node_modules/devextreme/esm/core/component_registrator.js
var registerComponent = function(name, namespace, componentClass) {
  if (!componentClass) {
    componentClass = namespace;
  } else {
    namespace[name] = componentClass;
  }
  getName(componentClass, name);
  component_registrator_callbacks_default.fire(name, componentClass);
};
var registerRendererComponent = function(name, componentClass) {
  renderer_default.fn[name] = function(options) {
    const isMemberInvoke = "string" === typeof options;
    let result;
    if (isMemberInvoke) {
      const memberName = options;
      const memberArgs = [].slice.call(arguments).slice(1);
      this.each(function() {
        const instance = componentClass.getInstance(this);
        if (!instance) {
          throw errors_default.Error("E0009", name);
        }
        const member = instance[memberName];
        const memberValue = member.apply(instance, memberArgs);
        if (void 0 === result) {
          result = memberValue;
        }
      });
    } else {
      this.each(function() {
        const instance = componentClass.getInstance(this);
        if (instance) {
          instance.option(options);
        } else {
          new componentClass(this, options);
        }
      });
      result = this;
    }
    return result;
  };
};
component_registrator_callbacks_default.add(registerRendererComponent);
var component_registrator_default = registerComponent;

// node_modules/devextreme/esm/events/pointer.js
init_config();

// node_modules/devextreme/esm/core/utils/support.js
var support_exports = {};
__export(support_exports, {
  animation: () => animation,
  inputType: () => inputType,
  nativeScrolling: () => nativeScrolling,
  pointerEvents: () => pointerEvents,
  styleProp: () => styleProp,
  stylePropPrefix: () => stylePropPrefix,
  supportProp: () => supportProp,
  touch: () => touch,
  touchEvents: () => touchEvents,
  transition: () => transition,
  transitionEndEventName: () => transitionEndEventName
});
init_dom_adapter();
init_call_once();
init_window();
init_style();
var {
  maxTouchPoints
} = getNavigator();
var transitionEndEventNames = {
  webkitTransition: "webkitTransitionEnd",
  MozTransition: "transitionend",
  OTransition: "oTransitionEnd",
  transition: "transitionend"
};
var supportProp = function(prop) {
  return !!styleProp(prop);
};
var isNativeScrollingSupported = function() {
  const {
    platform,
    mac: isMac
  } = devices_default.real();
  const isNativeScrollDevice = "ios" === platform || "android" === platform || isMac;
  return isNativeScrollDevice;
};
var inputType = function(type2) {
  if ("text" === type2) {
    return true;
  }
  const input = dom_adapter_default.createElement("input");
  try {
    input.setAttribute("type", type2);
    input.value = "wrongValue";
    return !input.value;
  } catch (e) {
    return false;
  }
};
var detectTouchEvents = function(hasWindowProperty, maxTouchPoints2) {
  return (hasWindowProperty("ontouchstart") || !!maxTouchPoints2) && !hasWindowProperty("callPhantom");
};
var detectPointerEvent = function(hasWindowProperty) {
  return hasWindowProperty("PointerEvent");
};
var touchEvents = detectTouchEvents(hasProperty, maxTouchPoints);
var pointerEvents = detectPointerEvent(hasProperty);
var touchPointersPresent = !!maxTouchPoints;
var touch = touchEvents || pointerEvents && touchPointersPresent;
var transition = call_once_default(function() {
  return supportProp("transition");
});
var transitionEndEventName = call_once_default(function() {
  return transitionEndEventNames[styleProp("transition")];
});
var animation = call_once_default(function() {
  return supportProp("animation");
});
var nativeScrolling = isNativeScrollingSupported();

// node_modules/devextreme/esm/events/pointer.js
init_iterator();

// node_modules/devextreme/esm/events/pointer/touch.js
init_extend();
init_iterator();

// node_modules/devextreme/esm/events/pointer/base.js
init_events_engine();

// node_modules/devextreme/esm/core/utils/browser.js
init_extend();
init_window();
var navigator = getNavigator();
var webkitRegExp = /(webkit)[ /]([\w.]+)/;
var mozillaRegExp = /(mozilla)(?:.*? rv:([\w.]+))/;
var browserFromUA = (ua) => {
  ua = ua.toLowerCase();
  const result = {};
  const matches = webkitRegExp.exec(ua) || ua.indexOf("compatible") < 0 && mozillaRegExp.exec(ua) || [];
  let browserName = matches[1];
  let browserVersion = matches[2];
  if ("webkit" === browserName) {
    result.webkit = true;
    if (ua.indexOf("chrome") >= 0 || ua.indexOf("crios") >= 0) {
      browserName = "chrome";
      browserVersion = /(?:chrome|crios)\/(\d+\.\d+)/.exec(ua);
      browserVersion = browserVersion && browserVersion[1];
    } else if (ua.indexOf("fxios") >= 0) {
      browserName = "mozilla";
      browserVersion = /fxios\/(\d+\.\d+)/.exec(ua);
      browserVersion = browserVersion && browserVersion[1];
    } else if (ua.indexOf("safari") >= 0 && /version|phantomjs/.test(ua)) {
      browserName = "safari";
      browserVersion = /(?:version|phantomjs)\/([0-9.]+)/.exec(ua);
      browserVersion = browserVersion && browserVersion[1];
    } else {
      browserName = "unknown";
      browserVersion = /applewebkit\/([0-9.]+)/.exec(ua);
      browserVersion = browserVersion && browserVersion[1];
    }
  }
  if (browserName) {
    result[browserName] = true;
    result.version = browserVersion;
  }
  return result;
};
var browser_default = extend({
  _fromUA: browserFromUA
}, browserFromUA(navigator.userAgent));

// node_modules/devextreme/esm/events/pointer/base.js
init_dom_adapter();
init_class();
init_event_target();
var BaseStrategy = class_default.inherit({
  ctor: function(eventName, originalEvents) {
    this._eventName = eventName;
    this._originalEvents = addNamespace2(originalEvents, "dxPointerEvents");
    this._handlerCount = 0;
    this.noBubble = this._isNoBubble();
  },
  _isNoBubble: function() {
    const eventName = this._eventName;
    return "dxpointerenter" === eventName || "dxpointerleave" === eventName;
  },
  _handler: function(e) {
    const delegateTarget = this._getDelegateTarget(e);
    const event = {
      type: this._eventName,
      pointerType: e.pointerType || eventSource(e),
      originalEvent: e,
      delegateTarget,
      timeStamp: browser_default.mozilla ? (/* @__PURE__ */ new Date()).getTime() : e.timeStamp
    };
    const target = getEventTarget(e);
    event.target = target;
    return this._fireEvent(event);
  },
  _getDelegateTarget: function(e) {
    let delegateTarget;
    if (this.noBubble) {
      delegateTarget = e.delegateTarget;
    }
    return delegateTarget;
  },
  _fireEvent: function(args) {
    return fireEvent(args);
  },
  _setSelector: function(handleObj) {
    this._selector = this.noBubble && handleObj ? handleObj.selector : null;
  },
  _getSelector: function() {
    return this._selector;
  },
  setup: function() {
    return true;
  },
  add: function(element, handleObj) {
    if (this._handlerCount <= 0 || this.noBubble) {
      element = this.noBubble ? element : dom_adapter_default.getDocument();
      this._setSelector(handleObj);
      const that = this;
      events_engine_default.on(element, this._originalEvents, this._getSelector(), function(e) {
        that._handler(e);
      });
    }
    if (!this.noBubble) {
      this._handlerCount++;
    }
  },
  remove: function(handleObj) {
    this._setSelector(handleObj);
    if (!this.noBubble) {
      this._handlerCount--;
    }
  },
  teardown: function(element) {
    if (this._handlerCount && !this.noBubble) {
      return;
    }
    element = this.noBubble ? element : dom_adapter_default.getDocument();
    if (".dxPointerEvents" !== this._originalEvents) {
      events_engine_default.off(element, this._originalEvents, this._getSelector());
    }
  },
  dispose: function(element) {
    element = this.noBubble ? element : dom_adapter_default.getDocument();
    events_engine_default.off(element, this._originalEvents);
  }
});
var base_default = BaseStrategy;

// node_modules/devextreme/esm/events/pointer/touch.js
var eventMap = {
  dxpointerdown: "touchstart",
  dxpointermove: "touchmove",
  dxpointerup: "touchend",
  dxpointercancel: "touchcancel",
  dxpointerover: "",
  dxpointerout: "",
  dxpointerenter: "",
  dxpointerleave: ""
};
var normalizeTouchEvent = function(e) {
  const pointers = [];
  each(e.touches, function(_, touch2) {
    pointers.push(extend({
      pointerId: touch2.identifier
    }, touch2));
  });
  return {
    pointers,
    pointerId: e.changedTouches[0].identifier
  };
};
var skipTouchWithSameIdentifier = function(pointerEvent) {
  return "ios" === devices_default.real().platform && ("dxpointerdown" === pointerEvent || "dxpointerup" === pointerEvent);
};
var TouchStrategy = base_default.inherit({
  ctor: function() {
    this.callBase.apply(this, arguments);
    this._pointerId = 0;
  },
  _handler: function(e) {
    if (skipTouchWithSameIdentifier(this._eventName)) {
      const touch2 = e.changedTouches[0];
      if (this._pointerId === touch2.identifier && 0 !== this._pointerId) {
        return;
      }
      this._pointerId = touch2.identifier;
    }
    return this.callBase.apply(this, arguments);
  },
  _fireEvent: function(args) {
    return this.callBase(extend(normalizeTouchEvent(args.originalEvent), args));
  }
});
TouchStrategy.map = eventMap;
TouchStrategy.normalize = normalizeTouchEvent;
var touch_default = TouchStrategy;

// node_modules/devextreme/esm/events/pointer/mouse.js
init_extend();

// node_modules/devextreme/esm/events/pointer/observer.js
init_iterator();
init_ready_callbacks();
init_dom_adapter();
var addEventsListener = function(events, handler) {
  ready_callbacks_default.add(function() {
    events.split(" ").forEach(function(event) {
      dom_adapter_default.listen(dom_adapter_default.getDocument(), event, handler, true);
    });
  });
};
var Observer = function(eventMap4, pointerEquals, onPointerAdding) {
  onPointerAdding = onPointerAdding || function() {
  };
  let pointers = [];
  const getPointerIndex = function(e) {
    let index2 = -1;
    each(pointers, function(i, pointer2) {
      if (!pointerEquals(e, pointer2)) {
        return true;
      }
      index2 = i;
      return false;
    });
    return index2;
  };
  const removePointer = function(e) {
    const index2 = getPointerIndex(e);
    if (index2 > -1) {
      pointers.splice(index2, 1);
    }
  };
  addEventsListener(eventMap4.dxpointerdown, function(e) {
    if (-1 === getPointerIndex(e)) {
      onPointerAdding(e);
      pointers.push(e);
    }
  });
  addEventsListener(eventMap4.dxpointermove, function(e) {
    pointers[getPointerIndex(e)] = e;
  });
  addEventsListener(eventMap4.dxpointerup, removePointer);
  addEventsListener(eventMap4.dxpointercancel, removePointer);
  this.pointers = function() {
    return pointers;
  };
  this.reset = function() {
    pointers = [];
  };
};
var observer_default = Observer;

// node_modules/devextreme/esm/events/pointer/mouse.js
var eventMap2 = {
  dxpointerdown: "mousedown",
  dxpointermove: "mousemove",
  dxpointerup: "mouseup",
  dxpointercancel: "",
  dxpointerover: "mouseover",
  dxpointerout: "mouseout",
  dxpointerenter: "mouseenter",
  dxpointerleave: "mouseleave"
};
var normalizeMouseEvent = function(e) {
  e.pointerId = 1;
  return {
    pointers: observer.pointers(),
    pointerId: 1
  };
};
var observer;
var activated = false;
var activateStrategy = function() {
  if (activated) {
    return;
  }
  observer = new observer_default(eventMap2, function() {
    return true;
  });
  activated = true;
};
var MouseStrategy = base_default.inherit({
  ctor: function() {
    this.callBase.apply(this, arguments);
    activateStrategy();
  },
  _fireEvent: function(args) {
    return this.callBase(extend(normalizeMouseEvent(args.originalEvent), args));
  }
});
MouseStrategy.map = eventMap2;
MouseStrategy.normalize = normalizeMouseEvent;
MouseStrategy.activate = activateStrategy;
MouseStrategy.resetObserver = function() {
  observer.reset();
};
var mouse_default = MouseStrategy;

// node_modules/devextreme/esm/events/pointer/mouse_and_touch.js
init_extend();
var eventMap3 = {
  dxpointerdown: "touchstart mousedown",
  dxpointermove: "touchmove mousemove",
  dxpointerup: "touchend mouseup",
  dxpointercancel: "touchcancel",
  dxpointerover: "mouseover",
  dxpointerout: "mouseout",
  dxpointerenter: "mouseenter",
  dxpointerleave: "mouseleave"
};
var activated2 = false;
var activateStrategy2 = function() {
  if (activated2) {
    return;
  }
  mouse_default.activate();
  activated2 = true;
};
var MouseAndTouchStrategy = base_default.inherit({
  EVENT_LOCK_TIMEOUT: 100,
  ctor: function() {
    this.callBase.apply(this, arguments);
    activateStrategy2();
  },
  _handler: function(e) {
    const isMouse = isMouseEvent(e);
    if (!isMouse) {
      this._skipNextEvents = true;
    }
    if (isMouse && this._mouseLocked) {
      return;
    }
    if (isMouse && this._skipNextEvents) {
      this._skipNextEvents = false;
      this._mouseLocked = true;
      clearTimeout(this._unlockMouseTimer);
      const that = this;
      this._unlockMouseTimer = setTimeout(function() {
        that._mouseLocked = false;
      }, this.EVENT_LOCK_TIMEOUT);
      return;
    }
    return this.callBase(e);
  },
  _fireEvent: function(args) {
    const normalizer = isMouseEvent(args.originalEvent) ? mouse_default.normalize : touch_default.normalize;
    return this.callBase(extend(normalizer(args.originalEvent), args));
  },
  dispose: function() {
    this.callBase();
    this._skipNextEvents = false;
    this._mouseLocked = false;
    clearTimeout(this._unlockMouseTimer);
  }
});
MouseAndTouchStrategy.map = eventMap3;
MouseAndTouchStrategy.resetObserver = mouse_default.resetObserver;
var mouse_and_touch_default = MouseAndTouchStrategy;

// node_modules/devextreme/esm/events/pointer.js
var getStrategy = (support, _ref) => {
  let {
    tablet,
    phone
  } = _ref;
  const pointerEventStrategy = getStrategyFromGlobalConfig();
  if (pointerEventStrategy) {
    return pointerEventStrategy;
  }
  if (support.touch && !(tablet || phone)) {
    return mouse_and_touch_default;
  }
  if (support.touch) {
    return touch_default;
  }
  return mouse_default;
};
var EventStrategy = getStrategy(support_exports, devices_default.real());
each(EventStrategy.map, (pointerEvent, originalEvents) => {
  event_registrator_default(pointerEvent, new EventStrategy(pointerEvent, originalEvents));
});
var pointer = {
  down: "dxpointerdown",
  up: "dxpointerup",
  move: "dxpointermove",
  cancel: "dxpointercancel",
  enter: "dxpointerenter",
  leave: "dxpointerleave",
  over: "dxpointerover",
  out: "dxpointerout"
};
function getStrategyFromGlobalConfig() {
  const eventStrategyName = config_default().pointerEventStrategy;
  return {
    "mouse-and-touch": mouse_and_touch_default,
    touch: touch_default,
    mouse: mouse_default
  }[eventStrategyName];
}
var pointer_default = pointer;

// node_modules/devextreme/esm/ui/themes.js
init_size();
init_dom_adapter();
init_renderer();
init_deferred();
init_html_parser();
init_iterator();
init_ready_callbacks();
init_window();

// node_modules/devextreme/esm/ui/themes_callback.js
init_callbacks();
var themeReadyCallback = callbacks_default();

// node_modules/devextreme/esm/ui/widget/ui.errors.js
init_error();
init_errors();
var ui_errors_default = error_default(errors_default.ERROR_MESSAGES, {
  E1001: "Module '{0}'. Controller '{1}' is already registered",
  E1002: "Module '{0}'. Controller '{1}' does not inherit from DevExpress.ui.dxDataGrid.Controller",
  E1003: "Module '{0}'. View '{1}' is already registered",
  E1004: "Module '{0}'. View '{1}' does not inherit from DevExpress.ui.dxDataGrid.View",
  E1005: "Public method '{0}' is already registered",
  E1006: "Public method '{0}.{1}' does not exist",
  E1007: "State storing cannot be provided due to the restrictions of the browser",
  E1010: "The template does not contain the TextBox widget",
  E1011: 'Items cannot be deleted from the List. Implement the "remove" function in the data store',
  E1012: "Editing type '{0}' with the name '{1}' is unsupported",
  E1016: "Unexpected type of data source is provided for a lookup column",
  E1018: "The 'collapseAll' method cannot be called if you use a remote data source",
  E1019: "Search mode '{0}' is unavailable",
  E1020: "The type cannot be changed after initialization",
  E1021: "{0} '{1}' you are trying to remove does not exist",
  E1022: 'The "markers" option is given an invalid value. Assign an array instead',
  E1023: 'The "routes" option is given an invalid value. Assign an array instead',
  E1025: "This layout is too complex to render",
  E1026: 'The "calculateCustomSummary" function is missing from a field whose "summaryType" option is set to "custom"',
  E1031: "Unknown subscription in the Scheduler widget: '{0}'",
  E1032: "Unknown start date in an appointment: '{0}'",
  E1033: "Unknown step in the date navigator: '{0}'",
  E1034: "The browser does not implement an API for saving files",
  E1035: "The editor cannot be created: {0}",
  E1037: "Invalid structure of grouped data",
  E1038: "The browser does not support local storages for local web pages",
  E1039: "A cell's position cannot be calculated",
  E1040: "The '{0}' key value is not unique within the data array",
  E1041: "The '{0}' script is referenced after the DevExtreme scripts or not referenced at all",
  E1042: "{0} requires the key field to be specified",
  E1043: "Changes cannot be processed due to the incorrectly set key",
  E1044: "The key field specified by the keyExpr option does not match the key field specified in the data store",
  E1045: "Editing requires the key field to be specified in the data store",
  E1046: "The '{0}' key field is not found in data objects",
  E1047: 'The "{0}" field is not found in the fields array',
  E1048: 'The "{0}" operation is not found in the filterOperations array',
  E1049: "Column '{0}': filtering is allowed but the 'dataField' or 'name' option is not specified",
  E1050: "The validationRules option does not apply to third-party editors defined in the editCellTemplate",
  E1051: `HtmlEditor's valueType is "{0}", but the {0} converter was not imported.`,
  E1052: '{0} should have the "dataSource" option specified',
  E1053: 'The "buttons" option accepts an array that contains only objects or string values',
  E1054: "All text editor buttons must have names",
  E1055: 'One or several text editor buttons have invalid or non-unique "name" values',
  E1056: 'The {0} widget does not support buttons of the "{1}" type',
  E1058: 'The "startDayHour" and "endDayHour" options must be integers in the [0, 24] range, with "endDayHour" being greater than "startDayHour".',
  E1059: "The following column names are not unique: {0}",
  E1060: "All editable columns must have names",
  E1061: 'The "offset" option must be an integer in the [-1440, 1440] range, divisible by 5 without a remainder.',
  E1062: 'The "cellDuration" must be a positive integer, evenly dividing the ("endDayHour" - "startDayHour") interval into minutes.',
  W1001: 'The "key" option cannot be modified after initialization',
  W1002: "An item with the key '{0}' does not exist",
  W1003: "A group with the key '{0}' in which you are trying to select items does not exist",
  W1004: "The item '{0}' you are trying to select in the group '{1}' does not exist",
  W1005: "Due to column data types being unspecified, data has been loaded twice in order to apply initial filter settings. To resolve this issue, specify data types for all grid columns.",
  W1006: "The map service returned the following error: '{0}'",
  W1007: "No item with key {0} was found in the data source, but this key was used as the parent key for item {1}",
  W1008: "Cannot scroll to the '{0}' date because it does not exist on the current view",
  W1009: "Searching works only if data is specified using the dataSource option",
  W1010: "The capability to select all items works with source data of plain structure only",
  W1011: 'The "keyExpr" option is not applied when dataSource is not an array',
  W1012: "The '{0}' key field is not found in data objects",
  W1013: 'The "message" field in the dialog component was renamed to "messageHtml". Change your code correspondingly. In addition, if you used HTML code in the message, make sure that it is secure',
  W1014: "The Floating Action Button exceeds the recommended speed dial action count. If you need to display more speed dial actions, increase the maxSpeedDialActionCount option value in the global config.",
  W1016: "The '{0}' field in the HTML Editor toolbar item configuration was renamed to '{1}'. Please make a corresponding change in your code.",
  W1017: "The 'key' property is not specified for a lookup data source. Please specify it to prevent requests for the entire dataset when users filter data.",
  W1018: "Infinite scrolling may not work properly with multiple selection. To use these features together, set 'selection.deferred' to true or set 'selection.selectAllMode' to 'page'.",
  W1019: "Filter query string exceeds maximum length limit of {0} characters.",
  W1020: "hideEvent is ignored when the shading property is true",
  W1021: `The '{0}' is not rendered because none of the DOM elements match the value of the "container" property.`,
  W1022: "{0} JSON parsing error: '{1}'",
  W1023: "Appointments require unique keys. Otherwise, the agenda view may not work correctly.",
  W1024: "The client-side export is enabled. Implement the 'onExporting' function.",
  W1025: "'scrolling.mode' is set to 'virtual' or 'infinite'. Specify the height of the component."
});

// node_modules/devextreme/esm/ui/themes.js
var window3 = getWindow();
var ready2 = ready_callbacks_default.add;
var viewPort = value;
var viewPortChanged = changeCallback;
var initDeferred = new Deferred();
var DX_LINK_SELECTOR = "link[rel=dx-theme]";
var THEME_ATTR = "data-theme";
var ACTIVE_ATTR = "data-active";
var DX_HAIRLINES_CLASS = "dx-hairlines";
var ANY_THEME = "any";
var context;
var $activeThemeLink;
var knownThemes;
var currentThemeName;
var pendingThemeName;
var defaultTimeout = 15e3;
var THEME_MARKER_PREFIX = "dx.";
function readThemeMarker() {
  if (!hasWindow()) {
    return null;
  }
  const element = renderer_default("<div>", context).addClass("dx-theme-marker").appendTo(context.documentElement);
  let result;
  try {
    result = window3.getComputedStyle(element.get(0)).fontFamily;
    if (!result) {
      return null;
    }
    result = result.replace(/["']/g, "");
    if (result.substr(0, THEME_MARKER_PREFIX.length) !== THEME_MARKER_PREFIX) {
      return null;
    }
    return result.substr(THEME_MARKER_PREFIX.length);
  } finally {
    element.remove();
  }
}
function waitForThemeLoad(themeName) {
  let waitStartTime;
  let timerId;
  let intervalCleared = true;
  pendingThemeName = themeName;
  function handleLoaded() {
    pendingThemeName = null;
    clearInterval(timerId);
    intervalCleared = true;
    themeReadyCallback.fire();
    themeReadyCallback.empty();
    initDeferred.resolve();
  }
  if (isPendingThemeLoaded() || !defaultTimeout) {
    handleLoaded();
  } else {
    if (!intervalCleared) {
      if (pendingThemeName) {
        pendingThemeName = themeName;
      }
      return;
    }
    waitStartTime = Date.now();
    intervalCleared = false;
    timerId = setInterval(function() {
      const isLoaded = isPendingThemeLoaded();
      const isTimeout = !isLoaded && Date.now() - waitStartTime > defaultTimeout;
      if (isTimeout) {
        ui_errors_default.log("W0004", pendingThemeName);
      }
      if (isLoaded || isTimeout) {
        handleLoaded();
      }
    }, 10);
  }
}
function isPendingThemeLoaded() {
  if (!pendingThemeName) {
    return true;
  }
  const anyThemePending = pendingThemeName === ANY_THEME;
  if ("resolved" === initDeferred.state() && anyThemePending) {
    return true;
  }
  const themeMarker = readThemeMarker();
  if (themeMarker && anyThemePending) {
    return true;
  }
  return themeMarker === pendingThemeName;
}
function processMarkup() {
  const $allThemeLinks = renderer_default(DX_LINK_SELECTOR, context);
  if (!$allThemeLinks.length) {
    return;
  }
  knownThemes = {};
  $activeThemeLink = renderer_default(parseHTML("<link rel=stylesheet>"), context);
  $allThemeLinks.each(function() {
    const link = renderer_default(this, context);
    const fullThemeName = link.attr(THEME_ATTR);
    const url = link.attr("href");
    const isActive = "true" === link.attr(ACTIVE_ATTR);
    knownThemes[fullThemeName] = {
      url,
      isActive
    };
  });
  $allThemeLinks.last().after($activeThemeLink);
  $allThemeLinks.remove();
}
function resolveFullThemeName(desiredThemeName) {
  const desiredThemeParts = desiredThemeName ? desiredThemeName.split(".") : [];
  let result = null;
  if (knownThemes) {
    if (desiredThemeName in knownThemes) {
      return desiredThemeName;
    }
    each(knownThemes, function(knownThemeName, themeData) {
      const knownThemeParts = knownThemeName.split(".");
      if (desiredThemeParts[0] && knownThemeParts[0] !== desiredThemeParts[0]) {
        return;
      }
      if (desiredThemeParts[1] && desiredThemeParts[1] !== knownThemeParts[1]) {
        return;
      }
      if (desiredThemeParts[2] && desiredThemeParts[2] !== knownThemeParts[2]) {
        return;
      }
      if (!result || themeData.isActive) {
        result = knownThemeName;
      }
      if (themeData.isActive) {
        return false;
      }
    });
  }
  return result;
}
function initContext(newContext) {
  try {
    if (newContext !== context) {
      knownThemes = null;
    }
  } catch (x) {
    knownThemes = null;
  }
  context = newContext;
}
function init(options) {
  options = options || {};
  initContext(options.context || dom_adapter_default.getDocument());
  if (!context) {
    return;
  }
  processMarkup();
  currentThemeName = void 0;
  current(options);
}
function current(options) {
  if (!arguments.length) {
    currentThemeName = currentThemeName || readThemeMarker();
    return currentThemeName;
  }
  detachCssClasses(viewPort());
  options = options || {};
  if ("string" === typeof options) {
    options = {
      theme: options
    };
  }
  const isAutoInit = options._autoInit;
  const loadCallback = options.loadCallback;
  let currentThemeData;
  currentThemeName = resolveFullThemeName(options.theme || currentThemeName);
  if (currentThemeName) {
    currentThemeData = knownThemes[currentThemeName];
  }
  if (loadCallback) {
    themeReadyCallback.add(loadCallback);
  }
  if (currentThemeData) {
    $activeThemeLink.attr("href", knownThemes[currentThemeName].url);
    if (themeReadyCallback.has() || "resolved" !== initDeferred.state() || options._forceTimeout) {
      waitForThemeLoad(currentThemeName);
    }
  } else if (isAutoInit) {
    if (hasWindow()) {
      waitForThemeLoad(ANY_THEME);
    }
    themeReadyCallback.fire();
    themeReadyCallback.empty();
  } else {
    throw ui_errors_default.Error("E0021", currentThemeName);
  }
  initDeferred.done(() => attachCssClasses(originalViewPort(), currentThemeName));
}
function getCssClasses(themeName) {
  themeName = themeName || current();
  const result = [];
  const themeNameParts = themeName && themeName.split(".");
  if (themeNameParts) {
    result.push("dx-theme-" + themeNameParts[0], "dx-theme-" + themeNameParts[0] + "-typography");
    if (themeNameParts.length > 1) {
      result.push("dx-color-scheme-" + themeNameParts[1] + (isMaterialBased(themeName) ? "-" + themeNameParts[2] : ""));
    }
  }
  return result;
}
var themeClasses;
function attachCssClasses(element, themeName) {
  themeClasses = getCssClasses(themeName).join(" ");
  renderer_default(element).addClass(themeClasses);
  !function() {
    const pixelRatio = hasWindow() && window3.devicePixelRatio;
    if (!pixelRatio || pixelRatio < 2) {
      return;
    }
    const $tester = renderer_default("<div>");
    $tester.css("border", ".5px solid transparent");
    renderer_default("body").append($tester);
    if (1 === getOuterHeight($tester)) {
      renderer_default(element).addClass(DX_HAIRLINES_CLASS);
      themeClasses += " " + DX_HAIRLINES_CLASS;
    }
    $tester.remove();
  }();
}
function detachCssClasses(element) {
  renderer_default(element).removeClass(themeClasses);
}
function isTheme(themeRegExp, themeName) {
  if (!themeName) {
    themeName = currentThemeName || readThemeMarker();
  }
  return new RegExp(themeRegExp).test(themeName);
}
function isMaterialBased(themeName) {
  return isMaterial(themeName) || isFluent(themeName);
}
function isMaterial(themeName) {
  return isTheme("material", themeName);
}
function isFluent(themeName) {
  return isTheme("fluent", themeName);
}
function isGeneric(themeName) {
  return isTheme("generic", themeName);
}
function isCompact(themeName) {
  return isTheme("compact", themeName);
}
function isWebFontLoaded(text, fontWeight) {
  const document2 = dom_adapter_default.getDocument();
  const testElement = document2.createElement("span");
  testElement.style.position = "absolute";
  testElement.style.top = "-9999px";
  testElement.style.left = "-9999px";
  testElement.style.visibility = "hidden";
  testElement.style.fontFamily = "Arial";
  testElement.style.fontSize = "250px";
  testElement.style.fontWeight = fontWeight;
  testElement.innerHTML = text;
  document2.body.appendChild(testElement);
  const etalonFontWidth = testElement.offsetWidth;
  testElement.style.fontFamily = "Roboto, RobotoFallback, Arial";
  const testedFontWidth = testElement.offsetWidth;
  testElement.parentNode.removeChild(testElement);
  return etalonFontWidth !== testedFontWidth;
}
function waitWebFont(text, fontWeight) {
  return new Promise((resolve) => {
    const clear = () => {
      clearInterval(intervalId);
      clearTimeout(timeoutId);
      resolve();
    };
    const intervalId = setInterval(() => {
      if (isWebFontLoaded(text, fontWeight)) {
        clear();
      }
    }, 15);
    const timeoutId = setTimeout(clear, 2e3);
  });
}
function autoInit() {
  init({
    _autoInit: true,
    _forceTimeout: true
  });
  if (renderer_default(DX_LINK_SELECTOR, context).length) {
    throw ui_errors_default.Error("E0022");
  }
}
if (hasWindow()) {
  autoInit();
} else {
  ready2(autoInit);
}
viewPortChanged.add(function(viewPort2, prevViewPort) {
  initDeferred.done(function() {
    detachCssClasses(prevViewPort);
    attachCssClasses(viewPort2);
  });
});
devices_default.changed.add(function() {
  init({
    _autoInit: true
  });
});

// node_modules/devextreme/esm/core/element.js
function getPublicElementNonJquery(element) {
  if (element && element.get) {
    return element.get(0);
  }
  return element;
}
var strategy = getPublicElementNonJquery;
function getPublicElement(element) {
  return strategy(element);
}

// node_modules/devextreme/esm/animation/translator.js
init_renderer();
init_element_data();
init_type();
var TRANSFORM_MATRIX_REGEX = /matrix(3d)?\((.+?)\)/;
var TRANSLATE_REGEX = /translate(?:3d)?\((.+?)\)/;
var locate = function($element) {
  $element = renderer_default($element);
  const translate = getTranslate($element);
  return {
    left: translate.x,
    top: translate.y
  };
};
function isPercentValue(value2) {
  return "string" === type(value2) && "%" === value2[value2.length - 1];
}
function cacheTranslate($element, translate) {
  if ($element.length) {
    data($element.get(0), "dxTranslator", translate);
  }
}
var clearCache = function($element) {
  if ($element.length) {
    removeData($element.get(0), "dxTranslator");
  }
};
var getTranslateCss = function(translate) {
  translate.x = translate.x || 0;
  translate.y = translate.y || 0;
  const xValueString = isPercentValue(translate.x) ? translate.x : translate.x + "px";
  const yValueString = isPercentValue(translate.y) ? translate.y : translate.y + "px";
  return "translate(" + xValueString + ", " + yValueString + ")";
};
var getTranslate = function($element) {
  let result = $element.length ? data($element.get(0), "dxTranslator") : null;
  if (!result) {
    const transformValue = $element.css("transform") || getTranslateCss({
      x: 0,
      y: 0
    });
    let matrix = transformValue.match(TRANSFORM_MATRIX_REGEX);
    const is3D = matrix && matrix[1];
    if (matrix) {
      matrix = matrix[2].split(",");
      if ("3d" === is3D) {
        matrix = matrix.slice(12, 15);
      } else {
        matrix.push(0);
        matrix = matrix.slice(4, 7);
      }
    } else {
      matrix = [0, 0, 0];
    }
    result = {
      x: parseFloat(matrix[0]),
      y: parseFloat(matrix[1]),
      z: parseFloat(matrix[2])
    };
    cacheTranslate($element, result);
  }
  return result;
};
var move = function($element, position) {
  $element = renderer_default($element);
  const left = position.left;
  const top = position.top;
  let translate;
  if (void 0 === left) {
    translate = getTranslate($element);
    translate.y = top || 0;
  } else if (void 0 === top) {
    translate = getTranslate($element);
    translate.x = left || 0;
  } else {
    translate = {
      x: left || 0,
      y: top || 0,
      z: 0
    };
    cacheTranslate($element, translate);
  }
  $element.css({
    transform: getTranslateCss(translate)
  });
  if (isPercentValue(left) || isPercentValue(top)) {
    clearCache($element);
  }
};
var resetPosition = function($element, finishTransition) {
  $element = renderer_default($element);
  let originalTransition;
  const stylesConfig = {
    left: 0,
    top: 0,
    transform: "none"
  };
  if (finishTransition) {
    originalTransition = $element.css("transition");
    stylesConfig.transition = "none";
  }
  $element.css(stylesConfig);
  clearCache($element);
  if (finishTransition) {
    $element.get(0).offsetHeight;
    $element.css("transition", originalTransition);
  }
};
var parseTranslate = function(translateString) {
  let result = translateString.match(TRANSLATE_REGEX);
  if (!result || !result[1]) {
    return;
  }
  result = result[1].split(",");
  result = {
    x: parseFloat(result[0]),
    y: parseFloat(result[1]),
    z: parseFloat(result[2])
  };
  return result;
};

// node_modules/devextreme/esm/core/utils/position.js
init_config();
init_type();
var getDefaultAlignment = (isRtlEnabled) => {
  const rtlEnabled = isRtlEnabled ?? config_default().rtlEnabled;
  return rtlEnabled ? "right" : "left";
};
var getBoundingRect = (element) => {
  var _element$getBoundingC;
  if (isWindow(element)) {
    return {
      width: element.outerWidth,
      height: element.outerHeight
    };
  }
  return null === (_element$getBoundingC = element.getBoundingClientRect) || void 0 === _element$getBoundingC ? void 0 : _element$getBoundingC.call(element);
};

// node_modules/devextreme/esm/core/utils/dom.js
init_dom_adapter();
init_renderer();
init_iterator();
init_type();
init_window();
var window4 = getWindow();
var getRootNodeHost = (element) => {
  if (!element.getRootNode) {
    return;
  }
  const host = element.getRootNode().host;
  if (isString(host)) {
    return;
  }
  return host;
};
var resetActiveElement = () => {
  const activeElement = dom_adapter_default.getActiveElement();
  if (activeElement && activeElement !== dom_adapter_default.getBody()) {
    var _activeElement$blur;
    null === (_activeElement$blur = activeElement.blur) || void 0 === _activeElement$blur || _activeElement$blur.call(activeElement);
  }
};
var clearSelection = () => {
  const selection = window4.getSelection();
  if (!selection) {
    return;
  }
  if ("Caret" === selection.type) {
    return;
  }
  if (selection.empty) {
    selection.empty();
  } else if (selection.removeAllRanges) {
    try {
      selection.removeAllRanges();
    } catch (e) {
    }
  }
};
var closestCommonParent = (startTarget, endTarget) => {
  const $startTarget = renderer_default(startTarget);
  const $endTarget = renderer_default(endTarget);
  if ($startTarget[0] === $endTarget[0]) {
    return $startTarget[0];
  }
  const $startParents = $startTarget.parents();
  const $endParents = $endTarget.parents();
  const startingParent = Math.min($startParents.length, $endParents.length);
  for (let i = -startingParent; i < 0; i++) {
    if ($startParents.get(i) === $endParents.get(i)) {
      return $startParents.get(i);
    }
  }
};
var normalizeTemplateElement = (element) => {
  let $element = isDefined(element) && (element.nodeType || isRenderer(element)) ? renderer_default(element) : renderer_default("<div>").html(element).contents();
  if (1 === $element.length) {
    if ($element.is("script")) {
      $element = normalizeTemplateElement($element.html().trim());
    } else if ($element.is("table")) {
      $element = $element.children("tbody").contents();
    }
  }
  return $element;
};
var clipboardText = (event, text) => {
  const clipboard = event.originalEvent && event.originalEvent.clipboardData || window4.clipboardData;
  if (!text) {
    return clipboard && clipboard.getData("Text");
  }
  clipboard && clipboard.setData("Text", text);
};
var contains = (container, element) => {
  if (!element) {
    return false;
  }
  if (isWindow(container)) {
    return contains(container.document, element);
  }
  return container.contains(element) || contains(container, getRootNodeHost(element));
};
var createTextElementHiddenCopy = (element, text, options) => {
  const elementStyles = window4.getComputedStyle(renderer_default(element).get(0));
  const includePaddings = options && options.includePaddings;
  return renderer_default("<div>").text(text).css({
    fontStyle: elementStyles.fontStyle,
    fontVariant: elementStyles.fontVariant,
    fontWeight: elementStyles.fontWeight,
    fontSize: elementStyles.fontSize,
    fontFamily: elementStyles.fontFamily,
    letterSpacing: elementStyles.letterSpacing,
    border: elementStyles.border,
    paddingTop: includePaddings ? elementStyles.paddingTop : "",
    paddingRight: includePaddings ? elementStyles.paddingRight : "",
    paddingBottom: includePaddings ? elementStyles.paddingBottom : "",
    paddingLeft: includePaddings ? elementStyles.paddingLeft : "",
    visibility: "hidden",
    whiteSpace: "pre",
    position: "absolute",
    float: "left"
  });
};
var insertBefore = (element, newElement) => {
  if (newElement) {
    dom_adapter_default.insertElement(element.parentNode, newElement, element);
  }
  return element;
};
var replaceWith = (element, newElement) => {
  if (!(newElement && newElement[0])) {
    return;
  }
  if (newElement.is(element)) {
    return element;
  }
  each(newElement, (_, currentElement) => {
    insertBefore(element[0], currentElement);
  });
  element.remove();
  return newElement;
};
var isElementInDom = ($element) => {
  const element = null === $element || void 0 === $element ? void 0 : $element.get(0);
  const shadowHost = null === element || void 0 === element ? void 0 : element.getRootNode().host;
  return !!renderer_default(shadowHost || element).closest(getWindow().document).length;
};

// node_modules/devextreme/esm/events/visibility_change.js
init_renderer();
init_events_engine();
var triggerVisibilityChangeEvent = function(eventName) {
  return function(element) {
    const $element = renderer_default(element || "body");
    const changeHandlers = $element.filter(".dx-visibility-change-handler").add($element.find(".dx-visibility-change-handler"));
    for (let i = 0; i < changeHandlers.length; i++) {
      events_engine_default.triggerHandler(changeHandlers[i], eventName);
    }
  };
};
var triggerShownEvent = triggerVisibilityChangeEvent("dxshown");
var triggerHidingEvent = triggerVisibilityChangeEvent("dxhiding");
var triggerResizeEvent = triggerVisibilityChangeEvent("dxresize");

// node_modules/devextreme/esm/core/templates/template_base.js
init_renderer();
init_dom_adapter();
init_callbacks();
init_errors();
var renderedCallbacks = callbacks_default({
  syncStrategy: true
});
var TemplateBase = class {
  render(options) {
    options = options || {};
    const onRendered = options.onRendered;
    delete options.onRendered;
    let $result;
    if (options.renovated && options.transclude && this._element) {
      $result = renderer_default("<div>").append(this._element).contents();
    } else {
      $result = this._renderCore(options);
    }
    this._ensureResultInContainer($result, options.container);
    renderedCallbacks.fire($result, options.container);
    onRendered && onRendered();
    return $result;
  }
  _ensureResultInContainer($result, container) {
    if (!container) {
      return;
    }
    const $container = renderer_default(container);
    const resultInContainer = contains($container.get(0), $result.get(0));
    $container.append($result);
    if (resultInContainer) {
      return;
    }
    const resultInBody = contains(dom_adapter_default.getBody(), $container.get(0));
    if (!resultInBody) {
      return;
    }
    triggerShownEvent($result);
  }
  _renderCore() {
    throw errors_default.Error("E0001");
  }
};

// node_modules/devextreme/esm/events/core/emitter.js
init_renderer();
init_common();
init_class();
init_callbacks();
init_extend();
var Emitter = class_default.inherit({
  ctor: function(element) {
    this._$element = renderer_default(element);
    this._cancelCallback = callbacks_default();
    this._acceptCallback = callbacks_default();
  },
  getElement: function() {
    return this._$element;
  },
  validate: function(e) {
    return !isDxMouseWheelEvent(e);
  },
  validatePointers: function(e) {
    return 1 === hasTouches(e);
  },
  allowInterruptionByMouseWheel: function() {
    return true;
  },
  configure: function(data2) {
    extend(this, data2);
  },
  addCancelCallback: function(callback) {
    this._cancelCallback.add(callback);
  },
  removeCancelCallback: function() {
    this._cancelCallback.empty();
  },
  _cancel: function(e) {
    this._cancelCallback.fire(this, e);
  },
  addAcceptCallback: function(callback) {
    this._acceptCallback.add(callback);
  },
  removeAcceptCallback: function() {
    this._acceptCallback.empty();
  },
  _accept: function(e) {
    this._acceptCallback.fire(this, e);
  },
  _requestAccept: function(e) {
    this._acceptRequestEvent = e;
  },
  _forgetAccept: function() {
    this._accept(this._acceptRequestEvent);
    this._acceptRequestEvent = null;
  },
  start: noop,
  move: noop,
  end: noop,
  cancel: noop,
  reset: function() {
    if (this._acceptRequestEvent) {
      this._accept(this._acceptRequestEvent);
    }
  },
  _fireEvent: function(eventName, e, params) {
    const eventData2 = extend({
      type: eventName,
      originalEvent: e,
      target: this._getEmitterTarget(e),
      delegateTarget: this.getElement().get(0)
    }, params);
    e = fireEvent(eventData2);
    if (e.cancel) {
      this._cancel(e);
    }
    return e;
  },
  _getEmitterTarget: function(e) {
    return (this.delegateSelector ? renderer_default(e.target).closest(this.delegateSelector) : this.getElement()).get(0);
  },
  dispose: noop
});
var emitter_default = Emitter;

// node_modules/devextreme/esm/events/core/emitter_registrator.js
init_renderer();
init_ready_callbacks();
init_dom_adapter();
init_events_engine();
init_element_data();
init_class();
init_extend();
init_iterator();

// node_modules/devextreme/esm/events/core/wheel.js
init_renderer();
init_events_engine();
var EVENT_NAME = "dxmousewheel";
var wheel = {
  setup: function(element) {
    const $element = renderer_default(element);
    events_engine_default.on($element, addNamespace2("wheel", "dxWheel"), wheel._wheelHandler.bind(wheel));
  },
  teardown: function(element) {
    events_engine_default.off(element, ".dxWheel");
  },
  _wheelHandler: function(e) {
    const {
      deltaMode,
      deltaY,
      deltaX,
      deltaZ
    } = e.originalEvent;
    fireEvent({
      type: EVENT_NAME,
      originalEvent: e,
      delta: this._normalizeDelta(deltaY, deltaMode),
      deltaX,
      deltaY,
      deltaZ,
      deltaMode,
      pointerType: "mouse"
    });
    e.stopPropagation();
  },
  _normalizeDelta(delta) {
    let deltaMode = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
    if (0 === deltaMode) {
      return -delta;
    } else {
      return -30 * delta;
    }
  }
};
event_registrator_default(EVENT_NAME, wheel);

// node_modules/devextreme/esm/events/core/emitter_registrator.js
var MANAGER_EVENT = "dxEventManager";
var EventManager = class_default.inherit({
  ctor: function() {
    this._attachHandlers();
    this.reset();
    this._proxiedCancelHandler = this._cancelHandler.bind(this);
    this._proxiedAcceptHandler = this._acceptHandler.bind(this);
  },
  _attachHandlers: function() {
    ready_callbacks_default.add(function() {
      const document2 = dom_adapter_default.getDocument();
      events_engine_default.subscribeGlobal(document2, addNamespace2(pointer_default.down, MANAGER_EVENT), this._pointerDownHandler.bind(this));
      events_engine_default.subscribeGlobal(document2, addNamespace2(pointer_default.move, MANAGER_EVENT), this._pointerMoveHandler.bind(this));
      events_engine_default.subscribeGlobal(document2, addNamespace2([pointer_default.up, pointer_default.cancel].join(" "), MANAGER_EVENT), this._pointerUpHandler.bind(this));
      events_engine_default.subscribeGlobal(document2, addNamespace2(EVENT_NAME, MANAGER_EVENT), this._mouseWheelHandler.bind(this));
    }.bind(this));
  },
  _eachEmitter: function(callback) {
    const activeEmitters = this._activeEmitters || [];
    let i = 0;
    while (activeEmitters.length > i) {
      const emitter = activeEmitters[i];
      if (false === callback(emitter)) {
        break;
      }
      if (activeEmitters[i] === emitter) {
        i++;
      }
    }
  },
  _applyToEmitters: function(method, arg) {
    this._eachEmitter(function(emitter) {
      emitter[method].call(emitter, arg);
    });
  },
  reset: function() {
    this._eachEmitter(this._proxiedCancelHandler);
    this._activeEmitters = [];
  },
  resetEmitter: function(emitter) {
    this._proxiedCancelHandler(emitter);
  },
  _pointerDownHandler: function(e) {
    if (isMouseEvent(e) && e.which > 1) {
      return;
    }
    this._updateEmitters(e);
  },
  _updateEmitters: function(e) {
    if (!this._isSetChanged(e)) {
      return;
    }
    this._cleanEmitters(e);
    this._fetchEmitters(e);
  },
  _isSetChanged: function(e) {
    const currentSet = this._closestEmitter(e);
    const previousSet = this._emittersSet || [];
    let setChanged = currentSet.length !== previousSet.length;
    each(currentSet, function(index2, emitter) {
      setChanged = setChanged || previousSet[index2] !== emitter;
      return !setChanged;
    });
    this._emittersSet = currentSet;
    return setChanged;
  },
  _closestEmitter: function(e) {
    const that = this;
    const result = [];
    let $element = renderer_default(e.target);
    function handleEmitter(_, emitter) {
      if (!!emitter && emitter.validatePointers(e) && emitter.validate(e)) {
        emitter.addCancelCallback(that._proxiedCancelHandler);
        emitter.addAcceptCallback(that._proxiedAcceptHandler);
        result.push(emitter);
      }
    }
    while ($element.length) {
      const emitters = data($element.get(0), "dxEmitter") || [];
      each(emitters, handleEmitter);
      $element = $element.parent();
    }
    return result;
  },
  _acceptHandler: function(acceptedEmitter, e) {
    const that = this;
    this._eachEmitter(function(emitter) {
      if (emitter !== acceptedEmitter) {
        that._cancelEmitter(emitter, e);
      }
    });
  },
  _cancelHandler: function(canceledEmitter, e) {
    this._cancelEmitter(canceledEmitter, e);
  },
  _cancelEmitter: function(emitter, e) {
    const activeEmitters = this._activeEmitters;
    if (e) {
      emitter.cancel(e);
    } else {
      emitter.reset();
    }
    emitter.removeCancelCallback();
    emitter.removeAcceptCallback();
    const emitterIndex = activeEmitters.indexOf(emitter);
    if (emitterIndex > -1) {
      activeEmitters.splice(emitterIndex, 1);
    }
  },
  _cleanEmitters: function(e) {
    this._applyToEmitters("end", e);
    this.reset(e);
  },
  _fetchEmitters: function(e) {
    this._activeEmitters = this._emittersSet.slice();
    this._applyToEmitters("start", e);
  },
  _pointerMoveHandler: function(e) {
    this._applyToEmitters("move", e);
  },
  _pointerUpHandler: function(e) {
    this._updateEmitters(e);
  },
  _mouseWheelHandler: function(e) {
    if (!this._allowInterruptionByMouseWheel()) {
      return;
    }
    e.pointers = [null];
    this._pointerDownHandler(e);
    this._adjustWheelEvent(e);
    this._pointerMoveHandler(e);
    e.pointers = [];
    this._pointerUpHandler(e);
  },
  _allowInterruptionByMouseWheel: function() {
    let allowInterruption = true;
    this._eachEmitter(function(emitter) {
      allowInterruption = emitter.allowInterruptionByMouseWheel() && allowInterruption;
      return allowInterruption;
    });
    return allowInterruption;
  },
  _adjustWheelEvent: function(e) {
    let closestGestureEmitter = null;
    this._eachEmitter(function(emitter) {
      if (!emitter.gesture) {
        return;
      }
      const direction2 = emitter.getDirection(e);
      if ("horizontal" !== direction2 && !e.shiftKey || "vertical" !== direction2 && e.shiftKey) {
        closestGestureEmitter = emitter;
        return false;
      }
    });
    if (!closestGestureEmitter) {
      return;
    }
    const direction = closestGestureEmitter.getDirection(e);
    const verticalGestureDirection = "both" === direction && !e.shiftKey || "vertical" === direction;
    const prop = verticalGestureDirection ? "pageY" : "pageX";
    e[prop] += e.delta;
  },
  isActive: function(element) {
    let result = false;
    this._eachEmitter(function(emitter) {
      result = result || emitter.getElement().is(element);
    });
    return result;
  }
});
var eventManager = new EventManager();
var registerEmitter = function(emitterConfig) {
  const emitterClass = emitterConfig.emitter;
  const emitterName = emitterConfig.events[0];
  const emitterEvents = emitterConfig.events;
  each(emitterEvents, function(_, eventName) {
    event_registrator_default(eventName, {
      noBubble: !emitterConfig.bubble,
      setup: function(element) {
        const subscriptions = data(element, "dxEmitterSubscription") || {};
        const emitters = data(element, "dxEmitter") || {};
        const emitter = emitters[emitterName] || new emitterClass(element);
        subscriptions[eventName] = true;
        emitters[emitterName] = emitter;
        data(element, "dxEmitter", emitters);
        data(element, "dxEmitterSubscription", subscriptions);
      },
      add: function(element, handleObj) {
        const emitters = data(element, "dxEmitter");
        const emitter = emitters[emitterName];
        emitter.configure(extend({
          delegateSelector: handleObj.selector
        }, handleObj.data), handleObj.type);
      },
      teardown: function(element) {
        const subscriptions = data(element, "dxEmitterSubscription");
        const emitters = data(element, "dxEmitter");
        const emitter = emitters[emitterName];
        delete subscriptions[eventName];
        let disposeEmitter = true;
        each(emitterEvents, function(_2, eventName2) {
          disposeEmitter = disposeEmitter && !subscriptions[eventName2];
          return disposeEmitter;
        });
        if (disposeEmitter) {
          if (eventManager.isActive(element)) {
            eventManager.resetEmitter(emitter);
          }
          emitter && emitter.dispose();
          delete emitters[emitterName];
        }
      }
    });
  });
};
var emitter_registrator_default = registerEmitter;

// node_modules/devextreme/esm/events/click.js
init_renderer();
init_events_engine();
init_dom_adapter();

// node_modules/devextreme/esm/animation/frame.js
init_window();
init_call_once();
var window5 = hasWindow() ? getWindow() : {};
var FRAME_ANIMATION_STEP_TIME = 1e3 / 60;
var request = function(callback) {
  return setTimeout(callback, 16.666666666666668);
};
var cancel = function(requestID) {
  clearTimeout(requestID);
};
var setAnimationFrameMethods = call_once_default(function() {
  const nativeRequest = window5.requestAnimationFrame || window5.webkitRequestAnimationFrame || window5.mozRequestAnimationFrame || window5.oRequestAnimationFrame || window5.msRequestAnimationFrame;
  const nativeCancel = window5.cancelAnimationFrame || window5.webkitCancelAnimationFrame || window5.mozCancelAnimationFrame || window5.oCancelAnimationFrame || window5.msCancelAnimationFrame;
  if (nativeRequest && nativeCancel) {
    request = nativeRequest;
    cancel = nativeCancel;
  }
});
function requestAnimationFrame() {
  setAnimationFrameMethods();
  return request.apply(window5, arguments);
}
function cancelAnimationFrame() {
  setAnimationFrameMethods();
  cancel.apply(window5, arguments);
}

// node_modules/devextreme/esm/events/utils/event_nodes_disposing.js
init_events_engine();
function nodesByEvent(event) {
  return event && [event.target, event.delegateTarget, event.relatedTarget, event.currentTarget].filter((node) => !!node);
}
var subscribeNodesDisposing = (event, callback) => {
  events_engine_default.one(nodesByEvent(event), removeEvent, callback);
};
var unsubscribeNodesDisposing = (event, callback) => {
  events_engine_default.off(nodesByEvent(event), removeEvent, callback);
};

// node_modules/devextreme/esm/events/click.js
init_event_target();
var CLICK_EVENT_NAME = "dxclick";
var prevented = null;
var lastFiredEvent = null;
var onNodeRemove = () => {
  lastFiredEvent = null;
};
var clickHandler = function(e) {
  const originalEvent = e.originalEvent;
  const eventAlreadyFired = lastFiredEvent === originalEvent || originalEvent && originalEvent.DXCLICK_FIRED;
  const leftButton = !e.which || 1 === e.which;
  if (leftButton && !prevented && !eventAlreadyFired) {
    if (originalEvent) {
      originalEvent.DXCLICK_FIRED = true;
    }
    unsubscribeNodesDisposing(lastFiredEvent, onNodeRemove);
    lastFiredEvent = originalEvent;
    subscribeNodesDisposing(lastFiredEvent, onNodeRemove);
    fireEvent({
      type: "dxclick",
      originalEvent: e
    });
  }
};
var ClickEmitter = emitter_default.inherit({
  ctor: function(element) {
    this.callBase(element);
    events_engine_default.on(this.getElement(), "click", clickHandler);
  },
  start: function(e) {
    prevented = null;
  },
  cancel: function() {
    prevented = true;
  },
  dispose: function() {
    events_engine_default.off(this.getElement(), "click", clickHandler);
  }
});
!function() {
  const desktopDevice = devices_default.real().generic;
  if (!desktopDevice) {
    let startTarget = null;
    let blurPrevented = false;
    const isInput = function(element) {
      return renderer_default(element).is("input, textarea, select, button ,:focus, :focus *");
    };
    const pointerDownHandler = function(e) {
      startTarget = e.target;
      blurPrevented = e.isDefaultPrevented();
    };
    const getTarget = function(e) {
      const target = getEventTarget(e);
      return renderer_default(target);
    };
    const clickHandler2 = function(e) {
      const $target = getTarget(e);
      if (!blurPrevented && startTarget && !$target.is(startTarget) && !renderer_default(startTarget).is("label") && isInput($target)) {
        resetActiveElement();
      }
      startTarget = null;
      blurPrevented = false;
    };
    const NATIVE_CLICK_FIXER_NAMESPACE = "NATIVE_CLICK_FIXER";
    const document2 = dom_adapter_default.getDocument();
    events_engine_default.subscribeGlobal(document2, addNamespace2(pointer_default.down, NATIVE_CLICK_FIXER_NAMESPACE), pointerDownHandler);
    events_engine_default.subscribeGlobal(document2, addNamespace2("click", NATIVE_CLICK_FIXER_NAMESPACE), clickHandler2);
  }
}();
emitter_registrator_default({
  emitter: ClickEmitter,
  bubble: true,
  events: ["dxclick"]
});

// node_modules/devextreme/esm/core/utils/array.js
init_type();
init_object();
init_config();
function createOccurrenceMap(array) {
  return array.reduce((map, value2) => {
    const count = (map.get(value2) ?? 0) + 1;
    map.set(value2, count);
    return map;
  }, /* @__PURE__ */ new Map());
}
var wrapToArray = function(item) {
  return Array.isArray(item) ? item : [item];
};
var getUniqueValues = function(values) {
  return [...new Set(values)];
};
var getIntersection = function(firstArray, secondArray) {
  const toRemoveMap = createOccurrenceMap(secondArray);
  return firstArray.filter((value2) => {
    const occurrencesCount = toRemoveMap.get(value2);
    occurrencesCount && toRemoveMap.set(value2, occurrencesCount - 1);
    return occurrencesCount;
  });
};
var removeDuplicates = function() {
  let from = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
  let toRemove = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
  const toRemoveMap = createOccurrenceMap(toRemove);
  return from.filter((value2) => {
    const occurrencesCount = toRemoveMap.get(value2);
    occurrencesCount && toRemoveMap.set(value2, occurrencesCount - 1);
    return !occurrencesCount;
  });
};
var normalizeIndexes = function(items, indexPropName, currentItem, needIndexCallback) {
  const indexedItems = {};
  const {
    useLegacyVisibleIndex
  } = config_default();
  let currentIndex = 0;
  const shouldUpdateIndex = (item) => !isDefined(item[indexPropName]) && (!needIndexCallback || needIndexCallback(item));
  items.forEach((item) => {
    const index2 = item[indexPropName];
    if (index2 >= 0) {
      indexedItems[index2] = indexedItems[index2] || [];
      if (item === currentItem) {
        indexedItems[index2].unshift(item);
      } else {
        indexedItems[index2].push(item);
      }
    } else {
      item[indexPropName] = void 0;
    }
  });
  if (!useLegacyVisibleIndex) {
    items.forEach((item) => {
      if (shouldUpdateIndex(item)) {
        while (indexedItems[currentIndex]) {
          currentIndex++;
        }
        indexedItems[currentIndex] = [item];
        currentIndex++;
      }
    });
  }
  currentIndex = 0;
  orderEach(indexedItems, function(index2, items2) {
    items2.forEach((item) => {
      if (index2 >= 0) {
        item[indexPropName] = currentIndex++;
      }
    });
  });
  if (useLegacyVisibleIndex) {
    items.forEach((item) => {
      if (shouldUpdateIndex(item)) {
        item[indexPropName] = currentIndex++;
      }
    });
  }
};
var groupBy = (array, getGroupName) => array.reduce((groupedResult, item) => {
  const groupName = getGroupName(item);
  groupedResult[groupName] = groupedResult[groupName] ?? [];
  groupedResult[groupName].push(item);
  return groupedResult;
}, {});

// node_modules/devextreme/esm/core/templates/child_default_template.js
var ChildDefaultTemplate = class extends TemplateBase {
  constructor(name) {
    super();
    this.name = name;
  }
};

// node_modules/devextreme/esm/core/templates/empty_template.js
init_renderer();
var EmptyTemplate = class extends TemplateBase {
  _renderCore() {
    return renderer_default();
  }
};

// node_modules/devextreme/esm/core/utils/comparator.js
init_dom_adapter();
init_data();
init_type();
var hasNegation = function(oldValue, newValue) {
  return 1 / oldValue === 1 / newValue;
};
var equals = function(oldValue, newValue) {
  oldValue = toComparable(oldValue, true);
  newValue = toComparable(newValue, true);
  if (oldValue && newValue && isRenderer(oldValue) && isRenderer(newValue)) {
    return newValue.is(oldValue);
  }
  const oldValueIsNaN = oldValue !== oldValue;
  const newValueIsNaN = newValue !== newValue;
  if (oldValueIsNaN && newValueIsNaN) {
    return true;
  }
  if (0 === oldValue && 0 === newValue) {
    return hasNegation(oldValue, newValue);
  }
  if (null === oldValue || "object" !== typeof oldValue || dom_adapter_default.isElementNode(oldValue)) {
    return oldValue === newValue;
  }
  return false;
};

// node_modules/devextreme/esm/core/options/utils.js
init_type();
init_common();
init_extend();
init_data();
var cachedGetters = {};
var convertRulesToOptions = (rules) => {
  const currentDevice = devices_default.current();
  return rules.reduce((options, _ref) => {
    let {
      device,
      options: ruleOptions
    } = _ref;
    const deviceFilter = device || {};
    const match = isFunction(deviceFilter) ? deviceFilter(currentDevice) : deviceMatch(currentDevice, deviceFilter);
    if (match) {
      extend(true, options, ruleOptions);
    }
    return options;
  }, {});
};
var normalizeOptions = (options, value2) => "string" !== typeof options ? options : {
  [options]: value2
};
var deviceMatch = (device, filter) => isEmptyObject(filter) || findBestMatches(device, [filter]).length > 0;
var getFieldName = (fullName) => fullName.substr(fullName.lastIndexOf(".") + 1);
var getParentName = (fullName) => fullName.substr(0, fullName.lastIndexOf("."));
var getNestedOptionValue = function(optionsObject, name) {
  cachedGetters[name] = cachedGetters[name] || compileGetter(name);
  return cachedGetters[name](optionsObject, {
    functionsAsIs: true
  });
};
var createDefaultOptionRules = function() {
  let options = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
  return options;
};

// node_modules/devextreme/esm/core/templates/function_template.js
var FunctionTemplate = class extends TemplateBase {
  constructor(render) {
    super();
    this._render = render;
  }
  _renderCore(options) {
    return normalizeTemplateElement(this._render(options));
  }
};

// node_modules/devextreme/esm/core/dom_component.js
init_renderer();
init_config();
init_errors();

// node_modules/devextreme/esm/core/component.js
init_config();
init_extend();

// node_modules/devextreme/esm/core/options/index.js
init_extends();
init_type();
init_common();

// node_modules/devextreme/esm/core/options/option_manager.js
init_data();
init_common();
init_extend();
init_type();
var cachedGetters2 = {};
var cachedSetters = {};
var OptionManager = class {
  constructor(options, optionsByReference) {
    this._options = options;
    this._optionsByReference = optionsByReference;
    this._changingCallback;
    this._changedCallback;
    this._namePreparedCallbacks;
  }
  _setByReference(options, rulesOptions) {
    extend(true, options, rulesOptions);
    for (const fieldName in this._optionsByReference) {
      if (Object.prototype.hasOwnProperty.call(rulesOptions, fieldName)) {
        options[fieldName] = rulesOptions[fieldName];
      }
    }
  }
  _setPreparedValue(name, value2, merge, silent) {
    const previousValue = this.get(this._options, name, false);
    if (!equals(previousValue, value2)) {
      const path = getPathParts(name);
      !silent && this._changingCallback(name, previousValue, value2);
      cachedSetters[name] = cachedSetters[name] || compileSetter(name);
      cachedSetters[name](this._options, value2, {
        functionsAsIs: true,
        merge: isDefined(merge) ? merge : !this._optionsByReference[name],
        unwrapObservables: path.length > 1 && !!this._optionsByReference[path[0]]
      });
      !silent && this._changedCallback(name, value2, previousValue);
    }
  }
  _prepareRelevantNames(options, name, value2, silent) {
    if (isPlainObject(value2)) {
      for (const valueName in value2) {
        this._prepareRelevantNames(options, `${name}.${valueName}`, value2[valueName]);
      }
    }
    this._namePreparedCallbacks(options, name, value2, silent);
  }
  get() {
    let options = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._options;
    let name = arguments.length > 1 ? arguments[1] : void 0;
    let unwrapObservables = arguments.length > 2 ? arguments[2] : void 0;
    cachedGetters2[name] = cachedGetters2[name] || compileGetter(name);
    return cachedGetters2[name](options, {
      functionsAsIs: true,
      unwrapObservables
    });
  }
  set(options, value2, merge, silent) {
    options = normalizeOptions(options, value2);
    for (const name in options) {
      this._prepareRelevantNames(options, name, options[name], silent);
    }
    for (const name in options) {
      this._setPreparedValue(name, options[name], merge, silent);
    }
  }
  onRelevantNamesPrepared(callBack) {
    this._namePreparedCallbacks = callBack;
  }
  onChanging(callBack) {
    this._changingCallback = callBack;
  }
  onChanged(callBack) {
    this._changedCallback = callBack;
  }
  dispose() {
    this._changingCallback = noop;
    this._changedCallback = noop;
  }
};

// node_modules/devextreme/esm/core/options/index.js
init_data();
init_extend();
var Options = class {
  constructor(options, defaultOptions, optionsByReference, deprecatedOptions) {
    this._deprecatedCallback;
    this._startChangeCallback;
    this._endChangeCallback;
    this._default = defaultOptions;
    this._deprecated = deprecatedOptions;
    this._deprecatedNames = [];
    this._initDeprecatedNames();
    this._optionManager = new OptionManager(options, optionsByReference);
    this._optionManager.onRelevantNamesPrepared((options2, name, value2, silent) => this._setRelevantNames(options2, name, value2, silent));
    this._cachedOptions = {};
    this._rules = [];
  }
  set _initial(value2) {
    this._initialOptions = value2;
  }
  get _initial() {
    if (!this._initialOptions) {
      const rulesOptions = this._getByRules(this.silent("defaultOptionsRules"));
      this._initialOptions = this._default;
      this._optionManager._setByReference(this._initialOptions, rulesOptions);
    }
    return this._initialOptions;
  }
  _initDeprecatedNames() {
    for (const optionName in this._deprecated) {
      this._deprecatedNames.push(optionName);
    }
  }
  _getByRules(rules) {
    rules = Array.isArray(rules) ? this._rules.concat(rules) : this._rules;
    return convertRulesToOptions(rules);
  }
  _notifyDeprecated(option) {
    const info = this._deprecated[option];
    if (info) {
      this._deprecatedCallback(option, info);
    }
  }
  _setRelevantNames(options, name, value2, silent) {
    if (name) {
      const normalizedName = this._normalizeName(name, silent);
      if (normalizedName && normalizedName !== name) {
        this._setField(options, normalizedName, value2);
        this._clearField(options, name);
      }
    }
  }
  _setField(options, fullName, value2) {
    let fieldName = "";
    let fieldObject = null;
    do {
      fieldName = fieldName ? `.${fieldName}` : "";
      fieldName = getFieldName(fullName) + fieldName;
      fullName = getParentName(fullName);
      fieldObject = fullName ? this._optionManager.get(options, fullName, false) : options;
    } while (!fieldObject);
    fieldObject[fieldName] = value2;
  }
  _clearField(options, name) {
    delete options[name];
    const previousFieldName = getParentName(name);
    const fieldObject = previousFieldName ? this._optionManager.get(options, previousFieldName, false) : options;
    if (fieldObject) {
      delete fieldObject[getFieldName(name)];
    }
  }
  _normalizeName(name, silent) {
    if (this._deprecatedNames.length && name) {
      for (let i = 0; i < this._deprecatedNames.length; i++) {
        if (this._deprecatedNames[i] === name) {
          const deprecate = this._deprecated[name];
          if (deprecate) {
            !silent && this._notifyDeprecated(name);
            return deprecate.alias || name;
          }
        }
      }
    }
    return name;
  }
  addRules(rules) {
    this._rules = rules.concat(this._rules);
  }
  applyRules(rules) {
    const options = this._getByRules(rules);
    this.silent(options);
  }
  dispose() {
    this._deprecatedCallback = noop;
    this._startChangeCallback = noop;
    this._endChangeCallback = noop;
    this._optionManager.dispose();
  }
  onChanging(callBack) {
    this._optionManager.onChanging(callBack);
  }
  onChanged(callBack) {
    this._optionManager.onChanged(callBack);
  }
  onDeprecated(callBack) {
    this._deprecatedCallback = callBack;
  }
  onStartChange(callBack) {
    this._startChangeCallback = callBack;
  }
  onEndChange(callBack) {
    this._endChangeCallback = callBack;
  }
  isInitial(name) {
    const value2 = this.silent(name);
    const initialValue = this.initial(name);
    const areFunctions = isFunction(value2) && isFunction(initialValue);
    return areFunctions ? value2.toString() === initialValue.toString() : equalByValue(value2, initialValue);
  }
  initial(name) {
    return getNestedOptionValue(this._initial, name);
  }
  option(options, value2) {
    const isGetter = arguments.length < 2 && "object" !== type(options);
    if (isGetter) {
      return this._optionManager.get(void 0, this._normalizeName(options));
    } else {
      this._startChangeCallback();
      try {
        this._optionManager.set(options, value2);
      } finally {
        this._endChangeCallback();
      }
    }
  }
  silent(options, value2) {
    const isGetter = arguments.length < 2 && "object" !== type(options);
    if (isGetter) {
      return this._optionManager.get(void 0, options, void 0, true);
    } else {
      this._optionManager.set(options, value2, void 0, true);
    }
  }
  reset(name) {
    if (name) {
      const fullPath = getPathParts(name);
      const value2 = fullPath.reduce((value3, field) => value3 ? value3[field] : this.initial(field), null);
      const defaultValue = isObject(value2) ? _extends({}, value2) : value2;
      this._optionManager.set(name, defaultValue, false);
    }
  }
  getAliasesByName(name) {
    return Object.keys(this._deprecated).filter((aliasName) => name === this._deprecated[aliasName].alias);
  }
  isDeprecated(name) {
    return Object.prototype.hasOwnProperty.call(this._deprecated, name);
  }
  cache(name, options) {
    const isGetter = arguments.length < 2;
    if (isGetter) {
      return this._cachedOptions[name];
    } else {
      this._cachedOptions[name] = extend(this._cachedOptions[name], options);
    }
  }
};

// node_modules/devextreme/esm/core/component.js
init_class();

// node_modules/devextreme/esm/core/action.js
init_renderer();
init_window();
init_type();
init_iterator();
var Action = class _Action {
  constructor(action, config) {
    config = config || {};
    this._action = action;
    this._context = config.context || getWindow();
    this._beforeExecute = config.beforeExecute;
    this._afterExecute = config.afterExecute;
    this._component = config.component;
    this._validatingTargetName = config.validatingTargetName;
    const excludeValidators = this._excludeValidators = {};
    if (config.excludeValidators) {
      for (let i = 0; i < config.excludeValidators.length; i++) {
        excludeValidators[config.excludeValidators[i]] = true;
      }
    }
  }
  execute() {
    const e = {
      action: this._action,
      args: Array.prototype.slice.call(arguments),
      context: this._context,
      component: this._component,
      validatingTargetName: this._validatingTargetName,
      cancel: false,
      handled: false
    };
    const beforeExecute = this._beforeExecute;
    const afterExecute = this._afterExecute;
    const argsBag = e.args[0] || {};
    if (!this._validateAction(e)) {
      return;
    }
    null === beforeExecute || void 0 === beforeExecute || beforeExecute.call(this._context, e);
    if (e.cancel) {
      return;
    }
    const result = this._executeAction(e);
    if (argsBag.cancel) {
      return;
    }
    null === afterExecute || void 0 === afterExecute || afterExecute.call(this._context, e);
    return result;
  }
  _validateAction(e) {
    const excludeValidators = this._excludeValidators;
    const {
      executors
    } = _Action;
    for (const name in executors) {
      if (!excludeValidators[name]) {
        var _executor$validate;
        const executor = executors[name];
        null === (_executor$validate = executor.validate) || void 0 === _executor$validate || _executor$validate.call(executor, e);
        if (e.cancel) {
          return false;
        }
      }
    }
    return true;
  }
  _executeAction(e) {
    let result;
    const {
      executors
    } = _Action;
    for (const name in executors) {
      var _executor$execute;
      const executor = executors[name];
      null === (_executor$execute = executor.execute) || void 0 === _executor$execute || _executor$execute.call(executor, e);
      if (e.handled) {
        result = e.result;
        break;
      }
    }
    return result;
  }
  static registerExecutor(name, executor) {
    if (isPlainObject(name)) {
      each(name, _Action.registerExecutor);
      return;
    }
    _Action.executors[name] = executor;
  }
  static unregisterExecutor() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    each(args, function() {
      delete _Action.executors[this];
    });
  }
};
Action.executors = {};
var createValidatorByTargetElement = (condition) => (e) => {
  if (!e.args.length) {
    return;
  }
  const args = e.args[0];
  const element = args[e.validatingTargetName] || args.element;
  if (element && condition(renderer_default(element))) {
    e.cancel = true;
  }
};
Action.registerExecutor({
  disabled: {
    validate: createValidatorByTargetElement(($target) => $target.is(".dx-state-disabled, .dx-state-disabled *"))
  },
  readOnly: {
    validate: createValidatorByTargetElement(($target) => $target.is(".dx-state-readonly, .dx-state-readonly *:not(.dx-state-independent)"))
  },
  undefined: {
    execute: (e) => {
      if (!e.action) {
        e.result = void 0;
        e.handled = true;
      }
    }
  },
  func: {
    execute: (e) => {
      if (isFunction(e.action)) {
        e.result = e.action.call(e.context, e.args[0]);
        e.handled = true;
      }
    }
  }
});

// node_modules/devextreme/esm/core/component.js
init_errors();
init_callbacks();
init_events_strategy();

// node_modules/devextreme/esm/core/postponed_operations.js
init_deferred();
init_type();
var PostponedOperations = class {
  constructor() {
    this._postponedOperations = {};
  }
  add(key, fn, postponedPromise) {
    if (key in this._postponedOperations) {
      postponedPromise && this._postponedOperations[key].promises.push(postponedPromise);
    } else {
      const completePromise = new Deferred();
      this._postponedOperations[key] = {
        fn,
        completePromise,
        promises: postponedPromise ? [postponedPromise] : []
      };
    }
    return this._postponedOperations[key].completePromise.promise();
  }
  callPostponedOperations() {
    for (const key in this._postponedOperations) {
      const operation = this._postponedOperations[key];
      if (isDefined(operation)) {
        if (operation.promises && operation.promises.length) {
          when(...operation.promises).done(operation.fn).then(operation.completePromise.resolve);
        } else {
          operation.fn().done(operation.completePromise.resolve);
        }
      }
    }
    this._postponedOperations = {};
  }
};

// node_modules/devextreme/esm/core/component.js
init_type();
init_common();
init_data();
var getEventName = (actionName) => actionName.charAt(2).toLowerCase() + actionName.substr(3);
var isInnerOption = (optionName) => 0 === optionName.indexOf("_", 0);
var Component = class_default.inherit({
  _setDeprecatedOptions() {
    this._deprecatedOptions = {};
  },
  _getDeprecatedOptions() {
    return this._deprecatedOptions;
  },
  _getDefaultOptions: () => ({
    onInitialized: null,
    onOptionChanged: null,
    onDisposing: null,
    defaultOptionsRules: null
  }),
  _defaultOptionsRules: () => [],
  _setOptionsByDevice(rules) {
    this._options.applyRules(rules);
  },
  _convertRulesToOptions: (rules) => convertRulesToOptions(rules),
  _isInitialOptionValue(name) {
    return this._options.isInitial(name);
  },
  _setOptionsByReference() {
    this._optionsByReference = {};
  },
  _getOptionsByReference() {
    return this._optionsByReference;
  },
  ctor() {
    let options = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    const {
      _optionChangedCallbacks,
      _disposingCallbacks
    } = options;
    this.NAME = getName(this.constructor);
    this._eventsStrategy = EventsStrategy.create(this, options.eventsStrategy);
    this._updateLockCount = 0;
    this._optionChangedCallbacks = _optionChangedCallbacks || callbacks_default();
    this._disposingCallbacks = _disposingCallbacks || callbacks_default();
    this.postponedOperations = new PostponedOperations();
    this._createOptions(options);
  },
  _createOptions(options) {
    this.beginUpdate();
    try {
      this._setOptionsByReference();
      this._setDeprecatedOptions();
      this._options = new Options(this._getDefaultOptions(), this._getDefaultOptions(), this._getOptionsByReference(), this._getDeprecatedOptions());
      this._options.onChanging((name, previousValue, value2) => this._initialized && this._optionChanging(name, previousValue, value2));
      this._options.onDeprecated((option, info) => this._logDeprecatedOptionWarning(option, info));
      this._options.onChanged((name, value2, previousValue) => this._notifyOptionChanged(name, value2, previousValue));
      this._options.onStartChange(() => this.beginUpdate());
      this._options.onEndChange(() => this.endUpdate());
      this._options.addRules(this._defaultOptionsRules());
      if (options && options.onInitializing) {
        options.onInitializing.apply(this, [options]);
      }
      this._setOptionsByDevice(options.defaultOptionsRules);
      this._initOptions(options);
    } finally {
      this.endUpdate();
    }
  },
  _initOptions(options) {
    this.option(options);
  },
  _init() {
    this._createOptionChangedAction();
    this.on("disposing", (args) => {
      this._disposingCallbacks.fireWith(this, [args]);
    });
  },
  _logDeprecatedOptionWarning(option, info) {
    const message = info.message || `Use the '${info.alias}' option instead`;
    errors_default.log("W0001", this.NAME, option, info.since, message);
  },
  _logDeprecatedComponentWarning(since, alias) {
    errors_default.log("W0000", this.NAME, since, `Use the '${alias}' widget instead`);
  },
  _createOptionChangedAction() {
    this._optionChangedAction = this._createActionByOption("onOptionChanged", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _createDisposingAction() {
    this._disposingAction = this._createActionByOption("onDisposing", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _optionChanged(args) {
    switch (args.name) {
      case "onDisposing":
      case "onInitialized":
      case "defaultOptionsRules":
        break;
      case "onOptionChanged":
        this._createOptionChangedAction();
    }
  },
  _dispose() {
    this._optionChangedCallbacks.empty();
    this._createDisposingAction();
    this._disposingAction();
    this._eventsStrategy.dispose();
    this._options.dispose();
    this._disposed = true;
  },
  _lockUpdate() {
    this._updateLockCount++;
  },
  _unlockUpdate() {
    this._updateLockCount = Math.max(this._updateLockCount - 1, 0);
  },
  _isUpdateAllowed() {
    return 0 === this._updateLockCount;
  },
  _isInitializingRequired() {
    return !this._initializing && !this._initialized;
  },
  isInitialized() {
    return this._initialized;
  },
  _commitUpdate() {
    this.postponedOperations.callPostponedOperations();
    this._isInitializingRequired() && this._initializeComponent();
  },
  _initializeComponent() {
    this._initializing = true;
    try {
      this._init();
    } finally {
      this._initializing = false;
      this._lockUpdate();
      this._createActionByOption("onInitialized", {
        excludeValidators: ["disabled", "readOnly"]
      })();
      this._unlockUpdate();
      this._initialized = true;
    }
  },
  instance() {
    return this;
  },
  beginUpdate: function() {
    this._lockUpdate();
  },
  endUpdate: function() {
    this._unlockUpdate();
    this._isUpdateAllowed() && this._commitUpdate();
  },
  _optionChanging: noop,
  _notifyOptionChanged(option, value2, previousValue) {
    if (this._initialized) {
      const optionNames = [option].concat(this._options.getAliasesByName(option));
      for (let i = 0; i < optionNames.length; i++) {
        const name = optionNames[i];
        const args = {
          name: getPathParts(name)[0],
          fullName: name,
          value: value2,
          previousValue
        };
        if (!isInnerOption(name)) {
          this._optionChangedCallbacks.fireWith(this, [extend(this._defaultActionArgs(), args)]);
          this._optionChangedAction(extend({}, args));
        }
        if (!this._disposed && this._cancelOptionChange !== name) {
          this._optionChanged(args);
        }
      }
    }
  },
  initialOption(name) {
    return this._options.initial(name);
  },
  _defaultActionConfig() {
    return {
      context: this,
      component: this
    };
  },
  _defaultActionArgs() {
    return {
      component: this
    };
  },
  _createAction(actionSource, config) {
    let action;
    return (e) => {
      if (!isDefined(e)) {
        e = {};
      }
      if (!isPlainObject(e)) {
        e = {
          actionValue: e
        };
      }
      action = action || new Action(actionSource, extend({}, config, this._defaultActionConfig()));
      return action.execute.call(action, extend(e, this._defaultActionArgs()));
    };
  },
  _createActionByOption(optionName, config) {
    var _this = this;
    let action;
    let eventName;
    let actionFunc;
    config = extend({}, config);
    const result = function() {
      if (!eventName) {
        config = config || {};
        if ("string" !== typeof optionName) {
          throw errors_default.Error("E0008");
        }
        if (0 === optionName.indexOf("on")) {
          eventName = getEventName(optionName);
        }
        actionFunc = _this.option(optionName);
      }
      if (!action && !actionFunc && !config.beforeExecute && !config.afterExecute && !_this._eventsStrategy.hasEvent(eventName)) {
        return;
      }
      if (!action) {
        const beforeExecute = config.beforeExecute;
        config.beforeExecute = function() {
          for (var _len2 = arguments.length, props = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
            props[_key2] = arguments[_key2];
          }
          beforeExecute && beforeExecute.apply(_this, props);
          _this._eventsStrategy.fireEvent(eventName, props[0].args);
        };
        action = _this._createAction(actionFunc, config);
      }
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      if (config_default().wrapActionsBeforeExecute) {
        const beforeActionExecute = _this.option("beforeActionExecute") || noop;
        const wrappedAction = beforeActionExecute(_this, action, config) || action;
        return wrappedAction.apply(_this, args);
      }
      return action.apply(_this, args);
    };
    if (config_default().wrapActionsBeforeExecute) {
      return result;
    }
    const onActionCreated = this.option("onActionCreated") || noop;
    return onActionCreated(this, result, config) || result;
  },
  on(eventName, eventHandler) {
    this._eventsStrategy.on(eventName, eventHandler);
    return this;
  },
  off(eventName, eventHandler) {
    this._eventsStrategy.off(eventName, eventHandler);
    return this;
  },
  hasActionSubscription: function(actionName) {
    return !!this._options.silent(actionName) || this._eventsStrategy.hasEvent(getEventName(actionName));
  },
  isOptionDeprecated(name) {
    return this._options.isDeprecated(name);
  },
  _setOptionWithoutOptionChange(name, value2) {
    this._cancelOptionChange = name;
    this.option(name, value2);
    this._cancelOptionChange = false;
  },
  _getOptionValue(name, context2) {
    const value2 = this.option(name);
    if (isFunction(value2)) {
      return value2.bind(context2)();
    }
    return value2;
  },
  option() {
    return this._options.option(...arguments);
  },
  resetOption(name) {
    this.beginUpdate();
    this._options.reset(name);
    this.endUpdate();
  }
});

// node_modules/devextreme/esm/core/template_manager.js
init_renderer();
init_type();
init_common();
init_extend();

// node_modules/devextreme/esm/core/utils/template_manager.js
init_extends();
init_config();
init_errors();
init_renderer();

// node_modules/devextreme/esm/core/templates/template.js
init_renderer();

// node_modules/devextreme/esm/core/templates/template_engine_registry.js
init_type();
init_errors();
var templateEngines = {};
var currentTemplateEngine;
function registerTemplateEngine(name, templateEngine) {
  templateEngines[name] = templateEngine;
}
function setTemplateEngine(templateEngine) {
  if (isString(templateEngine)) {
    currentTemplateEngine = templateEngines[templateEngine];
    if (!currentTemplateEngine) {
      throw errors_default.Error("E0020", templateEngine);
    }
  } else {
    currentTemplateEngine = templateEngine;
  }
}
function getCurrentTemplateEngine() {
  return currentTemplateEngine;
}

// node_modules/devextreme/esm/core/templates/template.js
registerTemplateEngine("default", {
  compile: (element) => normalizeTemplateElement(element),
  render: (template, model, index2) => template.clone()
});
setTemplateEngine("default");
var Template = class extends TemplateBase {
  constructor(element) {
    super();
    this._element = element;
  }
  _renderCore(options) {
    const transclude = options.transclude;
    if (!transclude && !this._compiledTemplate) {
      this._compiledTemplate = getCurrentTemplateEngine().compile(this._element);
    }
    return renderer_default("<div>").append(transclude ? this._element : getCurrentTemplateEngine().render(this._compiledTemplate, options.model, options.index)).contents();
  }
  source() {
    return renderer_default(this._element).clone();
  }
};

// node_modules/devextreme/esm/core/utils/template_manager.js
init_common();
init_extend();
init_type();
var findTemplates = (element, name) => {
  const templates = renderer_default(element).contents().filter(`[data-options*="${name}"]`);
  return [].slice.call(templates).map((element2) => {
    const optionsString = renderer_default(element2).attr("data-options") || "";
    return {
      element: element2,
      options: config_default().optionsParser(optionsString)[name]
    };
  }).filter((template) => !!template.options);
};
var suitableTemplatesByName = (rawTemplates) => {
  const templatesMap = groupBy(rawTemplates, (template) => template.options.name);
  if (templatesMap[void 0]) {
    throw errors_default.Error("E0023");
  }
  const result = {};
  Object.keys(templatesMap).forEach((name) => {
    var _findBestMatches$;
    const suitableTemplate = null === (_findBestMatches$ = findBestMatches(devices_default.current(), templatesMap[name], (template) => template.options)[0]) || void 0 === _findBestMatches$ ? void 0 : _findBestMatches$.element;
    if (suitableTemplate) {
      result[name] = suitableTemplate;
    }
  });
  return result;
};
var addOneRenderedCall = (template) => {
  const render = template.render.bind(template);
  return extend({}, template, {
    render(options) {
      const templateResult = render(options);
      options && options.onRendered && options.onRendered();
      return templateResult;
    }
  });
};
var addPublicElementNormalization = (template) => {
  const render = template.render.bind(template);
  return extend({}, template, {
    render(options) {
      const $container = renderer_default(options.container);
      return render(_extends({}, options, {
        container: getPublicElement($container)
      }));
    }
  });
};
var getNormalizedTemplateArgs = (options) => {
  const args = [];
  if ("model" in options) {
    args.push(options.model);
  }
  if ("index" in options) {
    args.push(options.index);
  }
  args.push(options.container);
  return args;
};
var validateTemplateSource = (templateSource) => "string" === typeof templateSource ? normalizeTemplateElement(templateSource) : templateSource;
var templateKey = (templateSource) => isRenderer(templateSource) && templateSource[0] || templateSource;
var defaultCreateElement = (element) => new Template(element);
var acquireIntegrationTemplate = (templateSource, templates, isAsyncTemplate, skipTemplates) => {
  let integrationTemplate = null;
  if (!skipTemplates || -1 === skipTemplates.indexOf(templateSource)) {
    integrationTemplate = templates[templateSource];
    if (integrationTemplate && !(integrationTemplate instanceof TemplateBase)) {
      if (isFunction(integrationTemplate.render)) {
        integrationTemplate = addPublicElementNormalization(integrationTemplate);
      }
      if (!isAsyncTemplate) {
        integrationTemplate = addOneRenderedCall(integrationTemplate);
      }
    }
  }
  return integrationTemplate;
};
var acquireTemplate = (templateSource, createTemplate, templates, isAsyncTemplate, skipTemplates, defaultTemplates) => {
  if (null == templateSource) {
    return new EmptyTemplate();
  }
  if (templateSource instanceof ChildDefaultTemplate) {
    return defaultTemplates[templateSource.name];
  }
  if (templateSource instanceof TemplateBase) {
    return templateSource;
  }
  if (isFunction(templateSource.render) && !isRenderer(templateSource)) {
    return isAsyncTemplate ? templateSource : addOneRenderedCall(templateSource);
  }
  if (templateSource.nodeType || isRenderer(templateSource)) {
    return createTemplate(renderer_default(templateSource));
  }
  return acquireIntegrationTemplate(templateSource, templates, isAsyncTemplate, skipTemplates) || defaultTemplates[templateSource] || createTemplate(templateSource);
};

// node_modules/devextreme/esm/core/template_manager.js
var DX_POLYMORPH_WIDGET_TEMPLATE = new FunctionTemplate((_ref) => {
  let {
    model,
    parent
  } = _ref;
  const widgetName = model.widget;
  if (!widgetName) {
    return renderer_default();
  }
  const widgetElement = renderer_default("<div>");
  const widgetOptions = model.options || {};
  if (parent) {
    parent._createComponent(widgetElement, widgetName, widgetOptions);
  } else {
    widgetElement[widgetName](widgetOptions);
  }
  return widgetElement;
});
var TemplateManager = class {
  constructor(createElement, anonymousTemplateName) {
    this._tempTemplates = [];
    this._defaultTemplates = {};
    this._anonymousTemplateName = anonymousTemplateName || "template";
    this._createElement = createElement || defaultCreateElement;
    this._createTemplateIfNeeded = this._createTemplateIfNeeded.bind(this);
  }
  static createDefaultOptions() {
    return {
      integrationOptions: {
        watchMethod: function(fn, callback) {
          let options = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
          if (!options.skipImmediate) {
            callback(fn());
          }
          return noop;
        },
        templates: {
          "dx-polymorph-widget": DX_POLYMORPH_WIDGET_TEMPLATE
        },
        useDeferUpdateForTemplates: true
      }
    };
  }
  get anonymousTemplateName() {
    return this._anonymousTemplateName;
  }
  addDefaultTemplates(templates) {
    this._defaultTemplates = extend({}, this._defaultTemplates, templates);
  }
  dispose() {
    this._tempTemplates.forEach((tempTemplate) => {
      tempTemplate.template.dispose && tempTemplate.template.dispose();
    });
    this._tempTemplates = [];
  }
  extractTemplates($el) {
    const templates = this._extractTemplates($el);
    const anonymousTemplateMeta = this._extractAnonymousTemplate($el);
    return {
      templates,
      anonymousTemplateMeta
    };
  }
  _extractTemplates($el) {
    const templates = findTemplates($el, "dxTemplate");
    const suitableTemplates = suitableTemplatesByName(templates);
    templates.forEach((_ref2) => {
      let {
        element,
        options: {
          name
        }
      } = _ref2;
      if (element === suitableTemplates[name]) {
        renderer_default(element).addClass("dx-template-wrapper").detach();
      } else {
        renderer_default(element).remove();
      }
    });
    return Object.keys(suitableTemplates).map((name) => ({
      name,
      template: this._createTemplate(suitableTemplates[name])
    }));
  }
  _extractAnonymousTemplate($el) {
    const $anonymousTemplate = $el.contents().detach();
    const $notJunkTemplateContent = $anonymousTemplate.filter((_, element) => {
      const isTextNode = 3 === element.nodeType;
      const isEmptyText = renderer_default(element).text().trim().length < 1;
      return !(isTextNode && isEmptyText);
    });
    return $notJunkTemplateContent.length > 0 ? {
      template: this._createTemplate($anonymousTemplate),
      name: this._anonymousTemplateName
    } : {};
  }
  _createTemplateIfNeeded(templateSource) {
    const cachedTemplate = this._tempTemplates.filter((tempTemplate) => tempTemplate.source === templateKey(templateSource))[0];
    if (cachedTemplate) {
      return cachedTemplate.template;
    }
    const template = this._createTemplate(templateSource);
    this._tempTemplates.push({
      template,
      source: templateKey(templateSource)
    });
    return template;
  }
  _createTemplate(templateSource) {
    return this._createElement(validateTemplateSource(templateSource));
  }
  getTemplate(templateSource, templates, _ref3, context2) {
    let {
      isAsyncTemplate,
      skipTemplates
    } = _ref3;
    if (!isFunction(templateSource)) {
      return acquireTemplate(templateSource, this._createTemplateIfNeeded, templates, isAsyncTemplate, skipTemplates, this._defaultTemplates);
    }
    return new FunctionTemplate((options) => {
      const templateSourceResult = templateSource.apply(context2, getNormalizedTemplateArgs(options));
      if (!isDefined(templateSourceResult)) {
        return new EmptyTemplate();
      }
      let dispose = false;
      const template = acquireTemplate(templateSourceResult, (templateSource2) => {
        if (templateSource2.nodeType || isRenderer(templateSource2) && !renderer_default(templateSource2).is("script")) {
          return new FunctionTemplate(() => templateSource2);
        }
        dispose = true;
        return this._createTemplate(templateSource2);
      }, templates, isAsyncTemplate, skipTemplates, this._defaultTemplates);
      const result = template.render(options);
      dispose && template.dispose && template.dispose();
      return result;
    });
  }
};

// node_modules/devextreme/esm/core/dom_component.js
init_shadow_dom();
init_element_data();
init_iterator();
init_extend();
init_common();
init_type();
init_window();

// node_modules/devextreme/esm/events/short.js
init_events_engine();

// node_modules/devextreme/esm/events/core/keyboard_processor.js
init_renderer();
init_events_engine();
init_class();
var NAMESPACE = "KeyboardProcessor";
var createKeyDownOptions = (e) => ({
  keyName: normalizeKeyName(e),
  key: e.key,
  code: e.code,
  ctrl: e.ctrlKey,
  location: e.location,
  metaKey: e.metaKey,
  shift: e.shiftKey,
  alt: e.altKey,
  which: e.which,
  originalEvent: e
});
var KeyboardProcessor = class_default.inherit({
  _keydown: addNamespace2("keydown", NAMESPACE),
  _compositionStart: addNamespace2("compositionstart", NAMESPACE),
  _compositionEnd: addNamespace2("compositionend", NAMESPACE),
  ctor: function(options) {
    options = options || {};
    if (options.element) {
      this._element = renderer_default(options.element);
    }
    if (options.focusTarget) {
      this._focusTarget = options.focusTarget;
    }
    this._handler = options.handler;
    if (this._element) {
      this._processFunction = (e) => {
        const focusTargets = renderer_default(this._focusTarget).toArray();
        const isNotFocusTarget = this._focusTarget && this._focusTarget !== e.target && !focusTargets.includes(e.target);
        const shouldSkipProcessing = this._isComposingJustFinished && 229 === e.which || this._isComposing || isNotFocusTarget;
        this._isComposingJustFinished = false;
        if (!shouldSkipProcessing) {
          this.process(e);
        }
      };
      this._toggleProcessingWithContext = this.toggleProcessing.bind(this);
      events_engine_default.on(this._element, this._keydown, this._processFunction);
      events_engine_default.on(this._element, this._compositionStart, this._toggleProcessingWithContext);
      events_engine_default.on(this._element, this._compositionEnd, this._toggleProcessingWithContext);
    }
  },
  dispose: function() {
    if (this._element) {
      events_engine_default.off(this._element, this._keydown, this._processFunction);
      events_engine_default.off(this._element, this._compositionStart, this._toggleProcessingWithContext);
      events_engine_default.off(this._element, this._compositionEnd, this._toggleProcessingWithContext);
    }
    this._element = void 0;
    this._handler = void 0;
  },
  process: function(e) {
    this._handler(createKeyDownOptions(e));
  },
  toggleProcessing: function(_ref) {
    let {
      type: type2
    } = _ref;
    this._isComposing = "compositionstart" === type2;
    this._isComposingJustFinished = !this._isComposing;
  }
});
KeyboardProcessor.createKeyDownOptions = createKeyDownOptions;
var keyboard_processor_default = KeyboardProcessor;

// node_modules/devextreme/esm/events/short.js
function addNamespace3(event, namespace) {
  return namespace ? addNamespace2(event, namespace) : event;
}
function executeAction(action, args) {
  return "function" === typeof action ? action(args) : action.execute(args);
}
var active = {
  on: ($el, active2, inactive, opts) => {
    const {
      selector,
      showTimeout,
      hideTimeout,
      namespace
    } = opts;
    events_engine_default.on($el, addNamespace3("dxactive", namespace), selector, {
      timeout: showTimeout
    }, (event) => executeAction(active2, {
      event,
      element: event.currentTarget
    }));
    events_engine_default.on($el, addNamespace3("dxinactive", namespace), selector, {
      timeout: hideTimeout
    }, (event) => executeAction(inactive, {
      event,
      element: event.currentTarget
    }));
  },
  off: ($el, _ref) => {
    let {
      namespace,
      selector
    } = _ref;
    events_engine_default.off($el, addNamespace3("dxactive", namespace), selector);
    events_engine_default.off($el, addNamespace3("dxinactive", namespace), selector);
  }
};
var resize = {
  on: function($el, resize2) {
    let {
      namespace
    } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    events_engine_default.on($el, addNamespace3("dxresize", namespace), resize2);
  },
  off: function($el) {
    let {
      namespace
    } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    events_engine_default.off($el, addNamespace3("dxresize", namespace));
  }
};
var hover = {
  on: ($el, start, end, _ref2) => {
    let {
      selector,
      namespace
    } = _ref2;
    events_engine_default.on($el, addNamespace3("dxhoverend", namespace), selector, (event) => end(event));
    events_engine_default.on($el, addNamespace3("dxhoverstart", namespace), selector, (event) => executeAction(start, {
      element: event.target,
      event
    }));
  },
  off: ($el, _ref3) => {
    let {
      selector,
      namespace
    } = _ref3;
    events_engine_default.off($el, addNamespace3("dxhoverstart", namespace), selector);
    events_engine_default.off($el, addNamespace3("dxhoverend", namespace), selector);
  }
};
var visibility = {
  on: ($el, shown, hiding, _ref4) => {
    let {
      namespace
    } = _ref4;
    events_engine_default.on($el, addNamespace3("dxhiding", namespace), hiding);
    events_engine_default.on($el, addNamespace3("dxshown", namespace), shown);
  },
  off: ($el, _ref5) => {
    let {
      namespace
    } = _ref5;
    events_engine_default.off($el, addNamespace3("dxhiding", namespace));
    events_engine_default.off($el, addNamespace3("dxshown", namespace));
  }
};
var focus = {
  on: ($el, focusIn, focusOut, _ref6) => {
    let {
      namespace
    } = _ref6;
    events_engine_default.on($el, addNamespace3("focusin", namespace), focusIn);
    events_engine_default.on($el, addNamespace3("focusout", namespace), focusOut);
  },
  off: ($el, _ref7) => {
    let {
      namespace
    } = _ref7;
    events_engine_default.off($el, addNamespace3("focusin", namespace));
    events_engine_default.off($el, addNamespace3("focusout", namespace));
  },
  trigger: ($el) => events_engine_default.trigger($el, "focus")
};
var dxClick = {
  on: function($el, click2) {
    let {
      namespace
    } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    events_engine_default.on($el, addNamespace3("dxclick", namespace), click2);
  },
  off: function($el) {
    let {
      namespace
    } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    events_engine_default.off($el, addNamespace3("dxclick", namespace));
  }
};
var click = {
  on: function($el, click2) {
    let {
      namespace
    } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    events_engine_default.on($el, addNamespace3("click", namespace), click2);
  },
  off: function($el) {
    let {
      namespace
    } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    events_engine_default.off($el, addNamespace3("click", namespace));
  }
};
var index = 0;
var keyboardProcessors = {};
var generateListenerId = () => "keyboardProcessorId" + index++;
var keyboard = {
  on: (element, focusTarget, handler) => {
    const listenerId = generateListenerId();
    keyboardProcessors[listenerId] = new keyboard_processor_default({
      element,
      focusTarget,
      handler
    });
    return listenerId;
  },
  off: (listenerId) => {
    if (listenerId && keyboardProcessors[listenerId]) {
      keyboardProcessors[listenerId].dispose();
      delete keyboardProcessors[listenerId];
    }
  },
  _getProcessor: (listenerId) => keyboardProcessors[listenerId]
};

// node_modules/devextreme/esm/__internal/core/license/license_validation.js
init_extends();

// node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
function _objectWithoutPropertiesLoose(r, e) {
  if (null == r) return {};
  var t = {};
  for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
    if (e.includes(n)) continue;
    t[n] = r[n];
  }
  return t;
}

// node_modules/devextreme/esm/__internal/core/license/license_validation.js
init_config();
init_errors();
init_version();

// node_modules/devextreme/esm/__internal/utils/version.js
init_errors();
var assertedVersions = [];
var VERSION_SPLITTER = ".";
function stringifyVersion(version) {
  const {
    major,
    minor,
    patch
  } = version;
  return [major, minor, patch].join(VERSION_SPLITTER);
}
function parseVersion(version) {
  const [major, minor, patch] = version.split(".").map(Number);
  return {
    major,
    minor,
    patch
  };
}
function stringifyVersionList(assertedVersionList) {
  return assertedVersionList.map((assertedVersion) => `${assertedVersion.packageName}: ${assertedVersion.version}`).join("\n");
}
function versionsEqual(versionA, versionB) {
  return versionA.major === versionB.major && versionA.minor === versionB.minor && versionA.patch === versionB.patch;
}
function getPreviousMajorVersion(_ref) {
  let {
    major,
    minor,
    patch
  } = _ref;
  const previousMajorVersion = 1 === minor ? {
    major: major - 1,
    minor: 2,
    patch
  } : {
    major,
    minor: minor - 1,
    patch
  };
  return previousMajorVersion;
}
function assertedVersionsCompatible(currentVersion) {
  const mismatchingVersions = assertedVersions.filter((assertedVersion) => !versionsEqual(parseVersion(assertedVersion.version), currentVersion));
  if (mismatchingVersions.length) {
    errors_default.log("W0023", stringifyVersionList([{
      packageName: "devextreme",
      version: stringifyVersion(currentVersion)
    }, ...mismatchingVersions]));
    return false;
  }
  return true;
}

// node_modules/devextreme/esm/__internal/core/license/byte_utils.js
function base64ToBytes(base64) {
  return new Uint8Array(atob(base64).split("").map((s) => s.charCodeAt(0)));
}
function hexToBytes(string) {
  var _string$match;
  return new Uint8Array((null === (_string$match = string.match(/.{1,2}/g)) || void 0 === _string$match ? void 0 : _string$match.map((byte) => parseInt(byte, 16))) ?? []);
}
function stringToBytes(string) {
  const bytes = new Uint8Array(string.length);
  for (let k = 0; k < string.length; k += 1) {
    bytes[k] = 255 & string.charCodeAt(k);
  }
  return bytes;
}
function wordsToBytes(words) {
  const bytes = new Uint8Array(4 * words.length);
  for (let k = 0; k < bytes.length; k += 1) {
    bytes[k] = words[k >> 2] >>> 8 * (3 - k % 4);
  }
  return bytes;
}
function bytesToWords(bytes) {
  const words = new Uint32Array(1 + (bytes.length - 1 >> 2));
  for (let k = 0; k < bytes.length; k += 1) {
    words[k >> 2] |= bytes[k] << 8 * (3 - k % 4);
  }
  return words;
}
function leftRotate(x, n) {
  return (x << n | x >>> 32 - n) >>> 0;
}
function concatBytes(a, b) {
  const result = new Uint8Array(a.length + b.length);
  result.set(a, 0);
  result.set(b, a.length);
  return result;
}

// node_modules/devextreme/esm/__internal/core/license/key.js
var PUBLIC_KEY = {
  e: 65537,
  n: new Uint8Array([200, 219, 153, 203, 140, 7, 228, 253, 193, 243, 62, 137, 139, 60, 68, 242, 48, 142, 113, 88, 185, 235, 253, 105, 80, 74, 32, 170, 96, 74, 111, 250, 7, 205, 154, 3, 146, 115, 153, 53, 45, 132, 123, 56, 61, 208, 184, 201, 63, 24, 109, 223, 0, 179, 169, 102, 139, 224, 73, 233, 45, 173, 138, 66, 98, 88, 69, 76, 177, 111, 113, 218, 192, 33, 101, 152, 25, 134, 34, 173, 32, 82, 230, 44, 247, 200, 253, 170, 192, 246, 30, 12, 96, 205, 100, 249, 181, 93, 0, 231])
};
var INTERNAL_USAGE_ID = "ztVDI92-ekyPchAwMgtfIA";

// node_modules/devextreme/esm/__internal/core/license/pkcs1.js
var ASN1_SHA1 = "3021300906052b0e03021a05000414";
function pad(hash) {
  const dataLength = (8 * PUBLIC_KEY.n.length + 6) / 8;
  const data2 = concatBytes(hexToBytes(ASN1_SHA1), hash);
  if (data2.length + 10 > dataLength) {
    throw Error("Key is too short for SHA1 signing algorithm");
  }
  const padding = new Uint8Array(dataLength - data2.length);
  padding.fill(255, 0, padding.length - 1);
  padding[0] = 0;
  padding[1] = 1;
  padding[padding.length - 1] = 0;
  return concatBytes(padding, data2);
}

// node_modules/devextreme/esm/__internal/core/license/rsa_bigint.js
function compareSignatures(args) {
  try {
    const zero = BigInt(0);
    const one = BigInt(1);
    const eight = BigInt(8);
    const modExp = (base, exponent2, modulus2) => {
      let result = one;
      let b = base;
      let e = exponent2;
      while (e) {
        if (e & one) {
          result = result * b % modulus2;
        }
        b = b * b % modulus2;
        e >>= one;
      }
      return result;
    };
    const bigIntFromBytes = (bytes) => bytes.reduce((acc, cur) => (acc << eight) + BigInt(cur), zero);
    const actual = bigIntFromBytes(args.actual);
    const signature = bigIntFromBytes(args.signature);
    const exponent = BigInt(args.key.e);
    const modulus = bigIntFromBytes(args.key.n);
    const expected = modExp(signature, exponent, modulus);
    return expected === actual;
  } catch {
    return true;
  }
}

// node_modules/devextreme/esm/__internal/core/license/sha1.js
function preprocess(text) {
  const bytes = new Uint8Array(text.length + 1);
  bytes.set(stringToBytes(text));
  bytes[bytes.length - 1] = 128;
  const words = bytesToWords(new Uint8Array(bytes));
  const result = new Uint32Array(16 * Math.ceil((words.length + 2) / 16));
  result.set(words, 0);
  result[result.length - 1] = 8 * (bytes.length - 1);
  return result;
}
function sha1(text) {
  const message = preprocess(text);
  const h = new Uint32Array([1732584193, 4023233417, 2562383102, 271733878, 3285377520]);
  for (let i = 0; i < message.length; i += 16) {
    const w = new Uint32Array(80);
    for (let j = 0; j < 16; j += 1) {
      w[j] = message[i + j];
    }
    for (let j = 16; j < 80; j += 1) {
      const n = w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16];
      w[j] = n << 1 | n >>> 31;
    }
    let a = h[0];
    let b = h[1];
    let c = h[2];
    let d = h[3];
    let e = h[4];
    for (let j = 0; j < 80; j += 1) {
      const [f, k] = j < 20 ? [b & c | ~b & d, 1518500249] : j < 40 ? [b ^ c ^ d, 1859775393] : j < 60 ? [b & c | b & d | c & d, 2400959708] : [b ^ c ^ d, 3395469782];
      const temp = leftRotate(a, 5) + f + e + k + w[j];
      e = d;
      d = c;
      c = leftRotate(b, 30);
      b = a;
      a = temp;
    }
    h[0] += a;
    h[1] += b;
    h[2] += c;
    h[3] += d;
    h[4] += e;
  }
  return wordsToBytes(h);
}

// node_modules/devextreme/esm/__internal/core/license/trial_panel.client.js
init_extends();
var isClient = () => "undefined" !== typeof HTMLElement && "undefined" !== typeof customElements;
var SafeHTMLElement = isClient() ? HTMLElement : class {
};
var componentNames2 = {
  trigger: "dx-license-trigger",
  panel: "dx-license"
};
var attributeNames = {
  buyNow: "buy-now",
  licensingDoc: "licensing-doc",
  version: "version"
};
var commonStyles = {
  opacity: "1",
  visibility: "visible",
  "clip-path": "none",
  filter: "none"
};
var contentStyles = _extends({}, commonStyles, {
  width: "100%",
  height: "auto",
  "line-height": "normal",
  display: "block",
  "z-index": "1500",
  position: "static",
  transform: "translate(0px, 0px)",
  "background-color": "#FF7200",
  border: "none",
  margin: "auto",
  "box-sizing": "border-box",
  "text-align": "center"
});
var containerStyles = _extends({}, contentStyles, {
  display: "flex",
  "align-items": "center",
  "flex-direction": "row",
  position: "relative",
  top: "0px",
  left: "0px",
  padding: "0.5rem"
});
var buttonStyles = {
  width: "1rem",
  cursor: "pointer",
  height: "1rem"
};
var textStyles = _extends({}, commonStyles, {
  display: "inline",
  position: "static",
  padding: "0px",
  margin: "0px",
  color: "white",
  "font-family": "'Segoe UI','Open Sans Condensed',-apple-system,BlinkMacSystemFont,avenir next,avenir,helvetica neue,helvetica,Cantarell,Ubuntu,roboto,noto,arial,sans-serif",
  "font-size": "0.875rem",
  "font-wight": "600"
});
function createImportantStyles(defaultStyles, customStyles) {
  const styles = customStyles ? _extends({}, defaultStyles, customStyles) : defaultStyles;
  return Object.keys(styles).reduce((cssString, currentKey) => `${cssString}${[currentKey, `${styles[currentKey]} !important;`].join(": ")}`, "");
}
var DxLicense = class _DxLicense extends SafeHTMLElement {
  constructor() {
    var _DxLicense$customStyl, _DxLicense$customStyl2, _DxLicense$customStyl3, _DxLicense$customStyl4, _DxLicense$customStyl5;
    super();
    this._observer = null;
    this._inReassign = false;
    this._hidden = false;
    this._spanStyles = createImportantStyles(textStyles, null === (_DxLicense$customStyl = _DxLicense.customStyles) || void 0 === _DxLicense$customStyl ? void 0 : _DxLicense$customStyl.textStyles);
    this._linkStyles = createImportantStyles(textStyles, null === (_DxLicense$customStyl2 = _DxLicense.customStyles) || void 0 === _DxLicense$customStyl2 ? void 0 : _DxLicense$customStyl2.linkStyles);
    this._containerStyles = createImportantStyles(containerStyles, null === (_DxLicense$customStyl3 = _DxLicense.customStyles) || void 0 === _DxLicense$customStyl3 ? void 0 : _DxLicense$customStyl3.containerStyles);
    this._contentStyles = createImportantStyles(contentStyles, null === (_DxLicense$customStyl4 = _DxLicense.customStyles) || void 0 === _DxLicense$customStyl4 ? void 0 : _DxLicense$customStyl4.contentStyles);
    this._buttonStyles = createImportantStyles(buttonStyles, null === (_DxLicense$customStyl5 = _DxLicense.customStyles) || void 0 === _DxLicense$customStyl5 ? void 0 : _DxLicense$customStyl5.contentStyles);
  }
  _createSpan(text) {
    const span = document.createElement("span");
    span.innerText = text;
    span.style.cssText = this._spanStyles;
    return span;
  }
  _createLink(text, href) {
    const link = document.createElement("a");
    link.innerText = text;
    link.style.cssText = this._linkStyles;
    link.href = href;
    link.target = "_blank";
    return link;
  }
  _createButton() {
    const button = document.createElement("div");
    button.style.cssText = this._buttonStyles;
    const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    polygon.setAttribute("points", "13.4 12.7 8.7 8 13.4 3.4 12.6 2.6 8 7.3 3.4 2.6 2.6 3.4 7.3 8 2.6 12.6 3.4 13.4 8 8.7 12.7 13.4 13.4 12.7");
    polygon.style.cssText = createImportantStyles({
      fill: "#fff",
      opacity: ".5",
      "stroke-width": "0px"
    });
    svg.setAttribute("id", "Layer_1");
    svg.setAttribute("data-name", "Layer 1");
    svg.setAttribute("version", "1.1");
    svg.setAttribute("viewBox", "0 0 16 16");
    svg.style.cssText = createImportantStyles({
      "vertical-align": "baseline"
    });
    svg.appendChild(polygon);
    button.appendChild(svg);
    button.onclick = () => {
      this._hidden = true;
      this.style.cssText = createImportantStyles({
        display: "none"
      });
    };
    return button;
  }
  _createContentContainer() {
    const contentContainer = document.createElement("div");
    contentContainer.style.cssText = this._contentStyles;
    contentContainer.append(this._createSpan("For evaluation purposes only. Redistribution prohibited. Please "), this._createLink("register", this.getAttribute(attributeNames.licensingDoc)), this._createSpan(" an existing license or "), this._createLink("purchase a new license", this.getAttribute(attributeNames.buyNow)), this._createSpan(` to continue use of DevExpress product libraries (v${this.getAttribute(attributeNames.version)}).`));
    return contentContainer;
  }
  _reassignComponent() {
    this.innerHTML = "";
    this.style.cssText = this._containerStyles;
    this.append(this._createContentContainer(), this._createButton());
  }
  connectedCallback() {
    this._reassignComponent();
    if (!this._observer) {
      this._observer = new MutationObserver(() => {
        if (this._hidden) {
          var _this$_observer;
          null === (_this$_observer = this._observer) || void 0 === _this$_observer || _this$_observer.disconnect();
          return;
        }
        if (this._inReassign) {
          this._inReassign = false;
        } else {
          this._inReassign = true;
          this._reassignComponent();
        }
      });
      this._observer.observe(this, {
        childList: true,
        attributes: true,
        subtree: true
      });
    }
  }
  disconnectedCallback() {
    setTimeout(() => {
      const licensePanel = document.getElementsByTagName(componentNames2.panel);
      if (!licensePanel.length) {
        document.body.prepend(this);
      }
    }, 100);
  }
};
DxLicense.customStyles = void 0;
var DxLicenseTrigger = class extends SafeHTMLElement {
  connectedCallback() {
    this.style.cssText = createImportantStyles({
      display: "none"
    });
    const licensePanel = document.getElementsByTagName(componentNames2.panel);
    if (!licensePanel.length) {
      const license = document.createElement(componentNames2.panel);
      license.setAttribute(attributeNames.version, this.getAttribute(attributeNames.version));
      license.setAttribute(attributeNames.buyNow, this.getAttribute(attributeNames.buyNow));
      license.setAttribute(attributeNames.licensingDoc, this.getAttribute(attributeNames.licensingDoc));
      license.setAttribute("data-permanent", "true");
      document.body.prepend(license);
    }
  }
};
function registerCustomComponents(customStyles) {
  if (!customElements.get(componentNames2.trigger)) {
    DxLicense.customStyles = customStyles;
    customElements.define(componentNames2.trigger, DxLicenseTrigger);
    customElements.define(componentNames2.panel, DxLicense);
  }
}
function renderTrialPanel(buyNowUrl, licensingDocUrl, version, customStyles) {
  registerCustomComponents(customStyles);
  const trialPanelTrigger = document.createElement(componentNames2.trigger);
  trialPanelTrigger.setAttribute(attributeNames.buyNow, buyNowUrl);
  trialPanelTrigger.setAttribute(attributeNames.licensingDoc, licensingDocUrl);
  trialPanelTrigger.setAttribute(attributeNames.version, version);
  document.body.appendChild(trialPanelTrigger);
}

// node_modules/devextreme/esm/__internal/core/license/trial_panel.js
function showTrialPanel(buyNowUrl, licensingDocUrl, version, customStyles) {
  if (isClient()) {
    renderTrialPanel(buyNowUrl, licensingDocUrl, version, customStyles);
  }
}

// node_modules/devextreme/esm/__internal/core/license/types.js
var TokenKind;
!function(TokenKind2) {
  TokenKind2.corrupted = "corrupted";
  TokenKind2.verified = "verified";
  TokenKind2.internal = "internal";
}(TokenKind || (TokenKind = {}));

// node_modules/devextreme/esm/__internal/core/license/license_validation.js
var _excluded = ["customerId", "maxVersionAllowed", "format", "internalUsageId"];
var FORMAT = 1;
var RTM_MIN_PATCH_VERSION = 3;
var KEY_SPLITTER = ".";
var BUY_NOW_LINK = "https://go.devexpress.com/Licensing_Installer_Watermark_DevExtremeJQuery.aspx";
var LICENSING_DOC_LINK = "https://go.devexpress.com/Licensing_Documentation_DevExtremeJQuery.aspx";
var GENERAL_ERROR = {
  kind: TokenKind.corrupted,
  error: "general"
};
var VERIFICATION_ERROR = {
  kind: TokenKind.corrupted,
  error: "verification"
};
var DECODING_ERROR = {
  kind: TokenKind.corrupted,
  error: "decoding"
};
var DESERIALIZATION_ERROR = {
  kind: TokenKind.corrupted,
  error: "deserialization"
};
var PAYLOAD_ERROR = {
  kind: TokenKind.corrupted,
  error: "payload"
};
var VERSION_ERROR = {
  kind: TokenKind.corrupted,
  error: "version"
};
var validationPerformed = false;
function verifySignature(_ref) {
  let {
    text,
    signature: encodedSignature
  } = _ref;
  return compareSignatures({
    key: PUBLIC_KEY,
    signature: base64ToBytes(encodedSignature),
    actual: pad(sha1(text))
  });
}
function parseLicenseKey(encodedKey) {
  if (void 0 === encodedKey) {
    return GENERAL_ERROR;
  }
  const parts = encodedKey.split(KEY_SPLITTER);
  if (2 !== parts.length || 0 === parts[0].length || 0 === parts[1].length) {
    return GENERAL_ERROR;
  }
  if (!verifySignature({
    text: parts[0],
    signature: parts[1]
  })) {
    return VERIFICATION_ERROR;
  }
  let decodedPayload = "";
  try {
    decodedPayload = atob(parts[0]);
  } catch {
    return DECODING_ERROR;
  }
  let payload = {};
  try {
    payload = JSON.parse(decodedPayload);
  } catch {
    return DESERIALIZATION_ERROR;
  }
  const {
    customerId,
    maxVersionAllowed,
    format,
    internalUsageId
  } = payload, rest = _objectWithoutPropertiesLoose(payload, _excluded);
  if (void 0 !== internalUsageId) {
    return {
      kind: TokenKind.internal,
      internalUsageId
    };
  }
  if (void 0 === customerId || void 0 === maxVersionAllowed || void 0 === format) {
    return PAYLOAD_ERROR;
  }
  if (format !== FORMAT) {
    return VERSION_ERROR;
  }
  return {
    kind: TokenKind.verified,
    payload: _extends({
      customerId,
      maxVersionAllowed
    }, rest)
  };
}
function isPreview(patch) {
  return isNaN(patch) || patch < RTM_MIN_PATCH_VERSION;
}
function getLicenseCheckParams(_ref2) {
  let {
    licenseKey,
    version
  } = _ref2;
  let preview = false;
  try {
    preview = isPreview(version.patch);
    const {
      major,
      minor
    } = preview ? getPreviousMajorVersion(version) : version;
    if (!licenseKey) {
      return {
        preview,
        error: "W0019"
      };
    }
    const license = parseLicenseKey(licenseKey);
    if (license.kind === TokenKind.corrupted) {
      return {
        preview,
        error: "W0021"
      };
    }
    if (license.kind === TokenKind.internal) {
      return {
        preview,
        internal: true,
        error: license.internalUsageId === INTERNAL_USAGE_ID ? void 0 : "W0020"
      };
    }
    if (!(major && minor)) {
      return {
        preview,
        error: "W0021"
      };
    }
    if (10 * major + minor > license.payload.maxVersionAllowed) {
      return {
        preview,
        error: "W0020"
      };
    }
    return {
      preview,
      error: void 0
    };
  } catch {
    return {
      preview,
      error: "W0021"
    };
  }
}
function validateLicense(licenseKey) {
  let versionStr = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : fullVersion;
  if (validationPerformed) {
    return;
  }
  validationPerformed = true;
  const version = parseVersion(versionStr);
  const versionsCompatible = assertedVersionsCompatible(version);
  const {
    internal,
    error
  } = getLicenseCheckParams({
    licenseKey,
    version
  });
  if (!versionsCompatible && internal) {
    return;
  }
  if (error && !internal) {
    const buyNowLink = config_default().buyNowLink ?? BUY_NOW_LINK;
    const licensingDocLink = config_default().licensingDocLink ?? LICENSING_DOC_LINK;
    showTrialPanel(buyNowLink, licensingDocLink, fullVersion);
  }
  const preview = isPreview(version.patch);
  if (error) {
    errors_default.log(preview ? "W0022" : error);
    return;
  }
  if (preview && !internal) {
    errors_default.log("W0022");
  }
}
function peekValidationPerformed() {
  return validationPerformed;
}
var license_validation_default = {
  validateLicense
};

// node_modules/devextreme/esm/core/dom_component.js
var {
  abstract
} = Component;
var DOMComponent = Component.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      width: void 0,
      height: void 0,
      rtlEnabled: config_default().rtlEnabled,
      elementAttr: {},
      disabled: false,
      integrationOptions: {}
    }, this._useTemplates() ? TemplateManager.createDefaultOptions() : {});
  },
  ctor(element, options) {
    this._customClass = null;
    this._createElement(element);
    attachInstanceToElement(this._$element, this, this._dispose);
    this.callBase(options);
    const validationAlreadyPerformed = peekValidationPerformed();
    license_validation_default.validateLicense(config_default().licenseKey);
    if (!validationAlreadyPerformed && peekValidationPerformed()) {
      config_default({
        licenseKey: ""
      });
    }
  },
  _createElement(element) {
    this._$element = renderer_default(element);
  },
  _getSynchronizableOptionsForCreateComponent: () => ["rtlEnabled", "disabled", "templatesRenderAsynchronously"],
  _checkFunctionValueDeprecation: function(optionNames) {
    if (!this.option("_ignoreFunctionValueDeprecation")) {
      optionNames.forEach((optionName) => {
        if (isFunction(this.option(optionName))) {
          errors_default.log("W0017", optionName);
        }
      });
    }
  },
  _visibilityChanged: abstract,
  _dimensionChanged: abstract,
  _init() {
    this.callBase();
    this._checkFunctionValueDeprecation(["width", "height", "maxHeight", "maxWidth", "minHeight", "minWidth", "popupHeight", "popupWidth"]);
    this._attachWindowResizeCallback();
    this._initTemplateManager();
  },
  _setOptionsByDevice(instanceCustomRules) {
    this.callBase([].concat(this.constructor._classCustomRules || [], instanceCustomRules || []));
  },
  _isInitialOptionValue(name) {
    const isCustomOption = this.constructor._classCustomRules && Object.prototype.hasOwnProperty.call(this._convertRulesToOptions(this.constructor._classCustomRules), name);
    return !isCustomOption && this.callBase(name);
  },
  _attachWindowResizeCallback() {
    if (this._isDimensionChangeSupported()) {
      const windowResizeCallBack = this._windowResizeCallBack = this._dimensionChanged.bind(this);
      resize_callbacks_default.add(windowResizeCallBack);
    }
  },
  _isDimensionChangeSupported() {
    return this._dimensionChanged !== abstract;
  },
  _renderComponent() {
    addShadowDomStyles(this.$element());
    this._initMarkup();
    hasWindow() && this._render();
  },
  _initMarkup() {
    const {
      rtlEnabled
    } = this.option() || {};
    this._renderElementAttributes();
    this._toggleRTLDirection(rtlEnabled);
    this._renderVisibilityChange();
    this._renderDimensions();
  },
  _render() {
    this._attachVisibilityChangeHandlers();
  },
  _renderElementAttributes() {
    const {
      elementAttr
    } = this.option() || {};
    const attributes = extend({}, elementAttr);
    const classNames = attributes.class;
    delete attributes.class;
    this.$element().attr(attributes).removeClass(this._customClass).addClass(classNames);
    this._customClass = classNames;
  },
  _renderVisibilityChange() {
    if (this._isDimensionChangeSupported()) {
      this._attachDimensionChangeHandlers();
    }
    if (this._isVisibilityChangeSupported()) {
      const $element = this.$element();
      $element.addClass("dx-visibility-change-handler");
    }
  },
  _renderDimensions() {
    const $element = this.$element();
    const element = $element.get(0);
    const width = this._getOptionValue("width", element);
    const height = this._getOptionValue("height", element);
    if (this._isCssUpdateRequired(element, height, width)) {
      $element.css({
        width: null === width ? "" : width,
        height: null === height ? "" : height
      });
    }
  },
  _isCssUpdateRequired: (element, height, width) => !!(isDefined(width) || isDefined(height) || element.style.width || element.style.height),
  _attachDimensionChangeHandlers() {
    const $el = this.$element();
    const namespace = `${this.NAME}VisibilityChange`;
    resize.off($el, {
      namespace
    });
    resize.on($el, () => this._dimensionChanged(), {
      namespace
    });
  },
  _attachVisibilityChangeHandlers() {
    if (this._isVisibilityChangeSupported()) {
      const $el = this.$element();
      const namespace = `${this.NAME}VisibilityChange`;
      this._isHidden = !this._isVisible();
      visibility.off($el, {
        namespace
      });
      visibility.on($el, () => this._checkVisibilityChanged("shown"), () => this._checkVisibilityChanged("hiding"), {
        namespace
      });
    }
  },
  _isVisible() {
    const $element = this.$element();
    return $element.is(":visible");
  },
  _checkVisibilityChanged(action) {
    const isVisible = this._isVisible();
    if (isVisible) {
      if ("hiding" === action && !this._isHidden) {
        this._visibilityChanged(false);
        this._isHidden = true;
      } else if ("shown" === action && this._isHidden) {
        this._isHidden = false;
        this._visibilityChanged(true);
      }
    }
  },
  _isVisibilityChangeSupported() {
    return this._visibilityChanged !== abstract && hasWindow();
  },
  _clean: noop,
  _modelByElement() {
    const {
      modelByElement
    } = this.option();
    const $element = this.$element();
    return modelByElement ? modelByElement($element) : void 0;
  },
  _invalidate() {
    if (this._isUpdateAllowed()) {
      throw errors_default.Error("E0007");
    }
    this._requireRefresh = true;
  },
  _refresh() {
    this._clean();
    this._renderComponent();
  },
  _dispose() {
    this._templateManager && this._templateManager.dispose();
    this.callBase();
    this._clean();
    this._detachWindowResizeCallback();
  },
  _detachWindowResizeCallback() {
    if (this._isDimensionChangeSupported()) {
      resize_callbacks_default.remove(this._windowResizeCallBack);
    }
  },
  _toggleRTLDirection(rtl) {
    const $element = this.$element();
    $element.toggleClass("dx-rtl", rtl);
  },
  _createComponent(element, component) {
    let config = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    const synchronizableOptions = grep(this._getSynchronizableOptionsForCreateComponent(), (value2) => !(value2 in config));
    const {
      integrationOptions
    } = this.option();
    let {
      nestedComponentOptions
    } = this.option();
    nestedComponentOptions = nestedComponentOptions || noop;
    const nestedComponentConfig = extend({
      integrationOptions
    }, nestedComponentOptions(this));
    synchronizableOptions.forEach((optionName) => nestedComponentConfig[optionName] = this.option(optionName));
    this._extendConfig(config, nestedComponentConfig);
    let instance;
    if (isString(component)) {
      const $element = renderer_default(element)[component](config);
      instance = $element[component]("instance");
    } else if (element) {
      instance = component.getInstance(element);
      if (instance) {
        instance.option(config);
      } else {
        instance = new component(element, config);
      }
    }
    if (instance) {
      const optionChangedHandler = (_ref) => {
        let {
          name,
          value: value2
        } = _ref;
        if (synchronizableOptions.includes(name)) {
          instance.option(name, value2);
        }
      };
      this.on("optionChanged", optionChangedHandler);
      instance.on("disposing", () => this.off("optionChanged", optionChangedHandler));
    }
    return instance;
  },
  _extendConfig(config, extendConfig) {
    each(extendConfig, (key, value2) => {
      !Object.prototype.hasOwnProperty.call(config, key) && (config[key] = value2);
    });
  },
  _defaultActionConfig() {
    const $element = this.$element();
    const context2 = this._modelByElement($element);
    return extend(this.callBase(), {
      context: context2
    });
  },
  _defaultActionArgs() {
    const $element = this.$element();
    const model = this._modelByElement($element);
    const element = this.element();
    return extend(this.callBase(), {
      element,
      model
    });
  },
  _optionChanged(args) {
    switch (args.name) {
      case "width":
      case "height":
        this._renderDimensions();
        break;
      case "rtlEnabled":
        this._invalidate();
        break;
      case "elementAttr":
        this._renderElementAttributes();
        break;
      case "disabled":
      case "integrationOptions":
        break;
      default:
        this.callBase(args);
    }
  },
  _removeAttributes(element) {
    const attrs = element.attributes;
    for (let i = attrs.length - 1; i >= 0; i--) {
      const attr = attrs[i];
      if (attr) {
        const {
          name
        } = attr;
        if (!name.indexOf("aria-") || -1 !== name.indexOf("dx-") || "role" === name || "style" === name || "tabindex" === name) {
          element.removeAttribute(name);
        }
      }
    }
  },
  _removeClasses(element) {
    element.className = element.className.split(" ").filter((cssClass) => 0 !== cssClass.lastIndexOf("dx-", 0)).join(" ");
  },
  _updateDOMComponent(renderRequired) {
    if (renderRequired) {
      this._renderComponent();
    } else if (this._requireRefresh) {
      this._requireRefresh = false;
      this._refresh();
    }
  },
  endUpdate() {
    const renderRequired = this._isInitializingRequired();
    this.callBase();
    this._isUpdateAllowed() && this._updateDOMComponent(renderRequired);
  },
  $element() {
    return this._$element;
  },
  element() {
    const $element = this.$element();
    return getPublicElement($element);
  },
  dispose() {
    const element = this.$element().get(0);
    cleanDataRecursive(element, true);
    element.textContent = "";
    this._removeAttributes(element);
    this._removeClasses(element);
  },
  resetOption(optionName) {
    this.callBase(optionName);
    if ("width" === optionName || "height" === optionName) {
      const initialOption = this.initialOption(optionName);
      !isDefined(initialOption) && this.$element().css(optionName, "");
    }
  },
  _getAnonymousTemplateName() {
    return;
  },
  _initTemplateManager() {
    if (this._templateManager || !this._useTemplates()) {
      return;
    }
    const {
      integrationOptions = {}
    } = this.option();
    const {
      createTemplate
    } = integrationOptions;
    this._templateManager = new TemplateManager(createTemplate, this._getAnonymousTemplateName());
    this._initTemplates();
  },
  _initTemplates() {
    const {
      templates,
      anonymousTemplateMeta
    } = this._templateManager.extractTemplates(this.$element());
    const anonymousTemplate = this.option(`integrationOptions.templates.${anonymousTemplateMeta.name}`);
    templates.forEach((_ref2) => {
      let {
        name,
        template
      } = _ref2;
      this._options.silent(`integrationOptions.templates.${name}`, template);
    });
    if (anonymousTemplateMeta.name && !anonymousTemplate) {
      this._options.silent(`integrationOptions.templates.${anonymousTemplateMeta.name}`, anonymousTemplateMeta.template);
      this._options.silent("_hasAnonymousTemplateContent", true);
    }
  },
  _getTemplateByOption(optionName) {
    return this._getTemplate(this.option(optionName));
  },
  _getTemplate(templateSource) {
    const templates = this.option("integrationOptions.templates");
    const isAsyncTemplate = this.option("templatesRenderAsynchronously");
    const skipTemplates = this.option("integrationOptions.skipTemplates");
    return this._templateManager.getTemplate(templateSource, templates, {
      isAsyncTemplate,
      skipTemplates
    }, this);
  },
  _saveTemplate(name, template) {
    this._setOptionWithoutOptionChange("integrationOptions.templates." + name, this._templateManager._createTemplate(template));
  },
  _useTemplates: () => true
});
DOMComponent.getInstance = function(element) {
  return getInstanceByElement(renderer_default(element), this);
};
DOMComponent.defaultOptions = function(rule) {
  this._classCustomRules = this._classCustomRules || [];
  this._classCustomRules.push(rule);
};
var dom_component_default = DOMComponent;

// node_modules/devextreme/esm/events/core/emitter.feedback.js
init_class();
init_common();
var ACTIVE_EVENT_NAME = "dxactive";
var FeedbackEvent = class_default.inherit({
  ctor: function(timeout, fire) {
    this._timeout = timeout;
    this._fire = fire;
  },
  start: function() {
    const that = this;
    this._schedule(function() {
      that.force();
    });
  },
  _schedule: function(fn) {
    this.stop();
    this._timer = setTimeout(fn, this._timeout);
  },
  stop: function() {
    clearTimeout(this._timer);
  },
  force: function() {
    if (this._fired) {
      return;
    }
    this.stop();
    this._fire();
    this._fired = true;
  },
  fired: function() {
    return this._fired;
  }
});
var activeFeedback;
var FeedbackEmitter = emitter_default.inherit({
  ctor: function() {
    this.callBase.apply(this, arguments);
    this._active = new FeedbackEvent(0, noop);
    this._inactive = new FeedbackEvent(0, noop);
  },
  configure: function(data2, eventName) {
    switch (eventName) {
      case "dxactive":
        data2.activeTimeout = data2.timeout;
        break;
      case "dxinactive":
        data2.inactiveTimeout = data2.timeout;
    }
    this.callBase(data2);
  },
  start: function(e) {
    if (activeFeedback) {
      const activeChildExists = contains(this.getElement().get(0), activeFeedback.getElement().get(0));
      const childJustActivated = !activeFeedback._active.fired();
      if (activeChildExists && childJustActivated) {
        this._cancel();
        return;
      }
      activeFeedback._inactive.force();
    }
    activeFeedback = this;
    this._initEvents(e);
    this._active.start();
  },
  _initEvents: function(e) {
    const that = this;
    const eventTarget = this._getEmitterTarget(e);
    const mouseEvent = isMouseEvent(e);
    const isSimulator = devices_default.isSimulator();
    const deferFeedback = isSimulator || !mouseEvent;
    const activeTimeout = ensureDefined(this.activeTimeout, 30);
    const inactiveTimeout = ensureDefined(this.inactiveTimeout, 400);
    this._active = new FeedbackEvent(deferFeedback ? activeTimeout : 0, function() {
      that._fireEvent("dxactive", e, {
        target: eventTarget
      });
    });
    this._inactive = new FeedbackEvent(deferFeedback ? inactiveTimeout : 0, function() {
      that._fireEvent("dxinactive", e, {
        target: eventTarget
      });
      activeFeedback = null;
    });
  },
  cancel: function(e) {
    this.end(e);
  },
  end: function(e) {
    const skipTimers = e.type !== pointer_default.up;
    if (skipTimers) {
      this._active.stop();
    } else {
      this._active.force();
    }
    this._inactive.start();
    if (skipTimers) {
      this._inactive.force();
    }
  },
  dispose: function() {
    this._active.stop();
    this._inactive.stop();
    if (activeFeedback === this) {
      activeFeedback = null;
    }
    this.callBase();
  },
  lockInactive: function() {
    this._active.force();
    this._inactive.stop();
    activeFeedback = null;
    this._cancel();
    return this._inactive.force.bind(this._inactive);
  }
});
FeedbackEmitter.lock = function(deferred) {
  const lockInactive = activeFeedback ? activeFeedback.lockInactive() : noop;
  deferred.done(lockInactive);
};
emitter_registrator_default({
  emitter: FeedbackEmitter,
  events: ["dxactive", "dxinactive"]
});
var lock = FeedbackEmitter.lock;

// node_modules/devextreme/esm/events/hover.js
init_events_engine();
init_element_data();
init_class();
var HOVERSTART = "dxhoverstart";
var POINTERENTER_NAMESPACED_EVENT_NAME = addNamespace2(pointer_default.enter, "dxHoverStart");
var HOVEREND = "dxhoverend";
var POINTERLEAVE_NAMESPACED_EVENT_NAME = addNamespace2(pointer_default.leave, "dxHoverEnd");
var Hover = class_default.inherit({
  noBubble: true,
  ctor: function() {
    this._handlerArrayKeyPath = this._eventNamespace + "_HandlerStore";
  },
  setup: function(element) {
    data(element, this._handlerArrayKeyPath, {});
  },
  add: function(element, handleObj) {
    const that = this;
    const handler = function(e) {
      that._handler(e);
    };
    events_engine_default.on(element, this._originalEventName, handleObj.selector, handler);
    data(element, this._handlerArrayKeyPath)[handleObj.guid] = handler;
  },
  _handler: function(e) {
    if (isTouchEvent(e) || devices_default.isSimulator()) {
      return;
    }
    fireEvent({
      type: this._eventName,
      originalEvent: e,
      delegateTarget: e.delegateTarget
    });
  },
  remove: function(element, handleObj) {
    const handler = data(element, this._handlerArrayKeyPath)[handleObj.guid];
    events_engine_default.off(element, this._originalEventName, handleObj.selector, handler);
  },
  teardown: function(element) {
    removeData(element, this._handlerArrayKeyPath);
  }
});
var HoverStart = Hover.inherit({
  ctor: function() {
    this._eventNamespace = "dxHoverStart";
    this._eventName = HOVERSTART;
    this._originalEventName = POINTERENTER_NAMESPACED_EVENT_NAME;
    this.callBase();
  },
  _handler: function(e) {
    const pointers = e.pointers || [];
    if (!pointers.length) {
      this.callBase(e);
    }
  }
});
var HoverEnd = Hover.inherit({
  ctor: function() {
    this._eventNamespace = "dxHoverEnd";
    this._eventName = HOVEREND;
    this._originalEventName = POINTERLEAVE_NAMESPACED_EVENT_NAME;
    this.callBase();
  }
});
event_registrator_default(HOVERSTART, new HoverStart());
event_registrator_default(HOVEREND, new HoverEnd());

// node_modules/devextreme/esm/ui/widget/ui.widget.js
init_renderer();
init_common();
init_iterator();
init_extend();
init_type();

// node_modules/devextreme/esm/core/utils/version.js
function compare(x, y, maxLevel) {
  function normalizeArg(value2) {
    if ("string" === typeof value2) {
      return value2.split(".");
    }
    if ("number" === typeof value2) {
      return [value2];
    }
    return value2;
  }
  x = normalizeArg(x);
  y = normalizeArg(y);
  let length = Math.max(x.length, y.length);
  if (isFinite(maxLevel)) {
    length = Math.min(length, maxLevel);
  }
  for (let i = 0; i < length; i++) {
    const xItem = parseInt(x[i] || 0, 10);
    const yItem = parseInt(y[i] || 0, 10);
    if (xItem < yItem) {
      return -1;
    }
    if (xItem > yItem) {
      return 1;
    }
  }
  return 0;
}

// node_modules/devextreme/esm/ui/widget/ui.widget.js
function setAttribute(name, value2, target) {
  name = "role" === name || "id" === name ? name : `aria-${name}`;
  value2 = isDefined(value2) ? value2.toString() : null;
  target.attr(name, value2);
}
var Widget = dom_component_default.inherit({
  _feedbackHideTimeout: 400,
  _feedbackShowTimeout: 30,
  _supportedKeys: () => ({}),
  _getDefaultOptions() {
    return extend(this.callBase(), {
      hoveredElement: null,
      isActive: false,
      disabled: false,
      visible: true,
      hint: void 0,
      activeStateEnabled: false,
      onContentReady: null,
      hoverStateEnabled: false,
      focusStateEnabled: false,
      tabIndex: 0,
      accessKey: void 0,
      onFocusIn: null,
      onFocusOut: null,
      onKeyboardHandled: null,
      ignoreParentReadOnly: false,
      useResizeObserver: true
    });
  },
  _defaultOptionsRules: function() {
    return this.callBase().concat([{
      device: function() {
        const device = devices_default.real();
        const platform = device.platform;
        const version = device.version;
        return "ios" === platform && compare(version, "13.3") <= 0;
      },
      options: {
        useResizeObserver: false
      }
    }]);
  },
  _init() {
    this.callBase();
    this._initContentReadyAction();
  },
  _innerWidgetOptionChanged: function(innerWidget, args) {
    const options = Widget.getOptionsFromContainer(args);
    innerWidget && innerWidget.option(options);
    this._options.cache(args.name, options);
  },
  _bindInnerWidgetOptions(innerWidget, optionsContainer) {
    const syncOptions = () => this._options.silent(optionsContainer, extend({}, innerWidget.option()));
    syncOptions();
    innerWidget.on("optionChanged", syncOptions);
  },
  _getAriaTarget() {
    return this._focusTarget();
  },
  _initContentReadyAction() {
    this._contentReadyAction = this._createActionByOption("onContentReady", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _initMarkup() {
    const {
      disabled,
      visible: visible2
    } = this.option();
    this.$element().addClass("dx-widget");
    this._toggleDisabledState(disabled);
    this._toggleVisibility(visible2);
    this._renderHint();
    this._isFocusable() && this._renderFocusTarget();
    this.callBase();
  },
  _render() {
    this.callBase();
    this._renderContent();
    this._renderFocusState();
    this._attachFeedbackEvents();
    this._attachHoverEvents();
    this._toggleIndependentState();
  },
  _renderHint() {
    const {
      hint
    } = this.option();
    this.$element().attr("title", hint || null);
  },
  _renderContent() {
    deferRender(() => !this._disposed ? this._renderContentImpl() : void 0).done(() => !this._disposed ? this._fireContentReadyAction() : void 0);
  },
  _renderContentImpl: noop,
  _fireContentReadyAction: deferRenderer(function() {
    return this._contentReadyAction();
  }),
  _dispose() {
    this._contentReadyAction = null;
    this._detachKeyboardEvents();
    this.callBase();
  },
  _resetActiveState() {
    this._toggleActiveState(this._eventBindingTarget(), false);
  },
  _clean() {
    this._cleanFocusState();
    this._resetActiveState();
    this.callBase();
    this.$element().empty();
  },
  _toggleVisibility(visible2) {
    this.$element().toggleClass("dx-state-invisible", !visible2);
  },
  _renderFocusState() {
    this._attachKeyboardEvents();
    if (this._isFocusable()) {
      this._renderFocusTarget();
      this._attachFocusEvents();
      this._renderAccessKey();
    }
  },
  _renderAccessKey() {
    const $el = this._focusTarget();
    const {
      accessKey
    } = this.option();
    $el.attr("accesskey", accessKey);
  },
  _isFocusable() {
    const {
      focusStateEnabled,
      disabled
    } = this.option();
    return focusStateEnabled && !disabled;
  },
  _eventBindingTarget() {
    return this.$element();
  },
  _focusTarget() {
    return this._getActiveElement();
  },
  _isFocusTarget: function(element) {
    const focusTargets = renderer_default(this._focusTarget()).toArray();
    return focusTargets.includes(element);
  },
  _findActiveTarget($element) {
    return $element.find(this._activeStateUnit).not(".dx-state-disabled");
  },
  _getActiveElement() {
    const activeElement = this._eventBindingTarget();
    if (this._activeStateUnit) {
      return this._findActiveTarget(activeElement);
    }
    return activeElement;
  },
  _renderFocusTarget() {
    const {
      tabIndex
    } = this.option();
    this._focusTarget().attr("tabIndex", tabIndex);
  },
  _keyboardEventBindingTarget() {
    return this._eventBindingTarget();
  },
  _refreshFocusEvent() {
    this._detachFocusEvents();
    this._attachFocusEvents();
  },
  _focusEventTarget() {
    return this._focusTarget();
  },
  _focusInHandler(event) {
    if (!event.isDefaultPrevented()) {
      this._createActionByOption("onFocusIn", {
        beforeExecute: () => this._updateFocusState(event, true),
        excludeValidators: ["readOnly"]
      })({
        event
      });
    }
  },
  _focusOutHandler(event) {
    if (!event.isDefaultPrevented()) {
      this._createActionByOption("onFocusOut", {
        beforeExecute: () => this._updateFocusState(event, false),
        excludeValidators: ["readOnly", "disabled"]
      })({
        event
      });
    }
  },
  _updateFocusState(_ref, isFocused) {
    let {
      target
    } = _ref;
    if (this._isFocusTarget(target)) {
      this._toggleFocusClass(isFocused, renderer_default(target));
    }
  },
  _toggleFocusClass(isFocused, $element) {
    const $focusTarget = $element && $element.length ? $element : this._focusTarget();
    $focusTarget.toggleClass("dx-state-focused", isFocused);
  },
  _hasFocusClass(element) {
    const $focusTarget = renderer_default(element || this._focusTarget());
    return $focusTarget.hasClass("dx-state-focused");
  },
  _isFocused() {
    return this._hasFocusClass();
  },
  _getKeyboardListeners: () => [],
  _attachKeyboardEvents() {
    this._detachKeyboardEvents();
    const {
      focusStateEnabled,
      onKeyboardHandled
    } = this.option();
    const hasChildListeners = this._getKeyboardListeners().length;
    const hasKeyboardEventHandler = !!onKeyboardHandled;
    const shouldAttach = focusStateEnabled || hasChildListeners || hasKeyboardEventHandler;
    if (shouldAttach) {
      this._keyboardListenerId = keyboard.on(this._keyboardEventBindingTarget(), this._focusTarget(), (opts) => this._keyboardHandler(opts));
    }
  },
  _keyboardHandler(options, onlyChildProcessing) {
    if (!onlyChildProcessing) {
      const {
        originalEvent,
        keyName,
        which
      } = options;
      const keys = this._supportedKeys(originalEvent);
      const func = keys[keyName] || keys[which];
      if (void 0 !== func) {
        const handler = func.bind(this);
        const result = handler(originalEvent, options);
        if (!result) {
          return false;
        }
      }
    }
    const keyboardListeners = this._getKeyboardListeners();
    const {
      onKeyboardHandled
    } = this.option();
    keyboardListeners.forEach((listener) => listener && listener._keyboardHandler(options));
    onKeyboardHandled && onKeyboardHandled(options);
    return true;
  },
  _refreshFocusState() {
    this._cleanFocusState();
    this._renderFocusState();
  },
  _cleanFocusState() {
    const $element = this._focusTarget();
    $element.removeAttr("tabIndex");
    this._toggleFocusClass(false);
    this._detachFocusEvents();
    this._detachKeyboardEvents();
  },
  _detachKeyboardEvents() {
    keyboard.off(this._keyboardListenerId);
    this._keyboardListenerId = null;
  },
  _attachHoverEvents() {
    const {
      hoverStateEnabled
    } = this.option();
    const selector = this._activeStateUnit;
    const $el = this._eventBindingTarget();
    hover.off($el, {
      selector,
      namespace: "UIFeedback"
    });
    if (hoverStateEnabled) {
      hover.on($el, new Action((_ref2) => {
        let {
          event,
          element
        } = _ref2;
        this._hoverStartHandler(event);
        this.option("hoveredElement", renderer_default(element));
      }, {
        excludeValidators: ["readOnly"]
      }), (event) => {
        this.option("hoveredElement", null);
        this._hoverEndHandler(event);
      }, {
        selector,
        namespace: "UIFeedback"
      });
    }
  },
  _attachFeedbackEvents() {
    const {
      activeStateEnabled
    } = this.option();
    const selector = this._activeStateUnit;
    const $el = this._eventBindingTarget();
    active.off($el, {
      namespace: "UIFeedback",
      selector
    });
    if (activeStateEnabled) {
      active.on($el, new Action((_ref3) => {
        let {
          event,
          element
        } = _ref3;
        return this._toggleActiveState(renderer_default(element), true, event);
      }), new Action((_ref4) => {
        let {
          event,
          element
        } = _ref4;
        return this._toggleActiveState(renderer_default(element), false, event);
      }, {
        excludeValidators: ["disabled", "readOnly"]
      }), {
        showTimeout: this._feedbackShowTimeout,
        hideTimeout: this._feedbackHideTimeout,
        selector,
        namespace: "UIFeedback"
      });
    }
  },
  _detachFocusEvents() {
    const $el = this._focusEventTarget();
    focus.off($el, {
      namespace: `${this.NAME}Focus`
    });
  },
  _attachFocusEvents() {
    const $el = this._focusEventTarget();
    focus.on($el, (e) => this._focusInHandler(e), (e) => this._focusOutHandler(e), {
      namespace: `${this.NAME}Focus`,
      isFocusable: (index2, el) => renderer_default(el).is(focusable)
    });
  },
  _hoverStartHandler: noop,
  _hoverEndHandler: noop,
  _toggleActiveState($element, value2) {
    this.option("isActive", value2);
    $element.toggleClass("dx-state-active", value2);
  },
  _updatedHover() {
    const hoveredElement = this._options.silent("hoveredElement");
    this._hover(hoveredElement, hoveredElement);
  },
  _findHoverTarget($el) {
    return $el && $el.closest(this._activeStateUnit || this._eventBindingTarget());
  },
  _hover($el, $previous) {
    const {
      hoverStateEnabled,
      disabled,
      isActive
    } = this.option();
    $previous = this._findHoverTarget($previous);
    $previous && $previous.toggleClass("dx-state-hover", false);
    if ($el && hoverStateEnabled && !disabled && !isActive) {
      const newHoveredElement = this._findHoverTarget($el);
      newHoveredElement && newHoveredElement.toggleClass("dx-state-hover", true);
    }
  },
  _toggleDisabledState(value2) {
    this.$element().toggleClass("dx-state-disabled", Boolean(value2));
    this.setAria("disabled", value2 || void 0);
  },
  _toggleIndependentState() {
    this.$element().toggleClass("dx-state-independent", this.option("ignoreParentReadOnly"));
  },
  _setWidgetOption(widgetName, args) {
    if (!this[widgetName]) {
      return;
    }
    if (isPlainObject(args[0])) {
      each(args[0], (option, value3) => this._setWidgetOption(widgetName, [option, value3]));
      return;
    }
    const optionName = args[0];
    let value2 = args[1];
    if (1 === args.length) {
      value2 = this.option(optionName);
    }
    const widgetOptionMap = this[`${widgetName}OptionMap`];
    this[widgetName].option(widgetOptionMap ? widgetOptionMap(optionName) : optionName, value2);
  },
  _optionChanged(args) {
    const {
      name,
      value: value2,
      previousValue
    } = args;
    switch (name) {
      case "disabled":
        this._toggleDisabledState(value2);
        this._updatedHover();
        this._refreshFocusState();
        break;
      case "hint":
        this._renderHint();
        break;
      case "ignoreParentReadOnly":
        this._toggleIndependentState();
        break;
      case "activeStateEnabled":
        this._attachFeedbackEvents();
        break;
      case "hoverStateEnabled":
        this._attachHoverEvents();
        this._updatedHover();
        break;
      case "tabIndex":
      case "focusStateEnabled":
        this._refreshFocusState();
        break;
      case "onFocusIn":
      case "onFocusOut":
      case "useResizeObserver":
        break;
      case "accessKey":
        this._renderAccessKey();
        break;
      case "hoveredElement":
        this._hover(value2, previousValue);
        break;
      case "isActive":
        this._updatedHover();
        break;
      case "visible":
        this._toggleVisibility(value2);
        if (this._isVisibilityChangeSupported()) {
          this._checkVisibilityChanged(value2 ? "shown" : "hiding");
        }
        break;
      case "onKeyboardHandled":
        this._attachKeyboardEvents();
        break;
      case "onContentReady":
        this._initContentReadyAction();
        break;
      default:
        this.callBase(args);
    }
  },
  _isVisible() {
    const {
      visible: visible2
    } = this.option();
    return this.callBase() && visible2;
  },
  beginUpdate() {
    this._ready(false);
    this.callBase();
  },
  endUpdate() {
    this.callBase();
    if (this._initialized) {
      this._ready(true);
    }
  },
  _ready(value2) {
    if (0 === arguments.length) {
      return this._isReady;
    }
    this._isReady = value2;
  },
  setAria() {
    if (!isPlainObject(arguments.length <= 0 ? void 0 : arguments[0])) {
      setAttribute(arguments.length <= 0 ? void 0 : arguments[0], arguments.length <= 1 ? void 0 : arguments[1], (arguments.length <= 2 ? void 0 : arguments[2]) || this._getAriaTarget());
    } else {
      const target = (arguments.length <= 1 ? void 0 : arguments[1]) || this._getAriaTarget();
      each(arguments.length <= 0 ? void 0 : arguments[0], (name, value2) => setAttribute(name, value2, target));
    }
  },
  isReady() {
    return this._ready();
  },
  repaint() {
    this._refresh();
  },
  focus() {
    focus.trigger(this._focusTarget());
  },
  registerKeyHandler(key, handler) {
    const currentKeys = this._supportedKeys();
    this._supportedKeys = () => extend(currentKeys, {
      [key]: handler
    });
  }
});
Widget.getOptionsFromContainer = (_ref5) => {
  let {
    name,
    fullName,
    value: value2
  } = _ref5;
  let options = {};
  if (name === fullName) {
    options = value2;
  } else {
    const option = fullName.split(".").pop();
    options[option] = value2;
  }
  return options;
};
var ui_widget_default = Widget;

// node_modules/devextreme/esm/core/utils/math.js
init_type();
var sign = function(value2) {
  if (0 === value2) {
    return 0;
  }
  return value2 / Math.abs(value2);
};
var fitIntoRange = function(value2, minValue, maxValue) {
  const isMinValueUndefined = !minValue && 0 !== minValue;
  const isMaxValueUndefined = !maxValue && 0 !== maxValue;
  isMinValueUndefined && (minValue = !isMaxValueUndefined ? Math.min(value2, maxValue) : value2);
  isMaxValueUndefined && (maxValue = !isMinValueUndefined ? Math.max(value2, minValue) : value2);
  return Math.min(Math.max(value2, minValue), maxValue);
};
var inRange = function(value2, minValue, maxValue) {
  return value2 >= minValue && value2 <= maxValue;
};
function getExponent(value2) {
  return Math.abs(parseInt(value2.toExponential().split("e")[1]));
}
function getExponentialNotation(value2) {
  const parts = value2.toExponential().split("e");
  const mantissa = parseFloat(parts[0]);
  const exponent = parseInt(parts[1]);
  return {
    exponent,
    mantissa
  };
}
function multiplyInExponentialForm(value2, exponentShift) {
  const exponentialNotation = getExponentialNotation(value2);
  return parseFloat(`${exponentialNotation.mantissa}e${exponentialNotation.exponent + exponentShift}`);
}
function _isEdgeBug() {
  return "0.000300" !== 3e-4.toPrecision(3);
}
function adjust(value2, interval) {
  let precision = getPrecision(interval || 0) + 2;
  const separatedValue = value2.toString().split(".");
  const sourceValue = value2;
  const absValue = Math.abs(value2);
  let separatedAdjustedValue;
  const isExponentValue = isExponential(value2);
  const integerPart = absValue > 1 ? 10 : 0;
  if (1 === separatedValue.length) {
    return value2;
  }
  if (!isExponentValue) {
    if (isExponential(interval)) {
      precision = separatedValue[0].length + getExponent(interval);
    }
    value2 = absValue;
    value2 = value2 - Math.floor(value2) + integerPart;
  }
  precision = _isEdgeBug() && getExponent(value2) > 6 || precision > 7 ? 15 : 7;
  if (!isExponentValue) {
    separatedAdjustedValue = parseFloat(value2.toPrecision(precision)).toString().split(".");
    if (separatedAdjustedValue[0] === integerPart.toString()) {
      return parseFloat(separatedValue[0] + "." + separatedAdjustedValue[1]);
    }
  }
  return parseFloat(sourceValue.toPrecision(precision));
}
function getPrecision(value2) {
  const str = value2.toString();
  if (str.indexOf(".") < 0) {
    return 0;
  }
  const mantissa = str.split(".");
  const positionOfDelimiter = mantissa[1].indexOf("e");
  return positionOfDelimiter >= 0 ? positionOfDelimiter : mantissa[1].length;
}
function getRoot(x, n) {
  if (x < 0 && n % 2 !== 1) {
    return NaN;
  }
  const y = Math.pow(Math.abs(x), 1 / n);
  return n % 2 === 1 && x < 0 ? -y : y;
}
function solveCubicEquation(a, b, c, d) {
  if (Math.abs(a) < 1e-8) {
    a = b;
    b = c;
    c = d;
    if (Math.abs(a) < 1e-8) {
      a = b;
      b = c;
      if (Math.abs(a) < 1e-8) {
        return [];
      }
      return [-b / a];
    }
    const D2 = b * b - 4 * a * c;
    if (Math.abs(D2) < 1e-8) {
      return [-b / (2 * a)];
    } else if (D2 > 0) {
      return [(-b + Math.sqrt(D2)) / (2 * a), (-b - Math.sqrt(D2)) / (2 * a)];
    }
    return [];
  }
  const p = (3 * a * c - b * b) / (3 * a * a);
  const q = (2 * b * b * b - 9 * a * b * c + 27 * a * a * d) / (27 * a * a * a);
  let roots;
  let u;
  if (Math.abs(p) < 1e-8) {
    roots = [getRoot(-q, 3)];
  } else if (Math.abs(q) < 1e-8) {
    roots = [0].concat(p < 0 ? [Math.sqrt(-p), -Math.sqrt(-p)] : []);
  } else {
    const D3 = q * q / 4 + p * p * p / 27;
    if (Math.abs(D3) < 1e-8) {
      roots = [-1.5 * q / p, 3 * q / p];
    } else if (D3 > 0) {
      u = getRoot(-q / 2 - Math.sqrt(D3), 3);
      roots = [u - p / (3 * u)];
    } else {
      u = 2 * Math.sqrt(-p / 3);
      const t = Math.acos(3 * q / p / u) / 3;
      const k = 2 * Math.PI / 3;
      roots = [u * Math.cos(t), u * Math.cos(t - k), u * Math.cos(t - 2 * k)];
    }
  }
  for (let i = 0; i < roots.length; i++) {
    roots[i] -= b / (3 * a);
  }
  return roots;
}
function trunc(value2) {
  return Math.trunc ? Math.trunc(value2) : value2 > 0 ? Math.floor(value2) : Math.ceil(value2);
}
function getRemainderByDivision(dividend, divider, digitsCount) {
  if (divider === parseInt(divider)) {
    return dividend % divider;
  }
  const quotient = roundFloatPart(dividend / divider, digitsCount);
  return (quotient - parseInt(quotient)) * divider;
}
function getExponentLength(value2) {
  var _valueString$split$;
  const valueString = value2.toString();
  return (null === (_valueString$split$ = valueString.split(".")[1]) || void 0 === _valueString$split$ ? void 0 : _valueString$split$.length) || parseInt(valueString.split("e-")[1]) || 0;
}
function roundFloatPart(value2) {
  let digitsCount = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  return parseFloat(value2.toFixed(digitsCount));
}

// node_modules/devextreme/esm/events/gesture/emitter.gesture.js
init_renderer();
init_events_engine();
init_style();
init_call_once();
init_ready_callbacks();
init_common();
init_type();
var ready3 = ready_callbacks_default.add;
var abs = Math.abs;
var TOUCH_BOUNDARY = 10;
var supportPointerEvents = function() {
  return styleProp("pointer-events");
};
var setGestureCover = call_once_default(function() {
  const isDesktop = "desktop" === devices_default.real().deviceType;
  if (!supportPointerEvents() || !isDesktop) {
    return noop;
  }
  const $cover = renderer_default("<div>").addClass("dx-gesture-cover").css("pointerEvents", "none");
  events_engine_default.subscribeGlobal($cover, "dxmousewheel", function(e) {
    e.preventDefault();
  });
  ready3(function() {
    $cover.appendTo("body");
  });
  return function(toggle, cursor) {
    $cover.css("pointerEvents", toggle ? "all" : "none");
    toggle && $cover.css("cursor", cursor);
  };
});
var gestureCover = function(toggle, cursor) {
  const gestureCoverStrategy = setGestureCover();
  gestureCoverStrategy(toggle, cursor);
};
var GestureEmitter = emitter_default.inherit({
  gesture: true,
  configure: function(data2) {
    this.getElement().css("msTouchAction", data2.immediate ? "pinch-zoom" : "");
    this.callBase(data2);
  },
  allowInterruptionByMouseWheel: function() {
    return 2 !== this._stage;
  },
  getDirection: function() {
    return this.direction;
  },
  _cancel: function() {
    this.callBase.apply(this, arguments);
    this._toggleGestureCover(false);
    this._stage = 0;
  },
  start: function(e) {
    if (e._needSkipEvent || needSkipEvent(e)) {
      this._cancel(e);
      return;
    }
    this._startEvent = createEvent(e);
    this._startEventData = eventData(e);
    this._stage = 1;
    this._init(e);
    this._setupImmediateTimer();
  },
  _setupImmediateTimer: function() {
    clearTimeout(this._immediateTimer);
    this._immediateAccepted = false;
    if (!this.immediate) {
      return;
    }
    if (0 === this.immediateTimeout) {
      this._immediateAccepted = true;
      return;
    }
    this._immediateTimer = setTimeout(function() {
      this._immediateAccepted = true;
    }.bind(this), this.immediateTimeout ?? 180);
  },
  move: function(e) {
    if (1 === this._stage && this._directionConfirmed(e)) {
      this._stage = 2;
      this._resetActiveElement();
      this._toggleGestureCover(true);
      this._clearSelection(e);
      this._adjustStartEvent(e);
      this._start(this._startEvent);
      if (0 === this._stage) {
        return;
      }
      this._requestAccept(e);
      this._move(e);
      this._forgetAccept();
    } else if (2 === this._stage) {
      this._clearSelection(e);
      this._move(e);
    }
  },
  _directionConfirmed: function(e) {
    const touchBoundary = this._getTouchBoundary(e);
    const delta = eventDelta(this._startEventData, eventData(e));
    const deltaX = abs(delta.x);
    const deltaY = abs(delta.y);
    const horizontalMove = this._validateMove(touchBoundary, deltaX, deltaY);
    const verticalMove = this._validateMove(touchBoundary, deltaY, deltaX);
    const direction = this.getDirection(e);
    const bothAccepted = "both" === direction && (horizontalMove || verticalMove);
    const horizontalAccepted = "horizontal" === direction && horizontalMove;
    const verticalAccepted = "vertical" === direction && verticalMove;
    return bothAccepted || horizontalAccepted || verticalAccepted || this._immediateAccepted;
  },
  _validateMove: function(touchBoundary, mainAxis, crossAxis) {
    return mainAxis && mainAxis >= touchBoundary && (this.immediate ? mainAxis >= crossAxis : true);
  },
  _getTouchBoundary: function(e) {
    return this.immediate || isDxMouseWheelEvent(e) ? 0 : TOUCH_BOUNDARY;
  },
  _adjustStartEvent: function(e) {
    const touchBoundary = this._getTouchBoundary(e);
    const delta = eventDelta(this._startEventData, eventData(e));
    this._startEvent.pageX += sign(delta.x) * touchBoundary;
    this._startEvent.pageY += sign(delta.y) * touchBoundary;
  },
  _resetActiveElement: function() {
    if ("ios" === devices_default.real().platform && this.getElement().find(":focus").length) {
      resetActiveElement();
    }
  },
  _toggleGestureCover: function(toggle) {
    this._toggleGestureCoverImpl(toggle);
  },
  _toggleGestureCoverImpl: function(toggle) {
    const isStarted = 2 === this._stage;
    if (isStarted) {
      gestureCover(toggle, this.getElement().css("cursor"));
    }
  },
  _clearSelection: function(e) {
    if (isDxMouseWheelEvent(e) || isTouchEvent(e)) {
      return;
    }
    clearSelection();
  },
  end: function(e) {
    this._toggleGestureCover(false);
    if (2 === this._stage) {
      this._end(e);
    } else if (1 === this._stage) {
      this._stop(e);
    }
    this._stage = 0;
  },
  dispose: function() {
    clearTimeout(this._immediateTimer);
    this.callBase.apply(this, arguments);
    this._toggleGestureCover(false);
  },
  _init: noop,
  _start: noop,
  _move: noop,
  _stop: noop,
  _end: noop
});
GestureEmitter.initialTouchBoundary = TOUCH_BOUNDARY;
GestureEmitter.touchBoundary = function(newBoundary) {
  if (isDefined(newBoundary)) {
    TOUCH_BOUNDARY = newBoundary;
    return;
  }
  return TOUCH_BOUNDARY;
};
var emitter_gesture_default = GestureEmitter;

export {
  getPublicElement,
  locate,
  clearCache,
  getTranslateCss,
  getTranslate,
  move,
  resetPosition,
  parseTranslate,
  requestAnimationFrame,
  cancelAnimationFrame,
  resize_callbacks_default,
  getSessionStorage,
  changeCallback,
  value,
  originalViewPort,
  devices_default,
  inputType,
  touchEvents,
  pointerEvents,
  touch,
  transition,
  transitionEndEventName,
  animation,
  nativeScrolling,
  getDefaultAlignment,
  getBoundingRect,
  browser_default,
  event_registrator_default,
  removeEvent,
  focusable,
  tabbable,
  focused,
  isPointerEvent,
  isMouseEvent,
  isDxMouseWheelEvent,
  isTouchEvent,
  isFakeClickEvent,
  eventData,
  eventDelta,
  hasTouches,
  needSkipEvent,
  createEvent,
  fireEvent,
  normalizeKeyName,
  getChar,
  addNamespace2 as addNamespace,
  isCommandKeyPressed,
  getName,
  attachInstanceToElement,
  getInstanceByElement,
  component_registrator_default,
  resetActiveElement,
  closestCommonParent,
  clipboardText,
  contains,
  createTextElementHiddenCopy,
  replaceWith,
  isElementInDom,
  triggerShownEvent,
  triggerHidingEvent,
  triggerResizeEvent,
  TemplateBase,
  pointer_default,
  emitter_default,
  EVENT_NAME,
  emitter_registrator_default,
  CLICK_EVENT_NAME,
  _objectWithoutPropertiesLoose,
  ui_errors_default,
  wrapToArray,
  getUniqueValues,
  getIntersection,
  removeDuplicates,
  normalizeIndexes,
  Action,
  ChildDefaultTemplate,
  EmptyTemplate,
  findTemplates,
  equals,
  convertRulesToOptions,
  normalizeOptions,
  getFieldName,
  createDefaultOptionRules,
  Component,
  FunctionTemplate,
  keyboard_processor_default,
  resize,
  visibility,
  focus,
  dxClick,
  click,
  keyboard,
  dom_component_default,
  compare,
  ACTIVE_EVENT_NAME,
  lock,
  HOVERSTART,
  HOVEREND,
  ui_widget_default,
  current,
  isMaterialBased,
  isMaterial,
  isFluent,
  isGeneric,
  isCompact,
  waitWebFont,
  sign,
  fitIntoRange,
  inRange,
  getExponent,
  multiplyInExponentialForm,
  adjust,
  getPrecision,
  solveCubicEquation,
  trunc,
  getRemainderByDivision,
  getExponentLength,
  roundFloatPart,
  emitter_gesture_default
};
//# sourceMappingURL=chunk-O2ZOTGYJ.js.map
